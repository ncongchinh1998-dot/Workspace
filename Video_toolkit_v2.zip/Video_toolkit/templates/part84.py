"""PHẦN 8.4 — CÁC THIẾT LẬP CÒN LẠI & KIỂM TRA CÔNG THỨC LƯƠNG
Mục: Hiển thị là tổng thu nhập · Tổng nhóm dữ liệu lương · Hiển thị là thu nhập thực lãnh ·
     Trạng thái công thức & lưu ý khi chỉnh sửa · Cách kiểm tra kết quả công thức lương.  Hình: tư liệu phần 7–8."""
import sys, math
from hw_core import *
from part81 import (sub_card, full_of, shot_xy, FORM_FULL, XF, F, IMG_FORM, mini_chip, badge,
                    KQ_FULL, XK, KQ, TN_FULL, XT, TN, DS_FULL, XD, IMG_KQ, IMG_TN, IMG_DS)
from part7 import app_phone, APP_PC
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p84.wav"
OFFSET = 1.0
VOICE_DUR = 259.69
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan8_4_Thiet_lap_khac_va_kiem_tra.mp4"
HD = dict(ttn=-0.6, tn=20.2, tl=105.9, tt=166.2, kt=200.6)
SFX_AT = [0.0] + [OFFSET + v for v in list(HD.values())[1:]]

IMG_HTV = U + "Hiển_thị_với.png"; HTV_FULL = full_of(2864, 1532); XV = shot_xy(HTV_FULL)
IMG_PC = U + "Nhóm_công_thức_phụ_cấp.png"; PC_FULL = full_of(2812, 1524); XP = shot_xy(PC_FULL)
V = dict(TNDL=(1228, 548, 1585, 596), TTN=(1228, 603, 1580, 652), TL=(1825, 463, 2232, 512))
APP_PC_HEAD = (8, 432, 568, 516)

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
def htv(img): fs_shot(img, IMG_HTV, HTV_FULL, HTV_FULL, 0)
def form(img): fs_shot(img, IMG_FORM, FORM_FULL, FORM_FULL, 0)
def piece(t, pts):
    if t <= pts[0][0]: return pts[0][1]
    for (a_, ca), (b_, cb) in zip(pts, pts[1:]):
        if a_ <= t <= b_: return ca + (t - a_) * (cb - ca) / (b_ - a_)
    return pts[-1][1]

def fcard(d, x, y, w, lab, col, s, tick=None, size=24):
    """thẻ công thức nhỏ + ô tick 'Tổng nhóm dữ liệu lương'"""
    if s <= 0.01: return
    mini_chip(d, x, y, w, 58, lab, col, s, size)
    if tick is not None and s > 0.9:
        bx = x + w / 2 + 20
        d.rounded_rectangle([bx, y - 18, bx + 36, y + 18], 7, fill=WHITE, outline=GREEN if tick else LINE, width=3)
        if tick: d.line([bx + 8, y, bx + 15, y + 9, bx + 29, y - 9], fill=GREEN, width=5, joint="curve")

# ================= Hiển thị là tổng thu nhập =================
def sc_h_ttn(img, d, t): sub_card(img, d, t, HD["ttn"], "PHẦN 8", ["HIỂN THỊ LÀ", "TỔNG THU NHẬP"], 96)

def sc_ttn(img, d, t):
    htv(img)
    top_title(d, t, "Hiển thị là tổng thu nhập", 2.2)
    if t >= 2.8: hl(d, XV(*V["TTN"]), t)
    if t < 12.7: chip_bar(d, t, [(3.1, "Thường dùng khi triển khai áp tính thưởng: C&B được tư vấn & hướng dẫn theo tình huống thực tế", NAVY)], size=21)
    else: chip_bar(d, t, [(12.8, "Tính lương tự động: không cần thiết lập, không ảnh hưởng kết quả & các màn hình đang dùng", GREEN)], size=21)
    role_tag(img, d, CB, "C&B")

# ================= Tổng nhóm dữ liệu lương =================
def sc_h_tn(img, d, t): sub_card(img, d, t, HD["tn"], "PHẦN 8", ["TỔNG NHÓM DỮ LIỆU LƯƠNG"], 84)

def sc_app(img, d, t):
    paste(img, BOARD)
    top_title(d, t, "Hiển thị ngay tổng giá trị của một nhóm trên phiếu lương", 22.5)
    ct = piece(t, [(32.6, 10.5), (32.7, 12.8), (34.2, 14.3)])
    P = app_phone(img, d, 760, 78, 432, ct, 1.0, "p84")
    if 25.6 <= t < 32.6: hl(d, P(*APP_PC_HEAD), t)
    if 34.3 <= t < 37.6: hl(d, P(*APP_PC[:1] + (520,) + APP_PC[2:]), t)
    if t >= 37.7: hl(d, P(*APP_PC_HEAD), t)
    role_badge(img, d, EMP, "Nhân viên", 1420, 760, pop(t, 23.0, 0.5), 300)

def sc_cach1(img, d, t):
    if 49.6 <= t < 54.2:
        htv(img)
        top_title(d, t, "Cách 1: chọn Tổng nhóm dữ liệu lương tại công thức Tổng phụ cấp", 49.7)
        hl(d, XV(*V["TNDL"]), t)
        role_tag(img, d, CB, "C&B")
        return
    if t >= 54.2:
        fs_shot(img, IMG_PC, PC_FULL, PC_FULL, 0)
        top_title(d, t, "Kết quả Tổng phụ cấp = giá trị đại diện của nhóm PHỤ CẤP", 54.3)
        if 55.5 <= t < 58.0: hl(d, XP(283, 1232, 1000, 1292), t)
        if t >= 58.0: hl(d, XP(283, 990, 1000, 1055), t)
        return
    paste(img, BOARD)
    board_title(d, t, "Hai cách tạo giá trị tổng cho nhóm công thức", 44.3, size=54)
    s_ = pop(t, 46.2)
    if s_ > 0.01:
        card(d, 580, 560, 760, 600, s_, True, BLUE)
        if s_ > 0.9: text(d, (580, 300), "Cách 1: đã có công thức Tổng phụ cấp", 28, BLUE)
    for j, lab in enumerate(["Phụ cấp xăng", "Phụ cấp trách nhiệm", "Phụ cấp khác"]):
        fcard(d, 540, 390 + j * 80, 480, lab, (110, 122, 150), pop(t, 46.6 + j * 0.2, 0.4), tick=False)
    fcard(d, 540, 650, 480, "Tổng phụ cấp", GREEN, pop(t, 48.0, 0.4), tick=t >= 48.8)
    role_tag(img, d, CB, "C&B")

def sc_cach2(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Hai cách tạo giá trị tổng cho nhóm công thức", 61.1, size=54)
    card(d, 580, 560, 760, 600, 1, True, BLUE)
    text(d, (580, 300), "Cách 1: đã có công thức Tổng phụ cấp", 28, BLUE)
    for j, lab in enumerate(["Phụ cấp xăng", "Phụ cấp trách nhiệm", "Phụ cấp khác"]):
        fcard(d, 540, 390 + j * 80, 480, lab, (110, 122, 150), 1, tick=False)
    fcard(d, 540, 650, 480, "Tổng phụ cấp", GREEN, 1, tick=True)
    text(d, (580, 770), "Tổng phụ cấp → giá trị của nhóm", 24, GREEN, "Bold")
    s_ = pop(t, 61.5)
    if s_ > 0.01:
        card(d, 1360, 560, 760, 600, s_, True, ORANGE)
        if s_ > 0.9: text(d, (1360, 300), "Cách 2: chọn tại từng công thức riêng lẻ", 28, ORANGE)
    for j, lab in enumerate(["Phụ cấp xăng", "Phụ cấp trách nhiệm", "Phụ cấp khác"]):
        fcard(d, 1320, 390 + j * 80, 480, lab, ORANGE, pop(t, 62.0 + j * 0.2, 0.4), tick=t >= 63.3 + j * 0.4)
    fcard(d, 1320, 650, 480, "Tổng phụ cấp", (110, 122, 150), pop(t, 67.2, 0.4), tick=False)
    k = pop(t, 70.3, 0.4)
    if k > 0.01: text(d, (1360, 770), "Hệ thống cộng các công thức đã chọn", 24 * k, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B")

def sc_uutien(img, d, t):
    paste(img, BOARD)
    if t < 89.9:
        board_title(d, t, "Đã có công thức Tổng phụ cấp: ưu tiên cách 1", 76.3, size=54)
        for i, (st, lab, kind, col) in enumerate([(82.0, "Giảm số lượng thao tác\nkhi thiết lập", "check", BLUE),
                                                   (84.4, "Dễ kiểm soát khi bổ sung\nhoặc điều chỉnh công thức phụ cấp", "search", GREEN)]):
            vcard(d, 700 + i * 520, 540, 480, 380, pop(t, st), col, kind, lab, 26, True)
        role_tag(img, d, CB, "C&B")
        return
    board_title(d, t, "Lưu ý: tránh cộng trùng giá trị của nhóm", 90.0, size=54)
    s_ = pop(t, 91.4)
    if s_ > 0.01:
        card(d, W / 2, 500, 1200, 460, s_, True, RED)
        if s_ > 0.9: text(d, (W / 2, 315), "Nhiều công thức cùng nhóm đều chọn Tổng nhóm dữ liệu lương", 26, RED)
    for j, lab in enumerate(["Phụ cấp xăng", "Phụ cấp trách nhiệm", "Tổng phụ cấp"]):
        fcard(d, 860, 400 + j * 80, 520, lab, RED if j == 2 else ORANGE, pop(t, 93.6 + j * 0.2, 0.4), tick=True)
    k = pop(t, 95.9, 0.4)
    if k > 0.01: text(d, (W / 2, 660), "→ Hệ thống cộng giá trị của tất cả các công thức được chọn", 26 * k, INK, "Bold")
    pill(d, W / 2 + 60, 880, 1180, 72, NAVY, "Xác định rõ công thức nào tạo giá trị hiển thị cho nhóm phụ cấp", 25, pop(t, 100.2))
    role_tag(img, d, CB, "C&B")

# ================= Hiển thị là thu nhập thực lãnh =================
def sc_h_tl(img, d, t): sub_card(img, d, t, HD["tl"], "PHẦN 8", ["HIỂN THỊ LÀ", "THU NHẬP THỰC LÃNH"], 84)

def sc_tl(img, d, t):
    if t < 116.4:
        htv(img)
        top_title(d, t, "Hiển thị là thu nhập thực lãnh", 108.9)
        if t >= 109.3: hl(d, XV(*V["TL"]), t)
        chip_bar(d, t, [(112.1, "Xác định công thức thể hiện số tiền cuối cùng nhân viên được nhận", NAVY)], size=23)
    else:
        fs_shot(img, IMG_TN, TN_FULL, TN_FULL, 0)
        top_title(d, t, "Thông thường: chọn tại công thức Thực nhận / Thực lãnh", 116.5)
        if t >= 119.8: hl(d, XT(2550, 395, 2760, 1320), t)
        chip_bar(d, t, [(121.5, "Đã tổng hợp thu nhập, khấu trừ & trả về số tiền cuối cùng cần chi cho nhân viên", GREEN)], size=22)
    role_tag(img, d, CB, "C&B")

def sc_tlvd(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Cơ chế tương tự Tổng nhóm dữ liệu lương", 129.4, size=54)
    k0 = pop(t, 133.8, 0.4)
    if k0 > 0.01: text(d, (W / 2, 220), "Nhiều công thức cùng chọn → hệ thống cộng kết quả để xác định thu nhập thực lãnh", 26 * k0, INK, "Bold")
    for i, (st, lab, val) in enumerate([(144.4, "Công thức A", "5.000.000đ"), (146.4, "Công thức B", "10.000.000đ")]):
        s_ = pop(t, st)
        if s_ > 0.01:
            card(d, 470 + i * 560, 470, 440, 220, s_, True, BLUE)
            if s_ > 0.9:
                text(d, (470 + i * 560, 420), lab, 30, BLUE); text(d, (470 + i * 560, 490), val, 34, INK)
                fcard(d, 470 + i * 560 - 30, 550, 300, "Thu nhập thực lãnh", GREEN, pop(t, st + 3.5, 0.4), tick=t >= st + 4.0, size=18)
    if t >= 152.3: text(d, (750, 470), "+", 70, ORANGE)
    arrow(d, 1270, 470, 1380, 470, p(t, 152.4, 0.4), ORANGE, 8)
    s3 = pop(t, 152.6)
    if s3 > 0.01:
        card(d, 1600, 470, 400, 220, s3, True, ORANGE)
        if s3 > 0.9: text(d, (1600, 420), "Thực lãnh", 30, ORANGE)
        k = pop(t, 154.5, 0.4)
        if k > 0.01: text(d, (1600, 490), "15.000.000đ", 36 * k, INK)
    pill(d, W / 2 + 60, 820, 1260, 76, RED, "Đã có công thức Thực nhận / Thực lãnh cuối cùng → chỉ chọn tại công thức đó", 24, pop(t, 158.0))
    k2 = pop(t, 164.4, 0.4)
    if k2 > 0.01: text(d, (W / 2 + 60, 900), "để tránh cộng trùng kết quả", 26 * k2, RED, "Bold")
    role_tag(img, d, CB, "C&B")

# ================= Trạng thái công thức =================
def sc_h_tt(img, d, t): sub_card(img, d, t, HD["tt"], "PHẦN 8", ["TRẠNG THÁI CÔNG THỨC", "& LƯU Ý KHI CHỈNH SỬA"], 84)

def sc_tt(img, d, t):
    if t < 181.1:
        form(img)
        top_title(d, t, "Trạng thái công thức", 171.5)
        if t >= 172.4: hl(d, XF(*F["TTS"]), t)
        if t < 173.9: chip_bar(d, t, [(172.4, "Công thức đang áp dụng: để Đang sử dụng", GREEN)], size=24)
        else: chip_bar(d, t, [(174.0, "Không còn áp dụng → Ngưng sử dụng, hạn chế xử lý không cần thiết khi chạy lương", ORANGE)], size=22)
        role_tag(img, d, CB, "C&B")
        return
    fs_shot(img, IMG_DS, DS_FULL, DS_FULL, 0)
    if t < 192.1:
        if t >= 183.5: hl(d, XD(1300, 160, 2004, 262), t)
        if t >= 185.6: hl(d, XD(1318, 669, 1839, 1515), t)
        if t < 187.4: chip_bar(d, t, [(181.2, "Trước khi ngưng: kiểm tra công thức có đang được công thức khác sử dụng", NAVY)], size=22)
        else: chip_bar(d, t, [(187.5, "Vẫn còn tham chiếu → xử lý mối liên hệ này trước khi ngưng", RED)], size=24)
    else:
        if t >= 195.2: hl(d, XD(2600, 595, 2760, 1470), t)
        chip_bar(d, t, [(195.2, "Nhân bản để giữ công thức cũ làm phương án dự phòng trước khi thay đổi quy tắc mới", GREEN)], size=21)
    role_tag(img, d, CB, "C&B")

# ================= Kiểm tra kết quả =================
def sc_h_kt(img, d, t): sub_card(img, d, t, HD["kt"], "PHẦN 8", ["CÁCH KIỂM TRA KẾT QUẢ", "CÔNG THỨC LƯƠNG"], 84)

def sc_kt(img, d, t):
    if t < 210.1:
        fs_shot(img, IMG_KQ, KQ_FULL, KQ_FULL, 0)
        top_title(d, t, "Chạy thử trên một chu kỳ lương trước khi áp dụng chính thức", 203.2)
        if t >= 206.5: hl(d, XK(860, 252, 1470, 362), t)
        role_tag(img, d, CB, "C&B")
        return
    form(img)
    top_title(d, t, "Kết quả chưa đúng: lần lượt kiểm tra ba yếu tố", 210.2)
    if t >= 214.9: hl(d, XF(*F["CT"]), t)
    if t >= 223.5: hl(d, XF(*F["CTH"]), t)
    if t >= 236.1: hl(d, XF(*F["CHAY"]), t)
    if t < 223.5: chip_bar(d, t, [(215.3, "1. Nội dung: đúng chính sách tính lương & nguyên tắc vận hành dữ liệu?", RED)], size=22)
    elif t < 236.1: chip_bar(d, t, [(223.6, "2. Cách thể hiện: Tổng, Giá trị cuối cùng… phù hợp tính chất TPL?", RED)], size=22)
    else: chip_bar(d, t, [(236.2, "3. Cách chạy: hàng ngày hay cuối chu kỳ phù hợp cách doanh nghiệp muốn tính?", RED)], size=22)
    role_tag(img, d, CB, "C&B")

def sc_end(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Áp dụng các nguyên tắc vào từng tình huống tính lương", 247.2, size=52)
    k = pop(t, 252.3)
    pill(d, W / 2, 330, 360, 76, NAVY, "Bước tiếp theo", 32, k)
    s_ = pop(t, 253.6, 0.6)
    if s_ > 0.01:
        card(d, W / 2, 590, 1200, 320, s_, True, ORANGE)
        icon(d, "fx", W / 2 - 460 * s_, 590, s_, ORANGE, 90)
        text(d, (W / 2 + 80, 550), "XÂY DỰNG CÔNG THỨC THỰC TẾ", 50 * s_, NAVY)
        k2 = pop(t, 257.3)
        if k2 > 0.01: text(d, (W / 2 + 80, 630), "Thấy rõ cách các yếu tố phối hợp với nhau", 26 * k2, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B", pop(t, 247.4, 0.4))

SCENES = [(-OFFSET, 2.0, "h_ttn"), (2.0, HD["tn"], "ttn"), (HD["tn"], 22.4, "h_tn"), (22.4, 44.2, "app"), (44.2, 61.0, "cach1"),
          (61.0, 76.0, "cach2"), (76.0, HD["tl"], "uutien"), (HD["tl"], 108.6, "h_tl"), (108.6, 129.3, "tl"), (129.3, HD["tt"], "tlvd"),
          (HD["tt"], 171.4, "h_tt"), (171.4, HD["kt"], "tt"), (HD["kt"], 203.0, "h_kt"), (203.0, 246.6, "kt"), (246.6, 999, "end")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv84"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 10
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p84_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p84_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
