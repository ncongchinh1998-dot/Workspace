"""PHẦN 9.2 (voice 01/11/2026) — TÌNH HUỐNG 1: TÍNH TỔNG CÔNG TÍNH LƯƠNG.
Dùng lại bảng/thẻ tra cứu của part92, dựng theo mốc thời gian voice mới. Số liệu: 23,5 + 1 + 1 = 25,5 công."""
import sys, math
from hw_core import *
import part92 as P
from part81 import sub_card, FORM_FULL, XF, F, IMG_FORM, mini_chip, badge, hl_pad
from part81 import IMG_DD, DD_FULL, XDD, DD_ROWS

VOICE = A + "voice_p92b.wav"
OFFSET = 1.0
VOICE_DUR = 304.61
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = P.OUT
HD = dict(th1=-0.6)
SFX_AT = [0.0]

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
P.hl = lambda d, box, t=0.0, kind="rect": hl(d, box, t)
import part81; part81.hl = lambda d, box, t=0.0, kind="rect": hl(d, box, t)

# mốc đọc bảng theo voice mới: ngày 1 (công), ngày 2 (lễ), ngày 4 (công 0,5), ngày 5 (phép); ngày 3 & các ngày còn lại hiện ở "các ngày còn lại"
P.READ = [(112.1, [114.1, 114.1, 114.1]), (114.9, [116.8, 116.8, 116.8]), (128.3, [128.3, 128.3, 128.3]),
          (119.0, [121.2, 121.2, 121.2]), (122.9, [126.1, 126.1, 126.1])]
P.REST = 128.3
P.TABLE_T0 = 108.7

def sc_h_th1(img, d, t): sub_card(img, d, t, HD["th1"], "TÌNH HUỐNG 1", ["TÍNH TỔNG CÔNG", "TÍNH LƯƠNG"], 100)

def sc_rule(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Yêu cầu: tổng công tính lương theo cách tính của doanh nghiệp", 2.8, size=48)
    P.equation(d, t, [8.6, 10.1, 10.5, 11.4, 11.9, 13.0, 13.4])
    role_tag(img, d, CB, "C&B")

def sc_tpl(img, d, t):
    if t < 27.4:
        paste(img, BOARD)
        board_title(d, t, "Câu hỏi 1 · Cần dữ liệu nào?", 15.0, size=54)
        for i, (st, lab) in enumerate([(20.3, "Ngày công\ncủa nhân viên"), (21.9, "Ngày lễ"), (23.0, "Ngày nghỉ phép năm\nđã được duyệt")]):
            vcard(d, 460 + i * 500, 520, 440, 320, pop(t, st), GREEN, "db", lab, 28, True, f"0{i + 1}")
        pill(d, W / 2, 800, 760, 70, GREEN, "Các dữ liệu này đã có trên Haraworks", 26, pop(t, 25.3))
        role_tag(img, d, CB, "C&B")
        return
    P.fs_shot(img, P.IMG_ID, P.ID_FULL, P.ID_FULL, 0)
    if t < 36.1:
        top_title(d, t, "Tra cứu file tổng hợp thành phần lương hệ thống", 27.5)
        chip_bar(d, t, [(31.4, "Xác định thành phần lương phù hợp thay vì tạo thêm thành phần lương mới", NAVY)], size=23)
    else:
        top_title(d, t, "Ngoài tên thành phần lương, đọc thêm", 36.2)
        if 39.8 <= t < 41.1: hl(d, P.XI(*P.COL_MD), t)
        if t >= 41.1: hl(d, P.XI(*P.COL_GT), t)
        chip_bar(d, t, [(39.8, "Mục đích sử dụng", BLUE), (41.1, "Giá trị trả ra của hệ thống", ORANGE)], size=24)

def sc_cong(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu công", 46.0, size=54)
    P.lookup(d, t, "Ngày công", 48.2, "Số ngày công đã chấm & được duyệt, dựa trên\ngiờ công thực tế & giờ công chuẩn một ngày", 50.3,
             "Trả về số công theo từng ngày\n(có thể là số thập phân)", 63.5)
    k = pop(t, 57.2, 0.4)
    if k > 0.01: text(d, (1450, 245), "Ví dụ: giờ công chuẩn 1 ngày = 8 giờ", 24 * k, NAVY, "Bold")
    P.examples(d, t, [(61.0, "Được duyệt đủ 8 giờ", "8/8 = 1 công", 63.5), (64.6, "Được duyệt 4 giờ", "4/8 = 0,5 công", 66.3), (67.9, "Không phát sinh công", "0/8 = 0", 69.7)])   # thể hiện phép chia giờ duyệt / giờ chuẩn
    role_tag(img, d, CB, "C&B")

def sc_le(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu ngày lễ", 70.8, size=54)
    P.lookup(d, t, "Số ngày lễ", 72.2, "Xác định những ngày là ngày lễ", 72.6,
             "Ngày được xác định là ngày lễ = 1\nNhững ngày còn lại = 0", 74.6, ox=320)
    role_tag(img, d, CB, "C&B")

def sc_phep(img, d, t):
    paste(img, BOARD)
    if t < 90.6:
        board_title(d, t, "Dữ liệu phép năm", 80.5, size=54)
        P.lookup(d, t, "Số ngày phép năm", 81.0, "Số ngày phép năm đã được duyệt của nhân viên", 82.6,
                 "Ngày có phép năm đã duyệt → số ngày phép tương ứng\nNgày không phát sinh phép năm → 0", 85.3, ox=320)
    else:
        board_title(d, t, "Ba thành phần lương được sử dụng", 90.7, size=54)
        for i, (st, lab) in enumerate([(93.4, "Ngày công"), (94.3, "Số ngày lễ"), (96.1, "Số ngày phép năm")]):
            vcard(d, 460 + i * 500, 540, 440, 300, pop(t, st), GREEN, "db", lab, 30, True, f"0{i + 1}")
    role_tag(img, d, CB, "C&B")

def sc_ct(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Câu hỏi 2 · Công thức được thiết lập là gì?", 98.0, size=54)
    P.equation(d, t, [100.9, 102.1, 102.1, 102.8, 103.2, 104.5, 104.8], y=440)
    role_tag(img, d, CB, "C&B")

def sc_table(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu ghi nhận theo từng ngày đầu kỳ", 108.8, size=54)
    cur = None
    for i, (st, _) in enumerate(P.READ):
        if i == 2: continue
        if t >= st: cur = i
    if t >= P.REST: cur = None
    P.table(d, t, cur=cur, tot=dict(cong=134.2, le=136.4, phep=139.0))
    k = pop(t, 141.2)
    if k > 0.01:
        card(d, W / 2 + 40, 800, 1300, 150, k, True, ORANGE)
        text(d, (W / 2 + 40, 770), "Tổng công tính lương mong muốn", 26 * k, NAVY)
        k2 = pop(t, 143.9, 0.4)
        if k2 > 0.01: text(d, (W / 2 + 40, 830), "23,5 + 1 + 1 = 25,5 công", 40 * k2, ORANGE)
    role_tag(img, d, CB, "C&B")

def sc_setup(img, d, t):
    P.form(img)
    top_title(d, t, "Cách thể hiện & cách chạy nào cho kết quả 25,5 công?", 148.8)
    if t >= 149.2: hl(d, XF(*F["CTH"]), t)
    if t >= 150.0: hl(d, XF(*F["CHAY"]), t)
    role_tag(img, d, CB, "C&B")

RUN = [(161.0, 162.6, "1 + 0 + 0 = 1"), (163.5, 164.9, "0 + 1 + 0 = 1"), None, (167.2, 168.6, "0,5 + 0 + 0 = 0,5"), (170.0, 171.2, "0 + 0 + 1 = 1")]
RUNV = [1, 1, 1, 0.5, 1, None, 1, 1]
def sc_daily(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Chạy hàng ngày", 155.3, size=54)
    cur = None
    for i, r in enumerate(RUN):
        if r and t >= r[0]: cur = i
    if t >= 173.6: cur = None
    P.table(d, t, all_on=True, cur=cur, run_row=True)
    RY, CX, TX = P.RY, P.CX, P.TX
    text(d, (300, RY["run"]), "Chạy hàng ngày", fit_size(d, "Chạy hàng ngày", 24, "Bold", 230), ORANGE, "Bold")
    for i, v in enumerate(RUNV):
        if v is None:
            if t >= 173.6: text(d, (CX[i], RY["run"]), "…", 26, GREY)
            continue
        st = RUN[i][1] if i < 5 and RUN[i] else 173.6
        if t >= st: text(d, (CX[i], RY["run"]), P.fmt(v), 30, ORANGE)
    if cur is not None:
        pill(d, W / 2 + 40, 760, 900, 70, NAVY, f"Ngày {P.DAYS[cur]}: công + ngày lễ + phép năm = {RUN[cur][2]}", 24, 1)
    if 179.4 <= t < 192.8:                     # voice: "cộng các kết quả… lại với nhau" → dấu + giữa kết quả từng ngày
        for i in range(7):
            text(d, ((CX[i] + CX[i + 1]) / 2, RY["run"]), "+", 30 * pop(t, 179.4 + i * 0.15, 0.3), RED)
    if 194.4 <= t < 197.2 and int(t * 4) % 2 == 0:   # "chỉ lấy một kết quả khác 0 gần cuối kỳ" → khoanh ô ngày 30, nhấp nháy
        hl(d, (CX[7] - 40, RY["run"] - 28, CX[7] + 40, RY["run"] + 28), t)
    if 197.9 <= t < 201.2: hl(d, (CX[0] - 50, RY["run"] - 28, CX[7] + 50, RY["run"] + 28), t)   # trung bình các kết quả theo ngày
    if t >= 176.8:
        k = pop(t, 182.9, 0.4)
        if k > 0.01: text(d, (TX, RY["run"]), "25,5", 34 * k, GREEN)
        opts = [(176.8, "Tổng", "cộng kết quả các ngày\n= 25,5 công", True),
                (192.8, "Giá trị cuối cùng khác không", "chỉ lấy kết quả khác 0\ngần cuối kỳ = 1 (ngày 30)", False),
                (197.0, "Giá trị trung bình", "Tổng ÷ 30 ngày\n= 25,5 ÷ 30 = 0,85", False)]
        for j, (st, lab, val, ok) in enumerate(opts):
            s_ = pop(t, st)
            if s_ <= 0.01: continue
            x = 500 + j * 540
            card(d, x, 860, 500, 190, s_, True, GREEN if ok else RED)
            if s_ > 0.9:
                text(d, (x, 805), lab, fit_size(d, lab, 26, "Bold", 460), GREEN if ok else RED, "Bold")
                text(d, (x, 880), val, 24, INK, "Bold")
                if ok or t >= 201.0: badge(d, x + 240, 775, ok, 1, 24)
    role_tag(img, d, CB, "C&B")

def sc_end(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Chạy một lần cuối chu kỳ", 209.4, size=54)
    hl_on = None
    for st, key in [(222.1, "cong"), (224.9, "le"), (227.7, "phep")]:
        if t >= st: hl_on = key
    P.table(d, t, all_on=True, tot=dict(cong=222.3, le=225.2, phep=228.0))
    if hl_on and t < 232.6: hl(d, (1570, P.RY[hl_on] - 30, 1810, P.RY[hl_on] + 30), t)
    k = pop(t, 214.4, 0.4)
    if k > 0.01: text(d, (W / 2 + 40, 700), "Không tính riêng từng ngày: tại ngày cuối chu kỳ, tổng hợp dữ liệu của từng thành phần lương trước", 22 * k, INK, "Bold")
    s_ = pop(t, 230.4)
    if s_ > 0.01:
        card(d, W / 2 + 40, 820, 900, 130, s_, True, ORANGE)
        k2 = pop(t, 232.7, 0.4)
        if k2 > 0.01: text(d, (W / 2 + 40, 820), "23,5 + 1 + 1 = 25,5 công", 40 * k2, ORANGE)
    pill(d, W / 2 + 40, 960, 1100, 64, GREEN, "Cách thể hiện Tổng: cả chạy hàng ngày & chạy cuối kỳ đều ra 25,5 công", 22, pop(t, 238.0))
    role_tag(img, d, CB, "C&B")

def sc_choose(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Vậy nên chọn cách nào?", 247.6, size=56)
    hcard(d, 640, 380, 900, 150, pop(t, 250.1), BLUE, "calendar", "Công, phép, ngày lễ được ghi nhận\n& thay đổi theo từng ngày", 26, True)
    arrow(d, 1100, 380, 1220, 380, p(t, 255.2, 0.4), ORANGE, 8)
    s_ = pop(t, 255.4)
    if s_ > 0.01:
        card(d, 1520, 380, 540, 180, s_, True, GREEN)
        text(d, (1520, 380), "Ưu tiên\nchạy hàng ngày", 34 * s_, GREEN)
        badge(d, 1770, 300, True, s_, 26)
    hcard(d, W / 2 + 40, 640, 1300, 120, pop(t, 257.9), GREEN, "check", "Tổng công tính lương cập nhật tương ứng theo dữ liệu từng ngày", 25, True)
    hcard(d, W / 2 + 40, 800, 1300, 120, pop(t, 263.0), NAVY, "fx", "Thuận tiện khi công thức khác dùng tiếp kết quả để tính lương, thu nhập khác", 25, True)
    role_tag(img, d, CB, "C&B")

SUM = [(273.7, "Thành phần lương", "Ngày công · Số ngày lễ · Số ngày phép năm", GREEN),
       (278.3, "Công thức", "Ngày công + Số ngày lễ + Số ngày phép năm", BLUE),
       (283.0, "Cách thể hiện", "Tổng", ORANGE), (285.4, "Cách chạy", "Hàng ngày", NAVY)]
def sc_sum(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thiết lập cho tình huống 1", 270.9, size=56)
    for j, (st, lab, val, col) in enumerate(SUM):
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        y = 280 + j * 150
        card(d, W / 2 + 40, y, 1400, 120, s_, True, col)
        if s_ > 0.9:
            mini_chip(d, 560, y, 360, 62, lab, col, 1, 24)
            text(d, (800, y), val, 30, INK, "Bold", anchor="lm")
            badge(d, 1660, y, True, 1, 24)
    role_tag(img, d, CB, "C&B")

FLOW = [(290.6, "Xác định dữ liệu\ncần sử dụng", "search", GREEN), (292.4, "Tìm đúng\nthành phần lương", "db", CYAN),
        (293.8, "Xây dựng\ncông thức", "fx", BLUE), (295.1, "Chọn cách thể hiện\n& cách chạy", "run", ORANGE)]
def sc_recap(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Từ nhu cầu thực tế đến công thức trên Haraworks", 287.7, size=52)
    for i, (st, lab, kind, col) in enumerate(FLOW):
        vcard(d, 330 + i * 420, 540, 370, 340, pop(t, st), col, kind, lab, 26, True, f"0{i + 1}")
        if i: arrow(d, 330 + (i - 1) * 420 + 190, 540, 330 + i * 420 - 190, 540, p(t, st - 0.2, 0.3), ORANGE, 6)
    role_tag(img, d, CB, "C&B")

def sc_next(img, d, t):
    paste(img, BOARD)
    k = pop(t, 298.3)
    pill(d, W / 2, 330, 400, 76, NAVY, "Tình huống tiếp theo", 32, k)
    s_ = pop(t, 299.7, 0.6)
    if s_ > 0.01:
        card(d, W / 2, 590, 1300, 320, s_, True, ORANGE)
        icon(d, "fx", W / 2 - 520 * s_, 590, s_, ORANGE, 90)
        text(d, (W / 2 + 60, 545), "Dùng kết quả Tổng công tính lương", 40 * s_, NAVY)
        k2 = pop(t, 302.8, 0.4)
        if k2 > 0.01: text(d, (W / 2 + 60, 625), "để xây dựng công thức lương trong tháng", 30 * k2, ORANGE)
    role_tag(img, d, CB, "C&B", k)

SCENES = [(-OFFSET, 2.6, "h_th1"), (2.6, 15.4, "rule"), (15.4, 45.9, "tpl"), (45.9, 70.6, "cong"), (70.6, 80.3, "le"),
          (80.3, 97.5, "phep"), (97.5, 108.6, "ct"), (108.6, 148.6, "table"), (148.6, 155.2, "setup"), (155.2, 209.3, "daily"),
          (209.3, 247.4, "end"), (247.4, 270.6, "choose"), (270.6, 287.4, "sum"), (287.4, 298.0, "recap"), (298.0, 999, "next")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv92b"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 11
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p92b_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p92b_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
