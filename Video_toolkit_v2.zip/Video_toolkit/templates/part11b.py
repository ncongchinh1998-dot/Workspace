"""PHẦN 11 · 12 · 13 (voice 01/11/2026). Giữ cảnh part11, ánh xạ thời gian bằng remap_voice; bổ sung:
- tiêu đề PHẦN 12 (phiếu lương) & PHẦN 13 (tổng kết) theo voice mới + câu chuyển tiếp;
- thao tác vào phiếu lương trên App: cắt khung hình chính + khung đỏ từng bước (Ứng dụng → Nhân sự → Lương nhân viên);
- tên chu kỳ lương đồng bộ "Tháng mm/yyyy" (web & App); số Tổng thu nhập trên báo cáo theo nhân viên làm tròn 2 số lẻ (sửa đè)."""
import sys, math
from hw_core import *
from remap_voice import make_maps
from rename_tool import rename
import part11 as P
from part81 import sub_card, mini_chip

M, Minv = make_maps(A + "words_p11.json", A + "words_p11b.json")
VOICE = A + "voice_p11b.wav"
OFFSET = 1.0
VOICE_DUR = 322.49
TOTAL = OFFSET + VOICE_DUR + 1.5
OUT = P.OUT
HD = dict(p11=-0.6, p12=89.6, p13=172.2)
SFX_AT = [0.0, OFFSET + 89.6, OFFSET + 172.2]

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
P.hl = lambda d, box, t=0.0, kind="rect": hl(d, box, t)

# ---------- sửa đè trên bản quay web ----------
NV_ROWS = [(535, "133,064.52"), (591, "13,608,870.97"), (646, "128,571,428.57"), (701, "783,792.31"), (756, "216,869.23"),
           (811, "865,322.58"), (867, "43,650.79"), (922, "6,924.62"), (977, "15,000,000.00"), (1033, "58,035,714.29")]
_scr0 = P.scr
def scr(img, key, path, tc, spec=P.REC_BR):
    _scr0(img, key, path, tc, spec)
    B = lambda *b: P.B(*b, spec)
    if key == "tn":
        if tc < 36.0 or 44.0 <= tc < 53.0: rename(img, B(567, 307, 782, 330), "Tháng 07/2022", 17)
        elif 37.5 <= tc < 44.0: rename(img, B(113, 220, 528, 241), "Tháng 07/2022 (01/07/2022 - 31/07/2022)", 17, mode="dark")
    elif key == "dv" and 8.2 <= tc <= 10.9:
        rename(img, B(311, 469, 522, 492), "Tháng 07/2022", 16)
    elif key == "nv" and tc >= 10.5:
        for y, v in NV_ROWS: rename(img, B(1322, y - 3, 1508, y + 17), v, 17, align="right", mode="dark")
P.scr = scr

# ---------- App: đổi tên chu kỳ lương ----------
_app0 = P.app_phone
def app_phone(img, d, cx, top, sw, tc, s=1.0):
    Q = _app0(img, d, cx, top, sw, tc, s)
    if s > 0.98:
        k = sw / 576
        if 8.0 <= tc < 16.5 or 26.0 <= tc < 28.8: rename(img, Q(40, 180, 352, 213), "Tháng 07/2022", int(24 * k))
        elif 28.8 <= tc < 31.9:
            rename(img, Q(86, 164, 340, 193), "Tháng 10/2026", int(22 * k))
            rename(img, Q(86, 318, 362, 348), "Tháng 07/2022", int(22 * k))
    return Q
P.app_phone = app_phone

def old(fn): return lambda img, d, t: fn(img, d, Minv(t))

# ---------- cảnh mới ----------
def sc_to12(img, d, t):
    paste(img, BOARD)
    k = pop(t, 84.2)
    pill(d, W / 2, 330, 380, 76, NAVY, "Phần tiếp theo", 32, k)
    s_ = pop(t, 85.4, 0.6)
    if s_ > 0.01:
        card(d, W / 2, 590, 1240, 300, s_, True, ORANGE)
        icon(d, "doc", W / 2 - 480 * s_, 590, s_, ORANGE, 90)
        text(d, (W / 2 + 70, 550), "Nhân viên nhận & theo dõi phiếu lương", 40 * s_, NAVY)
        k2 = pop(t, 86.9, 0.4)
        if k2 > 0.01: text(d, (W / 2 + 70, 625), "Sau khi C&B hoàn tất kiểm tra kết quả", 26 * k2, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B", k)

def sc_h_p12(img, d, t): sub_card(img, d, t, HD["p12"], "PHẦN 12", ["PHIẾU LƯƠNG &", "TRẢI NGHIỆM CỦA NHÂN VIÊN"], 80)
def sc_h_p13(img, d, t): sub_card(img, d, t, HD["p13"], "PHẦN 13", ["TỔNG KẾT"], 110)

def sc_to13(img, d, t):
    paste(img, BOARD)
    k = pop(t, 163.3)
    pill(d, W / 2, 330, 340, 76, NAVY, "Phần cuối", 32, k)
    s_ = pop(t, 164.6, 0.6)
    if s_ > 0.01:
        card(d, W / 2, 590, 1300, 300, s_, True, ORANGE)
        text(d, (W / 2, 550), "Tổng kết toàn bộ quy trình", 42 * s_, NAVY)
        k2 = pop(t, 166.6, 0.4)
        if k2 > 0.01: text(d, (W / 2, 625), "& những nguyên tắc C&B cần ghi nhớ khi thiết lập, điều chỉnh bảng lương", 24 * k2, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B", k)

# ---------- thao tác vào phiếu lương trên App: chậm lại, khung từng bước ----------
N0, N1 = 93.7, M(86.5)
NAV = [(1.0, (465, 1148, 552, 1224), "Chọn Ứng dụng"), (2.3, (22, 318, 284, 420), "Chọn Nhân sự"),
       (6.0, (36, 888, 560, 948), "Chọn Lương nhân viên")]
_app_scene = old(P.FN["app"])
def sc_app(img, d, t):
    if t >= N1: return _app_scene(img, d, t)
    paste(img, BOARD)
    top_title(d, t, "Nhân viên xem thu nhập trên App Haraworks", N0 + 0.1)
    seg = (N1 - N0) / 3
    i = min(int((t - N0) / seg), 2)
    ct, box, lab = NAV[i]
    Q = P.app_phone(img, d, 640, 78, 432, ct)
    if t - N0 - i * seg > 0.5: hl(d, Q(*box), t)
    for j in range(i + 1):
        mini_chip(d, 1340, 360 + j * 110, 520, 72, f"{j + 1}. {NAV[j][2]}", BLUE if j < i else ORANGE, 1, 28)
    P.role_badge(img, d, EMP, "Nhân viên", 1700, 1000, 1, 230)

SCENES = []
for s, e, n in P.SCENES:
    if n == "h_tk": continue
    s2 = s if s < 0 else M(s); e2 = 999 if e >= 999 else M(e)
    if n == "recap1": e2 = 80.2
    if n == "app": s2 = N0
    if n == "flow": e2 = 163.2
    if n == "tk1": s2 = 174.6
    SCENES.append((s2, e2, n))
i_app = [n for _, _, n in SCENES].index("app")
SCENES[i_app:i_app] = [(80.2, HD["p12"], "to12"), (HD["p12"], N0, "h_p12")]
i_tk = [n for _, _, n in SCENES].index("tk1")
SCENES[i_tk:i_tk] = [(163.2, HD["p13"], "to13"), (HD["p13"], 174.6, "h_p13")]
FN = {n: old(P.FN[n]) for _, _, n in SCENES if n in P.FN}
FN.update(dict(to12=sc_to12, h_p12=sc_h_p12, to13=sc_to13, h_p13=sc_h_p13, app=sc_app,
               h_p11=P.FN["h_p11"]))

def preview(times, out="/tmp/pv11b"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 12
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "scenes":
        for s, e, nm in SCENES: print(f"{s:7.2f} {e:7.2f} {nm}")
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p11b_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p11b_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
