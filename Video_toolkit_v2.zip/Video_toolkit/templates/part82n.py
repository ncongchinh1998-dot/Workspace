"""PHẦN 8.2 (voice 01/11/2026) — Chạy một lần cuối chu kỳ & chạy hàng ngày.
Voice gốc bị lặp 1 lần đoạn "ngược lại… / như vậy…" (3:27–4:30) → đã cắt, giữ lần đọc đầu + câu tóm tắt cuối kỳ + câu chốt (voice_p82c.wav).
Ví dụ: tiền cơm 30.000đ, công thức IF(giờ công > 0, 30.000, 0); kỳ 06/2026, nhân viên A."""
import sys, math
from hw_core import *
from part81 import sub_card, full_of, shot_xy, FORM_FULL, XF, F, IMG_FORM, mini_chip, badge

VOICE = A + "voice_p82c.wav"
OFFSET = 1.0
VOICE_DUR = 228.85
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan8_2_Cong_thuc_luong.mp4"
HD = dict(chay=-0.6)
SFX_AT = [0.0]

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
def form(img): fs_shot(img, IMG_FORM, FORM_FULL, FORM_FULL, 0)

def sc_h_chay(img, d, t): sub_card(img, d, t, HD["chay"], "PHẦN 8", ["CHẠY MỘT LẦN CUỐI CHU KỲ", "VÀ CHẠY HÀNG NGÀY"], 80)

def sc_form(img, d, t):
    form(img)
    top_title(d, t, "Tính theo từng ngày hay một lần tại ngày cuối chu kỳ lương?", 3.4)
    if t >= 4.6: hl(d, XF(*F["CHAY"]), t)
    if t >= 22.3: hl(d, XF(*F["CTH"]), t)
    if t < 16.2: chip_bar(d, t, [(11.8, "Không chọn ô này → công thức được hiểu là chạy hàng ngày", NAVY)], size=24)
    else: chip_bar(d, t, [(16.3, "Xét dữ liệu từng ngày → tính theo điều kiện công thức → tổng hợp theo cách thể hiện", NAVY)], size=22)
    role_tag(img, d, CB, "C&B")

def sc_rule(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ví dụ: tiền cơm 30.000đ cho mỗi ngày có đi làm", 24.5, size=52)
    s_ = pop(t, 24.8)
    if s_ > 0.01:
        card(d, W / 2, 330, 1240, 170, s_, True, GREEN)
        text(d, (W / 2, 305), "Doanh nghiệp quy định: 30.000đ tiền cơm / ngày có đi làm", 30 * s_, INK, "Bold")
        k = pop(t, 29.4, 0.4)
        if k > 0.01: text(d, (W / 2, 365), "không phụ thuộc vào số giờ làm việc trong ngày", 26 * k, GREEN, "Bold")
    s2 = pop(t, 33.2)
    if s2 > 0.01:
        card(d, W / 2, 570, 1240, 200, s2, True, BLUE)
        text(d, (W / 2, 515), "Công thức thiết lập trên hệ thống", 24 * s2, GREY, "Bold")
        k1 = pop(t, 36.0, 0.4)
        if k1 > 0.01: text(d, (W / 2, 575), "Nếu giờ công > 0 → 30.000đ", 34 * k1, BLUE)
        k2 = pop(t, 39.8, 0.4)
        if k2 > 0.01: text(d, (W / 2, 625), "ngược lại → 0", 28 * k2, GREY, "Bold")
    mini_chip(d, 700, 790, 480, 64, "Chạy hàng ngày", NAVY, pop(t, 41.6, 0.4), 26)
    mini_chip(d, 1220, 790, 480, 64, "Cách thể hiện: Tổng", ORANGE, pop(t, 45.7, 0.4), 26)
    role_tag(img, d, CB, "C&B")

def sc_data(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Kỳ lương 06/2026 · Nhân viên A", 48.3, size=54)
    s_ = pop(t, 50.8)
    if s_ > 0.01:
        card(d, W / 2, 290, 1000, 110, s_, True, NAVY)
        text(d, (W / 2, 290), "Ngày công chuẩn: 26 ngày = 208 giờ", 32 * s_, NAVY)
    rows = [(57.7, "23 ngày", "làm đủ 8 giờ"), (60.1, "1 ngày", "làm 4 giờ"), (61.3, "1 ngày", "làm 6,4 giờ"), (63.8, "1 ngày", "không đi làm")]
    for j, (st, a, b) in enumerate(rows):
        k = pop(t, st, 0.4)
        if k <= 0.01: continue
        y = 450 + j * 110
        d.rounded_rectangle([560, y - 42, 1360, y + 42], 16, fill=WHITE, outline=LINE, width=3)
        text(d, (620, y), a, 32 * k, BLUE, anchor="lm"); text(d, (860, y), b, 30 * k, INK, "Bold", anchor="lm")
    role_tag(img, d, CB, "C&B")

# ---------- bảng theo ngày ----------
COLS = [("1/6", "Thứ 2"), ("2/6", "Thứ 3"), ("3/6", "Thứ 4"), ("4/6", "Thứ 5"), ("5/6", "Thứ 6"), ("6/6", "Thứ 7"), ("7/6", "CN"), ("…", "")]
HOURS = ["8", "4", "6,4", "0", "8", "8", "0", "…"]
RES = ["30.000", "30.000", "30.000", "0", "30.000", "30.000", "0", "…"]
# mốc đọc: (cột hiện, giờ, kết quả)
READ = [(69.3, 72.1, 75.3), (77.1, 79.9, 82.4), (84.2, 87.0, 90.1), (92.5, 95.5, 97.8), (99.2, 103.8, 105.5), (99.6, 103.9, 105.6), (107.2, 109.9, 110.7), (112.0, 112.0, 112.0)]
CX = [530 + i * 142 for i in range(8)]; TX = 1700; X0, X1 = 170, 1830
def daytable(d, t, show_res=True, all_on=False, cur=None, tot_h=None, tot_r=None, dim_res=False):
    card(d, (X0 + X1) / 2, 450, X1 - X0, 380, 1, True, BLUE)
    hy, y1, y2 = 330, 450, 545
    if cur is not None:
        x = CX[cur]; d.rounded_rectangle([x - 66, hy - 50, x + 66, y2 + 38], 14, fill=(255, 242, 222))
    text(d, (330, hy), "Ngày", 26, GREY, "Bold")
    text(d, (330, y1), "Giờ công", 26, INK, "Bold")
    if show_res: text(d, (330, y2), "Kết quả công thức", 22, ORANGE, "Bold")
    for i, (dd, wd) in enumerate(COLS):
        st, sh, sr = READ[i]
        if not (all_on or t >= st): continue
        text(d, (CX[i], hy - 12), dd, 26, NAVY); 
        if wd: text(d, (CX[i], hy + 20), wd, 17, GREY, "Bold")
        if all_on or t >= sh: text(d, (CX[i], y1), HOURS[i], 28, BLUE if HOURS[i] not in ("0",) else GREY, "Bold")
        if show_res and (all_on or t >= sr):
            v = RES[i]
            text(d, (CX[i], y2), v, fit_size(d, v, 24, "Bold", 128), (190, 196, 210) if dim_res else (GREEN if v not in ("0", "…") else GREY), "Bold")
    text(d, (TX, hy), "Tổng kỳ", 26, ORANGE)
    d.line([X0 + 15, hy + 44, X1 - 15, hy + 44], fill=LINE, width=3)
    d.line([1595, hy - 50, 1595, y2 + 38], fill=LINE, width=3)
    if tot_h:
        k = pop(t, tot_h, 0.4)
        if k > 0.01: text(d, (TX, y1), "194,4 giờ", 30 * k, ORANGE)
    if tot_r and show_res:
        k = pop(t, tot_r, 0.4)
        if k > 0.01: text(d, (TX, y2), "750.000đ", 30 * k, GREEN)
    return hy, y1, y2

def sc_daily(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thử 1 · Chạy hàng ngày (cách thể hiện Tổng)", 65.8, size=52)
    cur = None
    for i, (st, _, _) in enumerate(READ[:7]):
        if t >= st: cur = i
    if t >= 112.0: cur = None
    if 99.2 <= t < 107.2: cur = 4 if t < 102.0 else 5
    daytable(d, t, cur=cur, tot_r=138.3)
    if cur is not None:
        h = HOURS[cur]; r = RES[cur]
        msg = f"{COLS[cur][0]} ({COLS[cur][1]}): giờ công {h} " + ("> 0 → 30.000đ" if r != "0" else "= 0 → 0")
        pill(d, W / 2, 760, 900, 72, NAVY, msg, 26, 1)
    if 112.0 <= t < 125.3:
        pill(d, W / 2, 760, 1200, 72, NAVY, "Xét theo cách này cho từng ngày đến hết chu kỳ lương", 26, pop(t, 112.3))
    if t >= 125.3:
        s_ = pop(t, 125.4)
        if s_ > 0.01:
            card(d, W / 2, 800, 1500, 190, s_, True, GREEN)
            text(d, (W / 2, 750), "Cách thể hiện Tổng: cộng kết quả của từng ngày", 26 * s_, INK, "Bold")
            k = pop(t, 131.4, 0.4)
            if k > 0.01: text(d, (W / 2, 815), "30.000 + 30.000 + 30.000 + 0 + 30.000 + 30.000 + 0 + … = 750.000đ", 30 * k, GREEN)
            k2 = pop(t, 140.3, 0.4)
            if k2 > 0.01: text(d, (W / 2, 865), "Tiền cơm của nhân viên A khi công thức chạy hàng ngày", 22 * k2, GREY, "Bold")
    role_tag(img, d, CB, "C&B")

def sc_endcyc(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thử 2 · Chạy một lần cuối chu kỳ (cách thể hiện vẫn là Tổng)", 144.8, size=46)
    hy, y1, y2 = daytable(d, t, all_on=True, show_res=t < 156.3, dim_res=t >= 150.0, tot_h=172.2)
    if 156.3 <= t < 162.3:
        pill(d, W / 2, 545, 1100, 64, RED, "Không xét điều kiện giờ công > 0 riêng cho từng ngày", 24, pop(t, 156.4))
    if 162.3 <= t < 174.3: hl(d, (CX[0] - 60, y1 - 34, CX[7] + 60, y1 + 34), t)
    if t >= 174.3: hl(d, (1610, y1 - 34, 1820, y1 + 34), t)
    s_ = pop(t, 166.7)
    if s_ > 0.01 and t < 178.8:
        card(d, W / 2, 790, 1300, 120, s_, True, ORANGE)
        text(d, (W / 2, 790), "8 + 4 + 6,4 + 0 + 8 + 8 + 0 + … = 194,4 giờ", 32 * s_, ORANGE)
    if t >= 178.8:
        s2 = pop(t, 178.9)
        card(d, W / 2, 800, 1300, 190, s2, True, RED)
        if s2 > 0.9:
            text(d, (W / 2, 755), "Ngày cuối kỳ mới xét: giờ công cả kỳ 194,4 > 0", 26, INK, "Bold")
            k = pop(t, 186.6, 0.4)
            if k > 0.01: text(d, (W / 2, 825), "→ Kết quả công thức = 30.000đ", 36 * k, RED)
            badge(d, W / 2 + 620, 720, False, pop(t, 189.3, 0.4), 28)
    role_tag(img, d, CB, "C&B")

def sc_compare(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Cùng dữ liệu chấm công, hai cách chạy cho kết quả khác nhau", 190.4, size=46)
    s1 = pop(t, 195.6)
    if s1 > 0.01:
        card(d, 560, 480, 760, 420, s1, True, GREEN)
        if s1 > 0.9:
            text(d, (560, 320), "Chạy hàng ngày", 36, GREEN)
            text(d, (560, 420), "Xét điều kiện tại từng ngày\n→ cộng kết quả theo cách thể hiện", 24, INK, "Bold")
            k = pop(t, 205.6, 0.4)
            if k > 0.01: text(d, (560, 560), "750.000đ", 56 * k, GREEN)
    s2 = pop(t, 207.5)
    if s2 > 0.01:
        card(d, 1360, 480, 760, 420, s2, True, ORANGE)
        if s2 > 0.9:
            text(d, (1360, 320), "Chạy một lần cuối chu kỳ", 36, ORANGE)
            text(d, (1360, 420), "Chỉ tính một lần\ntại ngày cuối cùng của chu kỳ", 24, INK, "Bold")
            k = pop(t, 213.5, 0.4)
            if k > 0.01: text(d, (1360, 560), "30.000đ", 56 * k, ORANGE)
    role_tag(img, d, CB, "C&B")

def sc_note(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Điểm cần lưu ý", 216.6, size=56)
    s_ = pop(t, 217.6)
    if s_ > 0.01:
        card(d, W / 2 + 40, 420, 1400, 200, s_, True, ORANGE)
        text(d, (W / 2 + 40, 380), "Cách thể hiện trên bảng lương không chỉ quyết định", 28 * s_, INK, "Bold")
        text(d, (W / 2 + 40, 440), "kết quả cuối cùng được lấy theo cách nào", 28 * s_, ORANGE)
    s2 = pop(t, 222.3)
    if s2 > 0.01:
        card(d, W / 2 + 40, 680, 1400, 200, s2, True, BLUE)
        text(d, (W / 2 + 40, 640), "mà còn ảnh hưởng trực tiếp đến dữ liệu hệ thống sử dụng", 28 * s2, INK, "Bold")
        text(d, (W / 2 + 40, 700), "khi công thức cần đọc các giá trị ghi nhận theo từng ngày", 28 * s2, BLUE)
    role_tag(img, d, CB, "C&B")

SCENES = [(-OFFSET, 3.2, "h_chay"), (3.2, 24.3, "form"), (24.3, 48.2, "rule"), (48.2, 65.6, "data"), (65.6, 144.5, "daily"),
          (144.5, 190.2, "endcyc"), (190.2, 216.4, "compare"), (216.4, 999, "note")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv82n"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 8
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p82n_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p82n_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
