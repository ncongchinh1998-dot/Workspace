"""PHẦN 9.1 — THỰC HÀNH BẰNG TÌNH HUỐNG CỤ THỂ (mở đầu: 4 yếu tố)
Chưa có tư liệu riêng → dùng lại màn hình phần 8 (form công thức lương, file thành phần lương) + sơ đồ minh hoạ."""
import sys, math
from hw_core import *
from part81 import sub_card, full_of, shot_xy, FORM_FULL, XF, F, IMG_FORM, mini_chip, badge
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p91.wav"
OFFSET = 1.0
VOICE_DUR = 104.89
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan9_1_Thuc_hanh_tinh_huong.mp4"
HD = dict(p9=-0.6)
SFX_AT = [0.0]

IMG_ID = U + "TPL_trả_ID_kèm_mục_đích_sử_dụng.png"; ID_FULL = full_of(2878, 1655); XI = shot_xy(ID_FULL)
COL_TEN = (99, 517, 261, 1500); COL_GT = (1114, 517, 1657, 1500)

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
def form(img): fs_shot(img, IMG_FORM, FORM_FULL, FORM_FULL, 0)

FOUR = [("Thành phần lương", "db", GREEN), ("Công thức tính", "fx", BLUE),
        ("Cách thể hiện\ntrên bảng lương", "chart", ORANGE), ("Cách chạy\ncông thức", "run", NAVY)]
def four_cards(d, t, t0, y=560, step=0.25, hi=None):
    for i, (lab, kind, col) in enumerate(FOUR):
        x = 330 + i * 420
        vcard(d, x, y, 380, 340, pop(t, t0 + i * step), col, kind, lab, 28, True, f"0{i + 1}")
        if hi is not None and hi == i: hl(d, (x - 190, y - 170, x + 190, y + 170), t)

def sc_h_p9(img, d, t): sub_card(img, d, t, HD["p9"], "PHẦN 9", ["THỰC HÀNH BẰNG", "TÌNH HUỐNG CỤ THỂ"], 96)

def sc_recap(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Kết hợp các cấu phần đã học", 3.9, size=56)
    for i, (st, lab, kind, col) in enumerate([(6.2, "Thành phần lương", "db", GREEN), (7.2, "Nhóm công thức", "logic", NAVY), (8.5, "Công thức lương", "fx", BLUE)]):
        vcard(d, 300 + i * 380, 520, 340, 320, pop(t, st), col, kind, lab, 28, True)
    arrow(d, 1250, 520, 1370, 520, p(t, 11.0, 0.4), ORANGE, 8)
    vcard(d, 1600, 520, 400, 360, pop(t, 12.8), ORANGE, "doc", "Tình huống\ncụ thể", 30, True)
    role_tag(img, d, CB, "C&B", pop(t, 4.2, 0.4))

def sc_goal(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Mục tiêu của phần này", 14.2, size=56)
    s_ = pop(t, 16.2)
    if s_ > 0.01:
        card(d, 470, 520, 560, 300, s_, True, (130, 140, 160))
        text(d, (470, 520), "Ghi nhớ một\ncông thức mẫu", 36 * s_, GREY)
        badge(d, 720, 400, False, pop(t, 15.7, 0.4), 30)
    s1 = pop(t, 19.5)
    if s1 > 0.01:
        card(d, 1100, 520, 440, 300, s1, True, BLUE)
        text(d, (1100, 520), "Yêu cầu tính\nlương thực tế", 32 * s1, BLUE)
    arrow(d, 1330, 520, 1420, 520, p(t, 21.2, 0.4), ORANGE, 8)
    s2 = pop(t, 21.4)
    if s2 > 0.01:
        card(d, 1640, 520, 400, 300, s2, True, GREEN)
        text(d, (1640, 520), "Quy tắc thiết lập\ntrên Haraworks", 30 * s2, GREEN)
        badge(d, 1830, 400, True, pop(t, 22.6, 0.4), 30)
    role_tag(img, d, CB, "C&B")

def sc_four(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Bốn yếu tố chính khi xây dựng công thức lương", 24.3, size=52)
    four_cards(d, t, 30.8, hi=0 if t >= 33.0 else None)
    role_tag(img, d, CB, "C&B")

def sc_f1(img, d, t):
    fs_shot(img, IMG_ID, ID_FULL, ID_FULL, 0)
    top_title(d, t, "01 · Thành phần lương", 35.1)
    if 39.3 <= t < 41.5: hl(d, XI(*COL_TEN), t)
    if t >= 41.6: hl(d, XI(*COL_GT), t)
    if t < 39.2: chip_bar(d, t, [(35.1, "Dữ liệu cần dùng để tính đã có trên Haraworks hay chưa?", NAVY)], size=24)
    elif t < 41.5: chip_bar(d, t, [(39.2, "Đang được ghi nhận tại thành phần lương nào?", NAVY)], size=24)
    else: chip_bar(d, t, [(41.5, "Giá trị của thành phần lương được hình thành thế nào theo từng ngày?", NAVY)], size=23)

def sc_f2(img, d, t):
    form(img)
    top_title(d, t, "02 · Công thức tính", 46.9)
    if t >= 47.4: hl(d, XF(*F["CT"]), t)
    if t < 53.4: chip_bar(d, t, [(49.1, "Khoản này tính theo quy tắc nào? Có điều kiện áp dụng hay không?", NAVY)], size=23)
    else: chip_bar(d, t, [(53.4, "Kết hợp các thành phần lương thế nào để cho ra kết quả mong muốn?", NAVY)], size=23)
    role_tag(img, d, CB, "C&B")

def sc_f3(img, d, t):
    form(img)
    top_title(d, t, "03 · Cách thể hiện trên bảng lương", 59.9)
    if t >= 60.3: hl(d, XF(*F["CTH"]), t)
    chip_bar(d, t, [(62.6, "Lấy dữ liệu theo cách nào: Tổng, Giá trị cuối cùng, Giá trị cuối cùng khác không…", NAVY)], size=22)
    role_tag(img, d, CB, "C&B")

def sc_f4(img, d, t):
    form(img)
    top_title(d, t, "04 · Cách chạy công thức", 72.1)
    if t >= 72.5: hl(d, XF(*F["CHAY"]), t)
    chip_bar(d, t, [(74.3, "Xét & tính theo từng ngày, hay chỉ một lần tại ngày cuối chu kỳ lương?", NAVY)], size=23)
    role_tag(img, d, CB, "C&B")

def sc_combine(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Bốn yếu tố phối hợp tạo ra kết quả công thức", 81.2, size=52)
    hi = None
    for i, st in enumerate([89.8, 91.5, 92.7, 94.7]):
        if t >= st: hi = i
    four_cards(d, t, 81.3, y=440, step=0.12, hi=hi)
    for i in range(4):
        arrow(d, 330 + i * 420, 620, 960, 760, p(t, 83.2, 0.4), ORANGE, 5)
    s_ = pop(t, 83.6)
    if s_ > 0.01:
        card(d, W / 2, 820, 520, 110, s_, True, ORANGE)
        text(d, (W / 2, 820), "Kết quả công thức", 32 * s_, NAVY)
    pill(d, W / 2 + 60, 965, 1000, 66, RED, "Kết quả chưa đúng → lần lượt kiểm tra lại bốn yếu tố", 24, pop(t, 86.0))
    role_tag(img, d, CB, "C&B")

def sc_next(img, d, t):
    paste(img, BOARD)
    k = pop(t, 96.8)
    pill(d, W / 2, 330, 360, 76, NAVY, "Phần tiếp theo", 32, k)
    s_ = pop(t, 99.4, 0.6)
    if s_ > 0.01:
        card(d, W / 2, 590, 1240, 320, s_, True, ORANGE)
        icon(d, "doc", W / 2 - 480 * s_, 590, s_, ORANGE, 90)
        text(d, (W / 2 + 80, 550), "ÁP DỤNG VÀO TÌNH HUỐNG CỤ THỂ", 48 * s_, NAVY)
        k2 = pop(t, 101.6)
        if k2 > 0.01: text(d, (W / 2 + 80, 630), "Phân tích cách xây dựng công thức từ nhu cầu thực tế", 26 * k2, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B", k)

SCENES = [(-OFFSET, 3.5, "h_p9"), (3.5, 14.0, "recap"), (14.0, 23.8, "goal"), (23.8, 35.0, "four"), (35.0, 46.3, "f1"),
          (46.3, 58.6, "f2"), (58.6, 71.3, "f3"), (71.3, 81.0, "f4"), (81.0, 96.5, "combine"), (96.5, 999, "next")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv91"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 4
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p91_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p91_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
