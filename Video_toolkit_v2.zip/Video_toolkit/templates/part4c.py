"""PHẦN 4 — CHU KỲ LƯƠNG & THAM SỐ LƯƠNG (voice mới 23/10)
Các cảnh cũ giữ nguyên bố cục, chạy theo nhịp voice mới (ánh xạ thời gian theo từng từ).
Cảnh dựng mới: thu nhập thay đổi theo ngày, phạm vi xem phiếu lương (màn hình hệ thống), chu kỳ chạy thử,
thời điểm khóa dữ liệu, thời gian duyệt công tối đa (màn hình + ví dụ + phân biệt 2 quy tắc)."""
import sys, math
sys.path.insert(0, "/home/claude")

# ---- nạp các cảnh cũ của Phần 4, sửa chữ cho khớp lời đọc mới ----
SRC = open("/home/claude/part4.py").read()
SRC = SRC[:SRC.index("SCENES = [")]
PATCH = [
    ('"Nhân viên bổ sung\\ndữ liệu đến khi nào?"', '"Nhân viên được tạo dữ liệu\\ntrong khoảng thời gian nào?"'),
    ('"Sau khóa, ai xử lý\\nngoại lệ?"', '"Sau khóa, ai còn xử lý\\ndữ liệu phát sinh?"'),
    ('"Hai phần nền tảng"', '"Hai nội dung ảnh hưởng trực tiếp đến tính lương"'),
    ('"Hiểu ý nghĩa\\ncủa từng phần"', '"Ý nghĩa của\\ntừng nội dung"'),
    ('"Biết thông tin nào\\ncần kiểm tra"', '"Thông tin C&B\\ncần kiểm tra"'),
    ('"Hiểu liên quan thế nào\\nđến dữ liệu tính lương"', '"Ảnh hưởng đến\\nquá trình tính lương"'),
    ('        pill(d, 1260, 900, 300, 64, RED, "Quan trọng nhất", 26, k)\n        sparks(', '        pass\n        if False: sparks('),
    ('"Không tách rời khỏi bảng lương"', '"Liên quan trực tiếp đến dữ liệu tính lương"'),
    ('        if k > 0.01: pill(d, W / 2, 200, 460, 66, RED, "Điểm quan trọng cần ghi nhớ", 26, k)', '        pass'),
    ('"Chu kỳ lương\\nTính lương cho kỳ nào"', '"Chu kỳ lương\\nKhoảng thời gian lấy dữ liệu để tính"'),
    ('"Tham số lương\\nMốc thời gian & dữ liệu đầu vào"', '"Tham số lương\\nKiểm soát cập nhật, duyệt & chốt"'),
    ('"Đúng phạm vi áp dụng"', '"Đúng phạm vi nhân viên được xem phiếu lương"'),
    ('"Dữ liệu đầu vào đã cập nhật, duyệt & khóa"', '"Dữ liệu đầu vào đã cập nhật & phê duyệt"'),
    ('"Dùng sau khi doanh nghiệp\\ngo-live tính lương tự động"', '"Dùng khi doanh nghiệp đã chính thức\\nvận hành tính lương tự động"'),
    ('"Hệ thống tự động\\nchạy lương hằng ngày"', '"Nếu thiết lập chạy lương\\ntự động hàng ngày"'),
    ('"Hoàn tất kỳ lương &\\nthanh toán cho nhân viên"', '"Hoàn tất tính lương &\\nchi lương cho nhân viên"'),
    ('"Số liệu là kết quả cuối cùng\\ntại thời điểm chi lương"', '"Số liệu giữ theo kết quả\\nđã xác định khi chi lương"'),
    ('"Vẫn xem được thu nhập kỳ đã chốt"', '"Vẫn xem được phiếu lương kỳ đã chốt"'),
    ('"Kiểm tra khi xây dựng &\\nđiều chỉnh công thức mới"', '"Kiểm tra công thức lương mới\\ntrước khi dùng chính thức"'),
    ('"Được cấp quyền xem"', '"Người có quyền vẫn xem"'),
    ('icon(d, "run", 1530, 380, k, CYAN, 46)', 'pass'),
    ('pill(d, 1530, 470, 200, 60, CYAN, f"Ngày {day:02d}", 26, k)', 'pass'),
    ('pill(d, 1250, 990, 560, 70, GREEN, "Thấy thu nhập thay đổi theo từng ngày", 26, pop(t, c("thay đổi", 89.35)))', 'pass'),
    ('.get(app_t(13.0 + (t - 80) * 0.6))', '.get(min(12.2, 10.6 + max(0.0, t - 80) * 0.15))'),
    ('"Một nguyên tắc kiểm soát dữ liệu"', '"Kiểm soát dữ liệu theo một luồng rõ ràng"'),
    ('"Các mốc thời gian không tồn tại riêng lẻ"', '"Các thiết lập trong tham số lương"'),
    ('"Quản lý được duyệt\\nđến khi nào?"', '"Quản lý được duyệt\\ntrong khoảng thời gian nào?"'),
]
for a, b in PATCH:
    if a in SRC: SRC = SRC.replace(a, b)
    else: print("PATCH MISS:", a[:40])
G = {"__name__": "p4old"}
_argv = sys.argv; sys.argv = ["p4old"]
exec(compile(SRC, "part4_old", "exec"), G)
sys.argv = _argv
globals().update({k: v for k, v in G.items() if not k.startswith("__")})
H_OLD = dict(H)

VOICE = A + "voice_p4_v3.wav"
OFFSET = 1.5
VOICE_DUR = 462.57
TOTAL = OFFSET + VOICE_DUR + 0.8
OUT = "/mnt/user-data/outputs/Phan4_Chu_ky_luong_va_Tham_so_luong.mp4"
HN = dict(ckl=40.4, scope=149.6, delete=209.3, tsl=247.1, lock=281.4, after=355.1, link=396.5)
SFX_AT = [0.0] + [OFFSET + v for v in HN.values()]
U = "/mnt/user-data/uploads/"

from cues import Cues
cn = Cues(A + "words_p4_v3.json")
from remap_voice import make_maps
M, Minv = make_maps(A + "words_p4.json", A + "words_p4_v3.json")
def old(fn): return lambda img, d, t: fn(img, d, Minv(t))

HL_PAD = 10
def hl(d, box, t=0.0):
    b = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(b, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))

_shots = {}
_BOARD_FULL = BG.copy(); paste(_BOARD_FULL, BOARD)        # nền BOARD hoàn chỉnh để che vùng cũ
def panel(img, d, path, crop, x, y, w, s=1.0):
    """Đặt một vùng ảnh hệ thống (crop) vào khung tại (x, y) rộng w. Trả về hàm đổi toạ độ ảnh gốc -> khung hình."""
    if path not in _shots: _shots[path] = Image.open(path).convert("RGB")
    im = _shots[path].crop(crop); k = w / im.width; h = int(im.height * k)
    if s > 0.01:
        d.rounded_rectangle([x - 8, y - 8, x + w + 8, y + h + 8], 16, fill=WHITE, outline=LINE, width=3)
        img.paste(im.resize((int(w), h), Image.LANCZOS), (int(x), int(y)))
    return lambda x0, y0, x1, y1: (x + (x0 - crop[0]) * k, y + (y0 - crop[1]) * k, x + (x1 - crop[0]) * k, y + (y1 - crop[1]) * k)

# ================= Trạng thái chu kỳ lương: thu nhập thay đổi theo từng ngày =================
def sc_states_new(img, d, t):
    to = Minv(t)
    G["sc_states"](img, d, to)
    if to < 92.54:                      # pha Công khai: thay nhãn cũ bằng thẻ thu nhập tạm tính theo ngày
        T0 = cn("hàng ngày", 86); k = pop(t, T0)
        if k > 0.01:
            day = 5 + int(clamp((t - T0) / 9.0) * 4)                 # ngày chạy tăng dần, thu nhập tạm tính tăng theo
            val = 8_950_000 + (day - 5) * 1_790_000
            card(d, 1640, 390, 380, 200, k, True, CYAN)
            text(d, (1640, 330), f"Ngày {day:02d}", 34 * k, CYAN)
            text(d, (1640, 385), "Thu nhập tạm tính", 22 * k, GREY, "Bold")
            text(d, (1640, 440), f"{val:,.0f} đ".replace(",", "."), 32 * k, GREEN)
            arrow(d, 1400, 390, 1445, 390, k, CYAN, 5)
        pill(d, 1250, 990, 640, 70, GREEN, "Nhân viên theo dõi kết quả thu nhập trong kỳ", 26, pop(t, cn("theo dõi", 94)))

# ================= Phạm vi nhân viên được xem phiếu lương: màn hình hệ thống =================
IMG_TC = U + "Tùy_chỉnh.png"           # 2879x1533 · Chỉnh sửa chu kỳ lương
TC_CROP = (1190, 230, 2420, 1040)
def sc_scope_new(img, d, t):
    to = Minv(t)
    G["sc_scope"](img, d, to)
    # che phần thẻ minh hoạ cũ bên trái bằng màn hình hệ thống thật
    img.paste(_BOARD_FULL.crop((40, 200, 740, 980)), (40, 200))
    s_ = pop(t, 153.2)
    if s_ > 0.01:
        X = panel(img, d, IMG_TC, TC_CROP, 60, 230, 640, s_)
        if t >= cn("đơn vị trí", 153):
            if t < cn("chọn tất", 162): hl(d, X(1830, 750, 2395, 1015), t)       # Đơn vị, VTCV muốn mở kì lương
            elif t < cn("chọn tùy", 168): hl(d, X(1830, 815, 2395, 862), t)       # Tất cả
            else: hl(d, X(1830, 860, 2390, 1015), t)                               # Tùy chỉnh + Chọn đối tượng
    hcard(d, 380, 820, 640, 110, pop(t, cn("nhân viên nào", 157)), NAVY, "people", "Xác định nhân viên nào được xem phiếu lương", 24)
    if t >= cn("theo từng giai", 194) - 0.3: pill(d, 380, 935, 600, 66, ORANGE, "Triển khai theo từng giai đoạn", 26, pop(t, cn("theo từng giai", 194)))

# ================= Xóa chu kỳ lương: chu kỳ chạy thử / kiểm tra kết quả =================
def sc_delete_new(img, d, t):
    to = Minv(t)
    if to >= c("tuy nhiên", 204.85):
        G["sc_delete"](img, d, to); return
    G["sc_delete"](img, d, to)
    # vẽ lại cột phải: 2 loại chu kỳ theo voice mới
    img.paste(_BOARD_FULL.crop((1220, 260, 1800, 790)), (1220, 260))
    img.paste(_BOARD_FULL.crop((0, 0, W, 140)), (0, 0)); d2 = ImageDraw.Draw(img)
    board_title(d2, t, "Chu kỳ dùng để chạy thử, kiểm tra kết quả", 211.8)
    fade = p(t, cn("được xóa", 216), 0.5)
    for j, (st, lab) in enumerate([(cn("chạy thử", 213), "Kỳ chạy thử"), (cn("kiểm tra kết", 213), "Kỳ kiểm tra kết quả")]):
        hcard(d2, 1500, 400 + j * 170, 440, 120, pop(t, st), mix_color(BLUE, 1 - 0.6 * fade), "calendar", lab, 30)

# ================= Thời điểm khóa dữ liệu công phép (màn hình Tham số lương đầy đủ) =================
IMG_LOCK = A + "ts_clean.png"             # 1280x696 · Chỉnh sửa tham số lương (đã xóa khung đỏ vẽ sẵn, khung đỏ do video tự vẽ)
FULL_TS = (0, 0, 1240, 450)        # toàn màn hình: thanh menu trái, đường dẫn, toàn bộ form
F_BREAD = (40, 0, 326, 30); F_LOCK = (496, 88, 1036, 145); F_APPR = (496, 296, 760, 356); F_LUI = (772, 352, 1036, 410)
def ts_screen(img, d, x, y, w, s=1.0, appr3=False):
    """Toàn màn hình Tham số lương. appr3: sửa đè giá trị 'Thời gian duyệt công tối đa' thành 3 cho khớp ví dụ."""
    X = panel(img, d, IMG_LOCK, FULL_TS, x, y, w, s)
    if appr3 and s > 0.01:
        b = X(505, 326, 600, 350); d.rectangle(b, fill=WHITE)
        k = (b[2] - b[0]) / 95
        f = ImageFont.truetype(A + "Inter.ttf", max(8, int(12.5 * k))); f.set_variation_by_name("Regular")
        d.text((b[0] + 6 * k, b[1] + 3 * k), "3", font=f, fill=(24, 24, 27))
    return X

def sc_lock(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thời điểm khóa dữ liệu công phép", 284.9)
    s_ = pop(t, 285.0)
    X = ts_screen(img, d, 40, 190, 1220, s_)
    if s_ > 0.9 and t < 288.5: hl(d, X(*F_BREAD), t)                      # đường dẫn: Danh sách tham số lương > Chỉnh sửa
    if t >= 288.5: hl(d, X(*F_LOCK), t)                                    # Ngày khóa công, phép · Giờ khóa công, phép
    items = [(cn("đây là mốc", 289), "Mốc ngừng cập nhật\ndữ liệu của kỳ lương", "lock", RED),
             (cn("nhân viên không", 295), "Nhân viên không gửi /\nđiều chỉnh đề nghị của kỳ", "people", BLUE),
             (cn("quản lý cũng", 302), "Quản lý không phê duyệt\nđề nghị thuộc kỳ đó", "check", NAVY)]
    for j, (st, lab, kind, col) in enumerate(items):
        hcard(d, 1600, 330 + j * 190, 560, 150, pop(t, st), col, kind, lab, 24, True)
    role_tag(img, d, CB, "C&B")

DAYS = [("29", "Th.8"), ("30", "Th.8"), ("31", "Th.8"), ("01", "Th.9"), ("02", "Th.9"), ("03", "Th.9")]
def day_strip(d, t, y, today, ok, locked=(), x0=420, cw=180):
    for i, (dd, mm) in enumerate(DAYS):
        x = x0 + i * cw
        on = i in ok; lk = i in locked
        fill = (220, 245, 228) if on else ((255, 232, 232) if lk else (238, 242, 252))
        out = GREEN if on else (RED if lk else (205, 212, 230))
        d.rounded_rectangle([x - cw * 0.43, y - 46, x + cw * 0.43, y + 46], 14, fill=fill, outline=out, width=4 if (on or lk) else 2)
        text(d, (x, y - 12), dd, 36, INK); text(d, (x, y + 24), mm, 20, GREY, "Bold")
        if on: badge(d, x + cw * 0.38, y - 42, True, 1.0, 17)
        if lk: icon(d, "lock", x + cw * 0.38, y - 42, 1.0, RED, 24)
        if i == today:
            text(d, (x, y - 88), "Hôm nay", 24, ORANGE)
            d.polygon([(x - 13, y - 70), (x + 13, y - 70), (x, y - 55)], fill=ORANGE)

def sc_lock_ex(img, d, t):
    """Ví dụ khóa 12h 02/09: màn hình hệ thống bên trái (khoanh đúng thiết lập đang nói), diễn biến ngày bên phải."""
    paste(img, BOARD)
    board_title(d, t, "Ví dụ: dữ liệu kỳ lương tháng 8 khóa lúc 12h ngày 02/09", 308.7, size=46)
    T_BEFORE, T_AFTER, T_RANGE = cn("trước thời điểm", 313), cn("từ mười hai", 321), cn("dù ngày", 331)
    X = ts_screen(img, d, 30, 230, 960, 1.0, appr3=True)
    hl(d, X(*F_LOCK), t)                                                     # Ngày khóa 02 · Giờ 12:00
    bx = X(*F_LOCK); text(d, ((bx[0] + bx[2]) / 2, bx[1] - 30), "Khóa ngày 02 lúc 12:00", 22, RED, "Bold")
    if t >= T_BEFORE + 2.0:
        hl(d, X(*F_APPR), t)                                                 # Thời gian duyệt công tối đa = 3
        bx = X(*F_APPR); text(d, ((bx[0] + bx[2]) / 2, bx[3] + 36), "Duyệt tối đa 3 ngày", 22, RED, "Bold")
    if t < T_AFTER:
        ok, lk, lab, col = ((2, 3, 4) if t >= T_BEFORE else ()), (), "Trước 12h ngày 02/09", GREEN
        note = "Vẫn được bổ sung / phê duyệt dữ liệu kỳ tháng 8\nnếu còn trong thời gian cho phép (3 ngày)"
    else:
        ok, lk, lab, col = (3, 4), (2,), "Từ 12h ngày 02/09", RED
        note = "Kỳ tháng 8 đã khóa: ngày 31/08 không tạo,\nđiều chỉnh hay phê duyệt được nữa"
    pill(d, 1420, 260, 420, 66, col, lab, 28, pop(t, 309.5 if t < T_AFTER else T_AFTER))
    day_strip(d, t, 480, 4, ok, lk, x0=1065, cw=148)
    if t >= T_BEFORE:
        hcard(d, 1420, 700, 820, 150, pop(t, (T_BEFORE if t < T_AFTER else T_AFTER) + 0.4), col, "calendar" if t < T_AFTER else "lock", note, 23, True)
    if t >= T_RANGE:
        pill(d, 1420, 880, 820, 66, ORANGE, "dù 31/08 vẫn nằm trong 3 ngày gần nhất", 24, pop(t, T_RANGE))
    role_tag(img, d, CB, "C&B")

def sc_three_rules(img, d, t):
    """Hiểu đơn giản 3 thiết lập: khoanh lần lượt trên màn hình hệ thống, thẻ giải thích bên dưới cùng màu."""
    paste(img, BOARD)
    board_title(d, t, "Hiểu đơn giản ba thiết lập", 338.2)
    X = ts_screen(img, d, 220, 150, 1480, 1.0, appr3=True)
    rules = [(cn("số ngày được", 338), F_LUI, "Số ngày được phép tạo công lùi", "Nhân viên được tạo\ncông lùi đến ngày nào", BLUE, "people"),
             (cn("thời gian duyệt", 343), F_APPR, "Thời gian duyệt công tối đa", "Quản lý được duyệt\nlùi đến ngày nào", GREEN, "check"),
             (cn("còn thời điểm", 347), F_LOCK, "Thời điểm khóa dữ liệu", "Khi nào việc cập nhật\ndữ liệu của kỳ phải dừng", RED, "lock")]
    cur = None
    for j, r in enumerate(rules):
        if t >= r[0]: cur = j
    for j, (st, box, name, mean, col, kind) in enumerate(rules):
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        x = 560 + j * 440
        card(d, x, 920, 420, 200, s_, j == cur, col)
        text(d, (x, 860), name, fit_size(d, name, 23, "ExtraBold", 390) * s_, col, "ExtraBold")
        text(d, (x, 945), mean, 24 * s_, INK, "Bold")
    if cur is not None: hl(d, X(*rules[cur][1]), t)
    role_tag(img, d, CB, "C&B")

def sub(key, kicker, lines, size=96):
    return lambda img, d, t: sub_card(img, d, t, HN[key], kicker, lines, size)

def sc_part_new(img, d, t): G["sc_part"](img, d, min(t, 1.2))

SCENES = [(-OFFSET, 3.6, "part"), (3.6, HN["ckl"], "intro"), (HN["ckl"], 42.4, "h_ckl"), (42.4, M(52.38), "ckl_def"),
          (M(52.38), M(59.87), "ckl_rec"), (M(59.87), 74.4, "ckl_states"), (74.4, HN["scope"], "states"),
          (HN["scope"], 153.0, "h_scope"), (153.0, HN["delete"], "scope"), (HN["delete"], 211.8, "h_delete"),
          (211.8, HN["tsl"], "delete"), (HN["tsl"], 249.2, "h_tsl"), (249.2, HN["lock"], "tsl_problem"),
          (HN["lock"], 284.9, "h_lock"), (284.9, 308.6, "lock"), (308.6, 338.2, "lock_ex"), (338.2, HN["after"], "three_rules"),
          (HN["after"], 358.3, "h_after"), (358.3, 378.7, "after"), (378.7, HN["link"], "principle"),
          (HN["link"], 399.3, "h_link"), (399.3, 437.6, "link"), (437.6, 446.8, "outro1"), (446.8, 999, "outro2")]

def intro_old(img, d, t):
    to = Minv(t)
    fn = G["sc_intro1"] if to < 13.94 else (G["sc_intro2"] if to < 20.13 else G["sc_intro3"])
    fn(img, d, to)

FN = dict(part=sc_part_new, intro=intro_old,
          h_ckl=sub("ckl", "PHẦN 4", ["CHU KỲ LƯƠNG"], 118), ckl_def=old(G["sc_ckl_def"]), ckl_rec=old(G["sc_ckl_rec"]),
          ckl_states=old(G["sc_ckl_states"]), states=sc_states_new,
          h_scope=sub("scope", "CHU KỲ LƯƠNG", ["PHẠM VI NHÂN VIÊN", "ĐƯỢC XEM PHIẾU LƯƠNG"], 84), scope=sc_scope_new,
          h_delete=sub("delete", "CHU KỲ LƯƠNG", ["XÓA CHU KỲ LƯƠNG"], 96), delete=sc_delete_new,
          h_tsl=sub("tsl", "PHẦN 4", ["THAM SỐ LƯƠNG"], 118), tsl_problem=old(G["sc_tsl_problem"]),
          h_lock=sub("lock", "THAM SỐ LƯƠNG", ["THỜI ĐIỂM KHÓA", "DỮ LIỆU CÔNG PHÉP"], 96), lock=sc_lock,
          lock_ex=sc_lock_ex, three_rules=sc_three_rules,
          h_after=sub("after", "THAM SỐ LƯƠNG", ["KIỂM SOÁT DỮ LIỆU", "SAU THỜI ĐIỂM KHÓA"], 80), after=old(G["sc_after"]),
          principle=old(G["sc_principle"]), h_link=sub("link", "PHẦN 4", ["MỐI LIÊN HỆ", "VỚI BẢNG LƯƠNG"], 96),
          link=old(G["sc_link"]), outro1=old(G["sc_outro1"]), outro2=old(G["sc_outro2"]))

def preview(times):
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.resize((960, 540)).save(f"/tmp/pv4c_{tv}.png")

N = 12
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p4c_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p4c_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
