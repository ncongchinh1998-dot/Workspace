"""PHẦN 6 — THÀNH PHẦN LƯƠNG · đoạn 6.2 (dựng trên khung của 6.1)
Mục: 6.1 Thành phần lương là gì · Kiểm tra thành phần lương đã có trên hệ thống ·
     Nguyên tắc vận hành của thành phần lương · Tạo mới thành phần lương.
Quy chuẩn: màn hình hệ thống full khung rồi phóng vào vùng đang nói, khoanh đỏ đúng chỗ được nhắc,
không thêm chữ trùng nội dung đã có trên màn hình, nhãn vai trò góc trái dưới, âm thanh mẫu ở mỗi tiêu đề mục.
Mốc thời gian (voice-time) lấy từ nhận dạng giọng nói từng từ (words_p61.json)."""
import sys, math
from hw_core import *
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p62.wav"
OFFSET = 1.0
VOICE_DUR = 339.33
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan6_2_Nhap_dat_lai_xuat_du_lieu_TPL.mp4"
HD = dict(nhap=-0.6, datlai=114.1, xuat=154.0, sua=226.8, dung=235.7, tk=294.8)      # tiêu đề mục (voice-time)
SFX_AT = [0.0] + [OFFSET + v for v in list(HD.values())[1:]]

# ---------- Tư liệu ----------
IMG_3YT = U + "3_YẾU_TỐ_CÂU_THÀNH_BẢNG_LƯƠNG.png"                  # 2120x1199
IMG_CXT = U + "Chuỗi_xác_thực.png"                                 # 2805x1532 danh sách TPL
IMG_NT = U + "nguyên_tắc_vận_hành_của_Thành_phần_lương.png"        # 2879x1701 file Excel TPL hệ thống
IMG_CTCT = U + "Hình_ảnh_công_thức_chi_tiết.png"                   # 2773x1497 chỉnh sửa công thức
IMG_TPLCT = U + "TPL_dùng_trong_công_thức_lương.png"                # 2777x1526 danh sách công thức lương
REC_DS = U + "Màn_hình_thành_phần_lương.mp4"                       # 1912x1016
REC_TAO = U + "Tạo_TPL.mp4"                                        # 1912x1016
REC_XL = U + "File_excel_tổng_hợp_DS_TPL_gửi_khách.mp4"            # 1824x1078
REC_TK = U + "Tìm_kiếm_tpl_trên_excel.mp4"                         # 1824x1078

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    w_ = 6 + int(2 * abs(math.sin(t * 5)))
    if kind == "rect": d.rounded_rectangle(box, 10, outline=RED, width=w_)
    else: d.ellipse(box, outline=RED, width=w_)

def badge(d, x, y, ok, s, r0=24):
    if s <= 0.01: return
    r = r0 * s; w = max(int(6 * s), 1)
    d.ellipse([x - r, y - r, x + r, y + r], fill=GREEN if ok else RED)
    if ok: d.line([x - r * 0.45, y, x - r * 0.1, y + r * 0.4, x + r * 0.5, y - r * 0.35], fill=WHITE, width=w, joint="curve")
    else:
        d.line([x - r * 0.4, y - r * 0.4, x + r * 0.4, y + r * 0.4], fill=WHITE, width=w)
        d.line([x - r * 0.4, y + r * 0.4, x + r * 0.4, y - r * 0.4], fill=WHITE, width=w)

def sub_card(img, d, t, t0, kicker, lines, size=96):
    paste(img, SECTION)
    pill(d, 280, 280, 340, 76, BLUE, kicker, 30, pop(t, t0 + 0.05), weight="ExtraBold")
    for j, line in enumerate(lines):
        k = p(t, t0 + 0.15 + j * 0.12, 0.45)
        if k > 0: text(d, (110, 430 + j * size * 1.12 + (1 - k) * 50), line, size, NAVY, anchor="lm", align="left")
    underline(d, 115, 430 + (len(lines) - 1) * size * 1.12 + size * 0.75, 700, p(t, t0 + 0.45, 0.5))
    person(img, d, CB, 1220, 900, 340, pop(t, t0 + 0.4, 0.5), "C&B", 30)

def shot_xy(box):
    k = 1920 / (box[2] - box[0])
    return lambda x0, y0, x1, y1: ((x0 - box[0]) * k, (y0 - box[1]) * k, (x1 - box[0]) * k, (y1 - box[1]) * k)
def full_of(iw, ih): return box169(iw / 2, ih / 2, iw, iw, ih)
ZOOM_MILD = 0.0          # mức phóng: 0 = giữ nguyên màn hình, 1 = phóng sát vùng cần nói
def mild(box, full):
    return tuple(full[i] + (box[i] - full[i]) * ZOOM_MILD for i in range(4))

# Bản quay: full khung rồi phóng dần vào box1 (toạ độ khung đã ghép 1920x1080)
FULLB = (0, 0, 1920, 1080)
_clips = {}
REC_WEB = dict(crop=(0, 0, 1912, 1016), size=(1920, 1020), y0=30, sw=1912)   # bản quay web
REC_XLS = dict(crop=(0, 0, 1824, 1026), size=(1920, 1080), y0=0, sw=1824)    # bản quay Excel
def recz(img, key, path, tc, box1, k, spec=REC_WEB):
    if key not in _clips: _clips[key] = Clip(path, spec["size"], spec["crop"])
    fr = _clips[key].get(tc); bg = Image.new("RGB", (1920, 1080), WHITE)
    if fr is not None: bg.paste(fr, (0, spec["y0"]))
    box1 = mild(box1, FULLB)
    k = ease(clamp(k)); box = tuple(FULLB[i] + (box1[i] - FULLB[i]) * k for i in range(4))
    img.paste(bg.resize((1920, 1080), Image.LANCZOS, box=box), (0, 0))
    return box
def RZ(box, x0, y0, x1, y1, spec=REC_WEB):
    s_ = 1920 / spec["sw"]; kk = 1920 / (box[2] - box[0]); y_ = spec["y0"]
    return ((x0 * s_ - box[0]) * kk, (y0 * s_ + y_ - box[1]) * kk, (x1 * s_ - box[0]) * kk, (y1 * s_ + y_ - box[1]) * kk)
def piece(t, pts):
    if t <= pts[0][0]: return pts[0][1]
    for (a_, ca), (b_, cb) in zip(pts, pts[1:]):
        if a_ <= t <= b_: return ca + (t - a_) * (cb - ca) / (b_ - a_)
    return pts[-1][1]

# ---------- Tư liệu 6.2 ----------
REC_NHAP = U + "Nhập_dữ_liệu_TPL_1.mp4"        # 1824x1078 · tải mẫu → điền → tải lên
REC_DL = U + "Đặt_lại_dữ_liệu_TPL_1.mp4"        # 1912x1016 · hộp thoại Xuất dữ liệu TPL / Đặt lại dữ liệu
REC_DT = U + "Đổi_tên_TPL_1.mp4"                # 1824x1078 · đổi tên TPL → công thức tự cập nhật
IMG_XTH = U + "Xuất_tổng_hợp_1.png"             # 2879x1709
IMG_XCT = U + "Xuất_chi_tiết_1.png"             # 2851x1645
IMG_CTH = U + "Cách_thể_hiện_trên_bảng_lương_1.png"   # 2750x1522 form thêm mới công thức lương
def scr(img, key, path, tc, spec=REC_WEB):
    return recz(img, key, path, tc, FULLB, 0, spec)
def B(x0, y0, x1, y1, spec=REC_WEB): return RZ(FULLB, x0, y0, x1, y1, spec)
CTH_FULL = full_of(2750, 1522); XC = shot_xy(CTH_FULL)
XTH_FULL = full_of(2879, 1709); XT = shot_xy(XTH_FULL)
XCT_FULL = full_of(2851, 1645); XD = shot_xy(XCT_FULL)

# ================= Nhập dữ liệu vào thành phần lương =================
def sc_h_nhap(img, d, t): sub_card(img, d, t, HD["nhap"], "PHẦN 6", ["NHẬP DỮ LIỆU VÀO", "THÀNH PHẦN LƯƠNG"], 96)

def sc_intro(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thành phần lương do C&B tạo: nhập dữ liệu theo từng nhân viên", 2.0, size=48)
    steps = [(10.9, "Tải file mẫu", "doc", BLUE), (12.3, "Điền dữ liệu\ncác cột có dấu *", "sheet", GREEN), (51.2, "Tải file lên\n& nhập dữ liệu", "db", ORANGE)]
    for i, (st, lab, kind, col) in enumerate(steps):
        vcard(d, 520 + i * 440, 520, 380, 340, pop(t, 2.3 + i * 0.25), col, kind, lab, 28, i == 0, f"0{i + 1}")
    role_tag(img, d, CB, "C&B", pop(t, 3.6, 0.4))

def sc_nhap(img, d, t):
    ct = piece(t, [(6.9, 0.3), (10.9, 1.6), (12.0, 2.8), (12.25, 7.0), (12.3, 16.6), (17.8, 16.6), (26.6, 60.0), (27.1, 62.0), (48.9, 62.0), (54.2, 87.0)])
    scr(img, "nhap", REC_NHAP, ct, REC_XLS)
    top_title(d, t, "Nhập dữ liệu vào thành phần lương", 6.9)
    if 9.8 <= t < 12.0: hl(d, B(530, 272, 895, 362, REC_XLS), t)                                     # Tải về
    if 13.4 <= t < 17.8:                                                                            # các cột có dấu *
        hl(d, B(40, 295, 243, 372, REC_XLS), t); hl(d, B(445, 295, 760, 372, REC_XLS), t)
    if 27.7 <= t < 48.9: hl(d, B(445, 295, 555, 398, REC_XLS), t)                                   # Ngày lương
    if t < 17.8: chip_bar(d, t, [(14.6, "Các cột không có dấu * có thể để trống", NAVY)], size=24)
    elif t < 27.1: chip_bar(d, t, [(17.8, "Mã chu kỳ lương · mã nhân viên · mã thành phần lương: sao chép từ màn hình tương ứng", ORANGE)], size=22)
    elif t < 48.9:
        if t < 40.2: chip_bar(d, t, [(31.1, "Ngày lương nằm trong khoảng thời gian của chu kỳ lương đang nhập", NAVY)], size=24)
        else: chip_bar(d, t, [(40.2, "Ví dụ kỳ lương tháng 10/2026: từ 01/10/2026 đến 31/10/2026", GREEN)], size=24)
    role_tag(img, d, CB, "C&B")

def sc_note(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Lưu ý: nhập lần sau không tự ghi đè dữ liệu lần trước", 54.4, size=50)
    s0 = pop(t, 60.2)
    if s0 > 0.01:
        card(d, W / 2, 270, 1300, 120, s0, True, RED, (255, 240, 240))
        text(d, (W / 2, 270), "Haraworks ghi nhận tất cả dữ liệu được nhập hàng loạt vào thành phần lương", 30 * s0, RED)
    # ví dụ: hai lần nhập
    k = pop(t, 70.3)
    if k > 0.01:
        card(d, 700, 600, 900, 340, k, True, BLUE)
        text(d, (700, 470), "Thành phần lương: Khoản bổ sung", 30 * k, INK)
        for j, (st, lab, val) in enumerate([(71.1, "Lần nhập 1", "500.000 đ"), (76.3, "Lần nhập 2", "1.000.000 đ")]):
            s_ = pop(t, st)
            if s_ > 0.01:
                y = 560 + j * 100
                d.rounded_rectangle([320, y - 38, 1080, y + 38], 14, fill=(238, 244, 255))
                text(d, (420, y), lab, 26 * s_, GREY, anchor="lm")
                text(d, (1040, y), val, 30 * s_, BLUE, "ExtraBold", anchor="rm")
        badge(d, 1080, 470, True, pop(t, 80.3, 0.4), 30)
    s2 = pop(t, 80.3)
    if s2 > 0.01:
        hcard(d, 1480, 600, 640, 160, s2, GREEN, "check", "Cả hai dữ liệu đều được\nhệ thống ghi nhận", 28, True)
    role_tag(img, d, CB, "C&B")

def sc_cth(img, d, t):
    T_EX = 89.0
    if t < T_EX:
        fs_shot(img, IMG_CTH, CTH_FULL, CTH_FULL, 0)
        top_title(d, t, "Giá trị dùng khi tính lương phụ thuộc cách thể hiện tại công thức lương", 82.8)
        if t >= 85.6: hl(d, XC(1174, 955, 1777, 1073), t)                     # Cách thể hiện trên bảng lương
        role_tag(img, d, CB, "C&B")
        return
    paste(img, BOARD)
    board_title(d, t, "Cùng dữ liệu 500.000 đ và 1.000.000 đ", T_EX)
    for i, (st, lab, val, col) in enumerate([(89.8, "Cách thể hiện: Tổng", "1.500.000 đ", BLUE), (94.9, "Cách thể hiện: Giá trị lớn nhất", "1.000.000 đ", ORANGE)]):
        s_ = pop(t, st)
        if s_ > 0.01:
            x = 560 + i * 800
            card(d, x, 480, 680, 320, s_, True, col)
            text(d, (x, 400), lab, 32 * s_, INK)
            text(d, (x, 500), "Giá trị được sử dụng", 26 * s_, GREY, "Bold")
            text(d, (x, 570), val, 54 * s_, col, "ExtraBold")
    pill(d, W / 2, 790, 900, 76, NAVY, "Sẽ đi sâu cách thể hiện trên bảng lương ở phần Công thức lương", 24, pop(t, 99.3))
    role_tag(img, d, CB, "C&B")

def sc_rel(img, d, t, t0=104.4):
    paste(img, BOARD)
    board_title(d, t, "Mối quan hệ cơ bản cần ghi nhớ", t0)
    s1 = pop(t, t0 + 3.2)
    if s1 > 0.01:
        card(d, 560, 520, 640, 340, s1, True, GREEN)
        icon(d, "db", 560, 430, s1, GREEN, 70)
        text(d, (560, 540), "Thành phần lương", 36 * s1, INK)
        text(d, (560, 600), "là nơi chứa dữ liệu", 28 * s1, GREEN, "Bold")
    arrow(d, 900, 520, 1020, 520, p(t, t0 + 5.6, 0.4), ORANGE, 8)
    s2 = pop(t, t0 + 5.6)
    if s2 > 0.01:
        card(d, 1360, 520, 640, 340, s2, True, BLUE)
        icon(d, "fx", 1360, 430, s2, BLUE, 70)
        text(d, (1360, 540), "Công thức lương", 36 * s2, INK)
        text(d, (1360, 600), "xác định cách sử dụng dữ liệu\nđể thực hiện tính toán", 26 * s2, BLUE, "Bold")
    role_tag(img, d, CB, "C&B", pop(t, t0 + 0.5, 0.4))

# ================= Đặt lại dữ liệu =================
def sc_h_datlai(img, d, t): sub_card(img, d, t, 114.1, "PHẦN 6", ["ĐẶT LẠI DỮ LIỆU"], 110)

def sc_dl_why(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Khi cần điều chỉnh dữ liệu đã nhập", 116.0)
    for j, (st, lab, kind, col) in enumerate([(121.2, "Dữ liệu đã nhập bị sai", "warn", RED), (122.1, "Cần thay thế", "doc", ORANGE),
                                               (123.2, "Cần điều chỉnh bổ sung\ntheo thực tế vận hành", "calendar", BLUE)]):
        hcard(d, 460, 330 + j * 160, 640, 130, pop(t, st), col, kind, lab, 28, True)
    for j, (st, lab, col) in enumerate([(127.1, "1. Xóa dữ liệu cũ trước", RED), (128.7, "2. Nhập lại giá trị đúng", GREEN)]):
        hcard(d, 1380, 420 + j * 180, 680, 140, pop(t, st), col, "check" if j else "warn", lab, 30, True)
    arrow(d, 800, 490, 1020, 490, p(t, 127.1, 0.4), ORANGE, 7)
    role_tag(img, d, CB, "C&B", pop(t, 126.5, 0.4))

F_CKL = (555, 170, 930, 248); F_TPL = (968, 170, 1345, 248); F_NGAY = (555, 265, 1345, 342)
F_CX = (555, 365, 900, 525); F_XTH = (555, 400, 900, 450); F_XCT = (555, 470, 900, 525)
F_BTN_XUAT = (887, 557, 1028, 612); F_BTN_DL = (1048, 557, 1203, 612); F_XUAT_LIST = (832, 116, 1160, 172)
# khi đã chọn thành phần lương (xuất hiện thẻ "Khoản bổ sung") hộp thoại dài ra, các trường dịch xuống
TAG = dict(F_TPL=(968, 170, 1345, 285), F_NGAY=(555, 300, 1345, 385), F_CX=(555, 405, 900, 565), F_XTH=(555, 435, 900, 490),
           F_XCT=(555, 505, 900, 565), F_BTN_DL=(1048, 597, 1203, 652))
def F(name, ct): return TAG[name] if ct >= 9.6 and name in TAG else globals()[name]
def sc_datlai(img, d, t):
    ct = piece(t, [(131.6, 0.5), (133.0, 2.8), (141.4, 7.5), (142.7, 10.5), (144.6, 11.8), (146.0, 13.8), (153.6, 14.6), (154.0, 18.5)])
    scr(img, "dl", REC_DL, ct)
    top_title(d, t, "Đặt lại dữ liệu thành phần lương", 131.6)
    if 141.4 <= t < 142.7: hl(d, B(*F("F_TPL", ct)), t)                                        # chọn thành phần lương
    if 142.7 <= t < 144.6: hl(d, B(*F("F_NGAY", ct)), t)                                       # phạm vi dữ liệu
    if 144.6 <= t < 146.0: hl(d, B(*F("F_BTN_DL", ct)), t)                                     # nút Đặt lại dữ liệu
    if 146.0 <= t < 153.6: hl(d, B(645, 80, 1265, 320), t)                            # hộp xác nhận
    if t < 139.0: chip_bar(d, t, [(132.6, "Đặt lại dữ liệu trong phạm vi cần điều chỉnh, rồi nhập lại bằng file đã xử lý đúng", NAVY)], size=22)
    elif t >= 147.2: chip_bar(d, t, [(147.2, "Kiểm tra đúng chu kỳ lương, thành phần lương & khoảng thời gian trước khi đặt lại", RED)], size=22)
    role_tag(img, d, CB, "C&B")

# ================= Xuất dữ liệu thành phần lương =================
def sc_h_xuat(img, d, t): sub_card(img, d, t, 154.0, "PHẦN 6", ["XUẤT DỮ LIỆU", "THÀNH PHẦN LƯƠNG"], 96)

def sc_xuat(img, d, t):
    T_TH, T_CT = 191.5, 202.1
    if T_TH <= t < 200.3:                                                 # file xuất tổng hợp
        fs_shot(img, IMG_XTH, XTH_FULL, XTH_FULL, 0)
        top_title(d, t, "Xuất tổng hợp: dữ liệu các thành phần lương chung một sheet", T_TH)
        hl(d, XT(1641, 484, 1971, 674), t)
        role_tag(img, d, CB, "C&B")
        return
    if t >= T_CT:                                                          # file xuất chi tiết
        fs_shot(img, IMG_XCT, XCT_FULL, XCT_FULL, 0)
        top_title(d, t, "Xuất chi tiết: mỗi thành phần lương một sheet riêng", T_CT)
        hl(d, XD(1638, 480, 1971, 621), t)
        role_tag(img, d, CB, "C&B")
        return
    ct = piece(t, [(156.2, 0.8), (166.4, 1.8), (168.6, 3.2), (170.2, 4.5), (176.3, 6.3), (178.2, 8.5), (184.0, 10.8), (200.3, 10.8), (202.1, 10.8)])
    scr(img, "xu", REC_DL, ct)
    top_title(d, t, "Xuất dữ liệu thành phần lương", 156.4)
    if 166.4 <= t < 168.6: hl(d, B(*F_XUAT_LIST), t)                       # nút Xuất dữ liệu thành phần lương
    if 170.2 <= t < 176.3: hl(d, B(*F_CKL), t)                              # Chu kỳ lương (bắt buộc)
    if 177.7 <= t < 181.4: hl(d, B(*F("F_TPL", ct)), t)                              # Thành phần lương
    if 181.4 <= t < 184.3: hl(d, B(*F("F_NGAY", ct)), t)                             # khoảng thời gian
    if 184.3 <= t < 189.8: hl(d, B(*F("F_CX", ct)), t)                               # Cách xuất
    if 189.8 <= t < T_TH: hl(d, B(*F("F_XTH", ct)), t)
    if 200.3 <= t < T_CT: hl(d, B(*F("F_XCT", ct)), t)
    if 170.2 <= t < 176.3: chip_bar(d, t, [(172.0, "Bắt buộc: để hệ thống xác định đúng dữ liệu thuộc kỳ cần xuất", NAVY)], size=24)
    elif 177.7 <= t < 181.4: chip_bar(d, t, [(177.7, "Chọn tất cả hoặc một thành phần lương cụ thể", NAVY)], size=24)
    role_tag(img, d, CB, "C&B")

def sc_xuat_note(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Chức năng xuất dữ liệu áp dụng cho dữ liệu C&B chủ động nhập", 209.4, size=48)
    s1 = pop(t, 211.4)
    if s1 > 0.01:
        card(d, 560, 520, 680, 380, s1, True, GREEN)
        icon(d, "doc", 560, 400, s1, GREEN, 64)
        text(d, (560, 510), "Dữ liệu C&B nhập vào", 32 * s1, INK)
        text(d, (560, 580), "→ Xuất dữ liệu thành phần lương", 26 * s1, GREEN, "Bold")
    s2 = pop(t, 215.6)
    if s2 > 0.01:
        card(d, 1360, 520, 680, 380, s2, True, BLUE)
        icon(d, "db", 1360, 400, s2, BLUE, 64)
        text(d, (1360, 510), "Dữ liệu hệ thống tạo sẵn", 32 * s2, INK)
        text(d, (1360, 580), "→ Kiểm tra tại màn hình tương ứng", 26 * s2, BLUE, "Bold")
        k = pop(t, 224.2)
        if k > 0.01: text(d, (1360, 640), "Ví dụ: Chấm công, Làm thêm", 26 * k, GREY, "Bold")
    role_tag(img, d, CB, "C&B", pop(t, 210.1, 0.4))

# ================= Chỉnh sửa thành phần lương =================
def sc_h_sua(img, d, t): sub_card(img, d, t, 226.8, "PHẦN 6", ["CHỈNH SỬA", "THÀNH PHẦN LƯƠNG"], 104)

def sc_sua(img, d, t):
    ct = piece(t, [(228.6, 0.3), (229.8, 0.6), (230.2, 3.2), (231.6, 6.5), (233.6, 9.5), (234.6, 12.6)])
    scr(img, "dt", REC_DT, ct, REC_XLS)
    top_title(d, t, "Đổi tên thành phần lương", 228.6)
    if ct < 0.85: hl(d, B(860, 470, 1228, 530, REC_XLS), t)                    # công thức đang dùng tên cũ
    if 3.2 <= ct < 7.8: hl(d, B(765, 290, 1158, 368, REC_XLS), t)              # Tên thành phần lương
    if ct >= 12.0: hl(d, B(860, 470, 1228, 530, REC_XLS), t)                   # công thức tự cập nhật tên mới
    chip_bar(d, t, [(231.2, "Hệ thống tự động cập nhật tên mới tại các công thức lương đang dùng thành phần đó", GREEN)], size=22)
    role_tag(img, d, CB, "C&B")

# ================= Thành phần lương được sử dụng trong công thức như thế nào =================
def sc_h_dung(img, d, t): sub_card(img, d, t, 235.7, "PHẦN 6", ["THÀNH PHẦN LƯƠNG ĐƯỢC SỬ DỤNG", "TRONG CÔNG THỨC NHƯ THẾ NÀO"], 76)

def sc_flow(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Vai trò của thành phần lương trong quá trình tính lương", 239.2, size=50)
    hcard(d, 360, 420, 460, 120, pop(t, 244.1), BLUE, "db", "Dữ liệu từ nghiệp vụ\ntrên Haraworks", 26, True)
    hcard(d, 360, 600, 460, 120, pop(t, 246.5), ORANGE, "doc", "Dữ liệu C&B nhập vào", 26, True)
    arrow(d, 600, 510, 760, 510, p(t, 248.8, 0.4), ORANGE, 7)
    s_ = pop(t, 248.8)
    if s_ > 0.01:
        card(d, 960, 510, 360, 260, s_, True, GREEN)
        icon(d, "db", 960, 460, s_, GREEN, 60)
        text(d, (960, 560), "Thành phần lương", 30 * s_, INK)
    arrow(d, 1150, 510, 1310, 510, p(t, 251.1, 0.4), ORANGE, 7)
    s2 = pop(t, 251.1)
    if s2 > 0.01:
        card(d, 1540, 510, 400, 260, s2, True, BLUE)
        icon(d, "fx", 1540, 460, s2, BLUE, 60)
        text(d, (1540, 560), "Công thức lương\nthực hiện tính toán", 28 * s2, INK)
    role_tag(img, d, CB, "C&B")

def sc_use(img, d, t):
    fs_shot(img, IMG_CTH, CTH_FULL, CTH_FULL, 0)
    if t < 266.5: top_title(d, t, "Công thức lấy & xử lý dữ liệu theo cách nào", 254.7)
    elif t < 275.9: top_title(d, t, "Cách thể hiện: tổng, giá trị lớn nhất…", 266.5)
    else: top_title(d, t, "Công thức chạy hàng ngày hay chạy cuối kỳ", 275.9)
    if 262.7 <= t < 275.9: hl(d, XC(1174, 955, 1777, 1073), t)              # Cách thể hiện trên bảng lương
    if t >= 278.0: hl(d, XC(1836, 1249, 2226, 1292), t)                     # Chạy một lần cuối chu kỳ
    if t >= 281.1: chip_bar(d, t, [(281.1, "Các thiết lập này được phân tích chi tiết ở phần Công thức lương", NAVY)], size=24)
    role_tag(img, d, CB, "C&B")

def sc_rel2(img, d, t): sc_rel(img, d, t, 284.5)

# ================= Tổng kết =================
def sc_h_tk(img, d, t): sub_card(img, d, t, 294.8, "PHẦN 6", ["TỔNG KẾT"], 110)

def sc_tk(img, d, t):
    paste(img, BOARD)
    if t < 310.7:
        board_title(d, t, "Ba câu hỏi khi xử lý thành phần lương", 296.6)
        qs = [(300.7, "Công thức cần\ndữ liệu gì?", "fx", BLUE), (302.5, "Dữ liệu đó đã có\nthành phần lương chưa?", "search", CYAN),
              (305.7, "Nếu chưa: nhập hoặc kết nối\nvào thành phần nào?", "db", ORANGE)]
        for i, (st, lab, kind, col) in enumerate(qs):
            vcard(d, 500 + i * 460, 520, 420, 380, pop(t, st), col, kind, lab, 26, True, f"0{i + 1}")
    else:
        board_title(d, t, "Trong vận hành cần nhớ", 310.7)
        items = [(310.7, "Kiểm tra thành phần lương đã có trước khi tạo mới", "search", BLUE),
                 (313.8, "Kiểm tra kỹ dữ liệu trước khi nhập hàng loạt", "check", GREEN),
                 (316.8, "Nhập hàng loạt lại không tự ghi đè dữ liệu cũ", "warn", RED),
                 (320.5, "Dùng Đặt lại dữ liệu khi cần thay thế dữ liệu sai", "doc", ORANGE),
                 (324.0, "Kiểm tra công thức liên quan trước khi ngưng sử dụng", "fx", NAVY)]
        for j, (st, lab, kind, col) in enumerate(items):
            hcard(d, W / 2, 260 + j * 140, 1200, 112, pop(t, st), col, kind, lab, 28, True)
    role_tag(img, d, CB, "C&B", pop(t, 298.3, 0.4))

def sc_end(img, d, t):
    if t < 333.5:
        sc_rel(img, d, t, 327.9 - 3.0)
        return
    paste(img, BOARD)
    k = pop(t, 333.5)
    pill(d, W / 2, 300, 360, 76, NAVY, "Bước tiếp theo", 32, k)
    s_ = pop(t, 334.7, 0.6)
    if s_ > 0.01:
        card(d, W / 2, 560, 1100, 320, s_, True, ORANGE)
        icon(d, "logic", W / 2 - 420 * s_, 560, s_, ORANGE, 90)
        text(d, (W / 2 + 90, 520), "NHÓM CÔNG THỨC", 58 * s_, NAVY)
        k2 = pop(t, 335.6)
        if k2 > 0.01: text(d, (W / 2 + 90, 600), "Tổ chức công thức thành bảng lương & phiếu lương", 26 * k2, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B", k)


# ================= Cảnh dựng theo voice mới (thời gian voice mới) =================
_pn = {}
def pan_img(key, tc, crop):
    if key not in _pn:
        import subprocess, os
        f = f"/tmp/pan_{key}.png"
        subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-ss", str(tc), "-i", REC_NHAP, "-frames:v", "1", f])
        _pn[key] = Image.open(f).convert("RGB").crop(crop)
    return _pn[key]
PANELS = [("ck", 11.5, (40, 130, 1100, 520), "Màn hình Chu kỳ lương", "Mã chu kỳ lương", (520, 315, 760, 500), 18.45, 23.73, (40, 143)),
          ("nv", 23.5, (40, 130, 1100, 520), "Màn hình Hồ sơ nhân viên", "Mã nhân viên", (205, 440, 355, 495), 19.41, 24.49, (143, 243)),
          ("tp", 50.5, (40, 130, 1100, 580), "Màn hình Thành phần lương", "Mã thành phần lương", (390, 455, 580, 555), 20.27, 25.59, (555, 660))]
def sc_copy(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Sao chép mã từ các màn hình tương ứng", 17.6)
    pw = 590
    hdr = pan_img("hdr", 47.0, (40, 295, 860, 398)); hw = 1100; hs = hw / hdr.width
    hx, hy = (W - hw) / 2, 800
    sh = pop(t, 18.2)
    if sh > 0.01:
        img.paste(hdr.resize((hw, int(hdr.height * hs))), (int(hx), hy))
        d.rectangle([hx, hy, hx + hw, hy + hdr.height * hs], outline=LINE, width=3)
        text(d, (W / 2, hy - 30), "File mẫu nhập dữ liệu", 26, GREY, "Bold")
    for i, (key, tc, crop, title, code, box, t_in, t_hl, col) in enumerate(PANELS):
        s_ = pop(t, t_in)
        if s_ <= 0.01: continue
        im = pan_img(key, tc, crop); sc = pw / im.width
        px = 40 + i * (pw + 45); py = 300
        img.paste(im.resize((pw, int(im.height * sc))), (int(px), py))
        d.rectangle([px, py, px + pw, py + im.height * sc], outline=LINE, width=3)
        text(d, (px + pw / 2, py - 70), title, 26, NAVY, "ExtraBold")
        text(d, (px + pw / 2, py - 32), "→ " + code, 24, ORANGE, "Bold")
        if t >= t_hl:
            hl(d, (px + (box[0] - crop[0]) * sc, py + (box[1] - crop[1]) * sc, px + (box[2] - crop[0]) * sc, py + (box[3] - crop[1]) * sc), t)
            cx0, cx1 = hx + (col[0] - 40) * hs, hx + (col[1] - 40) * hs
            hl(d, (cx0, hy, cx1, hy + hdr.height * hs), t)
            arrow(d, px + pw / 2, py + im.height * sc + 14, (cx0 + cx1) / 2, hy - 8, p(t, t_hl, 0.4), ORANGE, 5)
    role_tag(img, d, CB, "C&B")


UP_STEPS = [(70.0, (480, 170, 1340, 600), "1. Chọn dữ liệu tải lên", (915, 300, 1315, 365), 47.1),
            (76.0, (0, 30, 900, 600), "2. Chọn file đã điền", (205, 205, 610, 245), 48.3),
            (79.0, (480, 170, 1340, 830), "3. Kiểm tra cột tương ứng → Nhập dữ liệu", (1105, 740, 1295, 805), 49.5),
            (85.5, (900, 560, 1824, 1078), "4. Hệ thống tải dữ liệu lên", (1245, 915, 1780, 1070), 50.7)]
_up = {}
def up_img(tc):
    if tc not in _up:
        import subprocess
        f = f"/tmp/up_{tc}.png"
        subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-ss", str(tc), "-i", REC_NHAP, "-frames:v", "1", f])
        _up[tc] = Image.open(f).convert("RGB")
    return _up[tc]
def sc_upload(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Tải file lên & nhập dữ liệu", 46.97)
    cw, ch = 880, 400
    for i, (tc, crop, lab, box, st) in enumerate(UP_STEPS):
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        cx, cy = 60 + (i % 2) * (cw + 40), 150 + (i // 2) * (ch + 60)
        im = up_img(tc).crop(crop); sc = min(cw / im.width, (ch - 50) / im.height)
        iw, ih = int(im.width * sc), int(im.height * sc); ox, oy = cx + (cw - iw) // 2, cy + 50
        img.paste(im.resize((iw, ih)), (ox, oy))
        d.rectangle([ox, oy, ox + iw, oy + ih], outline=LINE, width=3)
        text(d, (cx + cw / 2, cy + 20), lab, 26, NAVY, "ExtraBold")
        if t >= st + 0.4:
            hl(d, (ox + (box[0] - crop[0]) * sc, oy + (box[1] - crop[1]) * sc, ox + (box[2] - crop[0]) * sc, oy + (box[3] - crop[1]) * sc), t)
    role_tag(img, d, CB, "C&B")

def sc_nhaplai(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ghi nhớ ở phần này", 101.2)
    s_ = pop(t, 103.7)
    if s_ > 0.01:
        card(d, W / 2, 470, 1300, 260, s_, True, RED, (255, 240, 240))
        icon(d, "warn", W / 2 - 560 * s_, 470, s_, RED, 64)
        text(d, (W / 2 + 40, 430), "Nhập lại dữ liệu", 40 * s_, INK)
        text(d, (W / 2 + 40, 510), "≠ thay thế dữ liệu đã nhập trước đó", 40 * s_, RED, "ExtraBold")
    pill(d, W / 2, 740, 760, 76, NAVY, "Muốn thay thế dữ liệu sai: dùng Đặt lại dữ liệu", 26, pop(t, 106.4))
    role_tag(img, d, CB, "C&B", pop(t, 102.0, 0.4))

# ---- ánh xạ thời gian: voice mới -> voice cũ (cảnh cũ giữ nguyên, chạy theo nhịp voice mới) ----
import json, bisect, difflib
_wo = json.load(open("/tmp/words_p62_old.json")); _wn = json.load(open(A + "words_p62.json"))
_sm = difflib.SequenceMatcher(a=[w for w, _ in _wo], b=[w for w, _ in _wn], autojunk=False)
_pairs = sorted((_wo[a + k][1], _wn[b + k][1]) for a, b, n in _sm.get_matching_blocks() for k in range(n))
_xo = [p_[0] for p_ in _pairs]; _xn = [p_[1] for p_ in _pairs]
def _interp(t, xs, ys):
    i = bisect.bisect_left(xs, t)
    if i <= 0: return ys[0] + (t - xs[0])
    if i >= len(xs): return ys[-1] + (t - xs[-1])
    x0, x1, y0, y1 = xs[i - 1], xs[i], ys[i - 1], ys[i]
    return y0 if x1 == x0 else y0 + (t - x0) * (y1 - y0) / (x1 - x0)
def M(t_old): return _interp(t_old, _xo, _xn)
def Minv(t_new): return _interp(t_new, _xn, _xo)
def old(fn): return lambda img, d, t: fn(img, d, Minv(t))

VOICE_DUR = 318.29; TOTAL = OFFSET + VOICE_DUR + 1.0
HD = dict(nhap=-0.6, datlai=107.5, xuat=M(154.0), sua=M(226.8), dung=M(235.7), tk=274.1)
SFX_AT = [0.0] + [OFFSET + v for v in list(HD.values())[1:]]
SCENES = [(-OFFSET, 1.8, "h_nhap"), (1.8, 6.9, "intro"), (6.9, 17.6, "nhap"), (17.6, 26.9, "copy"), (26.9, 46.97, "nhap"), (46.97, M(54.2), "upload"),
          (M(54.2), M(82.8), "note"), (M(82.8), 101.2, "cth"), (101.2, HD["datlai"], "nhaplai"),
          (HD["datlai"], M(116.0), "h_datlai"), (M(116.0), M(131.6), "dl_why"), (M(131.6), HD["xuat"], "datlai"),
          (HD["xuat"], M(156.2), "h_xuat"), (M(156.2), M(209.4), "xuat"), (M(209.4), HD["sua"], "xuat_note"),
          (HD["sua"], M(228.6), "h_sua"), (M(228.6), HD["dung"], "sua"), (HD["dung"], M(239.0), "h_dung"),
          (M(239.0), M(254.7), "flow"), (M(254.7), HD["tk"], "use"), (HD["tk"], M(296.4), "h_tk"),
          (M(296.4), M(324.9), "tk"), (M(324.9), 999, "end")]
NEWT = {"copy", "nhaplai", "upload"}
FN = {n: (globals()["sc_" + n] if n in NEWT else old(globals()["sc_" + n])) for _, _, n in SCENES}

def preview(times):
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.resize((960, 540)).save(f"/tmp/pv62_{tv}.png")

N = 9
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p62_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p62_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
