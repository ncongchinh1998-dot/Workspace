"""PHẦN 9.2 — TÌNH HUỐNG 1: TÍNH TỔNG CÔNG TÍNH LƯƠNG
Hình mẫu Excel của khách chỉ là gợi ý → dựng lại bảng dữ liệu theo ngày (số liệu khớp voice: tổng 23,5 công + 1 lễ + 1 phép = 25,5).
Màn hình thật dùng lại: file TPL hệ thống, form công thức lương."""
import sys, math
from hw_core import *
from part81 import sub_card, full_of, shot_xy, FORM_FULL, XF, F, IMG_FORM, mini_chip, badge
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p92.wav"
OFFSET = 1.0
VOICE_DUR = 504.09
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan9_2_Tinh_huong_1_Tong_cong.mp4"
HD = dict(th1=-0.6)
SFX_AT = [0.0]

IMG_ID = U + "TPL_trả_ID_kèm_mục_đích_sử_dụng.png"; ID_FULL = full_of(2878, 1655); XI = shot_xy(ID_FULL)
COL_MD = (556, 517, 1104, 1500); COL_GT = (1124, 517, 1657, 1500)

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
def form(img): fs_shot(img, IMG_FORM, FORM_FULL, FORM_FULL, 0)
def fmt(v): return ("%g" % v).replace(".", ",")

# ---------- phương trình yêu cầu ----------
EQ = [("Tổng công tính lương", NAVY), ("=", None), ("Ngày công", GREEN), ("+", None), ("Số ngày lễ", GREEN), ("+", None), ("Số ngày phép năm", GREEN)]
def equation(d, t, times, y=380, scale=1.0):
    xs = [330, 600, 820, 1020, 1210, 1400, 1620]; ws = [420, 0, 300, 0, 300, 0, 380]
    for (lab, col), x, w, st in zip(EQ, xs, ws, times):
        k = pop(t, st, 0.4)
        if k <= 0.01: continue
        if col: mini_chip(d, x, y, w * scale, 74 * scale, lab, col, k, 28 * scale)
        else: text(d, (x, y), lab, 56 * k * scale, ORANGE)

# ---------- bảng dữ liệu theo ngày ----------
DAYS = ["1", "2", "3", "4", "5", "…", "29", "30"]
DATA = dict(cong=[1, 0, 1, 0.5, 0, None, 1, 1], le=[0, 1, 0, 0, 0, None, 0, 0], phep=[0, 0, 0, 0, 1, None, 0, 0])
TOT = dict(cong=23.5, le=1, phep=1)
ROWS = [("cong", "Ngày công"), ("le", "Số ngày lễ"), ("phep", "Số ngày phép năm")]
CX = [500 + i * 135 for i in range(8)]; TX = 1660; RY = dict(head=290, cong=365, le=435, phep=505, run=590)
# mốc đọc từng ô (ngày 1–5): [công, lễ, phép]
READ = [(190.2, [192.1, 194.3, 196.2]), (197.9, [199.2, 201.3, 203.4]), (205.0, [206.4, 208.5, 210.6]),
        (212.3, [213.7, 216.6, 218.8]), (220.5, [221.8, 224.0, 226.1])]
REST = 227.6
TABLE_T0 = 188.7
def table(d, t, all_on=False, cur=None, tot=None, run_row=False):
    """tot: dict row->mốc hiện tổng; cur: cột đang đọc (tô nền)"""
    s_ = pop(t, TABLE_T0) if not all_on else 1
    if s_ <= 0.01: return
    card(d, W / 2 + 40, 445 if not run_row else 470, 1680, 380 if not run_row else 430, s_, True, BLUE)
    if s_ < 0.95: return
    if cur is not None:
        x = CX[cur]; d.rounded_rectangle([x - 62, RY["head"] - 34, x + 62, (RY["run"] if run_row else RY["phep"]) + 30], 14, fill=(255, 242, 222))
    text(d, (300, RY["head"]), "Ngày", 26, GREY, "Bold")
    for i, dd in enumerate(DAYS): text(d, (CX[i], RY["head"]), dd, 28, NAVY)
    text(d, (TX, RY["head"]), "Tổng kỳ", 26, ORANGE)
    for key, lab in ROWS:
        text(d, (300, RY[key]), lab, fit_size(d, lab, 24, "Bold", 230), INK, "Bold")
        for i, v in enumerate(DATA[key]):
            if v is None:
                if all_on or t >= REST: text(d, (CX[i], RY[key]), "…", 26, GREY)
                continue
            if i < 5:
                st = READ[i][1][[k for k, _ in ROWS].index(key)]
                vis = all_on or t >= st
            else:
                vis = all_on or t >= REST
            if vis: text(d, (CX[i], RY[key]), fmt(v), 28, GREEN if v else GREY, "Bold")
        if tot and key in tot:
            k = pop(t, tot[key], 0.4)
            if k > 0.01: text(d, (TX, RY[key]), fmt(TOT[key]), 32 * k, ORANGE)
    d.line([175, RY["head"] + 32, 1825, RY["head"] + 32], fill=LINE, width=3)
    d.line([1560, RY["head"] - 34, 1560, (RY["run"] if run_row else RY["phep"]) + 30], fill=LINE, width=3)

# ================= Mở đầu =================
def sc_h_th1(img, d, t): sub_card(img, d, t, HD["th1"], "TÌNH HUỐNG 1", ["TÍNH TỔNG CÔNG", "TÍNH LƯƠNG"], 100)

def sc_rule(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Yêu cầu: tổng công tính lương theo cách tính của doanh nghiệp", 3.1, size=48)
    equation(d, t, [9.9, 10.9, 11.3, 12.1, 12.4, 13.7, 14.0])
    s_ = pop(t, 17.6)
    if s_ > 0.01:
        text(d, (W / 2, 560), "Lần lượt áp dụng bốn yếu tố", 32 * s_, NAVY)
        for i, (lab, col) in enumerate([("01 Thành phần lương", GREEN), ("02 Công thức tính", BLUE), ("03 Cách thể hiện", ORANGE), ("04 Cách chạy", NAVY)]):
            mini_chip(d, 390 + i * 380, 660, 340, 70, lab, col, pop(t, 18.4 + i * 0.2, 0.4), 24)
    role_tag(img, d, CB, "C&B")

def sc_tpl(img, d, t):
    if t < 46.0:
        paste(img, BOARD)
        board_title(d, t, "Bước 1 · Xác định thành phần lương", 21.6, size=54)
        k0 = pop(t, 25.2, 0.4)
        if k0 > 0.01: text(d, (W / 2, 230), "Dữ liệu nào dùng để tính & đang ghi nhận tại thành phần lương nào?", 26 * k0, INK, "Bold")
        for i, (st, lab) in enumerate([(36.3, "Ngày công\ncủa nhân viên"), (38.0, "Ngày lễ"), (39.3, "Ngày nghỉ phép năm\nđã được duyệt")]):
            vcard(d, 460 + i * 500, 540, 440, 320, pop(t, st), GREEN, "db", lab, 28, True, f"0{i + 1}")
        pill(d, W / 2, 820, 760, 70, GREEN, "Cả ba dữ liệu đều đã vận hành trên Haraworks", 26, pop(t, 42.0))
        role_tag(img, d, CB, "C&B")
        return
    fs_shot(img, IMG_ID, ID_FULL, ID_FULL, 0)
    if t < 54.4:
        top_title(d, t, "Tra cứu file tổng hợp thành phần lương hệ thống", 46.1)
        chip_bar(d, t, [(51.6, "Tìm thành phần lương phù hợp thay vì tạo thêm thành phần lương mới", NAVY)], size=23)
    else:
        top_title(d, t, "Không chỉ đọc tên thành phần lương", 54.6)
        if 59.8 <= t < 61.5: hl(d, XI(*COL_MD), t)
        if t >= 61.6: hl(d, XI(*COL_GT), t)
        chip_bar(d, t, [(59.8, "Mục đích sử dụng", BLUE), (61.6, "Giá trị trả ra của hệ thống", ORANGE)], size=24)

# ---------- thẻ tra cứu thành phần lương ----------
def lookup(d, t, name, t_name, purpose, t_p, ret, t_r, kw=None, t_kw=None, ox=0):
    """ox: dời ngang cả thẻ (ox=320 → thẻ ra giữa khung khi bên phải không có nội dung)"""
    s_ = pop(t, t_name - 0.6)
    if s_ <= 0.01: return
    card(d, 640 + ox, 530, 1000, 620, s_, True, GREEN)
    if s_ < 0.95: return
    if kw:
        d.rounded_rectangle([200 + ox, 255, 1080 + ox, 315], 14, fill=WHITE, outline=LINE, width=3)
        icon(d, "search", 235 + ox, 285, 0.45, GREY, 60)
        n = int(clamp((t - t_kw) / 0.6) * len(kw)) if t >= t_kw else 0
        text(d, (275 + ox, 285), kw[:n] + ("|" if t < t_kw + 1.5 else ""), 26, INK, "Bold", anchor="lm")
    k = pop(t, t_name, 0.4)
    if k > 0.01: mini_chip(d, 640 + ox, 370, 700, 66, name, GREEN, k, 30)
    k1 = pop(t, t_p, 0.4)
    if k1 > 0.01:
        text(d, (200 + ox, 445), "Mục đích sử dụng", 22, BLUE, "Bold", anchor="lm")
        text(d, (200 + ox, 505), purpose, 23 * k1, INK, "Bold", anchor="lm", align="left")
    k2 = pop(t, t_r, 0.4)
    if k2 > 0.01:
        text(d, (200 + ox, 610), "Giá trị trả ra của hệ thống", 22, ORANGE, "Bold", anchor="lm")
        text(d, (200 + ox, 670), ret, 23 * k2, INK, "Bold", anchor="lm", align="left")

def examples(d, t, rows, x=1450, y0=330):
    """rows: [(mốc, trái, phải)] hoặc [(mốc nhãn, trái, phải, mốc kết quả)] — nhãn hiện khi voice nêu điều kiện, kết quả hiện khi voice nêu kết quả"""
    for j, r in enumerate(rows):
        st, a, b = r[:3]; st_b = r[3] if len(r) > 3 else st
        k = pop(t, st, 0.4)
        if k <= 0.01: continue
        y = y0 + j * 120
        d.rounded_rectangle([x - 300, y - 46, x + 300, y + 46], 16, fill=(243, 246, 252), outline=LINE, width=2)
        text(d, (x - 280, y), a, 22 * k, INK, "Bold", anchor="lm")
        kb = pop(t, st_b, 0.4)
        if kb > 0.01: text(d, (x + 280, y), b, 26 * kb, GREEN, anchor="rm")

def sc_cong(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu công", 64.8, size=54)
    lookup(d, t, "Ngày công", 71.9,
           "Tính số ngày công đã chấm & được duyệt\n= tổng giờ công được duyệt ÷ giờ công chuẩn 1 ngày", 74.8,
           "Số ngày công được duyệt theo từng ngày\n(có thể là số thập phân)", 84.6, kw="công", t_kw=67.6)
    k = pop(t, 91.4, 0.4)
    if k > 0.01: text(d, (1450, 245), "Ví dụ: giờ công chuẩn 1 ngày = 8 giờ", 24 * k, NAVY, "Bold")
    examples(d, t, [(96.0, "Được duyệt 8 giờ", "1 công"), (100.5, "Được duyệt 4 giờ", "0,5 công"), (104.8, "Không phát sinh công", "0")])
    role_tag(img, d, CB, "C&B")

def sc_le(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu ngày lễ", 109.6, size=54)
    lookup(d, t, "Số ngày lễ", 114.2, "Xác định những ngày được thiết lập\nlà nghỉ lễ quốc gia", 116.4,
           "Ngày được xác định là ngày lễ = 1\nCác ngày còn lại = 0", 121.1)
    k = pop(t, 127.6, 0.4)
    if k > 0.01: text(d, (1450, 245), "Ví dụ", 26 * k, NAVY, "Bold")
    examples(d, t, [(129.2, "Ngày 2 là ngày lễ", "1"), (132.6, "Ngày 1 không phải ngày lễ", "0")])
    role_tag(img, d, CB, "C&B")

def sc_phep(img, d, t):
    paste(img, BOARD)
    if t < 160.6:
        board_title(d, t, "Dữ liệu phép năm", 136.6, size=54)
        lookup(d, t, "Số ngày phép năm", 141.0, "Lấy số ngày phép thuộc loại phép năm\nđã được duyệt của nhân viên", 143.1,
               "Trả kết quả theo từng ngày", 147.6)
        k = pop(t, 149.8, 0.4)
        if k > 0.01: text(d, (1450, 245), "Ví dụ", 26 * k, NAVY, "Bold")
        examples(d, t, [(150.7, "Ngày 5 có 1 ngày phép năm được duyệt", "1"), (157.0, "Ngày không phát sinh phép năm", "0")])
    else:
        board_title(d, t, "Ba thành phần lương cần sử dụng", 160.7, size=54)
        for i, (st, lab) in enumerate([(165.4, "Ngày công"), (167.1, "Số ngày lễ"), (169.0, "Số ngày phép năm")]):
            vcard(d, 460 + i * 500, 540, 440, 300, pop(t, st), GREEN, "db", lab, 30, True, f"0{i + 1}")
    role_tag(img, d, CB, "C&B")

def sc_ct(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Bước 2 · Công thức tính", 171.5, size=54)
    equation(d, t, [175.4, 176.6, 177.0, 177.7, 178.1, 179.2, 179.6], y=440)
    pill(d, W / 2, 680, 920, 72, NAVY, "Xem dữ liệu thực tế được hệ thống ghi nhận theo từng ngày", 25, pop(t, 181.7))
    role_tag(img, d, CB, "C&B")

def sc_table(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu ghi nhận theo từng ngày trong kỳ", 188.8, size=54)
    cur = None
    for i, (st, _) in enumerate(READ):
        if t >= st: cur = i
    if t >= REST: cur = None
    table(d, t, cur=cur, tot=dict(cong=233.3, le=236.9, phep=239.9))
    k = pop(t, 241.3)
    if k > 0.01:
        card(d, W / 2 + 40, 800, 1300, 150, k, True, ORANGE)
        text(d, (W / 2 + 40, 770), "Tổng công tính lương mong muốn", 26 * k, NAVY)
        k2 = pop(t, 244.9, 0.4)
        if k2 > 0.01: text(d, (W / 2 + 40, 830), "23,5 + 1 + 1 = 25,5 công", 40 * k2, ORANGE)
    role_tag(img, d, CB, "C&B")

def sc_setup(img, d, t):
    form(img)
    top_title(d, t, "Bước 3–4 · Cách thể hiện & cách chạy công thức", 250.3)
    if t >= 252.4: hl(d, XF(*F["CTH"]), t)
    if t >= 253.5: hl(d, XF(*F["CHAY"]), t)
    if t < 263.1: chip_bar(d, t, [(255.4, "Hệ thống cần xử lý dữ liệu thế nào để trả về đúng 25,5 công?", NAVY)], size=24)
    elif t < 274.2: chip_bar(d, t, [(263.2, "Chưa chắc chọn thiết lập nào → lấy trường hợp mẫu đã biết kết quả, chạy thử & đối chiếu", ORANGE)], size=21)
    else: chip_bar(d, t, [(274.2, "Kết quả mong muốn trong ví dụ: 25,5 công", GREEN)], size=24)
    role_tag(img, d, CB, "C&B")

RUN = [(287.2, 292.3, "1 + 0 + 0 = 1"), (294.0, 298.7, "0 + 1 + 0 = 1"), (300.7, 305.5, "1 + 0 + 0 = 1"),
       (307.6, 312.4, "0,5 + 0 + 0 = 0,5"), (314.8, 319.4, "0 + 0 + 1 = 1")]
RUNV = [1, 1, 1, 0.5, 1, None, 1, 1]
def sc_daily(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thử 1 · Chạy hàng ngày", 278.9, size=54)
    cur = None
    for i, (st, _, _) in enumerate(RUN):
        if t >= st: cur = i
    if t >= 321.5: cur = None
    table(d, t, all_on=True, cur=cur, run_row=True)
    text(d, (300, RY["run"]), "Chạy hàng ngày", fit_size(d, "Chạy hàng ngày", 24, "Bold", 230), ORANGE, "Bold")
    for i, v in enumerate(RUNV):
        if v is None:
            if t >= 321.5: text(d, (CX[i], RY["run"]), "…", 26, GREY)
            continue
        st = RUN[i][1] if i < 5 else 321.6
        if t >= st: text(d, (CX[i], RY["run"]), fmt(v), 30, ORANGE)
    if cur is not None and t >= RUN[cur][0]:
        pill(d, W / 2 + 40, 760, 900, 70, NAVY, f"Ngày {DAYS[cur]}: công + ngày lễ + phép năm = {RUN[cur][2]}", 24, 1)
    if t >= 325.5:
        k = pop(t, 327.6, 0.4)
        if k > 0.01: text(d, (TX, RY["run"]), "25,5", 34 * k, GREEN)
        opts = [(327.8, "Tổng", "25,5 công", True), (343.8, "Giá trị cuối cùng khác không", "chỉ 1 (ngày cuối kỳ)", False),
                (352.6, "Giá trị trung bình", "≈ 0,85", False)]
        for j, (st, lab, val, ok) in enumerate(opts):
            s_ = pop(t, st)
            if s_ <= 0.01: continue
            x = 420 + j * 560
            card(d, x, 850, 520, 170, s_, True, GREEN if ok else RED)
            if s_ > 0.9:
                text(d, (x, 815), lab, fit_size(d, lab, 26, "Bold", 460), GREEN if ok else RED, "Bold")
                text(d, (x, 880), val, 30, INK)
                badge(d, x + 240, 775, ok, 1, 24)
    role_tag(img, d, CB, "C&B")

def sc_end(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thử 2 · Chạy một lần cuối chu kỳ", 368.1, size=54)
    hl_on = None
    for st, key in [(382.0, "cong"), (386.3, "le"), (389.7, "phep")]:
        if t >= st: hl_on = key
    table(d, t, all_on=True, tot=dict(cong=382.6, le=386.6, phep=390.0))
    if hl_on and t < 393.3: hl(d, (1570, RY[hl_on] - 30, 1810, RY[hl_on] + 30), t)
    k = pop(t, 372.0, 0.4)
    if k > 0.01: text(d, (W / 2 + 40, 700), "Không tính riêng từng ngày: tại ngày cuối chu kỳ, tổng hợp dữ liệu của từng thành phần lương trước", 22 * k, INK, "Bold")
    s_ = pop(t, 393.4)
    if s_ > 0.01:
        card(d, W / 2 + 40, 820, 900, 130, s_, True, ORANGE)
        k2 = pop(t, 396.3, 0.4)
        if k2 > 0.01: text(d, (W / 2 + 40, 820), "23,5 + 1 + 1 = 25,5 công", 40 * k2, ORANGE)
    pill(d, W / 2 + 40, 960, 1100, 64, GREEN, "Cách thể hiện Tổng: cả chạy hàng ngày & chạy cuối kỳ đều ra 25,5 công", 22, pop(t, 402.0))
    role_tag(img, d, CB, "C&B")

def sc_choose(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Vậy nên chọn cách nào?", 412.8, size=56)
    hcard(d, 640, 380, 900, 150, pop(t, 415.8), BLUE, "calendar", "Công, phép, ngày lễ được ghi nhận\n& thay đổi theo từng ngày", 26, True)
    arrow(d, 1100, 380, 1220, 380, p(t, 421.2, 0.4), ORANGE, 8)
    s_ = pop(t, 421.3)
    if s_ > 0.01:
        card(d, 1520, 380, 540, 180, s_, True, GREEN)
        text(d, (1520, 380), "Ưu tiên\nchạy hàng ngày", 34 * s_, GREEN)
        badge(d, 1770, 300, True, s_, 26)
    hcard(d, W / 2 + 40, 640, 1300, 120, pop(t, 424.5), GREEN, "check", "Tổng công tính lương được cập nhật theo dữ liệu phát sinh trong kỳ", 25, True)
    hcard(d, W / 2 + 40, 800, 1300, 120, pop(t, 430.3), NAVY, "fx", "Hữu ích khi công thức khác dùng tiếp kết quả để tính lương, thu nhập khác", 25, True)
    role_tag(img, d, CB, "C&B")

SUM = [(442.6, "Thành phần lương", "Ngày công · Số ngày lễ · Số ngày phép năm", GREEN),
       (449.1, "Công thức", "Ngày công + Số ngày lễ + Số ngày phép năm", BLUE),
       (454.3, "Cách thể hiện", "Tổng", ORANGE), (457.4, "Cách chạy", "Hàng ngày", NAVY)]
def sc_sum(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thiết lập cho tình huống 1", 439.6, size=56)
    for j, (st, lab, val, col) in enumerate(SUM):
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        y = 280 + j * 150
        card(d, W / 2 + 40, y, 1400, 120, s_, True, col)
        if s_ > 0.9:
            mini_chip(d, 560, y, 360, 62, lab, col, 1, 24)
            text(d, (800, y), val, 30, INK, "Bold", anchor="lm")
            badge(d, 1660, y, True, 1, 24)
    role_tag(img, d, CB, "C&B")

CHK = [(475.5, "Thành phần lương đã đúng dữ liệu cần sử dụng chưa?", GREEN), (478.6, "Công thức tính đã đúng cách doanh nghiệp đang tính chưa?", BLUE),
       (482.0, "Cách thể hiện có trả về đúng loại kết quả cần lấy chưa?", ORANGE),
       (486.4, "Cách chạy có phù hợp tính chất dữ liệu & mục đích sử dụng chưa?", NAVY)]
def sc_remember(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Điểm cần nhớ", 460.1, size=56)
    s_ = pop(t, 462.2)
    if s_ > 0.01:
        card(d, W / 2 + 40, 250, 1400, 120, s_, True, ORANGE)
        text(d, (W / 2 + 40, 250), "Chưa chắc → lấy trường hợp mẫu đã biết trước kết quả, chạy thử & đối chiếu", 25 * s_, INK, "Bold")
    for j, (st, lab, col) in enumerate(CHK):
        hcard(d, W / 2 + 40, 420 + j * 130, 1400, 108, pop(t, st), col, "search", lab, 25, True)
    role_tag(img, d, CB, "C&B")

FLOW = [(495.7, "Tra cứu\nthành phần lương", "search", GREEN), (497.0, "Đọc dữ liệu\nghi nhận theo ngày", "calendar", CYAN),
        (499.7, "Xây dựng\ncông thức", "fx", BLUE), (501.3, "Chọn cách thể hiện\n& cách chạy", "run", ORANGE)]
def sc_recap(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Từ nhu cầu thực tế đến công thức trên Haraworks", 493.5, size=52)
    for i, (st, lab, kind, col) in enumerate(FLOW):
        vcard(d, 330 + i * 420, 540, 370, 340, pop(t, st), col, kind, lab, 26, True, f"0{i + 1}")
        if i: arrow(d, 330 + (i - 1) * 420 + 190, 540, 330 + i * 420 - 190, 540, p(t, st - 0.2, 0.3), ORANGE, 6)
    role_tag(img, d, CB, "C&B")

SCENES = [(-OFFSET, 3.0, "h_th1"), (3.0, 21.0, "rule"), (21.0, 64.6, "tpl"), (64.6, 109.3, "cong"), (109.3, 136.4, "le"),
          (136.4, 170.9, "phep"), (170.9, 188.6, "ct"), (188.6, 250.0, "table"), (250.0, 278.6, "setup"),
          (278.6, 367.6, "daily"), (367.6, 412.6, "end"), (412.6, 439.0, "choose"), (439.0, 460.0, "sum"),
          (460.0, 493.0, "remember"), (493.0, 999, "recap")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv92"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 19
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p92_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p92_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
