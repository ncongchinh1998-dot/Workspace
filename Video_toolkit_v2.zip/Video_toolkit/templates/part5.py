"""PHẦN 5 — XÂY DỰNG BẢNG LƯƠNG
Đoạn 5.1: Quyền cần có để thiết lập và vận hành tính lương tự động.
Màn hình hệ thống hiển thị full khung hình; nhãn vai trò C&B góc trái dưới khi nói về thao tác vận hành."""
import sys, math
from hw_core import *
from cues import Cues
c = Cues(A + "words_p5.json")
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p5_v3.wav"          # voice 05/11 (sửa đoạn quyền thiết lập 1:00–1:25)
OFFSET = 1.5
VOICE_DUR = 626.79
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan5_1_Quyen_va_chuan_bi_du_lieu.mp4"
H_QUYEN = 2.3                                  # khoảng lặng trước tiêu đề mục "Quyền cần có…"
H_PREP, H_HSNV, H_HD = 153.4, 230.25, 382.1      # tiêu đề mục bổ sung
SFX_AT = [0.0, OFFSET + H_QUYEN, OFFSET + H_PREP, OFFSET + H_HSNV, OFFSET + H_HD]

# ---------- Ảnh hệ thống (kích thước gốc) ----------
IMG_3YT = U + "3_YẾU_TỐ_CÂU_THÀNH_BẢNG_LƯƠNG.png"                  # 2120x1199
IMG_QCH = U + "Cấu_hình_lương_thưởng_tại_HSNV.png"                 # 2805x1532
IMG_MCH = U + "Menu_cấu_hình_Lương_thưởng.png"                     # 2807x1629
IMG_QTN = U + "Thu_nhập_nhân_viên_tại_HSNV.png"                    # 2812x1526
IMG_MTN = U + "Menu_Thu_nhập_NV.png"                               # 2806x1477
IMG_PQ = U + "Thu_nhập_nhân_viên__CKL.png"                         # 2878x1512
REC_3M = U + "TPL__CTL__Nhóm.mp4"                                  # 1912x1016: Phân quyền -> Thêm quyền -> 3 menu
REC_PQDV = U + "Thao_tác_phân_quyền_theo_đơn_vị.mp4"              # 1912x1016: Thu nhập NV -> Chọn đơn vị áp dụng
FS_FULL = (0, 30, 1920, 1020)                                      # bản quay full khung (dư trên/dưới tô trắng)
_clips = {}
def rec(key, path, t_clip):
    if key not in _clips: _clips[key] = Clip(path, FS_FULL[2:], (0, 0, 1912, 1016))
    return _clips[key].get(t_clip)

def hl(d, box, t=0.0, kind="rect"):
    """Khoanh đỏ vùng quyền đang được nhắc tới."""
    w_ = 6 + int(2 * abs(math.sin(t * 5)))
    if kind == "rect": d.rounded_rectangle(box, 10, outline=RED, width=w_)
    else: d.ellipse(box, outline=RED, width=w_)

def full(iw, ih): return box169(iw / 2, ih / 2, iw, iw, ih)

# ================= Tiêu đề =================
def sc_part(img, d, t):
    paste(img, SECTION)
    pill(d, 250, 250, 280, 84, BLUE, "PHẦN 5", 40, pop(t, -1.45), weight="ExtraBold")
    for j, line in enumerate(["XÂY DỰNG", "BẢNG LƯƠNG"]):
        k = p(t, -1.3 + j * 0.15, 0.5)
        if k > 0: text(d, (110, 400 + j * 140 + (1 - k) * 60), line, 120, NAVY, anchor="lm", align="left")
    underline(d, 115, 640, 760, p(t, -0.9, 0.6))
    person(img, d, CB, 1200, 900, 380, pop(t, -0.8, 0.5), "C&B")

def sc_h_quyen(img, d, t):
    paste(img, SECTION)
    t0 = H_QUYEN
    pill(d, 280, 280, 340, 76, BLUE, "PHẦN 5", 30, pop(t, t0 + 0.05), weight="ExtraBold")
    for j, line in enumerate(["QUYỀN CẦN CÓ ĐỂ THIẾT LẬP", "& VẬN HÀNH TÍNH LƯƠNG", "TỰ ĐỘNG"]):
        k = p(t, t0 + 0.15 + j * 0.12, 0.45)
        if k > 0: text(d, (110, 420 + j * 92 + (1 - k) * 50), line, 76, NAVY, anchor="lm", align="left")
    underline(d, 115, 650, 700, p(t, t0 + 0.45, 0.5))
    person(img, d, CB, 1220, 900, 340, pop(t, t0 + 0.4, 0.5), "C&B", 30)

# ================= Vai trò & quyền quản trị =================
def sc_role(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Xác định vai trò & phạm vi phụ trách", c("trước tiên"))
    hcard(d, 640, 250, 560, 110, pop(t, c("vai trò")), BLUE, "people", "Vai trò công việc", 32, True)
    hcard(d, 1280, 250, 560, 110, pop(t, c("phạm vi")), ORANGE, "search", "Phạm vi phụ trách", 32, True)
    # Quản trị toàn hệ thống / ứng dụng Nhân sự -> đầy đủ quyền
    s1 = pop(t, c("toàn hệ"))
    if s1 > 0.01:
        card(d, 560, 600, 680, 380, s1, True, NAVY)
        icon(d, "shield", 560, 500, s1, NAVY, 70)
        text(d, (560, 620), "Quản trị toàn hệ thống", 32 * s1, INK)
        k2 = pop(t, c("ứng dụng", 14.96))
        if k2 > 0.01: text(d, (560, 690), "hoặc Quản trị ứng dụng Nhân sự", 28 * k2, BLUE, "Bold")
    arrow(d, 920, 600, 1080, 600, p(t, c("đầy đủ", 16.94), 0.4), ORANGE, 7)
    for j, (w, af, lab, kind, col) in enumerate(
            [("thiết lập bảng", 17.83, "Thiết lập bảng lương", "logic", ORANGE), ("trại", 20.6, "Chạy lương", "run", CYAN),
             ("xem kết", 20.34, "Xem kết quả", "search", GREEN)]):
        hcard(d, 1400, 470 + j * 130, 520, 105, pop(t, c(w, af)), col, kind, lab, 30, True)
    pill(d, 1400, 870, 320, 70, NAVY, "Toàn công ty", 30, pop(t, c("toàn công", 21.29)))

def sc_who(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ai thường được cấp quyền này?", c("nhóm quyền", 22.78))
    # Bên trái: vai trò quản lý tổng thể
    k = pop(t, c("quản lý tổng", 25.42))
    if k > 0.01: pill(d, 480, 240, 460, 66, NAVY, "Quản lý tổng thể → toàn quyền", 26, k)
    person(img, d, HR_LEAD, 330, 640, 300, pop(t, c("giám đốc", 26.37)), "Giám đốc /\nTrưởng phòng nhân sự", 26)
    person(img, d, CB, 650, 640, 300, pop(t, c("trưởng nhóm", 29.38)), "Trưởng nhóm C&B", 26)
    # Bên phải: C&B phụ trách từng phần -> phân quyền chi tiết
    st = c("với các", 32)
    if t >= st:
        d.line([960, 220, 960, 900], fill=LINE, width=4)
        person(img, d, CB, 1280, 640, 280, pop(t, c("từng phần", 33.12)), "C&B\nphụ trách phần việc", 24)
        person(img, d, CB, 1620, 640, 280, pop(t, c("từng nhóm", 34.25)), "C&B\nphụ trách nhóm NV", 24)
        pill(d, 1450, 240, 520, 66, ORANGE, "Phân quyền chi tiết", 26, pop(t, st))
        hcard(d, 1450, 900, 700, 120, pop(t, c("phân chi", 36.50)), ORANGE, "shield", "Theo đúng chức năng\n& phạm vi phụ trách", 28, True)
        chip_bar(d, t, [(c("gồm các", 40.09), "Thiết lập bảng lương", ORANGE), (c("chạy lương", 43.32), "Chạy lương", CYAN),
                        (c("xem kết", 45.00), "Xem kết quả", GREEN)], x0=1000, size=24)

# ================= 1. Quyền thiết lập bảng lương =================
def sc_setup(img, d, t):
    T_3YT, T_QCH, T_MCH, T_3M = c("để xây", 48.43), c("nếu con", 54.95), c("bao gồm", 63.88), c("nếu người", 66.75)
    if t < T_3YT:
        paste(img, BOARD)
        k = pop(t, c("đầu tiên", 42.89))
        pill(d, W / 2, 380, 300, 70, NAVY, "Thứ nhất", 30, k)
        if k > 0.01: text(d, (W / 2, 520), "Quyền thiết lập bảng lương", 76 * max(k, 0.3), NAVY)
        role_tag(img, d, CB, "C&B", k)
        return
    if t < T_QCH:          # 3 yếu tố cấu thành bảng lương
        fs_shot(img, IMG_3YT, full(2120, 1199), box169(1060, 560, 2000, 2120, 1199), (t - T_3YT) / 4.0)
        top_title(d, t, "Quyền thiết lập bảng lương", T_3YT)
        role_tag(img, d, CB, "C&B")
        return
    if t < T_MCH:          # quyền "Cấu hình lương thưởng" tại Hồ sơ nhân viên
        fs_shot(img, IMG_QCH, full(2805, 1532), box169(1950, 1100, 1700, 2805, 1532), (t - T_QCH - 1.5) / 3.0)
        top_title(d, t, "Cấp quyền: Cấu hình lương thưởng (tại Hồ sơ nhân viên)", T_QCH)
        if t > T_QCH + 4.6:   # khung đỏ quanh dòng "Cấu hình lương thưởng"
            w_ = 6 + int(2 * abs(math.sin(t * 5)))
            d.rounded_rectangle([420, 595, 1500, 690], 16, outline=RED, width=w_)
        role_tag(img, d, CB, "C&B")
        return
    if t < T_3M:           # menu Cấu hình lương thưởng
        fs_shot(img, IMG_MCH, full(2807, 1629), box169(420, 900, 1500, 2807, 1629), (t - T_MCH) / 2.5)
        top_title(d, t, "Bao gồm nhiều menu thuộc Cấu hình lương thưởng", T_MCH)
        if t > T_MCH + 1.8:   # 3 menu: Thành phần lương, Công thức lương, Nhóm công thức
            d.rounded_rectangle([95, 440, 450, 715], 16, outline=RED, width=6)
        role_tag(img, d, CB, "C&B")
        return
    # Chỉ cần 3 menu -> cấp riêng tại menu Phân quyền (bản quay TPL/CTL/Nhóm)
    ct = (t - T_3M) * 1.4
    fullscreen(img, rec("3m", REC_3M, ct), FS_FULL)
    top_title(d, t, "Cấp riêng quyền cho 3 menu (Menu Phân quyền · Ứng dụng Nhân sự)", T_3M)
    if ct < 1.6: hl(d, (35, 815, 200, 855), t)                     # menu Phân quyền
    if ct >= 10.0: hl(d, (1100, 300, 1890, 465), t)                # Thành phần lương / Công thức lương / Nhóm công thức
    role_tag(img, d, CB, "C&B")

# ================= 2. Quyền chạy lương & xem kết quả =================
def sc_run(img, d, t):
    T_QTN, T_MTN, T_PQ, T_UNIT = c("nếu conb", 81.5), c("khi đó", 88.64), c("nếu con", 95.40), c("khi đó", 103.49)
    if t < T_QTN:
        paste(img, BOARD)
        k = pop(t, c("tiếp theo", 77.10))
        pill(d, W / 2, 380, 300, 70, NAVY, "Thứ hai", 30, k)
        if k > 0.01: text(d, (W / 2, 520), "Quyền chạy lương & xem kết quả", 72 * max(k, 0.3), NAVY)
        role_tag(img, d, CB, "C&B", k)
        return
    if t < T_MTN:          # quyền Thu nhập nhân viên tại HSNV
        fs_shot(img, IMG_QTN, full(2812, 1526), box169(1950, 950, 1700, 2812, 1526), (t - T_QTN - 2.0) / 3.0)
        top_title(d, t, "Cấp quyền: Thu nhập nhân viên (tại Hồ sơ nhân viên)", T_QTN)
        if t > T_QTN + 5.0: hl(d, (420, 492, 1495, 592), t)          # dòng "Thu nhập nhân viên"
        chip_bar(d, t, [(c("toàn công", 84.08), "C&B phụ trách toàn công ty", NAVY)], size=26)
        role_tag(img, d, CB, "C&B")
        return
    if t < T_PQ:           # Lương nhân viên + Chu kỳ lương
        fs_shot(img, IMG_MTN, full(2806, 1477), box169(450, 560, 1450, 2806, 1477), (t - T_MTN) / 2.5)
        top_title(d, t, "Xem lương & chạy lương trên toàn công ty", T_MTN)
        if t > T_MTN + 2.5: hl(d, (100, 448, 470, 640), t)           # Lương nhân viên / Chu kì lương
        role_tag(img, d, CB, "C&B")
        return
    # phân quyền theo phạm vi đơn vị (bản quay thao tác chọn đơn vị áp dụng)
    ct = t - T_PQ
    fullscreen(img, rec("pqdv", REC_PQDV, ct), FS_FULL)
    if t < T_UNIT: top_title(d, t, "Phân quyền theo phạm vi đơn vị (Menu Phân quyền)", T_PQ)
    else: top_title(d, t, "Chỉ trong phạm vi đơn vị được cấp quyền", T_UNIT)
    if 0.4 < ct < 2.8: hl(d, (1092, 822, 1275, 932), t)            # Thu nhập nhân viên / Chu kỳ lương
    if 2.8 <= ct < 4.4: hl(d, (1296, 872, 1374, 946), t, "oval")   # biểu tượng chọn đơn vị
    if 13.0 <= ct < 14.15: hl(d, (548, 162, 1362, 392), t)         # các đơn vị đã chọn
    elif 14.15 <= ct < 14.55: hl(d, (548, 158, 1362, 228), t)      # ô đơn vị sau khi thu gọn (tắt khi đóng hộp thoại)
    if t < c("chỉ xem", 105.33) - 0.3:
        chip_bar(d, t, [(c("một số", 97.25), "C&B chỉ phụ trách một số đơn vị", ORANGE)], size=26)
    else:
        if t < c("chạy lương", 109.97) - 0.2:   # mỗi lúc một nhãn, ghi đủ câu
            chip_bar(d, t, [(c("chỉ xem", 105.33), "Lương nhân viên: chỉ xem thu nhập nhân viên thuộc đơn vị mình phụ trách", BLUE)], size=26)
        else:
            chip_bar(d, t, [(c("chạy lương", 109.97), "Chu kỳ lương: phạm vi chạy lương giới hạn theo đơn vị được cấp quyền", CYAN)], size=26)
    role_tag(img, d, CB, "C&B")

def badge(d, x, y, ok, s, r0=24):
    if s <= 0.01: return
    r = r0 * s
    d.ellipse([x - r, y - r, x + r, y + r], fill=GREEN if ok else RED)
    d.line([x - r * 0.45, y, x - r * 0.1, y + r * 0.4, x + r * 0.5, y - r * 0.35], fill=WHITE, width=max(int(6 * s), 1), joint="curve")

# ================= Ví dụ: 2 C&B =================
def sc_example(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ví dụ: doanh nghiệp có hai C&B", c("ví dụ", 115.39))
    d.line([960, 170, 960, 1000], fill=LINE, width=4)
    # Bên trái: C&B khối cửa hàng
    role_badge(img, d, CB, "C&B khối cửa hàng", 480, 400, pop(t, c("riêng khối", 118.99)), 210)
    hcard(d, 480, 510, 700, 120, pop(t, c("được phân", 124.99)), ORANGE, "shield", "Phân quyền theo đơn vị cửa hàng\n(Menu Phân quyền)", 26, True)
    for j in range(3):
        s_ = pop(t, c("cửa hàng", 126.72) + j * 0.12)
        hcard(d, 260 + j * 220, 680, 200, 90, s_, GREEN, "people", f"Cửa hàng {j + 1}", 22)
    hcard(d, 480, 850, 700, 110, pop(t, c("chỉ xem", 129.36)), GREEN, "check", "Chỉ xem & chạy lương khối cửa hàng", 26, True)
    # Bên phải: C&B toàn công ty
    role_badge(img, d, CB, "C&B toàn công ty", 1440, 400, pop(t, c("chung toàn", 121.51)), 210)
    hcard(d, 1440, 510, 700, 120, pop(t, c("được cấp", 135.08)), NAVY, "shield", "Quyền Thu nhập nhân viên\n(tại Hồ sơ nhân viên)", 26, True)
    k = pop(t, c("được cấp", 135.08, 0.4))
    if k > 0.01:
        card(d, 1440, 680, 640, 110, k, True, BLUE)
        text(d, (1440, 680), "Toàn công ty", 34 * k, BLUE)
    hcard(d, 1440, 850, 700, 110, pop(t, c("xem và chạy", 138.56)), GREEN, "check", "Xem & chạy lương toàn công ty", 26, True)

# ================= Tổng kết =================
def sc_sum(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Hai yếu tố khi phân quyền tính lương", c("như vậy", 141.29))
    vcard(d, 520, 520, 420, 360, pop(t, c("công việc gì", 145.88)), BLUE, "logic", "Phụ trách\ncông việc gì?", 34, t < c("phạm vi nào", 147.75), "01")
    vcard(d, 1040, 520, 420, 360, pop(t, c("phạm vi nào", 147.75)), ORANGE, "search", "Phụ trách\ntrên phạm vi nào?", 34, True, "02")
    arrow(d, 1270, 520, 1400, 520, p(t, c("lựa chọn", 149.48), 0.4), ORANGE, 8)
    s_ = pop(t, c("lựa chọn", 149.48))
    if s_ > 0.01:
        card(d, 1620, 520, 400, 360, s_, True, GREEN)
        icon(d, "shield", 1620, 440, s_, GREEN, 70)
        text(d, (1620, 590), "Quyền phù hợp\nthực tế vận hành", 30 * s_, INK)
    role_tag(img, d, CB, "C&B", pop(t, c("như vậy", 141.29)))

exec(open('/home/claude/part5_add.py').read())

SCENES = [(-OFFSET, H_QUYEN, "part"), (H_QUYEN, 6.37, "h_quyen"), (6.37, 23.97, "role"), (23.97, 47.05, "who"),
          (47.05, 78.19, "setup"), (78.19, 116.56, "run"), (116.56, 142.68, "example"), (142.68, H_PREP, "sum")] + SCENES_ADD
FN = dict(part=sc_part, h_quyen=sc_h_quyen, role=sc_role, who=sc_who, setup=sc_setup, run=sc_run, example=sc_example, sum=sc_sum, **FN_ADD)

# ---- Voice thu lại (24/10): giữ nguyên các cảnh, chạy theo nhịp voice mới (ánh xạ theo từng từ) ----
import sys as _s; _s.path.insert(0, "/home/claude")
from remap_voice import make_maps
_M, _Minv = make_maps(A + "words_p5_oldasr.json", A + "words_p5_v3.json")
SFX_AT = [0.0] + [OFFSET + _M(x - OFFSET) for x in SFX_AT[1:]]
SCENES = [(s_ if s_ <= -OFFSET else _M(s_), 999 if e_ >= 900 else _M(e_), n_) for s_, e_, n_ in SCENES]
FN = {k_: (v_ if k_ == "part" else (lambda f: (lambda img, d, t: f(img, d, _Minv(t))))(v_)) for k_, v_ in FN.items()}

# ---- Đoạn quyền thiết lập bảng lương đã viết lại trong voice 05/11 (dựng theo thời gian voice mới) ----
from cues import Cues as _Cues
c3 = _Cues(A + "words_p5_v3.json")
T3_MENU, T3_3M, T3_QCH, T3_RIENG, T3_END = c3("nếu con cần", 56), c3("trong đó có", 62), c3("thì có thể cấp quyền", 66), c3("nếu người", 70), c3("tiếp theo là", 83)
_setup_old = FN["setup"]
def sc_setup_v3(img, d, t):
    if not (T3_MENU <= t < T3_END):
        return _setup_old(img, d, t)
    if t < T3_QCH:          # khu vực menu Lương thưởng, trong đó có 3 menu
        fs_shot(img, IMG_MCH, full(2807, 1629), box169(420, 900, 1500, 2807, 1629), (t - T3_MENU) / 2.5)
        top_title(d, t, "Các menu trong khu vực Lương thưởng", T3_MENU)
        if t >= T3_3M + 0.3: d.rounded_rectangle([95, 440, 450, 715], 16, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
        chip_bar(d, t, [(c3("thành phần lương", T3_3M), "Thành phần lương", GREEN), (c3("công thức lương", T3_3M), "Công thức lương", BLUE),
                        (c3("nhóm công thức", T3_3M), "Nhóm công thức", ORANGE)], size=26)
        role_tag(img, d, CB, "C&B"); return
    if t < T3_RIENG:        # cấp quyền Cấu hình lương thưởng tại Hồ sơ nhân viên
        fs_shot(img, IMG_QCH, full(2805, 1532), box169(1950, 1100, 1700, 2805, 1532), (t - T3_QCH - 1.0) / 2.5)
        top_title(d, t, "Cấp quyền: Cấu hình lương thưởng (tại Hồ sơ nhân viên)", T3_QCH)
        if t > T3_QCH + 3.6: d.rounded_rectangle([420, 595, 1500, 690], 16, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
        role_tag(img, d, CB, "C&B"); return
    ct = (t - T3_RIENG) * (16.0 / max(1.0, T3_END - T3_RIENG))   # chỉ cần 1 trong 3 menu -> cấp riêng từng menu
    fullscreen(img, rec("3m", REC_3M, ct), FS_FULL)
    top_title(d, t, "Cấp riêng quyền cho từng menu (Menu Phân quyền · Ứng dụng Nhân sự)", T3_RIENG)
    if ct < 1.6: hl(d, (35, 815, 200, 855), t)
    if ct >= 10.0: hl(d, (1100, 300, 1890, 465), t)
    role_tag(img, d, CB, "C&B")
FN["setup"] = sc_setup_v3
for _i, (_s0, _e0, _n0) in enumerate(SCENES):        # nối mốc cảnh setup/run theo voice mới
    if _n0 == "setup": SCENES[_i] = (_s0, T3_END - 0.3, _n0)
    if _n0 == "run": SCENES[_i] = (T3_END - 0.3, _e0, _n0)

def preview(times):
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.resize((960, 540)).save(f"/tmp/pv5_{tv}.png")

N = 14
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p5_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p5_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
