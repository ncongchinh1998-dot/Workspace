"""PHẦN 10 — CHẠY LƯƠNG
Chu kỳ lương → Chi tiết chạy lương → chọn phạm vi (đơn vị / nhân viên) → Chạy lương → theo dõi lịch sử (100%) → lỗi → Reset trạng thái."""
import sys, math
from hw_core import *
from part81 import sub_card, full_of, shot_xy, mini_chip, badge, KQ_FULL, XK, KQ, IMG_KQ
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p10.wav"
OFFSET = 1.0
VOICE_DUR = 91.61
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan10_Chay_luong.mp4"
HD = dict(p10=-0.6)
SFX_AT = [0.0]

IMG_CKL = U + "1__Chọn_chạy_lương_tại_CKL.png"   # 2869x1493
CKL_BOX = (215, 0, 2869, 1493); XC = shot_xy(CKL_BOX)   # canh phải để thấy trọn icon "Chi tiết chạy lương"
IMG_DONE = U + "Chạy_lương_hoàn_tất.png"           # 2877x1528 (có khung đỏ vẽ tay → xoá)
IMG_RESET = U + "Reset_trạng_thái.png"              # 2871x1527 (có khung đỏ vẽ tay → xoá)
REC_SCOPE = U + "Chọn_phạm_vi_chạy_lương.mp4"       # 1824x1078 có thanh trình duyệt
REC_ERR = U + "Lỗi_chạy_lương.mp4"                  # 1912x1076

def clean(src, dst, area):
    import os, numpy as np
    if os.path.exists(dst): return dst
    a = np.array(Image.open(src).convert("RGB")).copy(); ai = a.astype(int)
    m = (ai[:, :, 0] - ai[:, :, 1] > 90) & (ai[:, :, 0] - ai[:, :, 2] > 90)
    x0, y0, x1, y1 = area; mm = np.zeros_like(m); mm[y0:y1, x0:x1] = True
    m &= mm
    # xoá nét khung: thay bằng màu nền lấy ngay bên trong khung
    a[m] = 255
    Image.fromarray(a).save(dst); return dst
DONE = clean(IMG_DONE, "/tmp/p10_done.png", (1500, 585, 1790, 710))
RESET = clean(IMG_RESET, "/tmp/p10_reset.png", (190, 195, 560, 315))
# đồng bộ tên chu kỳ lương theo dạng "Tháng mm/yyyy" (sửa đè trên ảnh/khung hình)
from rename_tool import rename
def _renamed(src, dst, edits, size=27):
    im = Image.open(src).convert("RGB")
    for box, new in edits: rename(im, box, new, size)
    im.save(dst); return dst
CKL2 = _renamed(IMG_CKL, "/tmp/p10_ckl2.png", [((226, 412, 528, 442), "Tháng 10/2026"), ((226, 602, 556, 632), "Tháng 07/2022")])
DONE2 = _renamed(DONE, "/tmp/p10_done2.png", [((226, y - 4, 528, y + 26), "Tháng 10/2026") for y in (636, 741, 846, 951, 1056, 1161)])
RESET2 = _renamed(RESET, "/tmp/p10_reset2.png", [((226, y - 4, 528, y + 26), "Tháng 10/2026") for y in (483, 594, 705, 817)])
KQ2 = _renamed(IMG_KQ, "/tmp/p10_kq2.png", [((896, 316, 1226, 348), "Tháng 07/2022")], 28)
ERR_ROWS = (380, 454, 527, 602)          # dòng "Kỳ Lương Tháng 10/2026" trên bản quay lỗi (1912x1076)
def letter(path, iw, ih):
    """dán trọn ảnh theo chiều ngang 1920, canh giữa dọc (không cắt mép trái/phải)"""
    k = 1920 / iw; h = int(ih * k); y0 = (1080 - h) // 2
    def draw(img):
        bg = Image.new("RGB", (1920, 1080), WHITE); bg.paste(Image.open(path).convert("RGB").resize((1920, h), Image.LANCZOS), (0, y0)); img.paste(bg, (0, 0))
    def xy(x0, y0_, x1, y1): return (x0 * k, y0_ * k + y0, x1 * k, y1 * k + y0)
    return draw, xy
_cache = {}
def L(path, iw, ih):
    if path not in _cache:
        dr, xy = letter(path, iw, ih); im = BG.copy(); dr(im); _cache[path] = (im, xy)
    return _cache[path]
def show(img, path, iw, ih):
    im, xy = L(path, iw, ih); img.paste(im, (0, 0)); return xy

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))

_clips = {}
REC_BR = dict(crop=(0, 0, 1824, 1078), size=(1920, 1135), y0=-55, sw=1824)
REC_E = dict(crop=(0, 0, 1912, 1076), size=(1920, 1080), y0=0, sw=1912)
def scr(img, key, path, tc, spec):
    if key not in _clips: _clips[key] = Clip(path, spec["size"], spec["crop"])
    fr = _clips[key].get(tc); bg = Image.new("RGB", (1920, 1080), WHITE)
    if fr is not None: bg.paste(fr, (0, spec["y0"]))
    img.paste(bg, (0, 0))
def B(x0, y0, x1, y1, spec):
    s_ = 1920 / spec["sw"]; y_ = spec["y0"]
    return (x0 * s_, y0 * s_ + y_, x1 * s_, y1 * s_ + y_)
def piece(t, pts):
    if t <= pts[0][0]: return pts[0][1]
    for (a_, ca), (b_, cb) in zip(pts, pts[1:]):
        if a_ <= t <= b_: return ca + (t - a_) * (cb - ca) / (b_ - a_)
    return pts[-1][1]

# toạ độ trên bản quay phạm vi (1824x1078)
S_FIELD = (128, 218, 930, 290)        # ô "Chọn đơn vị/ nhân viên muốn chạy lương"
S_TREE = (132, 296, 1000, 830)        # cây đơn vị
S_MENU = (262, 556, 525, 790)         # menu chọn cấp
S_FIELD_CHIPS = (128, 218, 930, 312)
S_SEARCH = (318, 294, 700, 342)
S_EMP = (560, 570, 1010, 640)
S_RUN = (1636, 306, 1752, 352)        # nút Chạy Lương (trước khi chạy)
S_TOAST = (1366, 132, 1790, 200)
S_PREP = (118, 198, 324, 240)
# toạ độ bản quay lỗi (1912x1076)
E_STATUS = (1052, 362, 1180, 408); E_MSG = (628, 168, 1276, 240)

def sc_h_p10(img, d, t): sub_card(img, d, t, HD["p10"], "PHẦN 10", ["CHẠY LƯƠNG"], 110)

def sc_ckl(img, d, t):
    XC = show(img, CKL2, 2869, 1493)
    top_title(d, t, "Chạy lương để Haraworks tính kết quả cho nhân viên", 1.9)
    if 7.8 <= t < 8.9: hl(d, XC(206, 400, 540, 456), t)
    if t >= 8.9: hl(d, XC(2540, 340, 2792, 456), t)
    role_tag(img, d, CB, "C&B")

def sc_scope(img, d, t):
    if t < 15.3: ct = piece(t, [(9.9, 0.0), (10.6, 2.0)])
    elif t < 17.8: ct = piece(t, [(15.3, 8.6), (16.4, 10.0)])
    elif t < 18.3: ct = 12.5
    elif t < 18.6: ct = 14.5
    elif t < 21.0: ct = 22.0
    elif t < 23.3: ct = 27.0
    elif t < 25.4: ct = 29.5
    elif t < 31.2: ct = 0.2
    elif t < 34.9: ct = 29.5
    else: ct = piece(t, [(34.9, 33.5), (35.9, 35.5)])
    scr(img, "scope", REC_SCOPE, ct, REC_BR)
    S = lambda b: B(*b, REC_BR)
    if 10.8 <= t < 12.5: hl(d, S(S_FIELD), t)
    if 12.5 <= t < 15.2: hl(d, S(S_TREE), t)
    if 16.5 <= t < 17.8: hl(d, S(S_MENU), t)
    if 17.8 <= t < 18.6: hl(d, S(S_FIELD_CHIPS if t < 18.3 else S_FIELD), t)
    if 19.0 <= t < 21.0: hl(d, S(S_SEARCH), t)
    if 21.1 <= t < 23.3: hl(d, S(S_EMP), t)
    if 23.4 <= t < 25.4: hl(d, S(S_FIELD), t)
    if 25.6 <= t < 31.2: hl(d, S(S_FIELD), t)
    if 33.9 <= t < 34.9: hl(d, S(S_RUN), t)
    if t >= 36.0: hl(d, S(S_TOAST), t)
    if t < 15.3: top_title(d, t, "Chọn phạm vi chạy lương: theo đơn vị hoặc theo từng nhân viên", 10.0)
    elif t < 18.6: top_title(d, t, "Ví dụ: chạy lương cho một đơn vị cụ thể", 15.4)
    elif t < 25.4: top_title(d, t, "Chỉ tính lại cho một nhân viên sau khi điều chỉnh dữ liệu", 18.7)
    elif t < 31.2: top_title(d, t, "Không chọn phạm vi", 25.6)
    else: top_title(d, t, "Chạy lương", 31.4)
    if 25.6 <= t < 31.2: chip_bar(d, t, [(26.2, "Chạy lương theo phạm vi được áp dụng của chu kỳ lương", NAVY)], size=24)
    if 16.5 <= t < 17.8: chip_bar(d, t, [(16.6, "Chọn đơn vị và các cấp cần chạy lương", NAVY)], size=24)
    if t >= 36.0: chip_bar(d, t, [(36.2, "Haraworks tính toán dựa trên dữ liệu đã ghi nhận & các công thức lương đã thiết lập", GREEN)], size=22)
    role_tag(img, d, CB, "C&B")

def sc_done(img, d, t):
    XD = show(img, DONE2, 2877, 1528)
    top_title(d, t, "Theo dõi tiến trình tại danh sách lịch sử", 42.0)
    if 43.4 <= t < 45.6: hl(d, XD(209, 500, 2766, 1225), t)
    if t >= 45.7: hl(d, XD(1524, 604, 1765, 692), t)
    chip_bar(d, t, [(47.8, "Trạng thái đạt 100%: quá trình chạy lương đã hoàn tất", GREEN)], size=24)
    role_tag(img, d, CB, "C&B")

def sc_err(img, d, t):
    ct = piece(t, [(49.7, 0.8), (51.3, 2.6), (52.1, 3.9)])
    scr(img, "err", REC_ERR, ct, REC_E)
    k = 1920 / 1912
    for y in ERR_ROWS: rename(img, (150 * k, (y - 4) * k, 352 * k, (y + 18) * k), "Tháng 10/2026", 19)
    E = lambda b: B(*b, REC_E)
    if 50.2 <= t < 51.3: hl(d, E(E_STATUS), t)
    if t >= 52.2: hl(d, E(E_MSG), t)
    top_title(d, t, "Tiến trình báo lỗi: mở thông tin lỗi để xác định nguyên nhân", 49.8)
    if t >= 54.1: chip_bar(d, t, [(54.1, "Lỗi do công thức lương hoặc dữ liệu đầu vào → điều chỉnh & chạy lương lại", ORANGE)], size=23)
    role_tag(img, d, CB, "C&B")

def sc_reset(img, d, t):
    XR = show(img, RESET2, 2871, 1527)
    top_title(d, t, "Chức năng Reset trạng thái lương", 61.7)
    if t >= 62.3: hl(d, XR(212, 226, 545, 290), t)
    if t < 69.8: chip_bar(d, t, [(65.0, "Chỉ dùng khi tiến trình chạy lương bị treo & không thể tiếp tục xử lý", ORANGE)], size=23)
    else: chip_bar(d, t, [(69.9, "Gặp trường hợp này: liên hệ Haraworks để được hỗ trợ kiểm tra trước khi reset", RED)], size=22)
    role_tag(img, d, CB, "C&B")

def sc_next(img, d, t):
    if t < 83.2:
        fs_shot(img, KQ2, KQ_FULL, KQ_FULL, 0)
        top_title(d, t, "Chạy lương hoàn tất → Thu nhập nhân viên: kiểm tra kết quả từng nhân viên", 76.5)
        role_tag(img, d, CB, "C&B")
        return
    paste(img, BOARD)
    k = pop(t, 83.3)
    pill(d, W / 2, 300, 380, 76, NAVY, "Phần tiếp theo", 32, k)
    s_ = pop(t, 85.2)
    if s_ > 0.01:
        card(d, W / 2, 520, 1300, 220, s_, True, ORANGE)
        text(d, (W / 2, 470), "KIỂM TRA KẾT QUẢ SAU KHI CHẠY LƯƠNG", 44 * s_, NAVY)
    for i, (st, lab) in enumerate([(86.7, "Công"), (87.2, "Lương"), (87.7, "Thu nhập"), (88.4, "Khấu trừ"), (89.3, "Kết quả cuối cùng")]):
        mini_chip(d, [450, 680, 910, 1140, 1410][i], 570, [210, 210, 210, 210, 300][i], 60, lab, BLUE if i < 4 else GREEN, pop(t, st, 0.4), 24)   # chip nằm gọn trong thẻ (310–1610)
    role_tag(img, d, CB, "C&B", k)

SCENES = [(-OFFSET, 1.7, "h_p10"), (1.7, 9.9, "ckl"), (9.9, 41.8, "scope"), (41.8, 49.6, "done"), (49.6, 61.5, "err"),
          (61.5, 76.4, "reset"), (76.4, 999, "next")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv10"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 4
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p10_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p10_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
