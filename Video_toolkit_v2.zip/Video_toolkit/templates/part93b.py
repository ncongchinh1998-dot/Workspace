"""PHẦN 9.3 (voice 01/11/2026) — TÌNH HUỐNG 2: TÍNH LƯƠNG TRONG THÁNG.
Kịch bản giữ cấu trúc cũ (đọc lại, chỉnh câu chữ) → giữ cảnh part93, ánh xạ thời gian bằng remap_voice.
Đoạn kết đổi: bỏ cảnh "mối quan hệ dữ liệu đầu vào"; câu chốt mới = lưu ý kiểm tra cách chạy của công thức cung cấp dữ liệu."""
import sys, math
from hw_core import *
from remap_voice import make_maps
import part93 as P
from part81 import badge

M, Minv = make_maps(A + "words_p93.json", A + "words_p93b.json")
VOICE = A + "voice_p93b.wav"
OFFSET = 1.0
VOICE_DUR = 444.01
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = P.OUT
SFX_AT = [0.0]

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
P.hl = lambda d, box, t=0.0, kind="rect": hl(d, box, t)

def old(fn): return lambda img, d, t: fn(img, d, Minv(t))

def sc_tctl_sum(img, d, t):
    """câu mới 129.6–138.2: công thức lương trong tháng dùng 3 dữ liệu"""
    paste(img, BOARD)
    board_title(d, t, "Công thức lương trong tháng sử dụng ba dữ liệu", 129.8, size=52)
    for i, (st, lab, kind, col) in enumerate([(133.1, "Mức lương chính", "doc", GREEN), (134.3, "Công chuẩn kỳ lương", "calendar", GREEN),
                                              (135.9, "Kết quả công thức\nTổng công tính lương", "fx", BLUE)]):
        vcard(d, 500 + i * 460, 540, 420, 340, pop(t, st), col, kind, lab, 28, True, f"0{i + 1}")
    role_tag(img, d, CB, "C&B")

def sc_note(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Lưu ý qua tình huống này", 429.6, size=56)
    s_ = pop(t, 432.4)
    if s_ > 0.01:
        card(d, W / 2 + 40, 400, 1460, 200, s_, True, BLUE)
        text(d, (W / 2 + 40, 360), "Khi một công thức sử dụng kết quả của công thức khác", 28 * s_, INK, "Bold")
        k = pop(t, 435.3, 0.4)
        if k > 0.01: text(d, (W / 2 + 40, 425), "→ kiểm tra cả cách chạy của công thức cung cấp dữ liệu", 30 * k, BLUE)
    s2 = pop(t, 438.5)
    if s2 > 0.01:
        card(d, W / 2 + 40, 680, 1460, 200, s2, True, ORANGE)
        text(d, (W / 2 + 40, 640), "Công thức cung cấp dữ liệu chạy theo cách nào", 28 * s2, INK, "Bold")
        text(d, (W / 2 + 40, 705), "sẽ ảnh hưởng đến giá trị công thức đang sử dụng nhận được", 28 * s2, ORANGE)
    role_tag(img, d, CB, "C&B")

SCENES = []
for s, e, n in P.SCENES:
    if n in ("remember", "end"): continue
    SCENES.append((s if s < 0 else M(s), M(e), n))
# chèn cảnh tóm tắt 3 dữ liệu (câu mới) vào giữa cảnh "tctl" và "ct"
SCENES = [(s, (129.4 if n == "tctl" else e), n) for s, e, n in SCENES]
SCENES = [x if x[2] != "ct" else (138.3, x[1], "ct") for x in SCENES]
SCENES.insert([n for _, _, n in SCENES].index("ct"), (129.4, 138.3, "tctl_sum"))
SCENES = [x if x[2] != "setup" else (x[0], 429.4, "setup") for x in SCENES]
SCENES.append((429.4, 999, "note"))
FN = {n: old(P.FN[n]) for _, _, n in SCENES if n in P.FN}
FN["tctl_sum"] = sc_tctl_sum; FN["note"] = sc_note

def preview(times, out="/tmp/pv93b"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 16
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "scenes":
        for s, e, nm in SCENES: print(f"{s:7.2f} {e:7.2f} {nm}")
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p93b_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p93b_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
