"""PHẦN 4 — CHU KỲ LƯƠNG & THAM SỐ LƯƠNG
Hình neo theo từng từ của voice (ASR). Âm thanh mẫu ở tiêu đề phần và mỗi tiêu đề mục."""
import sys, math
from hw_core import *
from cues import Cues
c = Cues(A + "words_p4.json")
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p4.wav"
OFFSET = 1.5
VOICE_DUR = 454.45
TOTAL = OFFSET + VOICE_DUR + 0.8
OUT = "/mnt/user-data/outputs/Phan4_Chu_ky_luong_va_Tham_so_luong.mp4"
# tiêu đề mục (voice-time, đặt ở khoảng lặng ngay trước khi đọc tiêu đề)
H = dict(ckl=35.55, scope=137.1, delete=189.75, tsl=227.5, approve=289.25, after=339.35, link=393.6)
SFX_AT = [0.0] + [OFFSET + v for v in H.values()]

# ---------- Screen recordings ----------
REC_DT = U + "Phần_4__Kỳ_lương_từ_đầu_tháng.mp4"
REC_2625 = U + "Phần_4__CKL_26_25.mp4"
REC_TSL = U + "phần_4__Tham_số_lương.mp4"
REC_LIST = U + "Phần_3__Chu_kỳ_lương.mp4"
APP_OLD = U + "Phần_2__Bảng_lương_trên_App.MP4"
# Bản quay phiếu lương mới (số liệu cộng/trừ đúng logic). Ánh xạ mốc của bản cũ -> bản mới để giữ nguyên nhịp các cảnh.
APP = U + "Phiếu_lương_nhân_viên_xem.MP4"
_APP_PTS = [(0.0, 0.0), (5.8, 6.0), (7.8, 10.6), (9.7, 12.7), (13.6, 16.5), (17.5, 19.5), (19.5, 21.8), (23.3, 21.8)]
def app_t(t_old):
    if t_old <= 0: return 0.0
    for (a_, ca), (b_, cb) in zip(_APP_PTS, _APP_PTS[1:]):
        if a_ <= t_old <= b_: return ca + (t_old - a_) * (cb - ca) / (b_ - a_)
    return 21.8

ZOOM = (420, 0, 1300, 650)          # phóng vùng form cho dễ đọc
_clips = {}
def clip(key, path, size, crop=ZOOM):
    if key not in _clips: _clips[key] = Clip(path, size, crop)
    return _clips[key]

IMG_CHECKBOX = U + "1791534636443_image.png"     # Cho phép quản trị cập nhật dữ liệu khi khóa lương
IMG_LOCKDATE = U + "1791534669138_image.png"     # Ngày khóa công, phép = 2 / Giờ 12:00
IMG_TOOLTIP = U + "1791534676218_image.png"      # Tooltip thời gian duyệt công tối đa QLTT
_imgs = {}
def kb_image(path, box0, box1, k, size):
    """Ảnh chụp màn hình có hiệu ứng zoom chậm (Ken Burns) từ box0 tới box1."""
    if path not in _imgs: _imgs[path] = Image.open(path).convert("RGB")
    k = ease(k); box = tuple(box0[i] + (box1[i] - box0[i]) * k for i in range(4))
    return _imgs[path].resize(size, Image.LANCZOS, box=box)

def mix_color(col, a, base=(225, 232, 248)):
    a = clamp(a); return tuple(int(col[i] * a + base[i] * (1 - a)) for i in range(3))

def badge(d, x, y, ok, s, r0=24):
    if s <= 0.01: return
    r = r0 * s
    d.ellipse([x - r, y - r, x + r, y + r], fill=GREEN if ok else RED)
    w = max(int(6 * s), 1)
    if ok: d.line([x - r * 0.45, y, x - r * 0.1, y + r * 0.4, x + r * 0.5, y - r * 0.35], fill=WHITE, width=w, joint="curve")
    else:
        d.line([x - r * 0.4, y - r * 0.4, x + r * 0.4, y + r * 0.4], fill=WHITE, width=w)
        d.line([x - r * 0.4, y + r * 0.4, x + r * 0.4, y - r * 0.4], fill=WHITE, width=w)

# ================= Title cards =================
def sc_part(img, d, t):
    paste(img, SECTION)
    pill(d, 250, 250, 280, 84, BLUE, "PHẦN 4", 40, pop(t, -1.45), weight="ExtraBold")
    for j, line in enumerate(["CHU KỲ LƯƠNG", "& THAM SỐ LƯƠNG"]):
        k = p(t, -1.3 + j * 0.15, 0.5)
        if k > 0: text(d, (110, 400 + j * 130 + (1 - k) * 60), line, 104, NAVY, anchor="lm", align="left")
    underline(d, 115, 630, 760, p(t, -0.9, 0.6))
    k = p(t, -0.7, 0.5)
    if k > 0: text(d, (110, 715 + (1 - k) * 30), "Nền tảng trước khi xây dựng bảng lương", 44, NAVY, "Bold", anchor="lm", align="left")

def sub_card(img, d, t, t0, kicker, lines, size=118):
    paste(img, SECTION)
    pill(d, 110 + 170, 280, 340, 76, BLUE, kicker, 30, pop(t, t0 + 0.05), weight="ExtraBold")
    for j, line in enumerate(lines):
        k = p(t, t0 + 0.15 + j * 0.12, 0.45)
        if k > 0: text(d, (110, 430 + j * size * 1.12 + (1 - k) * 50), line, size, NAVY, anchor="lm", align="left")
    underline(d, 115, 430 + (len(lines) - 1) * size * 1.12 + size * 0.75, 700, p(t, t0 + 0.45, 0.5))
    person(img, d, CB, 1180, 900, 340, pop(t, t0 + 0.4, 0.5), "C&B", 30)

def mk_sub(key, kicker, lines, size=118):
    return lambda img, d, t: sub_card(img, d, t, H[key], kicker, lines, size)

# ================= Intro =================
STEP_LABELS = ["Chu kỳ lương", "Tham số lương", "Bảng lương", "Chạy lương", "Kiểm tra kết quả"]
STEP_KINDS = ["calendar", "shield", "logic", "run", "check"]
STEP_COLS = [BLUE, NAVY, ORANGE, CYAN, GREEN]
def step_row(d, t, y, appear, lit=(0, 1), dim_others=True, focus=None):
    cw, gap = 300, 40; x0 = (W - (5 * cw + 4 * gap)) / 2 + cw / 2
    for i in range(5):
        x = x0 + i * (cw + gap)
        s_ = pop(t, appear + i * 0.1, 0.45)
        if s_ <= 0.01: continue
        on = i in lit or i == focus
        card(d, x, y, cw, 90, s_, on, STEP_COLS[i])
        icon(d, STEP_KINDS[i], x - cw * s_ / 2 + 45 * s_, y, s_, STEP_COLS[i] if on or not dim_others else (200, 206, 222), 28)
        text(d, (x - cw * s_ / 2 + 86 * s_, y), STEP_LABELS[i], fit_size(d, STEP_LABELS[i], 26 * s_, "Bold", (cw - 100) * s_),
             INK if on or not dim_others else GREY, "Bold", anchor="lm")
        if i < 4: arrow(d, x + cw / 2 + 4, y, x + cw / 2 + gap - 4, y, p(t, appear + 0.5, 0.3), ORANGE, 4)
    return x0, cw, gap

def sc_intro1(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Hai phần nền tảng", c("trong đó", shift=-0.2))
    x0, cw, gap = step_row(d, t, 260, c("trong đó"), lit=(0, 1) if t >= c("hai phần") else (), dim_others=t >= c("hai phần"))
    k = p(t, c("nền tảng"), 0.5)
    if k > 0:
        xa, xb = x0 - cw / 2, x0 + cw + gap + cw / 2
        d.line([xa, 330, xa, 350, xb, 350, xb, 330], fill=ORANGE, width=5)
        pill(d, (xa + xb) / 2, 380, 240, 60, ORANGE, "Nền tảng", 28, pop(t, c("nền tảng")))
    hcard(d, 560, 600, 640, 160, pop(t, c("kỳ tính")), BLUE, "calendar", "Chu kỳ lương\nXác định kỳ tính lương", 32, True)
    hcard(d, 560, 800, 640, 160, pop(t, c("dữ liệu đầu")), NAVY, "shield", "Tham số lương\nKiểm soát dữ liệu đầu vào", 32, True)
    k = pop(t, c("xây dựng bảng"))
    arrow(d, 900, 700, 1180, 700, p(t, c("xây dựng bảng"), 0.4), ORANGE, 7)
    hcard(d, 1480, 700, 520, 170, k, ORANGE, "logic", "Trước khi xây dựng\nBảng lương", 32, True)

def sc_intro2(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thường đã thiết lập từ khi triển khai", c("thực tế", 13.41))
    k = pop(t, c("giai đoạn", 15.32))
    if k > 0.01:
        card(d, 1100, 560, 900, 470, k, True, BLUE)
        text(d, (1100, 380), "Giai đoạn khởi tạo hệ thống", 38 * k, NAVY)
        text(d, (1100, 430), "Triển khai ứng dụng nhân sự", 30 * k, BLUE, "Bold")
    for j, (lab, kind, col) in enumerate([("Chu kỳ lương", "calendar", BLUE), ("Tham số lương", "shield", NAVY)]):
        s_ = pop(t, c("triển khai", 17.44) + j * 0.3)
        hcard(d, 1100, 560 + j * 140, 640, 110, s_, col, kind, lab, 34)
        badge(d, 1370, 560 + j * 140, True, pop(t, c("ứng dụng", 18.01) + j * 0.2, 0.4))
    person(img, d, CB, 380, 860, 420, pop(t, c("hai phần", 13.41)), "C&B")

def sc_intro3(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Trong video này", c("trong video"))
    s_ = pop(t, c("không đi"))
    if s_ > 0.01:
        hcard(d, 400, 330, 560, 120, s_, GREY, "edit", "Thiết lập từ đầu", 34)
        x = p(t, c("thiết lập từ", 22.51), 0.3)
        if x > 0: d.line([130, 330, 130 + 540 * x, 330], fill=RED, width=10)
    pill(d, 400, 470, 380, 70, NAVY, "Tập trung vào", 30, pop(t, c("tập trung")))
    items = [(c("hiểu ý"), "Hiểu ý nghĩa\ncủa từng phần", "search", BLUE), (c("biết những"), "Biết thông tin nào\ncần kiểm tra", "check", CYAN),
             (c("hiểu các", 29.67), "Hiểu liên quan thế nào\nđến dữ liệu tính lương", "db", ORANGE)]
    for j, (st, lab, kind, col) in enumerate(items):
        y = 600 + j * 150
        hcard(d, 640, y, 820, 125, pop(t, st), col, kind, lab, 32, j == 2 and t >= st)
    k = pop(t, c("quan trọng nhất"))
    if k > 0.01:
        pill(d, 1260, 900, 300, 64, RED, "Quan trọng nhất", 26, k)
        sparks(d, 1080, 860, -1, p(t, c("quan trọng nhất", shift=0.3), 0.3), t, 0.6); sparks(d, 1440, 860, 1, p(t, c("quan trọng nhất", shift=0.3), 0.3), t, 0.6)
    person(img, d, CB, 1580, 640, 380, pop(t, c("tập trung")), "C&B")

# ================= Chu kỳ lương =================
def month_strip(d, t, x0, y, label, n_days, cell, start_day=1, col=BLUE, k=1.0):
    if k <= 0.01: return
    d.rounded_rectangle([x0, y - 50, x0 + n_days * cell, y - 12], 10, fill=mix_color(col, 0.18 * k + (1 - k)))
    text(d, (x0 + n_days * cell / 2, y - 31), label, 24, mix_color(col, k), "Bold")
    for i in range(n_days):
        x = x0 + i * cell
        d.rectangle([x + 2, y, x + cell - 2, y + 44], fill=mix_color((238, 242, 252), k, (225, 232, 248)))
        if (i + start_day) in (1, 25, 26) or i + start_day == n_days:
            text(d, (x + cell / 2, y + 22), str(i + start_day), 16, mix_color(GREY, k), "Bold")

def range_bar(d, x0, x1, y, col, label, k):
    if k <= 0: return
    xe = x0 + (x1 - x0) * k
    d.rounded_rectangle([x0, y, xe, y + 40], 20, fill=col)
    if k > 0.9: text(d, ((x0 + x1) / 2, y + 20), label, 24, WHITE, "Bold")

def sc_ckl_def(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Chu kỳ lương là gì?", c("chu kỳ lương là", 35.76, -0.3))
    hcard(d, W / 2, 270, 1300, 140, pop(t, c("khoảng thời", 36.65)), BLUE, "calendar",
          "Khoảng thời gian hệ thống dùng để lấy dữ liệu\nvà tính lương cho một kỳ", 36, True)
    k = p(t, c("quy định", 42.80), 0.5)
    cell = 19; x0 = 230; y = 560
    month_strip(d, t, x0, y, "Tháng 7", 31, cell, k=k)
    month_strip(d, t, x0 + 31 * cell + 16, y, "Tháng 8", 31, cell, k=k)
    # Cách 1: ngày 1 -> cuối tháng
    a = p(t, c("từ ngày một", 43.76), 0.8)
    range_bar(d, x0, x0 + 31 * cell, y + 70, BLUE, "01/07 → 31/07", a)
    hcard(d, 1690, y + 90, 340, 100, pop(t, c("từ ngày một", 43.76)), BLUE, "calendar", "Từ ngày 1\nđến cuối tháng", 26)
    # Cách 2: 26 tháng trước -> 25 tháng sau
    b = p(t, c("mươi sáu", 47.89), 1.2)
    range_bar(d, x0 + 25 * cell, x0 + 31 * cell + 16 + 25 * cell, y + 140, ORANGE, "26/07 → 25/08", b)
    hcard(d, 1690, y + 220, 340, 100, pop(t, c("chu kỳ riêng", 45.85)), ORANGE, "calendar", "Chu kỳ riêng\n26 → 25", 26)

CK_SZ = (760, 380)
def sc_ckl_rec(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Khai báo Từ ngày – Đến ngày", c("khi tạo", 52.24, -0.2))
    st = c("khi tạo", 52.24)
    for j, (key, path, ft, spd, lab, col) in enumerate([("dt", REC_DT, 14.0, 1.4, "Từ ngày 1 → cuối tháng", BLUE),
                                                         ("26", REC_2625, 0.0, 0.85, "Từ ngày 26 → ngày 25", ORANGE)]):
        x = 500 + j * 920
        s_ = pop(t, st + j * 0.25, 0.6)
        scr = clip(key, path, CK_SZ).get(ft + (t - st) * spd) if s_ > 0.98 else None
        laptop(img, d, x, 260, CK_SZ[0], CK_SZ[1], scr, s_)
        pill(d, x, 760, 460, 76, col, lab, 30, s_)
    pill(d, 700, 900, 260, 70, NAVY, "Từ ngày", 30, pop(t, c("từ ngày", 54.51)))
    pill(d, 1000, 900, 260, 70, NAVY, "Đến ngày", 30, pop(t, c("đến ngày", 55.41)))
    k = pop(t, c("đúng kỳ", 56.39))
    if k > 0.01: text(d, (1400, 900), "theo đúng kỳ lương\nđang áp dụng", 28 * max(k, 0.3), INK, "Bold")

ST_COLS = [GREEN, NAVY, ORANGE]; ST_NAMES = ["Công khai", "Chốt", "Ẩn"]; ST_ICONS = ["people", "lock", "search"]
def sc_ckl_states(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Trạng thái của chu kỳ lương", c("trạng thái", 63.07))
    st = c("khi tạo", 59.02)
    s_ = pop(t, st, 0.6)
    scr = clip("st", REC_2625, (900, 450)).get(2.0 + (t - st) * 0.6) if s_ > 0.98 else None
    laptop(img, d, 640, 230, 900, 450, scr, s_)
    hcard(d, 640, 820, 760, 110, pop(t, c("trạng thái phù", 63.07)), BLUE, "calendar", "Ngoài thời gian tính lương:\nchọn trạng thái phù hợp", 28)
    pill(d, 1560, 330, 380, 80, NAVY, "3 trạng thái", 34, pop(t, c("ba trạng", 68.01)))
    for j, w in enumerate(["công khai", "chốt", "ẩn"]):
        hcard(d, 1560, 470 + j * 150, 380, 120, pop(t, c(w, 69)), ST_COLS[j], ST_ICONS[j], ST_NAMES[j], 34, True)

APP_SZ = (270, 600)
def state_tabs(d, t, active):
    for j in range(3):
        x = 560 + j * 400
        on = j == active
        d.rounded_rectangle([x - 180, 175, x + 180, 245], 35, fill=ST_COLS[j] if on else WHITE, outline=ST_COLS[j], width=4)
        text(d, (x, 210), ST_NAMES[j], 32, WHITE if on else ST_COLS[j])

def sc_states(img, d, t):
    paste(img, BOARD)
    T_CK, T_CH, T_AN = 72.15, 92.54, 111.35
    act = 0 if t < T_CH else (1 if t < T_AN else 2)
    board_title(d, t, "Trạng thái chu kỳ lương", 72.06, y=95)
    state_tabs(d, t, act)
    col = ST_COLS[act]
    def pts(items):
        for j, (st, lab, kind) in enumerate(items):
            hcard(d, 520, 360 + j * 150, 800, 125, pop(t, st), col, kind, lab, 30)
    if act == 0:
        pts([(c("like", 73.74), "Dùng sau khi doanh nghiệp\ngo-live tính lương tự động", "check"),
             (c("tự động chạy", 79.03), "Hệ thống tự động\nchạy lương hằng ngày", "run"),
             (c("cập nhật", 82.09), "Thu nhập cập nhật theo\ndữ liệu phát sinh trong kỳ", "grow")])
        ps = pop(t, c("tự động chạy", 79.03), 0.6)
        scr = clip("app2", APP, APP_SZ, None).get(app_t(13.0 + (t - 80) * 0.6)) if ps > 0.98 else None
        phone(img, d, 1250, 300, APP_SZ[0], APP_SZ[1], scr, ps)
        k = pop(t, c("hằng ngày", 80.09))
        if k > 0.01:
            day = 5 + int(clamp((t - c("hằng ngày", 80.09)) / 6) * 4)
            icon(d, "run", 1530, 380, k, CYAN, 46)
            pill(d, 1530, 470, 200, 60, CYAN, f"Ngày {day:02d}", 26, k)
        person(img, d, EMP, 1660, 800, 300, pop(t, c("nhân viên", 85.48)), "Nhân viên", 28)
        pill(d, 1250, 990, 560, 70, GREEN, "Thấy thu nhập thay đổi theo từng ngày", 26, pop(t, c("thay đổi", 89.35)))
    elif act == 1:
        pts([(c("hoàn tất", 92.10), "Hoàn tất kỳ lương &\nthanh toán cho nhân viên", "check"),
             (c("chuyển", 96.12), "C&B chuyển chu kỳ lương\nsang trạng thái Chốt", "lock"),
             (c("kết quả cuối", 101.15), "Số liệu là kết quả cuối cùng\ntại thời điểm chi lương", "doc"),
             (c("ngừng", 104.43), "Ngừng tự động chạy lại\nkỳ lương này hằng ngày", "run")])
        k = pop(t, c("chuyển", 96.12), 0.5)
        if k > 0.01:
            card(d, 1300, 470, 520, 380, k, True, NAVY)
            icon(d, "doc", 1300, 420, k, BLUE, 80)
            text(d, (1300, 560), "Bảng lương", 32 * k, INK)
            icon(d, "lock", 1430, 340, pop(t, c("chốt", 97.66)), NAVY, 46)
        s2 = pop(t, c("ngừng", 104.43))
        if s2 > 0.01:
            icon(d, "run", 1180, 340, s2, CYAN, 40)
            d.line([1150, 310, 1210, 370], fill=RED, width=8)
        person(img, d, EMP, 1660, 830, 280, pop(t, c("nhân viên vẫn", 106.51)), "Nhân viên", 28)
        pill(d, 1300, 760, 560, 70, GREEN, "Vẫn xem được thu nhập kỳ đã chốt", 26, pop(t, c("xem thu", 108.34)))
    else:
        pts([(c("thiết lập và", 113.14), "Giai đoạn thiết lập\n& chạy thử hệ thống", "edit"),
             (c("đối chiếu", 117.25), "Đối chiếu kết quả\nHaraworks với Excel", "compare"),
             (c("xây dựng", 123.67), "Kiểm tra khi xây dựng &\nđiều chỉnh công thức mới", "fx")])
        k = pop(t, c("đối chiếu", 117.25))
        if k > 0.01:
            card(d, 1150, 380, 300, 170, k, True, BLUE)
            lw, lh = int(LOGO_IMG.width * 0.75 * k), int(LOGO_IMG.height * 0.75 * k)
            lg = LOGO_IMG.resize((max(lw, 1), max(lh, 1)), Image.LANCZOS); img.paste(lg, (int(1150 - lw / 2), int(380 - lh / 2)), lg)
            k2 = pop(t, c("xoa", 120.49))
            card(d, 1600, 380, 300, 170, k2, True, GREEN)
            icon(d, "sheet", 1600, 365, k2, GREEN, 50)
            if k2 > 0.01: text(d, (1600, 440), "Excel", 26 * k2, GREEN)
            arrow(d, 1310, 360, 1440, 360, p(t, c("xoa", 120.49), 0.4), ORANGE, 5)
            arrow(d, 1440, 400, 1310, 400, p(t, c("xoa", 120.49, 0.2), 0.4), ORANGE, 5)
        s1 = pop(t, c("không hiển", 128.91))
        person(img, d, EMP, 1200, 870, 260, s1, "Nhân viên", 28)
        badge(d, 1290, 640, False, s1, 30)
        if s1 > 0.01: text(d, (1200, 960), "Không thấy kết quả", 24, RED, anchor="ma")
        s2 = pop(t, c("cấp quyền", 131.44))
        person(img, d, CB, 1600, 870, 260, s2, "C&B", 28)
        badge(d, 1700, 640, True, s2, 30)
        if s2 > 0.01: text(d, (1600, 960), "Được cấp quyền xem", 24, GREEN, anchor="ma")

# ================= Phạm vi áp dụng =================
UNITS = [("Cửa hàng 67\nHoàng Văn Thái", EMP, "Nhân viên A"), ("Phòng\nMarketing", STAFF, "Nhân viên B"), ("Đơn vị\nkhác", None, None)]
def unit_boxes(img, d, t, appear, state):
    """state: list of 'on'/'off'/'neutral' per unit."""
    for j, (name, who, lab) in enumerate(UNITS):
        x = 900 + j * 360; s_ = pop(t, appear + j * 0.15)
        if s_ <= 0.01: continue
        col = {"on": GREEN, "off": RED, "neutral": BLUE, "dim": (190, 198, 218)}[state[j]]
        card(d, x, 600, 320, 500, s_, state[j] in ("on", "off"), col)
        text(d, (x, 410), name, fit_size(d, name, 28 * s_, "ExtraBold", 280 * s_), INK if state[j] != "dim" else GREY)
        if who is not None: person(img, d, who, x, 720, 220, s_, lab, 24)
        else:
            for q in range(3):
                qx = x - 80 + q * 80
                icon(d, "people", qx, 640, s_, (170, 180, 205) if state[j] == "dim" else BLUE, 30)
        if state[j] in ("on", "off"):
            badge(d, x + 160, 350, state[j] == "on", s_, 28)
            text(d, (x, 810), "Xem được phiếu lương" if state[j] == "on" else "Không xem được", 22, col, "ExtraBold")

def radio(d, x, y, label, on, k=1.0):
    d.ellipse([x - 16, y - 16, x + 16, y + 16], outline=BLUE, width=4, fill=WHITE)
    if on: d.ellipse([x - 8, y - 8, x + 8, y + 8], fill=BLUE)
    text(d, (x + 30, y), label, 28, INK, "Bold", anchor="lm")

def sc_scope(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Đơn vị, vị trí công việc muốn mở kỳ lương", c("đơn vị", 140.61, -0.3), size=52)
    T_ALL, T_TUY, T_EX, T_PH = c("tất cả", 148.24), c("tùy", 155.31), c("cửa hàng", 162.47), c("thiết lập này", 173.15)
    k = pop(t, c("đơn vị", 140.61))
    if k > 0.01:
        card(d, 330, 420, 440, 260, k, True, BLUE)
        text(d, (330, 335), "Phạm vi xem phiếu lương", 26 * k, NAVY)
        if k > 0.9:
            radio(d, 180, 410, "Tất cả", T_ALL <= t < T_TUY)
            radio(d, 180, 480, "Tùy chỉnh", t >= T_TUY)
    hcard(d, 330, 680, 440, 130, pop(t, c("nhân viên nào", 144.23)), NAVY, "people", "Xác định nhân viên nào\nđược xem phiếu lương", 26)
    if t < T_ALL: return
    if t < T_TUY: state = ["on", "on", "on"]
    elif t < T_EX: state = ["neutral", "neutral", "neutral"]
    elif t < T_PH:
        state = ["on" if t >= c("cửa hàng", 162.47) else "neutral",
                 "off" if t >= c("nhân viên b", 169.16) else "neutral", "neutral"]
    else:
        state = ["on", "dim", "dim"] if t >= c("một số", 180.11) else ["neutral", "neutral", "neutral"]
    unit_boxes(img, d, t, T_ALL, state)
    if t >= T_PH:
        pill(d, 330, 860, 440, 70, ORANGE, "Triển khai theo từng giai đoạn", 26, pop(t, c("theo từng", 177.19)))
        k2 = pop(t, c("chưa hiển", 185.57))
        if k2 > 0.01: text(d, (1440, 900), "Đơn vị chưa áp dụng: chưa hiển thị phiếu lương", 26 * max(k2, 0.3), GREY, "Bold")

FIELD_CROP = (1040, 355, 520, 260)      # vùng trường "Đơn vị, VTCV muốn mở kỳ lương" (bản quay kỳ lương đầu tháng)
def sc_scope_demo(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Minh họa trên Haraworks", 188.4)
    s_ = pop(t, 188.6, 0.6)
    scr = clip("field", REC_DT, (840, 420), FIELD_CROP).get(12.0) if s_ > 0.98 else None
    laptop(img, d, 620, 250, 840, 420, scr, s_)
    a, b = c("tất cả", 189.00), c("tùy", 189.03)
    if s_ > 0.98:
        for yy, st_, col in [(490, a, BLUE), (535, b, ORANGE)]:
            k = p(t, st_, 0.3)
            if k > 0 and (t < b or st_ == b): d.rounded_rectangle([395, yy - 24, 395 + 260 * k, yy + 24], 14, outline=col, width=5)
    pill(d, 420, 830, 260, 76, BLUE, "Tất cả", 32, pop(t, a))
    pill(d, 760, 830, 260, 76, ORANGE, "Tùy", 32, pop(t, b))
    ex = c("với tùy", 189.05)
    if t >= ex:
        hcard(d, 1530, 330, 520, 120, pop(t, c("cửa hàng", 189.09)), ORANGE, "check", "Tùy: Cửa hàng 67\nHoàng Văn Thái", 28, True)
        for j, (who, lab, ok, w, af) in enumerate([(EMP, "Nhân viên A", True, "nhân viên a", 201), (STAFF, "Nhân viên B\n(Marketing)", False, "nhân viên b", 203)]):
            x = 1380 + j * 300; s2 = pop(t, c(w, af))
            person(img, d, who, x, 760, 260, s2, lab, 26)
            badge(d, x + 90, 520, ok, s2, 30)

# ================= Xóa chu kỳ lương =================
def sc_delete(img, d, t):
    paste(img, BOARD)
    WARN = c("tuy nhiên", 204.85)
    if t < WARN:
        board_title(d, t, "Chu kỳ dùng để kiểm tra, dùng thử", c("trong quá", 190.30))
        st = c("trong quá", 190.30); s_ = pop(t, st, 0.6)
        z = p(t, c("được xóa", 202.01) - 1.6, 1.4)
        box = (860 * z, 100 * z, 1720, 840 - 320 * z)
        sc_ = 860 / (box[2] - box[0])
        if s_ > 0.98:
            fr = clip("listbig", REC_LIST, (1720, 840), (0, 0, 1912, 935)).get(min(5.4, (t - st) * 0.9))
            laptop(img, d, 620, 260, 860, 420, fr.resize((860, 420), Image.LANCZOS, box=box), s_)
            if z > 0.95:
                for yy in (230, 287, 348):
                    x = 190 + (1630 - box[0]) * sc_; y = 282 + (yy - box[1]) * sc_
                    r = 26 + 8 * abs(math.sin(t * 5))
                    d.ellipse([x - r, y - r, x + r, y + r], outline=RED, width=5)
        else: laptop(img, d, 620, 260, 860, 420, None, s_)
        for j, (w, af) in enumerate([("kiểm tra", 194.73), ("dùng thử", 195.89), ("kiểm tra kết", 196.94)]):
            k = pop(t, c(w, af)); y = 340 + j * 150
            fade = p(t, c("được xóa", 202.01), 0.5)
            hcard(d, 1500, y, 440, 120, k, mix_color(BLUE, 1 - 0.6 * fade), "calendar", ["Kỳ kiểm tra", "Kỳ dùng thử", "Kỳ kiểm tra kết quả"][j], 30)
        tk = pop(t, c("được xóa", 202.01))
        if tk > 0.01:
            d.rounded_rectangle([1230, 800, 1770, 880], 40, fill=WHITE, outline=RED, width=4)
            text(d, (1500, 840), "Không còn dùng → có thể xóa", 28 * max(tk, 0.3), RED)
        pill(d, 620, 870, 560, 70, NAVY, "Hạn chế dữ liệu không cần thiết", 26, pop(t, c("hạn chế", 202.98)))
    else:
        k = pop(t, c("thận trọng", 206.62))
        board_title(d, t, "Thao tác cần đặc biệt thận trọng", WARN)
        if k > 0.01:
            card(d, W / 2, 330, 1200, 170, k, True, RED, (255, 238, 238))
            icon(d, "warn", W / 2 - 520 * k, 330, k, RED, 60)
            text(d, (W / 2 + 40, 330), "Xóa chu kỳ lương: toàn bộ dữ liệu tính toán\ncủa chu kỳ bị xóa và KHÔNG THỂ PHỤC HỒI",
                 fit_size(d, "Xóa chu kỳ lương: toàn bộ dữ liệu tính toán", 34 * k, "ExtraBold", 960 * k), RED)
        pill(d, W / 2, 500, 620, 74, NAVY, "Kiểm tra kỹ chu kỳ đang thao tác", 28, pop(t, c("kiểm tra kỹ", 216.99)))
        for j, (w, af, lab, ok, col, kind) in enumerate(
                [("dùng thử", 222.73, "Chu kỳ kiểm tra / dùng thử", True, BLUE, "calendar"),
                 ("đang lưu", 223.78, "Chu kỳ đang lưu kết quả\ntính lương cần sử dụng", False, NAVY, "lock")]):
            x = 640 + j * 640; s_ = pop(t, c(w, af))
            hcard(d, x, 720, 560, 160, s_, col, kind, lab, 30, True)
            if s_ > 0.01:
                badge(d, x + 250, 640, ok, s_, 28)
                text(d, (x, 840), "Có thể xóa" if ok else "Không xóa nhầm!", 28 * max(s_, 0.3), GREEN if ok else RED)
        if pop(t, c("đang lưu", 223.78)) > 0.01:
            text(d, (W / 2, 720), "≠", 90, ORANGE)

# ================= Tham số lương =================
def bubble(d, x, y, label, col, s_):
    if s_ <= 0.01: return
    w = (40 + len(label) * 16) * s_
    d.rounded_rectangle([x - w / 2, y - 30 * s_, x + w / 2, y + 30 * s_], 30 * s_, fill=col)
    text(d, (x, y), label, 24 * s_, WHITE, "Bold")

def sc_tsl_problem(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu vẫn thay đổi khi đang chốt lương", c("trong quá", 228.13))
    person(img, d, CB, W / 2, 760, 360, pop(t, c("cnb", 229.64)), "C&B")
    pill(d, W / 2, 300, 400, 76, BLUE, "Đang chốt & tính lương", 28, pop(t, c("kiểm tra và", 231.66)) * (1 - p(t, c("xác định rõ", 247.77) - 0.3, 0.3)))
    person(img, d, EMP, 300, 760, 320, pop(t, c("nhân viên", 233.40)), "Nhân viên")
    for j, (w, af) in enumerate([("công", 236.79), ("phép", 237.08), ("giờ làm", 237.56)]):
        s_ = pop(t, c(w, af))
        bubble(d, 580, 420 + j * 90, ["Đề nghị công", "Đề nghị phép", "Giờ làm thêm"][j], [BLUE, CYAN, ORANGE][j], s_)
    person(img, d, MANAGER, 1620, 760, 320, pop(t, c("quản lý", 238.96)), "Quản lý")
    for j in range(3):
        s_ = pop(t, c("phê duyệt", 239.87) + j * 0.2)
        bubble(d, 1340, 420 + j * 90, "Phê duyệt", GREEN, s_)
    k = pop(t, c("mất thêm", 243.31))
    if k > 0.01:
        card(d, W / 2, 930, 820, 110, k, True, RED, (255, 238, 238))
        icon(d, "clock", W / 2 - 360 * k, 930, k, RED, 38)
        text(d, (W / 2 + 30, 930), "Mất thêm thời gian chốt lại & tính lại lương", 30 * k, RED)
    k2 = pop(t, c("xác định rõ", 247.77))
    if k2 > 0.01:
        pill(d, W / 2, 250, 560, 76, NAVY, "Cần mốc dừng tiếp nhận dữ liệu", 28, k2)
        pill(d, W / 2, 340, 360, 70, ORANGE, "→ Tham số lương", 30, pop(t, c("thiết lập tham", 251.24)))

TS_SZ = (900, 450)
def sc_tsl_lock(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thời điểm khóa dữ liệu công, phép", c("thời điểm khóa", 253.94, -0.3))
    st = c("một trong", 252.68); s_ = pop(t, st, 0.6)
    scr = kb_image(IMG_LOCKDATE, (230, 40, 1110, 480), (450, 40, 1090, 360), (t - st - 1.0) / 4.0, TS_SZ) if s_ > 0.98 else None
    laptop(img, d, 600, 240, TS_SZ[0], TS_SZ[1], scr, s_)
    pill(d, 600, 860, 520, 76, NAVY, "Ngày khóa & giờ khóa công, phép", 26, pop(t, c("thời điểm khóa", 253.94)))
    hcard(d, 1500, 400, 620, 170, pop(t, c("nhân viên không", 257.38)), RED, "people", "Nhân viên KHÔNG thể gửi / điều chỉnh\nđề nghị công, phép, giờ làm thêm", 26, True)
    hcard(d, 1500, 620, 620, 150, pop(t, c("quản lý cũng", 264.61)), RED, "check", "Quản lý KHÔNG thể\ntiếp tục phê duyệt", 28, True)
    k = pop(t, c("của kỳ", 263.60))
    if k > 0.01: text(d, (1500, 790), "(của kỳ lương đó)", 26 * max(k, 0.3), GREY, "Bold")

def day_strip(d, x0, y, days, cell, k=1.0, highlight=(), bad=(), today=None, labels=True):
    for i, (dd, mm) in enumerate(days):
        x = x0 + i * cell
        fillc = (238, 242, 252)
        if i in highlight: fillc = (215, 245, 225)
        if i in bad: fillc = (255, 225, 225)
        d.rounded_rectangle([x + 4, y, x + cell - 4, y + 110], 16, fill=mix_color(fillc, k),
                            outline=GREEN if i in highlight else (RED if i in bad else LINE), width=4 if (i in highlight or i in bad) else 2)
        text(d, (x + cell / 2, y + 40), f"{dd:02d}", 40, mix_color(INK, k))
        text(d, (x + cell / 2, y + 82), f"Th.{mm}", 22, mix_color(GREY, k), "Bold")
        if i == today:
            d.polygon([(x + cell / 2 - 16, y - 34), (x + cell / 2 + 16, y - 34), (x + cell / 2, y - 12)], fill=ORANGE)
            text(d, (x + cell / 2, y - 56), "Hôm nay", 24, ORANGE, "ExtraBold")
        if i in bad: badge(d, x + cell - 18, y + 14, False, 1.0, 16)
        if i in highlight: badge(d, x + cell - 18, y + 14, True, 1.0, 16)

def lock_line(d, x, y0, y1, label, k):
    if k <= 0.01: return
    yy = y0 + (y1 - y0) * k
    for yv in range(int(y0), int(yy), 22): d.line([x, yv, x, min(yv + 12, yy)], fill=RED, width=6)
    if k > 0.9:
        icon(d, "lock", x, y0 - 40, 1.0, RED, 30)
        text(d, (x, y1 + 30), label, 26, RED)

def sc_tsl_example(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ví dụ: thời điểm khóa dữ liệu", c("ví dụ", 267.32))
    pill(d, 560, 230, 640, 76, NAVY, "Khóa dữ liệu: 12:00 ngày 2 hàng tháng", 28, pop(t, c("mười hai", 269.62)))
    pill(d, 1360, 230, 560, 76, BLUE, "Kỳ lương bắt đầu: ngày 1 hàng tháng", 28, pop(t, c("ngày bắt", 272.28)))
    days = [(28, 8), (29, 8), (30, 8), (31, 8), (1, 9), (2, 9), (3, 9), (4, 9)]
    cell = 190; x0 = (W - len(days) * cell) / 2; y = 470
    k = p(t, c("với kỳ", 274.92), 0.5)
    if k > 0:
        day_strip(d, x0, y, days, cell, k)
        kb = p(t, c("tháng tám", 275.86), 0.6)
        if kb > 0:
            xe = x0 + 4 * cell * kb
            d.rounded_rectangle([x0 + 4, y - 70, xe - 4, y - 20], 25, fill=BLUE)
            if kb > 0.9: text(d, (x0 + 2 * cell, y - 45), "Kỳ lương tháng 8", 26, WHITE)
        xl = x0 + 5.5 * cell
        lock_line(d, xl, y - 10, y + 160, "12:00 · 02/09 — Khóa dữ liệu kỳ tháng 8", p(t, c("khóa vào", 277.84), 0.5))
        sh = p(t, c("sau thời", 280.66), 0.5)
        if sh > 0:
            ov = Image.new("RGBA", (int(x0 + 8 * cell - xl), 110), (240, 82, 80, int(50 * sh)))
            img.paste(ov, (int(xl), y), ov)
    hcard(d, 640, 880, 760, 130, pop(t, c("nhân viên không", 281.26)), RED, "people", "Nhân viên: không gửi / điều chỉnh\nđề nghị kỳ lương tháng 8", 26, True)
    hcard(d, 1340, 880, 520, 130, pop(t, c("quản lý cũng", 286.37)), RED, "check", "Quản lý: không thể\nphê duyệt", 26, True)

def sc_approve(img, d, t):
    paste(img, BOARD)
    T_EX = c("ví dụ", 302.63)
    if t < T_EX:
        board_title(d, t, "Thời gian duyệt công tối đa", c("bên cạnh", 291.56))
        st = c("bên cạnh", 291.56); s_ = pop(t, st, 0.6)
        scr = kb_image(IMG_TOOLTIP, (230, 40, 1110, 480), (420, 170, 1060, 490), (t - st - 1.0) / 4.0, TS_SZ) if s_ > 0.98 else None
        laptop(img, d, 600, 240, TS_SZ[0], TS_SZ[1], scr, s_)
        person(img, d, MANAGER, 1500, 560, 300, pop(t, c("quản lý trực", 296.45)), "Quản lý trực tiếp", 28)
        hcard(d, 1500, 760, 620, 150, pop(t, c("phạm vi bao", 300.74)), NAVY, "calendar", "Được duyệt công trong phạm vi\nbao nhiêu ngày gần nhất", 28, True)
        return
    board_title(d, t, "Ví dụ: duyệt công tối đa 3 ngày", T_EX)
    pill(d, W / 2, 230, 520, 76, NAVY, "Thời gian duyệt công tối đa = 3 ngày", 28, pop(t, c("ba ngày", 305.56)))
    days = [(29, 8), (30, 8), (31, 8), (1, 9), (2, 9), (3, 9)]
    cell = 230; x0 = (W - len(days) * cell) / 2; y = 470
    T2 = c("sang ngày", 313.56)
    hl = []; today = None; bad = []
    if t < T2:
        if t >= c("vào ngày", 306.37): today = 3
        if t >= c("ngày một tháng chín", 309.00): hl.append(3)
        if t >= c("mươi mốt", 310.56): hl.append(2)
        if t >= c("ba mươi tháng", 312.18): hl.append(1)
    else:
        today = 4
        if t >= c("ngày hai tháng chín", 320.81): hl.append(4)
        if t >= c("ngày một tháng chín", 321.84): hl.append(3)
        if t >= c("mươi mốt", 323.77): hl.append(2)
        if t >= c("mươi mốt", 336.99): hl.remove(2); bad.append(2)
    k = p(t, T_EX + 0.3, 0.5)
    if k > 0: day_strip(d, x0, y, days, cell, k, hl, bad, today)
    if t >= T2:
        pill(d, x0 + 5.5 * cell, 640, 260, 60, ORANGE, "Trước 12:00", 26, pop(t, c("trước mười", 318.01)))
        xl = x0 + 3 * cell
        lock_line(d, xl, y - 10, y + 160, "12:00 · 02/09 — Khóa dữ liệu kỳ lương tháng 8", p(t, c("khóa dữ liệu", 329.31), 0.5))
    if t < T2: msg, st = "Phạm vi duyệt: 3 ngày gần nhất", c("có thể duyệt", 308.00)
    elif t < c("vì vậy", 331.45): msg, st = "Phạm vi dịch chuyển theo thời gian", c("dịch chuyển", 316.38)
    else: msg, st = "Từ 12:00 02/09: không còn duyệt công ngày 31/08", c("vì vậy", 331.45)
    hcard(d, W / 2, 870, 1000, 120, pop(t, st), RED if "không" in msg else GREEN, "calendar", msg, 32, True)

def sc_after(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ngoại lệ sau thời điểm khóa", c("trong thực", 341.06))
    st = c("vì vậy", 346.56); s_ = pop(t, st, 0.6)
    scr = kb_image(IMG_CHECKBOX, (230, 40, 1110, 480), (560, 180, 1200, 500), (t - st - 1.0) / 4.0, TS_SZ) if s_ > 0.98 else None
    laptop(img, d, 600, 240, TS_SZ[0], TS_SZ[1], scr, s_)
    hcard(d, 600, 330, 760, 120, pop(t, c("trường hợp", 344.47)) * (1 - p(t, st - 0.3, 0.3)), ORANGE, "warn",
          "Vẫn phát sinh trường hợp\ncần điều chỉnh dữ liệu", 30, True)
    pill(d, 600, 860, 760, 76, NAVY, "Cho phép quản trị cập nhật dữ liệu khi khóa", 26, pop(t, c("cho phép", 348.90)))
    T_Q = c("điểm quan", 358.58)
    if t < T_Q:
        person(img, d, CB, 1500, 620, 320, pop(t, c("khi bật", 351.84)), "C&B (quyền quản trị)", 28)
        hcard(d, 1500, 780, 620, 130, pop(t, c("xử lý", 355.55)), GREEN, "shield", "Xử lý dữ liệu phát sinh\nsau thời điểm khóa", 28, True)
    else:
        hcard(d, 1500, 330, 620, 140, pop(t, c("khi nào", 361.78)), NAVY, "lock", "Khi nào dữ liệu phải khóa?\n→ đảm bảo tiến độ tính lương", 26, True)
        hcard(d, 1500, 510, 620, 140, pop(t, c("ai được", 365.73)), GREEN, "shield", "Ai được quyền xử lý\nkhi có ngoại lệ?", 28, True)
        hcard(d, 1500, 720, 620, 140, pop(t, c("thời hạn", 371.09)), ORANGE, "calendar", "Thời hạn tạo yêu cầu công\ncủa nhân viên", 28, True)
        pill(d, 1500, 850, 500, 66, ORANGE, "Hạn chế yêu cầu tạo quá muộn", 26, pop(t, c("quá muộn", 375.49)))

def sc_principle(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Một nguyên tắc kiểm soát dữ liệu", c("chúng cùng", 380.59))
    k = pop(t, c("không tồn", 378.75))
    if k > 0.01: text(d, (W / 2, 190), "Các mốc thời gian không tồn tại riêng lẻ", 32 * max(k, 0.3), GREY, "Bold")
    items = [(c("bổ sung", 384.15), "Nhân viên bổ sung\ndữ liệu đến khi nào?", "people", BLUE),
             (c("duyệt đến", 386.65), "Quản lý được duyệt\nđến khi nào?", "check", CYAN),
             (c("được khóa", 388.76), "Khi nào dữ liệu\nđược khóa?", "lock", NAVY),
             (c("ai còn", 390.83), "Sau khóa, ai xử lý\nngoại lệ?", "shield", ORANGE)]
    cw, gap = 360, 60; x0 = (W - (4 * cw + 3 * gap)) / 2 + cw / 2; cy = 560
    for i, (st, lab, kind, col) in enumerate(items):
        x = x0 + i * (cw + gap)
        if i < 3: arrow(d, x + cw / 2 + 8, cy, x + cw / 2 + gap - 8, cy, p(t, items[i + 1][0] - 0.2, 0.25))
        active = st <= t < (items[i + 1][0] if i < 3 else 999)
        vcard(d, x, cy, cw, 380, pop(t, st), col, kind, lab, 28, active, f"0{i + 1}")

def sc_link(img, d, t):
    paste(img, BOARD)
    T_CHK = c("vì vậy", 415.31)
    if t < T_CHK:
        board_title(d, t, "Không tách rời khỏi bảng lương", c("đến đây", 394.93))
        k = pop(t, c("điểm quan", 395.57))
        if k > 0.01: pill(d, W / 2, 200, 460, 66, RED, "Điểm quan trọng cần ghi nhớ", 26, k)
        hcard(d, 520, 400, 700, 160, pop(t, c("chu kỳ lương giúp", 402.12)), BLUE, "calendar", "Chu kỳ lương\nTính lương cho kỳ nào", 32, True)
        hcard(d, 520, 640, 700, 160, pop(t, c("tham số lương giúp", 405.11)), NAVY, "shield", "Tham số lương\nMốc thời gian & dữ liệu đầu vào", 30, True)
        hb = pop(t, c("bảng lương những", 410.66), 0.6)
        for j, y in enumerate([400, 640]):
            arrow(d, 880, y, 1240, 520, p(t, c("khi đi", 409.97) + j * 0.15, 0.5), ORANGE, 7)
        if hb > 0.01:
            card(d, 1500, 520, 520, 360, hb, True, ORANGE)
            icon(d, "logic", 1500, 450, hb, ORANGE, 80)
            text(d, (1500, 560), "Bảng lương", 40 * hb, INK)
            text(d, (1500, 620), "thực hiện quy tắc tính lương", 26 * hb, GREY, "Bold")
        return
    board_title(d, t, "Trước khi xử lý bảng lương", T_CHK)
    person(img, d, CB, 360, 860, 420, pop(t, c("cần đảm", 417.30)), "C&B")
    items = [(c("đúng chu", 418.86), "Đúng chu kỳ lương đang được sử dụng", "calendar", BLUE),
             (c("đúng phạm", 420.93), "Đúng phạm vi áp dụng", "people", CYAN),
             (c("dữ liệu đầu", 422.73), "Dữ liệu đầu vào đã cập nhật, duyệt & khóa", "lock", NAVY)]
    for j, (st, lab, kind, col) in enumerate(items):
        y = 330 + j * 190
        hcard(d, 1160, y, 960, 150, pop(t, st), col, kind, lab, 34, True)
        badge(d, 1690, y, True, pop(t, st + 0.4, 0.4), 30)
    for j, (w, af) in enumerate([("cập nhật", 424.05), ("duyệt", 424.72), ("khóa", 425.29)]):
        pill(d, 900 + j * 260, 900, 220, 66, NAVY, ["Cập nhật", "Duyệt", "Khóa"][j], 28, pop(t, c(w, af)))
    k = pop(t, c("quy trình", 425.92))
    if k > 0.01: text(d, (1680, 900), "theo quy trình\ndoanh nghiệp", 24 * max(k, 0.3), GREY, "Bold")

def sc_outro1(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Vai trò trong toàn bộ quá trình", c("điều cần", 427.33))
    focus = 2 if t >= c("tập trung", 437.5) else None
    step_row(d, t, 300, c("vai trò", 428.50), lit=(0, 1), dim_others=True, focus=focus)
    for j in range(2):
        cw, gap = 300, 40; x0 = (W - (5 * cw + 4 * gap)) / 2 + cw / 2
        badge(d, x0 + j * (cw + gap) + cw / 2 - 18, 260, True, pop(t, c("sẵn sàng", 434.62) + j * 0.15, 0.4), 22)
    k = pop(t, c("tập trung", 437.5), 0.6)
    if k > 0.01:
        card(d, W / 2 + 40, 640, 780, 320, k, True, ORANGE)
        icon(d, "logic", W / 2 - 230, 640, k, ORANGE, 90)
        text(d, (W / 2 + 140, 600), "BẢNG LƯƠNG", 56 * k, NAVY)
        text(d, (W / 2 + 140, 680), "Phần cần tập trung nhiều nhất", 30 * k, ORANGE, "Bold")
        sparks(d, W / 2 - 380, 520, -1, p(t, c("bảng lương", 437.99, 0.3), 0.3), t); sparks(d, W / 2 + 460, 520, 1, p(t, c("bảng lương", 437.99, 0.3), 0.3), t)
    else:
        k2 = pop(t, c("thiết lập nền", 432.14))
        hcard(d, W / 2, 650, 860, 150, k2, GREEN, "check", "Thiết lập nền tảng & dữ liệu đầu vào\nđã sẵn sàng", 32, True)

def sc_outro2(img, d, t):
    paste(img, BOARD)
    # tiếp nối hình Bảng lương từ cảnh trước, thu nhỏ thành tiêu đề phần sau
    card(d, W / 2, 130, 720, 130, 1.0, True, ORANGE)
    icon(d, "logic", W / 2 - 290, 130, 1.0, ORANGE, 46)
    text(d, (W / 2 - 220, 105), "PHẦN TIẾP THEO", 24, ORANGE, anchor="lm")
    text(d, (W / 2 - 220, 150), "BẢNG LƯƠNG", 44, NAVY, anchor="lm")
    person(img, d, CB, 380, 800, 400, pop(t, c("phần tiếp", 439.20)), "C&B")
    icon(d, "q", 560, 360, pop(t, c("câu hỏi", 441.59, 0.3)), ORANGE, 50)
    hcard(d, 1150, 400, 1000, 200, pop(t, c("trước khi", 443.05)), ORANGE, "q",
          "Trước khi đưa bảng lương lên hệ thống,\nC&B cần chuẩn bị những gì?", 34, True)
    s1 = pop(t, c("chuyển cách", 448.83))
    if s1 > 0.01:
        hcard(d, 900, 740, 520, 140, s1, GREEN, "sheet", "Cách tính lương\nthực tế của doanh nghiệp", 26, True)
        arrow(d, 1180, 740, 1330, 740, p(t, c("thành cấu", 451.03), 0.4), ORANGE, 7)
    s2 = pop(t, c("cấu trúc", 451.33))
    if s2 > 0.01:
        card(d, 1580, 740, 440, 160, s2, True, BLUE)
        lw, lh = int(LOGO_IMG.width * 0.7 * s2), int(LOGO_IMG.height * 0.7 * s2)
        lg = LOGO_IMG.resize((max(lw, 1), max(lh, 1)), Image.LANCZOS); img.paste(lg, (int(1580 - lw / 2), int(710 - lh / 2)), lg)
        text(d, (1580, 790), "Cấu trúc bảng lương", 26 * s2, NAVY)

SCENES = [(-OFFSET, 4.36, "part"), (4.36, 13.94, "intro1"), (13.94, 20.13, "intro2"), (20.13, H["ckl"], "intro3"),
          (H["ckl"], 37.23, "h_ckl"), (37.23, 52.38, "ckl_def"), (52.38, 59.87, "ckl_rec"), (59.87, 72.06, "ckl_states"),
          (72.06, H["scope"], "states"), (H["scope"], 139.65, "h_scope"), (139.65, H["delete"], "scope"), 
          (H["delete"], 191.55, "h_delete"), (191.55, H["tsl"], "delete"), (H["tsl"], 229.11, "h_tsl"), (229.11, 253.32, "tsl_problem"),
          (253.32, 268.09, "tsl_lock"), (268.09, H["approve"], "tsl_example"), (H["approve"], 292.51, "h_approve"), (292.51, H["after"], "approve"),
          (H["after"], 341.93, "h_after"), (341.93, 377.32, "after"), (377.32, H["link"], "principle"), (H["link"], 395.77, "h_link"),
          (395.77, 427.91, "link"), (427.91, 441.0, "outro1"), (441.0, 999, "outro2")]
FN = dict(part=sc_part, intro1=sc_intro1, intro2=sc_intro2, intro3=sc_intro3,
          h_ckl=mk_sub("ckl", "PHẦN 4", ["CHU KỲ LƯƠNG"]), ckl_def=sc_ckl_def, ckl_rec=sc_ckl_rec, ckl_states=sc_ckl_states, states=sc_states,
          h_scope=mk_sub("scope", "CHU KỲ LƯƠNG", ["PHẠM VI ÁP DỤNG"], 104), scope=sc_scope, scope_demo=sc_scope_demo,
          h_delete=mk_sub("delete", "CHU KỲ LƯƠNG", ["XÓA CHU KỲ LƯƠNG"], 96), delete=sc_delete,
          h_tsl=mk_sub("tsl", "PHẦN 4", ["THAM SỐ LƯƠNG"]), tsl_problem=sc_tsl_problem, tsl_lock=sc_tsl_lock, tsl_example=sc_tsl_example,
          h_approve=mk_sub("approve", "THAM SỐ LƯƠNG", ["THỜI GIAN DUYỆT", "CÔNG TỐI ĐA"], 96), approve=sc_approve,
          h_after=mk_sub("after", "THAM SỐ LƯƠNG", ["KIỂM SOÁT DỮ LIỆU", "SAU THỜI ĐIỂM KHÓA"], 80), after=sc_after, principle=sc_principle,
          h_link=mk_sub("link", "PHẦN 4", ["MỐI LIÊN HỆ", "VỚI BẢNG LƯƠNG"], 96), link=sc_link, outro1=sc_outro1, outro2=sc_outro2)

def preview(times):
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.resize((960, 540)).save(f"/tmp/pv4_{tv}.png")

N = 12
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p4_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p4_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
