"""PHẦN 8.3 (voice 01/11/2026) — HIỂN THỊ TRÊN CÁC BÁO CÁO.
Kịch bản mới: Hiển thị trên báo cáo (xuất Excel) · Báo cáo tổng hợp lương theo đơn vị (ví dụ cửa hàng A/B) ·
Báo cáo tổng hợp lương theo nhân viên (khai thuế quý / quyết toán năm) · Chọn đúng công thức cho từng báo cáo.
Áp dụng lưu ý: tên chu kỳ "Tháng mm/yyyy"; số Tổng thu nhập ở báo cáo theo NV làm tròn 2 số lẻ; khung đúng mục voice nhắc."""
import sys, math
from hw_core import *
from part81 import sub_card, mini_chip, badge, full_of, shot_xy
from rename_tool import rename
import part83 as P
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p83b.wav"
OFFSET = 1.0
VOICE_DUR = 163.61
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan8_3_Thiet_lap_hien_thi.mp4"
HD = dict(bc=-0.6)
SFX_AT = [0.0]

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
def htv(img): fs_shot(img, P.IMG_HTV, P.HTV_FULL, P.HTV_FULL, 0)
def vhl(d, k, t): hl(d, P.XV(*P.V[k]), t)
LEFT = (1228, 405, 1770, 760)       # cột các ô "Hiển thị trên báo cáo / … theo đơn vị / … theo nhân viên"

# ảnh nút Xuất dữ liệu: đổi tên kỳ lương
XUAT2 = "/tmp/p83_xuat2.png"
_im = Image.open(P.IMG_XUAT).convert("RGB"); rename(_im, (896, 324, 1226, 356), "Tháng 07/2022", 28); _im.save(XUAT2)

REC_TN = U + "Xem_thu_nhập_nhân_viên.mp4"; REC_NV = U + "Báo_cáo_lương_cá_nhân__thuế_TNCN_.mp4"
REC_BR = dict(crop=(0, 0, 1824, 1078), size=(1920, 1135), y0=-55, sw=1824)
_clips = {}
def scr(img, key, path, tc):
    if key not in _clips: _clips[key] = Clip(path, REC_BR["size"], REC_BR["crop"])
    fr = _clips[key].get(tc); bg = Image.new("RGB", (1920, 1080), WHITE)
    if fr is not None: bg.paste(fr, (0, REC_BR["y0"]))
    img.paste(bg, (0, 0))
def B(x0, y0, x1, y1): s_ = 1920 / 1824; return (x0 * s_, y0 * s_ - 55, x1 * s_, y1 * s_ - 55)
NV_ROWS = [(535, "133,064.52"), (591, "13,608,870.97"), (646, "128,571,428.57"), (701, "783,792.31"), (756, "216,869.23"),
           (811, "865,322.58"), (867, "43,650.79"), (922, "6,924.62"), (977, "15,000,000.00"), (1033, "58,035,714.29")]

def sc_h_bc(img, d, t): sub_card(img, d, t, HD["bc"], "PHẦN 8", ["HIỂN THỊ TRÊN", "CÁC BÁO CÁO"], 100)

def sc_intro(img, d, t):
    htv(img)
    top_title(d, t, "Chọn công thức cần xuất hiện trên từng loại báo cáo", 2.4)
    if t >= 12.6:                      # 3 ô hiển thị trên báo cáo (2 ô đầu sát nhau → lề hẹp)
        for k_ in ("BC", "THDV"):
            b = P.XV(*P.V[k_]); hl(d, (b[0] + 7, b[1] + 7, b[2] - 7, b[3] - 7), t)
        vhl(d, "THNV", t)
    if t < 10.6: chip_bar(d, t, [(4.4, "Sau khi tính lương: tiếp tục dùng kết quả để tổng hợp báo cáo & các nghiệp vụ sau tính lương", NAVY)], size=21)
    else: chip_bar(d, t, [(10.8, "Lựa chọn tùy theo mục đích sử dụng của từng báo cáo", NAVY)], size=24)
    role_tag(img, d, CB, "C&B")

def sc_bc(img, d, t):
    if t < 21.4:
        htv(img); top_title(d, t, "Hiển thị trên báo cáo", 18.2)
        if t >= 19.4: vhl(d, "BC", t)
        role_tag(img, d, CB, "C&B"); return
    if t < 33.0:
        fs_shot(img, XUAT2, P.XUAT_BOX, P.XUAT_BOX, 0)
        top_title(d, t, "Xuất bảng lương ra file Excel", 21.5)
        if t >= 22.6: hl(d, P.XX(2584, 143, 2798, 214), t)
        if t >= 25.3: chip_bar(d, t, [(25.4, "Chỉ công thức được chọn thiết lập này mới xuất hiện trong file", NAVY)], size=24)
        role_tag(img, d, CB, "C&B"); return
    scr(img, "tn", REC_TN, 58.0)
    top_title(d, t, "File Excel chỉ gồm những kết quả cần xuất", 33.1)
    chip_bar(d, t, [(33.1, "Kiểm tra", BLUE), (34.0, "Đối chiếu", BLUE), (34.9, "Lưu trữ", BLUE)] if t < 36.0 else
             [(36.0, "Không đưa toàn bộ công thức dùng trong quá trình tính lương vào file", ORANGE)], size=24)
    role_tag(img, d, CB, "C&B")

STORES = [("Cửa hàng A", 61.0), ("Cửa hàng B", 68.2)]
def sc_dv(img, d, t):
    if t < 52.6:
        htv(img); top_title(d, t, "Hiển thị trên báo cáo tổng hợp lương theo đơn vị", 41.6)
        if t >= 42.8: vhl(d, "THDV", t)
        if t >= 47.9: chip_bar(d, t, [(48.0, "Kết quả công thức xuất hiện tại báo cáo tổng hợp lương theo đơn vị", NAVY)], size=23)
        role_tag(img, d, CB, "C&B"); return
    if t < 79.6:
        paste(img, BOARD)
        board_title(d, t, "Sau mỗi kỳ lương: tổng hợp chi phí lương theo đơn vị", 52.8, size=50)
        k0 = pop(t, 55.6, 0.4)
        if k0 > 0.01: text(d, (W / 2, 210), "Theo từng phòng ban, cửa hàng hoặc đơn vị", 28 * k0, NAVY, "Bold")
        for i, (lab, st) in enumerate(STORES):
            s_ = pop(t, st)
            if s_ <= 0.01: continue
            x = 560 + i * 800
            card(d, x, 430, 680, 260, s_, True, BLUE)
            if s_ > 0.9:
                text(d, (x, 340), lab, 32, BLUE)
                for j, row in enumerate(["Tổng tiền thưởng = ?", "Tổng tiền làm thêm giờ = ?"]):
                    k = pop(t, st + (0 if j == 0 else 3.2), 0.4) if i == 0 else 1
                    if k > 0.01: text(d, (x, 410 + j * 60), row, 26 * k, INK, "Bold")
        k1 = pop(t, 71.0)
        if k1 > 0.01:
            card(d, W / 2, 790, 1500, 200, k1, True, ORANGE)
            text(d, (W / 2, 735), "Chọn các công thức cần tổng hợp theo đơn vị", 26 * k1, INK, "Bold")
            for j, (st, lab) in enumerate([(75.9, "Thưởng"), (76.4, "Làm thêm giờ"), (78.2, "Các khoản lương"), (78.6, "Phụ cấp khác")]):
                mini_chip(d, 520 + j * 290, 820, 260, 60, lab, ORANGE, pop(t, st, 0.4), 24)
        role_tag(img, d, CB, "C&B"); return
    if t < 82.7:
        htv(img); top_title(d, t, "Bật hiển thị trên báo cáo tổng hợp lương", 79.7)
        vhl(d, "THDV", t); role_tag(img, d, CB, "C&B"); return
    fs_shot(img, P.IMG_BCDV, P.BCDV_BOX, P.BCDV_BOX, 0)
    if t >= 83.4: hl(d, P.XB(1106, 96, 1779, 132), t)
    if t >= 87.3: hl(d, P.XB(620, 345, 1080, 1140), t)
    if t < 88.4: chip_bar(d, t, [(83.5, "Báo cáo tổng hợp kết quả theo từng đơn vị", NAVY)], size=24)
    else: chip_bar(d, t, [(88.5, "Không phải tự cộng lại số liệu từ từng nhân viên", GREEN)], size=24)

def sc_nv(img, d, t):
    if t < 103.7:
        paste(img, BOARD)
        board_title(d, t, "Tổng hợp dữ liệu theo từng nhân viên", 95.7, size=54)
        s_ = pop(t, 99.8)
        if s_ > 0.01:
            card(d, W / 2, 520, 1100, 220, s_, True, BLUE)
            text(d, (W / 2, 520), "Phục vụ kê khai & quyết toán\nthuế thu nhập cá nhân", 36 * s_, BLUE)
        role_tag(img, d, CB, "C&B"); return
    if t < 109.8:
        htv(img); top_title(d, t, "Hiển thị tại báo cáo tổng hợp lương theo nhân viên", 103.9)
        if t >= 105.5: vhl(d, "THNV", t)
        role_tag(img, d, CB, "C&B"); return
    if t < 126.3:
        paste(img, BOARD)
        board_title(d, t, "Ví dụ: khai thuế theo quý hoặc quyết toán thuế cuối năm", 110.0, size=48)
        for j, (st, lab) in enumerate([(117.4, "Tổng thu nhập"), (118.4, "Tổng thu nhập chịu thuế"), (120.2, "Tổng số thuế TNCN phải nộp")]):
            hcard(d, W / 2, 330 + j * 150, 1000, 120, pop(t, st), [BLUE, ORANGE, RED][j], "chart", lab, 30, True)
        k = pop(t, 122.5, 0.4)
        if k > 0.01: text(d, (W / 2, 790), "của từng nhân viên trong khoảng thời gian cần khai báo", 28 * k, INK, "Bold")
        role_tag(img, d, CB, "C&B"); return
    scr(img, "nv", REC_NV, 12.0)
    for y, v in NV_ROWS: rename(img, B(1322, y - 3, 1508, y + 17), v, 17, align="right", mode="dark")
    top_title(d, t, "Báo cáo tổng hợp lương theo nhân viên", 126.5)
    if 129.5 <= t < 136.9: hl(d, B(728, 222, 1206, 248), t)
    if t >= 132.8: hl(d, B(1322, 470, 1512, 1052), t)
    if t >= 137.0: chip_bar(d, t, [(137.0, "Lấy số liệu 3 tháng khi khai thuế theo quý, hoặc cả năm khi quyết toán thuế TNCN", GREEN)], size=21)
    role_tag(img, d, CB, "C&B")

def sc_end(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Không cần đưa tất cả công thức vào cả hai báo cáo", 145.5, size=50)
    k0 = pop(t, 150.0, 0.4)
    if k0 > 0.01: text(d, (W / 2, 215), "Với mỗi báo cáo, bắt đầu từ nhu cầu sử dụng", 30 * k0, NAVY, "Bold")
    for i, (st, ttl, q, col) in enumerate([(153.2, "Báo cáo theo đơn vị", "Cần tổng hợp khoản nào\ntheo đơn vị?", BLUE),
                                           (156.0, "Báo cáo theo nhân viên", "Cần tổng hợp chỉ tiêu nào\ntheo từng nhân viên?", ORANGE)]):
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        x = 560 + i * 800
        card(d, x, 500, 700, 300, s_, True, col)
        if s_ > 0.9:
            text(d, (x, 400), ttl, 32, col)
            text(d, (x, 520), q, 30, INK, "Bold")
    pill(d, W / 2, 800, 980, 76, GREEN, "→ Chọn đúng công thức hiển thị trên báo cáo tương ứng", 27, pop(t, 158.6))
    role_tag(img, d, CB, "C&B")

SCENES = [(-OFFSET, 2.2, "h_bc"), (2.2, 18.0, "intro"), (18.0, 41.4, "bc"), (41.4, 95.2, "dv"), (95.2, 145.1, "nv"), (145.1, 999, "end")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv83c"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 6
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p83c_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p83c_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
