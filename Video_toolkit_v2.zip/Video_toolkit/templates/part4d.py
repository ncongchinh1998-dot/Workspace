"""PHẦN 4 — bản voice đầy đủ (Phần_4_-_voice_full).
Giữ các cảnh đã duyệt của bản trước (part4c) và chạy theo nhịp voice mới; dựng mới:
- Chu kỳ lương: khai báo Từ ngày/Đến ngày và Trạng thái trên TOÀN MÀN HÌNH Chỉnh sửa chu kỳ lương.
- Thời điểm khóa dữ liệu, mục mới "Giới hạn thời gian tạo công & duyệt công" (tạo công lùi, duyệt công tối đa, kết hợp với khóa).
- Chú thích dạng hộp có đường dẫn đặt ở vùng trống bên trái màn hình hệ thống, không đè lên chữ của hệ thống."""
import sys, math
sys.path.insert(0, "/home/claude")
_argv = sys.argv; sys.argv = ["p4c"]
C = {"__name__": "p4c"}
exec(compile(open("/home/claude/part4c.py").read(), "part4c", "exec"), C)
sys.argv = _argv
globals().update({k: v for k, v in C.items() if not k.startswith("__") and k not in ("SCENES", "FN", "preview", "N")})
from remap_voice import make_maps
from cues import Cues
c4 = Cues(A + "words_p4_v4.json")
M34, Minv34 = make_maps(A + "words_p4_v3.json", A + "words_p4_v4.json")
def v3(fn): return lambda img, d, t: fn(img, d, Minv34(t))

VOICE = A + "voice_p4_v4.wav"
VOICE_DUR = 531.29
TOTAL = OFFSET + VOICE_DUR + 0.8
OUT = "/mnt/user-data/outputs/Phan4_Chu_ky_luong_va_Tham_so_luong.mp4"
H4 = dict(ckl=M34(40.4), scope=M34(149.6), delete=M34(209.3), tsl=M34(247.1), lock=279.2, limit=327.0, after=431.4, link=M34(396.5))
SFX_AT = [0.0] + [OFFSET + v for v in H4.values()]

# ---------- chú thích: hộp chữ ở vùng trống bên trái + đường dẫn tới đúng ô ----------
def callout_below(d, X, field, label, col=RED, t=0.0, panel_bottom=None, w=300):
    """Hộp chú thích đặt ngay dưới màn hình hệ thống, đường dẫn thẳng lên ô (dùng cho ô ở cột phải)."""
    fb = X(*field); xc = (fb[0] + fb[2]) / 2
    y0 = (panel_bottom if panel_bottom is not None else X(0, 450, 0, 450)[1]) + 40
    f = fit_size(d, label, 22, "ExtraBold", w - 24)
    d.rounded_rectangle([xc - w / 2, y0, xc + w / 2, y0 + 48], 12, fill=col)
    text(d, (xc, y0 + 24), label, f, WHITE, "ExtraBold")
    d.line([xc, y0, xc, fb[3] + HL_PAD + 2], fill=col, width=4)
    d.ellipse([xc - 6, fb[3] + HL_PAD - 4, xc + 6, fb[3] + HL_PAD + 8], fill=col)

def callout(d, X, field, label, col=RED, t=0.0, side_x=70, k=1.0):
    if field[0] >= 770:                       # ô ở cột phải: chú thích bên dưới để đường dẫn không cắt qua chữ
        return callout_below(d, X, field, label, col, t)
    """X: hàm đổi toạ độ màn hình hệ thống; field: ô cần chỉ (toạ độ ảnh gốc); hộp đặt ở cột trống bên trái (x ~ 70–440 ảnh gốc)."""
    fb = X(*field); yc = (fb[1] + fb[3]) / 2
    bx0, _, bx1, _ = X(side_x, 0, 445, 0)
    f = fit_size(d, label, 22, "ExtraBold", bx1 - bx0 - 24)
    d.rounded_rectangle([bx0, yc - 24, bx1, yc + 24], 12, fill=col)
    text(d, ((bx0 + bx1) / 2, yc), label, f, WHITE, "ExtraBold")
    x2 = fb[0] - HL_PAD - 2
    d.line([bx1, yc, x2, yc], fill=col, width=4)
    d.ellipse([x2 - 6, yc - 6, x2 + 6, yc + 6], fill=col)

# ---------- màn hình Chỉnh sửa chu kỳ lương (toàn màn hình) ----------
IMG_TC2 = U + "Tùy_chỉnh.png"          # 2879x1533
TC_FULL = full_of(2879, 1533) if "full_of" in globals() else box169(1439.5, 766.5, 2879, 2879, 1533)
def tc_full(img):
    fs_shot(img, IMG_TC2, TC_FULL, TC_FULL, 0)
    k = 1920 / (TC_FULL[2] - TC_FULL[0])
    return lambda x0, y0, x1, y1: ((x0 - TC_FULL[0]) * k, (y0 - TC_FULL[1]) * k, (x1 - TC_FULL[0]) * k, (y1 - TC_FULL[1]) * k)
F_TUDEN = (1238, 385, 2382, 494); F_TRANGTHAI = (1238, 768, 1783, 862)
def sc_ckl_rec4(img, d, t):
    X = tc_full(img)
    top_title(d, t, "Khai báo Từ ngày – Đến ngày theo kỳ lương đang áp dụng", c4("khi tạo chu", 58))
    if t >= c4("từ ngày và", 60): hl(d, X(*F_TUDEN), t)
    role_tag(img, d, CB, "C&B")

REC_CKL = U + "Phần_4__CKL_26_25_1.mp4"     # 1912x1016 · Thêm mới chu kỳ lương, có mở danh sách Trạng thái (Công khai / Chốt / Ẩn)
_ckc = {}
def piece(t, pts):
    if t <= pts[0][0]: return pts[0][1]
    for (a_, ca), (b_, cb) in zip(pts, pts[1:]):
        if a_ <= t <= b_: return ca + (t - a_) * (cb - ca) / (b_ - a_)
    return pts[-1][1]
def sc_ckl_states4(img, d, t):
    if "c" not in _ckc: _ckc["c"] = Clip(REC_CKL, (1920, 1020), (0, 0, 1912, 1016))
    ct = piece(t, [(69.3, 6.0), (76.0, 7.45), (79.4, 8.4)])
    img.paste(Image.new("RGB", (1920, 1080), (255, 255, 255)), (0, 0))
    fr = _ckc["c"].get(ct)
    if fr is not None: img.paste(fr, (0, 30))
    k = 1920 / 1912
    B_ = lambda x0, y0, x1, y1: (x0 * k, y0 * k + 30, x1 * k, y1 * k + 30)
    top_title(d, t, "Trạng thái của chu kỳ lương", c4("lưu ý trạng", 66))
    if t >= c4("lưu ý trạng", 66) + 0.4:
        hl(d, B_(835, 440, 1160, 600) if 7.45 <= ct < 8.45 else B_(835, 440, 1160, 500), t)   # Trạng thái (+ danh sách 3 trạng thái)
    role_tag(img, d, CB, "C&B")

# ---------- màn hình Tham số lương: giá trị theo ví dụ (3 ngày) ----------
F_LUI_V = (781, 384, 860, 406)
def ts4(img, d, x, y, w, s=1.0, lui3=False):
    X = ts_screen(img, d, x, y, w, s, appr3=True)
    if lui3 and s > 0.01:
        b = X(*F_LUI_V); d.rectangle(b, fill=WHITE); k = (b[2] - b[0]) / 79
        f = ImageFont.truetype(A + "Inter.ttf", max(8, int(12.5 * k))); f.set_variation_by_name("Regular")
        d.text((b[0] + 9 * k, b[1] + 3 * k), "3", font=f, fill=(24, 24, 27))
    return X

def sc_lock4(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thời điểm khóa dữ liệu công phép của kỳ lương", 283.0, size=50)
    s_ = pop(t, 283.1)
    X = ts4(img, d, 40, 190, 1220, s_)
    if s_ > 0.9 and t < 286.6: hl(d, X(*F_BREAD), t)                         # đường dẫn tới màn hình
    if t >= 286.6:
        hl(d, X(*F_LOCK), t); callout(d, X, F_LOCK, "Ngày & giờ khóa", RED, t)
    items = [(c4("đây là mốc", 286), "Mốc ngừng cập nhật\ndữ liệu của kỳ lương", "lock", RED),
             (c4("nhân viên không", 292), "Nhân viên không gửi /\nđiều chỉnh đề nghị của kỳ", "people", BLUE),
             (c4("quản lý cũng", 298), "Quản lý không phê duyệt\nđề nghị thuộc kỳ đó", "check", NAVY)]
    for j, (st, lab, kind, col) in enumerate(items):
        hcard(d, 1600, 330 + j * 190, 560, 150, pop(t, st), col, kind, lab, 24, True)
    role_tag(img, d, CB, "C&B")

def sc_lock_ex4(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ví dụ: dữ liệu kỳ lương tháng 8 khóa lúc 12h ngày 02/09", 305.6, size=46)
    TB, TA = c4("trước thời điểm", 310), c4("từ mười hai", 318)
    X = ts4(img, d, 30, 230, 960)
    hl(d, X(*F_LOCK), t); callout(d, X, F_LOCK, "Khóa ngày 02 lúc 12:00", RED, t)
    if t < TA:
        lab, col, lk, note = "Trước 12h ngày 02/09", GREEN, (), "Dữ liệu kỳ tháng 8 vẫn được bổ sung / phê duyệt\nnếu còn trong thời gian cho phép"
    else:
        lab, col, lk, note = "Từ 12h ngày 02/09", RED, (0, 1, 2), "Dữ liệu kỳ tháng 8 đã khóa\nđể hoàn tất quá trình tính lương"
    pill(d, 1420, 260, 420, 66, col, lab, 28, pop(t, 306.2 if t < TA else TA))
    day_strip(d, t, 480, 4, (), lk, x0=1065, cw=148)
    d.rounded_rectangle([1065 - 70, 555, 1065 + 2 * 148 + 70, 575], 8, fill=(255, 220, 220) if t >= TA else (230, 236, 250))
    text(d, (1065 + 148, 600), "Kỳ lương tháng 8", 22, RED if t >= TA else NAVY, "Bold")
    if t >= TB: hcard(d, 1420, 760, 820, 150, pop(t, TB if t < TA else TA + 0.3), col, "calendar" if t < TA else "lock", note, 23, True)
    role_tag(img, d, CB, "C&B")

def sc_h_limit(img, d, t): sub_card(img, d, t, H4["limit"], "THAM SỐ LƯƠNG", ["GIỚI HẠN THỜI GIAN", "TẠO CÔNG & DUYỆT CÔNG"], 80)

def sc_two_settings(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Hai thiết lập liên quan thời gian tạo công & duyệt công", 330.5, size=48)
    X = ts4(img, d, 220, 170, 1480, 1.0, lui3=True)
    if t >= 332.6:
        hl(d, X(*F_LUI), t); callout(d, X, F_LUI, "Nhân viên tạo công", BLUE, t)
        hl(d, X(*F_APPR), t); callout(d, X, F_APPR, "Quản lý duyệt công", GREEN, t)
    role_tag(img, d, CB, "C&B")

def strip_case(img, d, t, title, field, color, who, who_lab, t_ex, label_ok, lui3):
    paste(img, BOARD)
    board_title(d, t, title, None if False else t_ex - 8, size=48)
    X = ts4(img, d, 30, 200, 960, 1.0, lui3=True)
    hl(d, X(*field), t); callout(d, X, field, label_ok, color, t)
    if t >= t_ex:
        pill(d, 1420, 260, 520, 66, color, "Ví dụ: 3 ngày · hôm nay 02/09", 26, pop(t, t_ex))
        day_strip(d, t, 470, 4, (2, 3, 4) if t >= t_ex + 1.0 else (), x0=1065, cw=148)
        if t >= t_ex + 1.0:
            for i in (0, 1):
                xx = 1065 + i * 148
                d.line([xx - 50, 440, xx + 50, 500], fill=GREY, width=3)
            hcard(d, 1420, 690, 820, 120, pop(t, t_ex + 1.0), color, "check",
                  f"{who_lab}: 31/08, 01/09, 02/09\nNgày trước đó nằm ngoài khoảng cho phép", 23, True)
    role_tag(img, d, who, "Nhân viên" if who is EMP else "Quản lý")

def sc_lui(img, d, t):
    strip_case(img, d, t, "Số ngày được phép tạo công lùi", F_LUI, BLUE, EMP, "Nhân viên tạo công cho",
               c4("ví dụ nếu", 346), "Tạo công lùi: 3 ngày", True)

def sc_duyet(img, d, t):
    strip_case(img, d, t, "Thời gian duyệt công tối đa của quản lý trực tiếp", F_APPR, GREEN, MANAGER, "Quản lý duyệt dữ liệu",
               c4("nếu thời gian", 369), "Duyệt công tối đa: 3 ngày", True)
    if t >= c4("tuy nhiên cả", 380):
        pill(d, 1420, 880, 820, 70, RED, "Cả hai vẫn bị giới hạn bởi thời điểm khóa dữ liệu", 24, pop(t, c4("tuy nhiên cả", 380)))

def sc_combined(img, d, t):
    paste(img, BOARD)
    TA = c4("từ mười hai giờ kỳ", 401)
    board_title(d, t, "Kết hợp với thời điểm khóa: 12h ngày 02/09", 390.0, size=48)
    X = ts4(img, d, 30, 200, 960, 1.0, lui3=True)
    hl(d, X(*F_LOCK), t); callout(d, X, F_LOCK, "Khóa 02 lúc 12:00", RED, t)
    hl(d, X(*F_LUI), t); hl(d, X(*F_APPR), t)
    callout(d, X, F_APPR, "Duyệt tối đa 3 ngày", GREEN, t)
    before = t < TA
    pill(d, 1420, 230, 420, 62, GREEN if before else RED, "Trước 12h ngày 02/09" if before else "Từ 12h ngày 02/09", 26, pop(t, 390.3 if before else TA))
    for r, (lab, col) in enumerate([("Nhân viên tạo công", BLUE), ("Quản lý duyệt công", GREEN)]):
        y = 420 + r * 230
        text(d, (1065 - 70, y - 85), lab, 24, col, "ExtraBold", anchor="lm")
        day_strip(d, t, y, 4 if r == 0 else -1, (2, 3, 4) if before else (3, 4), () if before else (2,), x0=1065, cw=148)
    if not before and t >= c4("dù ngày", 410):
        pill(d, 1420, 900, 820, 66, ORANGE, "31/08 bị khóa dù vẫn nằm trong 3 ngày gần nhất", 24, pop(t, c4("dù ngày", 410)))
    role_tag(img, d, CB, "C&B")

F_CHK = (777, 316, 1036, 352)
def sc_after4(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Kiểm soát dữ liệu sau thời điểm khóa", 434.2)
    X = ts4(img, d, 40, 190, 1220, pop(t, 434.4), lui3=True)
    s1 = pop(t, c4("trong quá trình vận", 433))
    if s1 > 0.01: hcard(d, 1600, 340, 560, 150, s1, ORANGE, "warn", "Sau thời điểm khóa vẫn có\nthể phát sinh dữ liệu cần điều chỉnh", 23, True)
    if t >= c4("tham số lương có", 438):
        hl(d, X(*F_CHK), t); callout(d, X, F_CHK, "Cho phép quản trị cập nhật khi khóa", NAVY, t)
    s2 = pop(t, c4("khi bật", 444))
    if s2 > 0.01:
        hcard(d, 1600, 560, 560, 170, s2, GREEN, "shield", "C&B có quyền quản trị vẫn\nxử lý được một số dữ liệu\nphát sinh sau thời điểm khóa", 23, True)
    role_tag(img, d, CB, "C&B")

def sc_three4(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Hiểu đơn giản ba thiết lập", 415.3)
    X = ts4(img, d, 220, 150, 1480, 1.0, lui3=True)
    rules = [(c4("số ngày được", 415), F_LUI, "Số ngày được phép tạo công lùi", "Nhân viên được tạo\ncông lùi đến ngày nào", BLUE, "Nhân viên tạo công"),
             (c4("thời gian duyệt công tối đa xác", 419), F_APPR, "Thời gian duyệt công tối đa", "Quản lý được duyệt\nlùi đến ngày nào", GREEN, "Quản lý duyệt công"),
             (c4("còn thời điểm", 423), F_LOCK, "Thời điểm khóa dữ liệu", "Khi nào việc cập nhật\ndữ liệu của kỳ phải dừng", RED, "Khóa dữ liệu")]
    cur = None
    for j, r in enumerate(rules):
        if t >= r[0]: cur = j
    for j, (st, box, name, mean, col, short) in enumerate(rules):
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        x = 560 + j * 440
        card(d, x, 920, 420, 200, s_, j == cur, col)
        text(d, (x, 860), name, fit_size(d, name, 23, "ExtraBold", 390) * s_, col, "ExtraBold")
        text(d, (x, 945), mean, 24 * s_, INK, "Bold")
        if t >= st: hl(d, X(*box), t); callout(d, X, box, short, col, t)
    role_tag(img, d, CB, "C&B")

# ---------- danh sách cảnh (thời gian voice đầy đủ) ----------
OLD = C["SCENES"]; FNC = C["FN"]
def mapped(name):
    for s, e, n in OLD:
        if n == name: return (M34(s) if s > -OFFSET else s, M34(e) if e < 900 else 999)
T_REC, T_ST, T_STATES = c4("khi tạo chu", 58), c4("ngoài khoảng", 64), c4("với trạng thái", 70) - 0.3
SCENES = [(-OFFSET, mapped("part")[1], "part"), (mapped("intro")[0], H4["ckl"], "intro"), (H4["ckl"], mapped("h_ckl")[1], "h_ckl"),
          (mapped("ckl_def")[0], T_REC, "ckl_def"), (T_REC, T_ST, "ckl_rec4"), (T_ST, T_STATES, "ckl_states4"),
          (T_STATES, H4["scope"], "states"), (H4["scope"], mapped("h_scope")[1], "h_scope"), (mapped("scope")[0], H4["delete"], "scope"),
          (H4["delete"], mapped("h_delete")[1], "h_delete"), (mapped("delete")[0], H4["tsl"], "delete"), (H4["tsl"], mapped("h_tsl")[1], "h_tsl"),
          (mapped("tsl_problem")[0], H4["lock"], "tsl_problem"), (H4["lock"], 283.0, "h_lock"), (283.0, 305.3, "lock4"),
          (305.3, H4["limit"], "lock_ex4"), (H4["limit"], 330.5, "h_limit"), (330.5, 339.0, "two_settings"), (339.0, 362.0, "lui"),
          (362.0, 389.6, "duyet"), (389.6, 414.8, "combined"), (414.8, H4["after"], "three4"),
          (H4["after"], 434.2, "h_after"), (434.2, mapped("principle")[0], "after4"), (mapped("principle")[0], H4["link"], "principle"),
          (H4["link"], mapped("h_link")[1], "h_link"), (mapped("link")[0], mapped("link")[1], "link"),
          (mapped("outro1")[0], mapped("outro1")[1], "outro1"), (mapped("outro2")[0], 999, "outro2")]
FN = {n: v3(FNC[n]) for n in ("intro", "h_ckl", "ckl_def", "states", "h_scope", "scope", "h_delete", "delete", "h_tsl", "tsl_problem",
                              "h_lock", "after", "principle", "h_link", "link", "outro1", "outro2")}
FN["part"] = FNC["part"]
FN["h_lock"] = lambda img, d, t: sub_card(img, d, t, H4["lock"], "THAM SỐ LƯƠNG", ["THỜI ĐIỂM KHÓA", "DỮ LIỆU CÔNG PHÉP"], 96)
FN["h_after"] = lambda img, d, t: sub_card(img, d, t, H4["after"], "THAM SỐ LƯƠNG", ["KIỂM SOÁT DỮ LIỆU", "SAU THỜI ĐIỂM KHÓA"], 80)
FN.update(after4=sc_after4, ckl_rec4=sc_ckl_rec4, ckl_states4=sc_ckl_states4, lock4=sc_lock4, lock_ex4=sc_lock_ex4, h_limit=sc_h_limit,
          two_settings=sc_two_settings, lui=sc_lui, duyet=sc_duyet, combined=sc_combined, three4=sc_three4)

def preview(times):
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.resize((960, 540)).save(f"/tmp/pv4d_{tv}.png")

N = 14
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p4d_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p4d_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
