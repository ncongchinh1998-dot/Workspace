"""PHẦN 2 — HÌNH DUNG KẾT QUẢ SAU KHI HOÀN TẤT TÍNH LƯƠNG
PHẦN 3 — CHU TRÌNH TÍNH LƯƠNG TRÊN HARAWORKS
Mốc hình neo theo từng từ của voice (ASR); âm thanh mẫu ở mỗi tiêu đề phần."""
import sys, math
from hw_core import *
from cues import Cues
c = Cues(A + "words_p23.json")
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p23.wav"
OFFSET = 0.8
VOICE_DUR = 140.45
TOTAL = OFFSET + VOICE_DUR + 0.8
P3 = 55.7                                    # khoảng lặng trước tiêu đề Phần 3
SFX_AT = [0.0, OFFSET + P3]                  # âm thanh mẫu cho mỗi tiêu đề phần (video-time)
OUT = "/mnt/user-data/outputs/Phan2_3_Ket_qua_va_Chu_trinh_tinh_luong.mp4"

# ---------- Screen recordings ----------
WEB = U + "Phần_2__Bảng_lương_C_B_gồm_các_thành_phần.mp4"; WEB_CROP = (0, 112, 1824, 878)
WEB2 = U + "Bảng_lương_gồm_các_thành_phần.mp4"     # bản quay mới: kéo ngang toàn bộ các cột bảng lương
APP_OLD = U + "Phần_2__Bảng_lương_trên_App.MP4"
# Bản quay phiếu lương mới (số liệu cộng/trừ đúng logic). Ánh xạ mốc của bản cũ -> bản mới để giữ nguyên nhịp các cảnh.
APP = U + "Phiếu_lương_nhân_viên_xem.MP4"
_APP_PTS = [(0.0, 0.0), (5.8, 6.0), (7.8, 10.6), (9.7, 12.7), (13.6, 16.5), (17.5, 19.5), (19.5, 20.7), (23.3, 20.7)]
def app_t(t_old):
    if t_old <= 0: return 0.0
    for (a_, ca), (b_, cb) in zip(_APP_PTS, _APP_PTS[1:]):
        if a_ <= t_old <= b_: return ca + (t_old - a_) * (cb - ca) / (b_ - a_)
    return 20.7

CKL = U + "Phần_3__Chu_kỳ_lương.mp4"; TSL = U + "Phần_3__Tham_số_lương.mp4"; CTL = U + "Phần_3__Công_thức_lương.mp4"
RUN = U + "Phần_3__Chạy_lương.mp4"
REC_CROP = (0, 0, 1912, 935)
# ---- Đồng nhất tên chu kỳ lương trên các bản quay: "Tháng mm/yyyy" ----
# (path) -> [(khung chữ gốc x0,y0,x1,y1 · chữ mới · khoảng thời gian clip áp dụng)]
_PERIOD_FIX = {   # (khung chữ gốc, chữ mới, khoảng thời gian clip, cỡ chữ theo px ảnh gốc, vùng lấy màu chữ mẫu)
    "Phần_3__Chu_kỳ_lương.mp4": [((135, 312, 330, 331), "Tháng 07/2022", (1.4, 99), 14.5, (134, 249, 241, 264)),
                                 ((135, 378, 300, 393), "Tháng 06/2022", (1.4, 99), 14.5, (134, 249, 241, 264))],
    "Phần_2__Bảng_lương_C_B_gồm_các_thành_phần.mp4": [((556, 287, 742, 305), "Tháng 07/2022", (0, 99), 15.0, None)],
    "Phiếu_lương_nhân_viên_xem.MP4": [((44, 185, 350, 210), "Tháng 10/2026", (4.0, 6.05), 22.0, None),
                                      ((44, 185, 350, 210), "Tháng 07/2022", (6.95, 20.85), 22.0, None),
                                      ((88, 168, 338, 190), "Tháng 10/2026", (6.05, 6.75), 22.0, None),
                                      ((88, 321, 360, 345), "Tháng 07/2022", (6.05, 6.75), 22.0, None)],
}
_FIX_FONT = {}
class FixClip(Clip):
    def __init__(self, path, size, crop, fixes):
        super().__init__(path, size, crop); self.fixes = fixes
    def get(self, t):
        fr = super().get(t)
        if fr is None: return fr
        tt = max(0.0, min(t, self.dur - 0.1)); todo = [f for f in self.fixes if f[2][0] <= tt <= f[2][1]]
        if not todo: return fr
        fr = fr.copy(); dd = ImageDraw.Draw(fr)
        cx, cy, cw, ch = self.crop if self.crop else (0, 0, None, None)
        if cw is None:
            from PIL import Image as _I
            cw, ch = self.src_size
        kx, ky = self.size[0] / cw, self.size[1] / ch
        for (x0, y0, x1, y1), txt, _, fpx, ref in todo:
            X0, Y0, X1, Y1 = (x0 - cx) * kx, (y0 - cy) * ky, (x1 - cx) * kx, (y1 - cy) * ky
            rb = ref if ref else (x0, y0, x1, y1)
            reg = fr.crop((int((rb[0] - cx) * kx), int((rb[1] - cy) * ky), int((rb[2] - cx) * kx) + 1, int((rb[3] - cy) * ky) + 1)).convert("RGB")
            px = list(reg.getdata())
            ink = max(px, key=lambda p: (p[2] - p[0]) * 2 - sum(p) / 3) if ref else min(px, key=lambda p: sum(p))   # màu link xanh / màu chữ tối
            bg = fr.getpixel((min(fr.width - 1, int(X1) + 6), int((Y0 + Y1) / 2)))
            dd.rectangle([X0 - 1, Y0 - 1, X1 + 1, Y1 + 1], fill=bg)
            fs = max(6, int(round(fpx * ky)))
            if fs not in _FIX_FONT:
                f_ = ImageFont.truetype(A + "Inter.ttf", fs); f_.set_variation_by_name("Regular"); _FIX_FONT[fs] = f_
            dd.text((X0, (Y0 + Y1) / 2), txt, font=_FIX_FONT[fs], fill=ink, anchor="lm")
        return fr

_clips = {}
def clip(key, path, size, crop=None):
    if key not in _clips:
        name = path.split("/")[-1]
        if name in _PERIOD_FIX:
            c_ = FixClip(path, size, crop, _PERIOD_FIX[name])
            if not crop:
                import subprocess as _sp
                w_, h_ = _sp.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", path],
                                 capture_output=True, text=True).stdout.strip().split(",")[:2]
                c_.src_size = (int(w_), int(h_))
            _clips[key] = c_
        else: _clips[key] = Clip(path, size, crop)
    return _clips[key]

# ================= PHẦN 2 =================
def part_card(img, d, t, t0, num, lines, sub, chars):
    paste(img, SECTION)
    pill(d, 250, 250, 280, 84, BLUE, f"PHẦN {num}", 40, pop(t, t0 + 0.05), weight="ExtraBold")
    for j, line in enumerate(lines):
        k = p(t, t0 + 0.2 + j * 0.15, 0.5)
        if k > 0: text(d, (110, 400 + j * 140 + (1 - k) * 60), line, 120, NAVY, anchor="lm", align="left")
    yl = 400 + (len(lines) - 1) * 140 + 100
    underline(d, 115, yl, 760, p(t, t0 + 0.5, 0.6))
    k = p(t, t0 + 0.7, 0.5)
    if k > 0: text(d, (110, yl + 80 + (1 - k) * 30), sub, 46, NAVY, "Bold", anchor="lm", align="left")
    for j, (idx, lab) in enumerate(chars):
        person(img, d, idx, 1110 + j * 210, 860, 280, pop(t, t0 + 0.6 + j * 0.15, 0.5), lab, 30)

def sc_p2(img, d, t):
    part_card(img, d, t, -0.8, 2, ["KẾT QUẢ", "TÍNH LƯƠNG"], "sau thiết lập sẽ trông như thế nào?", [(CB, "C&B"), (EMP, "Nhân viên")])

# Vùng màn hình hệ thống gần full màn (x0, y0, w, h)
FS_WEB = (0, 78, 1920, 924)            # full khung hình: bản quay web (đã cắt thanh trình duyệt), dư trên/dưới tô trắng
FS_REC = (0, 70, 1920, 939)            # full khung hình: bản quay ứng dụng web
PH_BIG = (405, 900)          # màn hình điện thoại lớn
TITLE_Y, TITLE_SZ = 78, 52

def piece(t, pts):
    if t <= pts[0][0]: return pts[0][1]
    for (a_, ca), (b_, cb) in zip(pts, pts[1:]):
        if a_ <= t <= b_: return ca + (t - a_) * (cb - ca) / (b_ - a_)
    return pts[-1][1]

def web_screen(t, st, spd, off=0.0):
    return clip("webfs", WEB, FS_WEB[2:], WEB_CROP).get(off + (t - st) * spd)

def sc_web(img, d, t):
    t_comp = 14.45
    o = t >= t_comp
    st = 3.1
    # Cùng bản quay danh sách bảng lương: đầu đoạn giữ ở các cột đầu, sau đó kéo ngang khớp từng thành phần voice liệt kê
    ct = piece(t, [(st, 0.0), (t_comp, 0.6), (17.6, 0.8), (19.0, 2.0), (20.1, 3.4), (21.0, 4.8), (22.0, 6.0), (22.6, 7.0),
                   (23.3, 8.5), (24.1, 10.0), (25.3, 10.9), (28.2, 11.0)])
    fullscreen(img, clip("webfs", WEB, FS_WEB[2:], WEB_CROP).get(ct), FS_WEB)
    if not o: top_title(d, t, "Kết quả hiển thị trên Haraworks", 3.4)
    else: top_title(d, t, "Bảng lương có thể bao gồm", t_comp)
    role_tag(img, d, CB, "C&B", pop(t, c("con", 3), 0.5))
    if not o:
        chip_bar(d, t, [(c("hoàn tất thiết", 4), "Hoàn tất thiết lập", GREEN), (c("chạy lương", 5), "Chạy lương", GREEN),
                        (c("kiểm tra", 10), "Kiểm tra", BLUE), (c("đối chiếu", 10), "Đối chiếu", CYAN), (c("quản lý", 10), "Quản lý kết quả", NAVY)])
    else:
        cols = [BLUE, CYAN, ORANGE, NAVY]
        items = [("công chuẩn", "Công chuẩn kỳ lương", 17), ("công thực", "Công thực tế", 18), ("ngày nghỉ", "Ngày nghỉ", 19.5),
                 ("làm thêm", "Làm thêm", 20.5), ("lương phụ", "Lương", 21.5), ("phụ cấp", "Phụ cấp", 22), ("thưởng", "Thưởng", 23),
                 ("khấu trừ", "Khấu trừ", 23.5), ("kết quả khác", "Các kết quả khác", 25)]
        chip_bar(d, t, [(c(w, af, -0.2 if w == "lương phụ" else 0), lab, cols[j % 4]) for j, (w, lab, af) in enumerate(items)], size=22, gap=10)

def sc_app(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Nhân viên xem trên ứng dụng", 28.4, TITLE_Y, TITLE_SZ)
    st = 28.4; ps = pop(t, st, 0.6)
    scr = clip("appbig2", APP, PH_BIG).get(app_t((t - st) * 1.58)) if ps > 0.98 else None
    phone(img, d, 960, 125, PH_BIG[0], PH_BIG[1], scr, ps)
    # Bên trái: nội dung về Nhân viên — icon vai trò đặt phía trên cột trái
    role_badge(img, d, EMP, "Nhân viên", 480, 360, pop(t, 28.6, 0.5))
    hcard(d, 480, 460, 420, 120, pop(t, c("thu nhập", 31)), BLUE, "chart", "Thu nhập", 34, True)
    hcard(d, 480, 610, 420, 120, pop(t, c("phiếu lương", 31.5)), CYAN, "doc", "Phiếu lương", 34, True)
    hcard(d, 480, 780, 420, 130, pop(t, c("chủ động", 40)), GREEN, "check", "Chủ động\nxem lại kết quả", 28, True)
    # Bên phải: nội dung về C&B — icon vai trò đặt phía trên cột phải
    t_cb = c("cấu trúc", 33)
    role_badge(img, d, CB, "C&B", 1500, 360, pop(t, t_cb, 0.5))
    hcard(d, 1500, 460, 560, 130, pop(t, t_cb), NAVY, "logic", "Hiển thị theo cấu trúc\nC&B đã thiết lập", 28, True)
    k = pop(t, c("gửi thủ công", 38))
    if k > 0.01:
        for j in range(3):
            x, y = 1420 + j * 80, 680 - j * 14
            d.rounded_rectangle([x - 50 * k, y - 34 * k, x + 50 * k, y + 34 * k], 8, fill=WHITE, outline=ORANGE, width=4)
            d.line([x - 50 * k, y - 34 * k, x, y + 4 * k, x + 50 * k, y - 34 * k], fill=ORANGE, width=4)
        x2 = p(t, c("gửi thủ công", 38, 0.4), 0.3)
        if x2 > 0:
            d.line([1350, 620, 1350 + 280 * x2, 620 + 110 * x2], fill=RED, width=12)
            d.line([1350, 730, 1350 + 280 * x2, 730 - 110 * x2], fill=RED, width=12)
        text(d, (1500, 800), "Không gửi thủ công\ntừng phiếu lương", 28 * max(k, 0.3), RED, "ExtraBold")

def sc_outputs(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Hai đầu ra của tính lương", c("tạo ra", 43, -0.3))
    # Đầu ra 1 & 2
    outs = [("bảng lương", 45, "Bảng lương", "doc", BLUE, CB, "C&B", 330),
            ("phiếu lương", 46, "Phiếu lương", "chat", CYAN, EMP, "Nhân viên", 700)]
    for w, af, lab, kind, col, who, wl, y in outs:
        s = pop(t, c(w, af))
        hcard(d, 1300, y, 400, 120, s, col, kind, lab, 34, True)
        person(img, d, who, 1660, y + 80, 200, pop(t, c(w, af, 0.5)), wl, 26)
    # Chu trình tính lương hoàn chỉnh trên Haraworks
    hs = pop(t, c("harws", 48), 0.6)
    cx, cy, R = 600, 560, 230
    if hs > 0.01:
        lw, lh = int(LOGO_IMG.width * 0.95 * hs), int(LOGO_IMG.height * 0.95 * hs)
        d.ellipse([cx - 175 * hs, cy - 175 * hs, cx + 175 * hs, cy + 175 * hs], fill=WHITE)
        lg = LOGO_IMG.resize((max(lw, 1), max(lh, 1)), Image.LANCZOS); img.paste(lg, (int(cx - lw / 2), int(cy - lh / 2 - 10)), lg)
    k = p(t, c("chu trình", 49), 1.0)
    if k > 0:
        d.arc([cx - R, cy - R, cx + R, cy + R], -90, -90 + 360 * k, fill=ORANGE, width=10)
        for i in range(5):
            a = math.radians(-90 + i * 72)
            if k * 5 > i: icon(d, ["calendar", "shield", "logic", "run", "check"][i], cx + R * math.cos(a), cy + R * math.sin(a),
                                  pop(t, c("chu trình", 49) + i * 0.18, 0.4), [BLUE, NAVY, ORANGE, CYAN, GREEN][i], 44)
        text(d, (cx, cy + 60), "Chu trình tính lương\nhoàn chỉnh", 28 * max(k, 0.3), NAVY, "ExtraBold")
    for i, (w, af, y) in enumerate([("bảng lương", 45, 330), ("phiếu lương", 46, 700)]):
        arrow(d, cx + R + 20, cy + (y - cy) * 0.3, 1080, y, p(t, c("chu trình", 49, 0.6) + i * 0.2, 0.5), ORANGE, 6)
    nx = pop(t, c("tiếp theo", 51))
    pill(d, 600, 930, 560, 80, NAVY, "Tiếp theo: toàn bộ chu trình", 30, nx)

# ================= PHẦN 3 =================
def sc_p3(img, d, t):
    part_card(img, d, t, P3, 3, ["CHU TRÌNH", "TÍNH LƯƠNG"], "trên Haraworks", [(CB, "C&B")])

STEP_LABELS = ["Chu kỳ lương", "Tham số lương", "Bảng lương", "Chạy lương", "Kiểm tra kết quả"]
STEP_KINDS = ["calendar", "shield", "logic", "run", "check"]
STEP_COLS = [BLUE, NAVY, ORANGE, CYAN, GREEN]
STEP_DESC = ["Xác định chu kỳ\nlương cần tính", "Kiểm tra tham số lương\nkiểm soát dữ liệu đầu vào",
             "Xây dựng bảng lương\nvới dữ liệu & công thức", "Thực hiện\nchạy lương", "Kiểm tra kết quả\nthu nhập từng nhân viên"]

def sc_steps(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Chu trình 5 bước trên Haraworks", c("hat", 59, -0.3))
    st = [c("xác định chu", 66), c("kiểm tra các", 68), c("xây dựng", 73), c("thực hiện chạy", 76), c("cuối cùng", 78)]
    n5 = c("năm bước", 62)
    cw, gap = 300, 40; x0 = (W - (5 * cw + 4 * gap)) / 2 + cw / 2; y = 210
    for i in range(5):
        x = x0 + i * (cw + gap)
        active = st[i] <= t < (st[i + 1] if i < 4 else 99)
        s_ = pop(t, n5 + i * 0.12, 0.45)
        if s_ <= 0.01: continue
        card(d, x, y, cw, 90, s_, active, STEP_COLS[i], WHITE)
        done = t >= st[i] - 0.05
        icon(d, STEP_KINDS[i], x - cw * s_ / 2 + 45 * s_, y, s_, STEP_COLS[i] if done else (200, 206, 222), 28)
        lab = STEP_LABELS[i] if done else f"Bước {i + 1}"
        text(d, (x - cw * s_ / 2 + 86 * s_, y), lab, fit_size(d, lab, 26 * s_, "Bold", (cw - 100) * s_), INK if done else GREY, "Bold", anchor="lm")
        if i < 4: arrow(d, x + cw / 2 + 4, y, x + cw / 2 + gap - 4, y, p(t, n5 + 0.6, 0.3), ORANGE, 4)
    person(img, d, CB, 480, 880, 420, pop(t, c("hat", 59)), "C&B")
    i = sum(1 for x in st if t >= x) - 1
    if i < 0:
        k = pop(t, n5 + 0.3, 0.5)
        if k > 0.01: text(d, (1180, 600), "5 bước", 150 * max(k, 0.3), NAVY)
        return
    cx, cy = 1180, 600; s_ = pop(t, st[i], 0.5)
    card(d, cx, cy, 860, 380, s_, True, STEP_COLS[i])
    if s_ > 0.01:
        icon(d, STEP_KINDS[i], cx - 430 * s_ + 130 * s_, cy, s_, STEP_COLS[i], 85)
        text(d, (cx - 430 * s_ + 250 * s_, cy - 120 * s_), f"BƯỚC {i + 1}", 30 * s_, STEP_COLS[i], anchor="lm")
        text(d, (cx - 430 * s_ + 250 * s_, cy + 10 * s_), STEP_DESC[i], fit_size(d, STEP_DESC[i], 42 * s_, "ExtraBold", 560 * s_), INK, anchor="lm", align="left")
        if i == 3:
            pr_ = clamp((t - st[3] - 0.3) / 1.0)
            d.rounded_rectangle([cx - 180, cy + 120, cx + 380, cy + 146], 13, fill=(230, 236, 248))
            if pr_ > 0: d.rounded_rectangle([cx - 180, cy + 120, cx - 180 + 560 * pr_, cy + 146], 13, fill=CYAN)
    sparks(d, cx - 470, cy - 160, -1, p(t, st[i] + 0.2, 0.3), t, 0.8)
    sparks(d, cx + 470, cy - 160, 1, p(t, st[i] + 0.2, 0.3), t, 0.8)

def sc_flow(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Một luồng rõ ràng", c("luồng", 84, -0.4))
    T5 = [c("xác định kỳ", 85), c("kiểm soát dữ", 87), c("thiết lập cách", 88), c("thực hiện chạy", 89.5), c("kiểm tra kết", 91)]
    labels = ["Xác định\nkỳ tính", "Kiểm soát dữ liệu\nđầu vào", "Thiết lập\ncách tính", "Thực hiện\nchạy lương", "Kiểm tra\nkết quả"]
    where = ["Chu kỳ lương", "Tham số lương", "Bảng lương", "Chạy lương", "Bảng lương & Phiếu lương"]
    cw, gap = 300, 50; x0 = (W - (5 * cw + 4 * gap)) / 2 + cw / 2; cy = 520
    for i in range(5):
        x = x0 + i * (cw + gap)
        if i < 4: arrow(d, x + cw / 2 + 8, cy, x + cw / 2 + gap - 8, cy, p(t, T5[i + 1] - 0.2, 0.25))
        active = T5[i] <= t < (T5[i + 1] if i < 4 else 99)
        s_ = pop(t, T5[i])
        vcard(d, x, cy, cw, 340, s_, STEP_COLS[i], STEP_KINDS[i], labels[i], 28, active, f"0{i + 1}")
        k = pop(t, T5[i] + 0.35, 0.4)
        if k > 0.01:
            d.rounded_rectangle([x - 135 * k, cy + 205, x + 135 * k, cy + 255], 25, fill=WHITE, outline=STEP_COLS[i], width=3)
            text(d, (x, cy + 230), where[i], fit_size(d, where[i], 22 * k, "Bold", 250 * k), STEP_COLS[i], "Bold")
        if active and s_ > 0.5:
            sparks(d, x - cw / 2 - 6, cy - 150, -1, p(t, T5[i] + 0.2, 0.3), t, 0.7)
            sparks(d, x + cw / 2 + 6, cy - 150, 1, p(t, T5[i] + 0.2, 0.3), t, 0.7)
    k = pop(t, T5[0] - 0.4, 0.4)
    if k > 0.01: text(d, (W / 2, 880), "Nơi thiết lập trên Haraworks", 28 * max(k, 0.3), GREY, "Bold")

# Mỗi thành phần + bản quay màn hình tương ứng (tốc độ gần 1x)
DETAIL = [  # (bắt đầu, tiêu đề, icon, màu, clip, crop, tốc độ, vai trò, [(cue, nhãn)])
    (93.4, "Chu kỳ lương", "calendar", BLUE, CKL, REC_CROP, 1.2, None, [(("khoảng thời", 95), "Khoảng thời gian lấy dữ liệu"), (("đúng kỳ", 97), "Tính lương đúng kỳ")]),
    (98.3, "Tham số lương", "shield", NAVY, TSL, REC_CROP, 1.3, None, [(("thời điểm", 100), "Thời điểm chốt dữ liệu công, phép"), (("trước khi", 102), "Trước khi tính lương")]),
    (104.3, "Bảng lương", "logic", ORANGE, CTL, REC_CROP, 1.15, CB, [(("xây dựng", 105), "C&B xây dựng các công thức"), (("chính sách", 107), "Theo chính sách lương của doanh nghiệp")]),
    (109.1, "Chạy lương", "run", CYAN, RUN, WEB_CROP, 0.85, None, [(("sử dụng", 110), "Hệ thống dùng các công thức này"), (("tính kết", 112), "Tính kết quả cho từng nhân viên")]),
]
def sc_detail(img, d, t):
    i = max(j for j in range(4) if t >= DETAIL[j][0] - 0.5)
    st, title, kind, col, path, crop, spd, role, notes = DETAIL[i]
    box = FS_WEB if crop == WEB_CROP else FS_REC
    fullscreen(img, clip(f"fs{i}", path, box[2:], crop).get(max(0, t - st) * spd + 0.2), box)
    top_title(d, t, title, st - 0.3)
    if role is not None: role_tag(img, d, role, "C&B", pop(t, st, 0.5))
    chip_bar(d, t, [(c(w, af), lab, col) for (w, af), lab in notes], size=26)

def sc_run(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "C&B thực hiện chạy lương", c("dữ liệu và", 114, -0.2))
    hcard(d, 300, 330, 400, 110, pop(t, c("dữ liệu và", 114)), BLUE, "db", "Dữ liệu", 32)
    hcard(d, 300, 470, 400, 110, pop(t, c("công thức tính", 115)), ORANGE, "fx", "Công thức\ntính lương", 30)
    pill(d, 300, 580, 260, 64, GREEN, "Sẵn sàng", 28, pop(t, c("sẵn sàng", 116)))
    role_tag(img, d, CB, "C&B", pop(t, c("cn", 117), 0.5))
    b = pop(t, c("chạy lương", 118))
    press = 1 - 0.08 * (p(t, c("chạy lương", 118, 0.3), 0.15) - p(t, c("chạy lương", 118, 0.5), 0.15))
    pill(d, 700, 760, 300 * press, 90, CYAN, "Chạy lương", 34, b)
    hs = pop(t, c("harws", 118.5), 0.6); cx, cy = 960, 470
    if hs > 0.01:
        r = 150 * hs
        d.ellipse([cx - r + 6, cy - r + 10, cx + r + 6, cy + r + 10], fill=SHADOW)
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=WHITE, outline=BLUE, width=6)
        lw, lh = int(LOGO_IMG.width * 0.75 * hs), int(LOGO_IMG.height * 0.75 * hs)
        lg = LOGO_IMG.resize((max(lw, 1), max(lh, 1)), Image.LANCZOS); img.paste(lg, (int(cx - lw / 2), int(cy - lh / 2)), lg)
        a = t * 2.4
        d.arc([cx - r - 18, cy - r - 18, cx + r + 18, cy + r + 18], math.degrees(a), math.degrees(a) + 100, fill=ORANGE, width=8)
    for j, (w, af, y0) in enumerate([("dữ liệu", 120, 330), ("công thức", 120.5, 470)]):
        ty = cy + (y0 - cy) * 0.4
        arrow(d, 505, y0, 790, ty, p(t, c(w, af), 0.4), BLUE if j == 0 else ORANGE, 6)
        if p(t, c(w, af, 0.4), 0.3) >= 1:
            f = (t * 1.2 + j * 0.5) % 1
            d.ellipse([505 + 285 * f - 10, y0 + (ty - y0) * f - 10, 505 + 285 * f + 10, y0 + (ty - y0) * f + 10], fill=BLUE if j == 0 else ORANGE)
    arrow(d, 1130, cy, 1270, cy, p(t, c("tạo ra", 122), 0.4), GREEN, 6)
    for j in range(5):
        s_ = pop(t, c("tạo ra", 122, 0.3) + j * 0.25, 0.4)
        if s_ <= 0.01: continue
        y = 260 + j * 125
        card(d, 1550, y, 500, 100, s_, False, GREEN)
        d.ellipse([1340, y - 30, 1400, y + 30], fill=[BLUE, CYAN, ORANGE, NAVY, BLUE][j])
        d.rounded_rectangle([1420, y - 22, 1420 + 180 * s_, y - 6], 8, fill=(200, 210, 232))
        d.rounded_rectangle([1420, y + 6, 1420 + 120 * s_, y + 22], 8, fill=(225, 231, 245))
        icon(d, "check", 1745, y, pop(t, c("từng nhân", 123) + j * 0.12, 0.4), GREEN, 26)
    k = pop(t, c("từng nhân", 123), 0.4)
    if k > 0.01: text(d, (1550, 900), "Kết quả cho từng nhân viên", 30 * max(k, 0.3), GREEN)

def sc_check(img, d, t):
    t_nv = c("nhân viên", 127.8) - 0.15
    if t >= t_nv:
        paste(img, BOARD)
        board_title(d, t, "Kết quả cuối cùng", t_nv, TITLE_Y, TITLE_SZ)
    if t < t_nv:
        st = 124.4
        fullscreen(img, clip("web4fs", WEB, FS_WEB[2:], WEB_CROP).get(17.0 + (t - st) * 0.8), FS_WEB)
        top_title(d, t, "Kết quả cuối cùng", st + 0.1)
        role_tag(img, d, CB, "C&B", pop(t, c("con", 125.5), 0.5))
        chip_bar(d, t, [(c("kiểm tra trên", 126), "Kiểm tra trên Bảng lương", BLUE)], size=28)
    else:
        ps = pop(t, t_nv, 0.5)
        scr2 = clip("app4big2", APP, PH_BIG).get(app_t(13.0 + (t - t_nv) * 1.2)) if ps > 0.98 else None
        phone(img, d, 960, 125, PH_BIG[0], PH_BIG[1], scr2, ps)
        role_badge(img, d, EMP, "Nhân viên", 1500, 360, pop(t, t_nv, 0.5))
        hcard(d, 1500, 460, 560, 130, pop(t, c("theo dõi", 128)), CYAN, "doc", "Theo dõi trên\nPhiếu lương", 30, True)
        hcard(d, 1500, 630, 560, 130, pop(t, c("cấu hình", 129.5)), NAVY, "logic", "Theo cấu hình\nhiển thị", 30, True)

def sc_bridge(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Trước khi đi vào Bảng lương", 131.85, TITLE_Y, TITLE_SZ)
    cards = [("kỳ tính", 134, "Đúng kỳ tính", "calendar", BLUE, "chu kỳ", 138, "Chu kỳ lương", CKL, 2.0),
             ("thời điểm", 134.8, "Thời điểm\nchốt dữ liệu", "lock", ORANGE, "tham số", 139, "Tham số lương", TSL, 6.5)]
    for j, (w, af, lab, kind, col, w2, af2, where, path, ft) in enumerate(cards):
        x0 = 60 + j * 940; xc = x0 + 430
        hcard(d, xc, 230, 520, 120, pop(t, c(w, af)), col, kind, lab, 32, True)
        s_ = pop(t, c(w2, af2), 0.5)
        box = (x0, 330, 860, 421)
        scr = clip(f"th{j}", path, box[2:], REC_CROP).get(ft) if s_ > 0.98 else None
        screen(img, d, box, scr, s_)
        pill(d, xc, 840, 360, 76, col, where, 32, s_)
    k = pop(t, c("hai nội", 136), 0.4)
    if k > 0.01: text(d, (W / 2, 960), "Hai nội dung thiết lập trước tiên", 30 * max(k, 0.3), GREY, "Bold")

SCENES = [(-OFFSET, 3.1, "p2"), (3.1, 28.2, "web"), (28.2, 43.0, "app"), (43.0, P3, "outputs"),
          (P3, 59.0, "p3"), (59.0, 82.1, "steps"), (82.1, 92.9, "flow"), (92.9, 113.95, "detail"),
          (113.95, 124.4, "run"), (124.4, 131.2, "check"), (131.2, 999, "bridge")]
FN = dict(p2=sc_p2, web=sc_web, app=sc_app, outputs=sc_outputs, p3=sc_p3, steps=sc_steps, flow=sc_flow,
          detail=sc_detail, run=sc_run, check=sc_check, bridge=sc_bridge)

def preview(times):
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.resize((960, 540)).save(f"/tmp/pv23_{tv}.png")

if __name__ == "__main__":
    n = int(TOTAL * FPS); N = 5; size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p23_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p23_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
