"""PHẦN 8.3 (voice 04/11/2026) — THIẾT LẬP HIỂN THỊ CỦA CÔNG THỨC LƯƠNG.
Báo cáo · Báo cáo tổng hợp lương theo đơn vị · theo nhân viên · Hiển thị trên bảng lương · Hiển thị với (ví dụ tháng 9/10)
· Ẩn trên Thu nhập cá nhân khi giá trị bằng 0.  Màn hình hệ thống lấy từ tư liệu 8.3; tên chu kỳ dạng "Tháng mm/yyyy"."""
import sys, math
from hw_core import *
from part81 import sub_card, mini_chip, badge
from rename_tool import rename
import part83 as P
import part83c as C

VOICE = A + "voice_p83d.wav"
OFFSET = 1.0
VOICE_DUR = 342.07
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = P.OUT if hasattr(P, "OUT") else "/mnt/user-data/outputs/Phan8_3_Thiet_lap_hien_thi.mp4"
OUT = "/mnt/user-data/outputs/Phan8_3_Thiet_lap_hien_thi.mp4"
HD = dict(ht=-0.6)
SFX_AT = [0.0]

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
XV, V = P.XV, P.V
def vhl(d, k, t): hl(d, XV(*V[k]), t)
ALLB = (1228, 932, 2378, 1172); LKB = (1228, 1190, 2378, 1420); LK_TU = (1258, 1325, 1792, 1397); ALL_F = (1262, 1072, 2370, 1130)

# ---------- ảnh sửa đè ----------
def _mk(src, dst, edits):
    im = Image.open(src).convert("RGB")
    for box, new, sz in edits: rename(im, box, new, sz, mode="dark")
    im.save(dst); return dst
HTV4 = _mk(P.IMG_HTV, "/tmp/p83_htv4.png", [((1276, 1338, 1312, 1382), "4", 30)])     # liền kề trước: từ ngày 4
HTV5 = _mk(P.IMG_HTV, "/tmp/p83_htv5.png", [((1276, 1338, 1312, 1382), "5", 30)])     # liền kề trước: từ ngày 5
TNCN2 = _mk(P.IMG_TNCN, "/tmp/p83_tncn2.png", [((244, 230, 572, 262), "Tháng 07/2022", 28)])
def htv(img, path=None): fs_shot(img, path or P.IMG_HTV, P.HTV_FULL, P.HTV_FULL, 0)

# ================= mở đầu =================
def sc_h_ht(img, d, t): sub_card(img, d, t, HD["ht"], "PHẦN 8", ["THIẾT LẬP HIỂN THỊ", "CỦA CÔNG THỨC LƯƠNG"], 88)

def sc_intro(img, d, t):
    if t < 8.2:
        paste(img, BOARD)
        board_title(d, t, "Sau khi xác định cách tính của công thức", 2.7, size=54)
        for i, (st, lab, kind, col) in enumerate([(3.3, "Công thức tính", "fx", BLUE), (4.8, "Cách thể hiện", "chart", ORANGE), (5.9, "Cách chạy", "run", NAVY)]):
            vcard(d, 560 + i * 400, 520, 360, 300, pop(t, st), col, kind, lab, 28, True)
        role_tag(img, d, CB, "C&B"); return
    htv(img)
    top_title(d, t, "Kết quả tính cần được sử dụng & hiển thị ở đâu?", 8.3)
    if t >= 10.4: vhl(d, "GROUP", t)
    role_tag(img, d, CB, "C&B")

# ================= Báo cáo =================
def sc_bc(img, d, t):
    if t < 16.8:
        htv(img); top_title(d, t, "Hiển thị trên báo cáo", 12.2)
        if t >= 13.0: vhl(d, "BC", t)
        role_tag(img, d, CB, "C&B"); return
    if t < 22.3:
        fs_shot(img, C.XUAT2, P.XUAT_BOX, P.XUAT_BOX, 0)
        top_title(d, t, "Kết quả được đưa vào file Excel khi xuất bảng lương", 16.9)
        if t >= 19.6: hl(d, P.XX(2584, 143, 2798, 214), t)
        role_tag(img, d, CB, "C&B"); return
    C.scr(img, "tn", C.REC_TN, 58.0)
    top_title(d, t, "File Excel gồm những khoản cần có", 22.4)
    chip_bar(d, t, [(25.3, "Kiểm tra", BLUE), (25.8, "Đối chiếu", BLUE), (26.9, "Lưu trữ theo quy trình nội bộ", BLUE)], size=24)
    role_tag(img, d, CB, "C&B")

# ================= Báo cáo theo đơn vị =================
def sc_dv(img, d, t):
    if t < 32.6:
        htv(img); top_title(d, t, "Hiển thị trên báo cáo tổng hợp lương theo đơn vị", 29.1)
        if t >= 29.8: vhl(d, "THDV", t)
        role_tag(img, d, CB, "C&B"); return
    if t < 46.3:
        fs_shot(img, P.IMG_BCDV, P.BCDV_BOX, P.BCDV_BOX, 0)
        if t >= 33.3: hl(d, P.XB(1106, 96, 1779, 132), t)
        if t >= 37.6: hl(d, P.XB(620, 345, 1080, 1140), t)
        chip_bar(d, t, [(35.1, "Tổng hợp các khoản lương theo từng phòng ban hoặc đơn vị sau mỗi kỳ lương", NAVY)] if t < 41.0 else
                 [(41.1, "Theo dõi tổng giá trị của từng khoản tại từng đơn vị", GREEN)], size=22)
        return
    if t < 55.1:
        paste(img, BOARD)
        board_title(d, t, "Ví dụ", 46.5, size=56)
        for i, (lab, st) in enumerate([("Cửa hàng A", 47.2), ("Cửa hàng B", 52.6)]):
            s_ = pop(t, st)
            if s_ <= 0.01: continue
            x = 560 + i * 800
            card(d, x, 470, 680, 300, s_, True, BLUE)
            if s_ > 0.9:
                text(d, (x, 370), lab, 34, BLUE)
                rows = [("Tổng tiền thưởng = ?", 47.2 if i == 0 else 52.6), ("Tổng lương tăng ca = ?", 49.9 if i == 0 else 52.6)]
                for j, (row, st2) in enumerate(rows):
                    k = pop(t, st2, 0.4)
                    if k > 0.01: text(d, (x, 450 + j * 70), row, 28 * k, INK, "Bold")
        role_tag(img, d, CB, "C&B"); return
    htv(img); top_title(d, t, "Chọn công thức tương ứng với khoản thu nhập cần tổng hợp", 55.2)
    if t >= 57.0: vhl(d, "THDV", t)
    chip_bar(d, t, [(60.3, "Dữ liệu được đưa vào báo cáo đúng nhu cầu", GREEN)], size=24)
    role_tag(img, d, CB, "C&B")

# ================= Báo cáo theo nhân viên =================
def sc_nv(img, d, t):
    if t < 67.1:
        htv(img); top_title(d, t, "Hiển thị trên báo cáo tổng hợp lương theo nhân viên", 63.6)
        if t >= 64.3: vhl(d, "THNV", t)
        role_tag(img, d, CB, "C&B"); return
    if t < 82.0:
        C.scr(img, "nv", C.REC_NV, 12.0)
        for y, v in C.NV_ROWS: rename(img, C.B(1322, y - 3, 1508, y + 17), v, 17, align="right", mode="dark")
        if t >= 67.9: hl(d, C.B(728, 222, 1206, 248), t)
        chip_bar(d, t, [(70.3, "Tổng hợp số liệu thu nhập & thuế TNCN của từng nhân viên", NAVY)] if t < 76.3 else
                 [(76.4, "Chuẩn bị số liệu kê khai thuế theo quý hoặc quyết toán thuế trong năm", GREEN)], size=22)
        role_tag(img, d, CB, "C&B"); return
    if t < 91.0:
        paste(img, BOARD)
        board_title(d, t, "Các chỉ tiêu cần tổng hợp", 82.2, size=54)
        for j, (st, lab, col) in enumerate([(84.8, "Tổng thu nhập", BLUE), (85.7, "Tổng thu nhập chịu thuế", ORANGE), (87.5, "Tổng số thuế TNCN phải nộp", RED)]):
            hcard(d, W / 2, 330 + j * 150, 1000, 120, pop(t, st), col, "chart", lab, 30, True)
        k = pop(t, 89.8, 0.4)
        if k > 0.01: text(d, (W / 2, 790), "của từng nhân viên", 30 * k, INK, "Bold")
        role_tag(img, d, CB, "C&B"); return
    htv(img); top_title(d, t, "Chọn công thức tương ứng với chỉ tiêu cần tổng hợp", 91.1)
    if t >= 93.2: vhl(d, "THNV", t)
    chip_bar(d, t, [(98.5, "Chuẩn bị số liệu kê khai & quyết toán thuế thuận tiện hơn", GREEN)], size=24)
    role_tag(img, d, CB, "C&B")

# ================= Hiển thị trên bảng lương =================
FORMS = [("Công thức trung gian 1", False), ("Lương thực tế", True), ("Công thức trung gian 2", False), ("Phụ cấp", True), ("Tổng thu nhập", True)]
def sc_bl(img, d, t):
    if t < 107.3:
        htv(img); top_title(d, t, "Hiển thị trên bảng lương", 102.7)
        if t >= 103.5: vhl(d, "BL", t)
        role_tag(img, d, CB, "C&B"); return
    if t >= 131.0:
        htv(img); top_title(d, t, "Hiển thị trên bảng lương", 131.0); vhl(d, "BL", t)
        role_tag(img, d, CB, "C&B"); return
    paste(img, BOARD)
    board_title(d, t, "Không phải kết quả nào cũng cần hiển thị", 107.4, size=52)
    for j, (lab, show) in enumerate(FORMS):
        s_ = pop(t, 107.8 + j * 0.3)
        mini_chip(d, 480, 260 + j * 110, 600, 70, lab, BLUE if show else (130, 140, 160), s_, 26)
    s2 = pop(t, 115.6)
    if s2 > 0.01:
        card(d, 1360, 500, 840, 560, s2, True, NAVY)
        if s2 > 0.9:
            text(d, (1360, 265), "Bảng lương", 32, NAVY)
            shown = [l for l, sh in FORMS if sh]
            for i, l in enumerate(shown):
                x = 1120 + i * 240
                d.rounded_rectangle([x - 110, 320, x + 110, 400], 12, fill=(232, 240, 255))
                text(d, (x, 360), l, fit_size(d, l, 20, "Bold", 200), NAVY, "Bold")
                for r in range(3): d.rounded_rectangle([x - 110, 420 + r * 70, x + 110, 470 + r * 70], 10, fill=(245, 247, 251))
            text(d, (1360, 700), "Chỉ bật với kết quả cần xem, kiểm tra, lưu trữ", 22, NAVY, "Bold")
    for j, (lab, show) in enumerate(FORMS):
        if show: arrow(d, 790, 260 + j * 110, 930, 260 + j * 110, p(t, 115.8, 0.4), BLUE, 5)
    k = pop(t, 122.8)
    if k > 0.01:
        card(d, W / 2 + 60, 900, 1300, 150, k, True, ORANGE)
        text(d, (W / 2 + 60, 875), "Không bật: công thức vẫn được tính & dùng trong công thức khác", 24 * k, INK, "Bold")
        k2 = pop(t, 128.0, 0.4)
        if k2 > 0.01: text(d, (W / 2 + 60, 925), "nhưng kết quả không hiển thị trên bảng lương", 24 * k2, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B")

# ================= Hiển thị với =================
def ctrl_board(d, t, t0):
    board_title(d, t, "Tình huống thường gặp trong thời gian xử lý lương", t0, size=50)
    for (st, y, col, items, msg) in [(t0 + 2.9, 400, GREEN, [(144.7, "Công"), (146.3, "Làm thêm giờ")], "Cho nhân viên\nkiểm tra trước"),
                                    (t0 + 6.6, 680, ORANGE, [(148.4, "Lương"), (148.7, "Phụ cấp"), (149.5, "Tổng thu nhập")], "Vẫn đang được\ntính toán")]:
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        card(d, 980, y, 1300, 210, s_, True, col)
        if s_ < 0.9: continue
        d.line([1170, y - 70, 1170, y + 70], fill=LINE, width=3)
        n = len(items); xs = [750 + (i - (n - 1) / 2) * 250 for i in range(n)]
        for x, (st2, lab) in zip(xs, items): mini_chip(d, x, y, 230, 62, lab, col, pop(t, st2, 0.4), 24)
        text(d, (1380, y), msg, 26, col)

def sc_htv(img, d, t):
    if t < 140.5:
        htv(img); top_title(d, t, "Khi bật Hiển thị trên bảng lương: hiển thị với", 131.1)
        if t < 138.6: vhl(d, "BL", t)
        else: vhl(d, "SEC", t)
        if t >= 133.5: chip_bar(d, t, [(133.5, "Công thức hiển thị ở những chu kỳ lương nào & trong khoảng thời gian nào", NAVY)], size=22)
        role_tag(img, d, CB, "C&B"); return
    paste(img, BOARD); ctrl_board(d, t, 140.6); role_tag(img, d, CB, "C&B")

# ví dụ tháng 9: dải ngày tháng 10
def oct_bar(d, t, y, lab, col, start, st, note=None):
    x0, x1 = 700, 1800; dx = (x1 - x0) / 31
    k = pop(t, st, 0.4)
    if k <= 0.01: return
    text(d, (390, y), lab, fit_size(d, lab, 26, "Bold", 560), col, "Bold")
    d.rounded_rectangle([x0, y - 22, x1, y + 22], 10, fill=(236, 240, 247))
    d.rounded_rectangle([x0 + (start - 1) * dx, y - 22, x0 + (start - 1) * dx + (x1 - x0 - (start - 1) * dx) * k, y + 22], 10, fill=col)
    if note and k > 0.9: text(d, (x0 + (start - 1) * dx + 12, y), note, 20, WHITE, "Bold", anchor="lm")
def oct_axis(d, y=330):
    x0, x1 = 700, 1800; dx = (x1 - x0) / 31
    for day in (1, 3, 4, 5, 10, 15, 20, 25, 31):
        x = x0 + (day - 0.5) * dx; text(d, (x, y), str(day), 22, GREY, "Bold")
    text(d, (390, y), "Ngày trong tháng 10", 24, GREY, "Bold")

def sc_vd1(img, d, t):
    if 172.5 <= t < 189.0:
        htv(img, HTV4 if t >= 181.0 else None)
        top_title(d, t, "Thiết lập Hiển thị với", 172.6)
        if t < 181.0: hl(d, XV(*ALLB), t)
        else: hl(d, XV(*LKB), t)
        chip_bar(d, t, [(173.4, "Công & Làm thêm giờ: Tất cả chu kỳ lương · ngày 1 → 31", GREEN)] if t < 181.0 else
                 [(181.2, "Lương, Phụ cấp, Tổng thu nhập: Chu kỳ lương liền kề trước · ngày 4 → 31", ORANGE)], size=22)
        role_tag(img, d, CB, "C&B"); return
    paste(img, BOARD)
    board_title(d, t, "Ví dụ: tính lương tháng 9 từ ngày 1 đến ngày 5 tháng 10", 151.6, size=46)
    if t < 172.5:
        s_ = pop(t, 158.7)
        if s_ > 0.01:
            card(d, W / 2, 470, 1300, 330, s_, True, BLUE)
            if s_ > 0.9:
                text(d, (W / 2, 360), "Ngày 3 tháng 10, C&B muốn nhân viên", 28, INK, "Bold")
                mini_chip(d, W / 2 - 280, 450, 460, 66, "Xem trước: Công, Làm thêm giờ", GREEN, pop(t, 159.9, 0.4), 24)
                mini_chip(d, W / 2 + 280, 450, 520, 66, "Chưa hiện: Lương, Phụ cấp, Tổng thu nhập", ORANGE, pop(t, 163.8, 0.4), 22)
                k = pop(t, 167.7, 0.4)
                if k > 0.01: text(d, (W / 2, 560), "vì các số liệu này chưa hoàn tất", 26 * k, GREY, "Bold")
        role_tag(img, d, CB, "C&B"); return
    oct_axis(d)
    oct_bar(d, t, 450, "Công · Làm thêm giờ (tháng 9)", GREEN, 1, 189.3, "hiển thị từ ngày 1")
    oct_bar(d, t, 560, "Lương · Phụ cấp · Tổng thu nhập (tháng 9)", ORANGE, 4, 196.4, "hiển thị từ ngày 4")
    k = pop(t, 189.3)
    if k > 0.01:
        card(d, W / 2, 790, 1400, 190, k, True, NAVY)
        text(d, (W / 2, 750), "Ngày 1 → 3/10: nhân viên xem & kiểm tra Công, Làm thêm giờ của kỳ lương tháng 9", 22 * k, INK, "Bold")
        k2 = pop(t, 196.4, 0.4)
        if k2 > 0.01: text(d, (W / 2, 815), "Từ ngày 4/10: Lương, Phụ cấp & Tổng thu nhập tháng 9 mới bắt đầu hiển thị", 22 * k2, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B")

def sc_luuy(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Lưu ý: hai phạm vi hiển thị riêng biệt", 203.2, size=52)
    for i, (st, ttl, body, col) in enumerate([(209.8, "Chu kỳ lương liền kề trước", "Hiển thị tại kỳ lương ngay trước\nkỳ lương hiện tại", ORANGE),
                                              (215.3, "Tất cả chu kỳ lương", "Hiển thị ở các chu kỳ lương còn lại\n(không gồm kỳ đã có thiết lập riêng\nở chu kỳ liền kề trước)", GREEN)]):
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        x = 560 + i * 800
        card(d, x, 520, 700, 380, s_, True, col)
        if s_ > 0.9: text(d, (x, 400), ttl, 30, col); text(d, (x, 540), body, 24, INK, "Bold")
    role_tag(img, d, CB, "C&B")

def sc_vd2(img, d, t):
    if t < 238.8:
        htv(img, HTV5 if t >= 234.6 else None)
        top_title(d, t, "Ví dụ: Tổng thu nhập chọn đồng thời cả hai phạm vi", 224.2)
        if 230.7 <= t < 234.6: hl(d, XV(*ALLB), t)
        if t >= 234.6: hl(d, XV(*LKB), t)
        chip_bar(d, t, [(230.7, "Tất cả chu kỳ lương: ngày 1 → 31", GREEN)] if t < 234.6 else [(234.7, "Chu kỳ lương liền kề trước: ngày 5 → 31", ORANGE)], size=24)
        role_tag(img, d, CB, "C&B"); return
    paste(img, BOARD)
    board_title(d, t, "Ngày 5/10: kỳ lương liền kề trước là Tháng 09", 238.9, size=50)
    oct_axis(d)
    oct_bar(d, t, 450, "Tháng 09 (liền kề trước)", ORANGE, 5, 245.0, "Tổng thu nhập hiển thị từ ngày 5/10")
    oct_bar(d, t, 560, "Tháng 08 · 07 · 06 (cũ hơn)", GREEN, 1, 253.6, "Tổng thu nhập hiển thị từ ngày 1/10")
    k = pop(t, 251.3, 0.4)
    if k > 0.01: text(d, (W / 2 + 120, 640), "theo thiết lập chu kỳ lương liền kề trước", 22 * k, ORANGE, "Bold")
    k2 = pop(t, 262.4, 0.4)
    if k2 > 0.01: text(d, (W / 2 + 120, 700), "theo thiết lập tất cả chu kỳ lương", 22 * k2, GREEN, "Bold")
    role_tag(img, d, CB, "C&B")

def sc_note(img, d, t):
    if t < 275.4:
        htv(img); top_title(d, t, "Ghi chú: chọn Tất cả chu kỳ lương", 264.7)
        if t >= 266.2: hl(d, XV(*ALL_F), t)
        chip_bar(d, t, [(267.5, "Thời gian tự ghi nhận từ ngày 1 đến ngày 31", NAVY)] if t < 271.6 else
                 [(271.7, "C&B có thể điều chỉnh theo nhu cầu vận hành của doanh nghiệp", GREEN)], size=24)
        role_tag(img, d, CB, "C&B"); return
    paste(img, BOARD)
    board_title(d, t, "Chủ động kiểm soát thời điểm nhân viên nhìn thấy từng kết quả", 275.5, size=46)
    for (st, y, col, items, msg) in [(281.3, 400, GREEN, ["Công", "Làm thêm giờ"], "Đã sẵn sàng\nđể kiểm tra"),
                                    (285.9, 680, ORANGE, ["Lương cuối cùng"], "Vẫn đang\nđược xử lý")]:
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        card(d, 980, y, 1300, 210, s_, True, col)
        if s_ < 0.9: continue
        d.line([1170, y - 70, 1170, y + 70], fill=LINE, width=3)
        n = len(items); xs = [750 + (i - (n - 1) / 2) * 260 for i in range(n)]
        for x, lab in zip(xs, items): mini_chip(d, x, y, 240, 62, lab, col, 1, 24)
        text(d, (1380, y), msg, 26, col)
    role_tag(img, d, CB, "C&B")

# ================= Ẩn trên thu nhập cá nhân =================
ROWS_TN = [("Lương thực tế", "12.000.000", False), ("Phụ cấp trách nhiệm", "1.000.000", False), ("Thưởng khối cửa hàng", "0", True), ("Tổng thu nhập", "13.000.000", False)]
def sc_an(img, d, t):
    if t < 292.7:
        htv(img); top_title(d, t, "Ẩn trên Thu nhập cá nhân khi giá trị bằng 0", 289.0)
        if t >= 289.6: vhl(d, "AN", t)
        role_tag(img, d, CB, "C&B"); return
    if t < 300.4:
        fs_shot(img, TNCN2, P.TN_FULL, P.TN_FULL, 0)
        top_title(d, t, "Màn hình Thu nhập cá nhân trên máy tính", 292.8)
        if t >= 293.8: hl(d, P.XT(150, 40, 412, 84), t)
        chip_bar(d, t, [(295.9, "Thường được nhân viên khối văn phòng dùng để xem thu nhập của mình", NAVY)], size=22)
        role_tag(img, d, EMP, "Nhân viên"); return
    if t < 319.1:
        paste(img, BOARD)
        board_title(d, t, "Chính sách khác nhau cho từng khối nhân viên", 300.5, size=52)
        s0 = pop(t, 305.5)
        if s0 > 0.01:
            card(d, W / 2, 290, 760, 110, s0, True, ORANGE); text(d, (W / 2, 290), "Thưởng chỉ áp dụng cho khối cửa hàng", 30 * s0, ORANGE)
        for i, (st, ttl, val, col, ok) in enumerate([(307.0, "Khối cửa hàng", "Có giá trị", GREEN, True), (309.2, "Khối văn phòng", "= 0", (130, 140, 160), False)]):
            s_ = pop(t, st)
            if s_ <= 0.01: continue
            x = 560 + i * 800
            card(d, x, 640, 700, 380, s_, True, col)
            if s_ > 0.9:
                text(d, (x, 490), ttl, 34, GREEN if ok else NAVY); text(d, (x, 600), "Thưởng khối cửa hàng", 26, INK, "Bold")
                k = pop(t, st if ok else 314.3, 0.4)
                if k > 0.01: text(d, (x, 670), val, (40 if ok else 48) * k, GREEN if ok else RED)
                if ok: badge(d, x + 300, 490, True, 1, 24)
                elif t >= 311.5: text(d, (x, 760), "Không thuộc chính sách áp dụng", 22, GREY, "Bold")
        role_tag(img, d, CB, "C&B"); return
    if t < 323.0:
        fs_shot(img, P.IMG_AN, P.AN_FULL, P.AN_FULL, 0)
        top_title(d, t, "Công thức thưởng dành riêng cho khối cửa hàng", 319.2)
        if t >= 319.8: hl(d, P.XA(1828, 1320, 2372, 1394), t)
        role_tag(img, d, CB, "C&B"); return
    paste(img, BOARD)
    board_title(d, t, "Thu nhập cá nhân của nhân viên khối văn phòng", 323.1, size=52)
    for col, cx, label, hide, st in [(GREY, 560, "Không chọn ẩn", False, 323.4), (GREEN, 1360, "Chọn ẩn khi giá trị bằng 0", True, 326.0)]:
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        card(d, cx, 560, 700, 520, s_, True, col)
        if s_ < 0.9: continue
        text(d, (cx, 345), label, 30, col); y = 420
        for lab, val, zero in ROWS_TN:
            if zero and hide: continue
            d.rounded_rectangle([cx - 300, y - 32, cx + 300, y + 32], 12, fill=(255, 236, 236) if zero else (243, 246, 252))
            text(d, (cx - 280, y), lab, 24, INK, "Bold", anchor="lm"); text(d, (cx + 280, y), val, 24, RED if zero else GREEN, "Bold", anchor="rm")
            y += 80
        if hide: badge(d, cx + 320, 345, True, 1, 26)
    pill(d, W / 2 + 60, 920, 1180, 70, NAVY, "Chỉ hiển thị những khoản thực sự liên quan đến nhân viên", 26, pop(t, 331.6))
    role_tag(img, d, EMP, "Nhân viên")

SCENES = [(-OFFSET, 2.5, "h_ht"), (2.5, 12.0, "intro"), (12.0, 29.0, "bc"), (29.0, 63.4, "dv"), (63.4, 102.5, "nv"),
          (102.5, 131.0, "bl"), (131.0, 151.4, "htv"), (151.4, 202.2, "vd1"), (202.2, 224.0, "luuy"), (224.0, 264.5, "vd2"),
          (264.5, 288.8, "note"), (288.8, 999, "an")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv83d"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 12
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p83d_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p83d_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
