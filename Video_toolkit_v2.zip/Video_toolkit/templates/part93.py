"""PHẦN 9.3 — TÌNH HUỐNG 2: TÍNH LƯƠNG TRONG THÁNG
Lương trong tháng = Mức lương chính ÷ Công chuẩn kỳ lương × Tổng công tính lương (kết quả công thức tình huống 1).
Bảng mẫu Excel của khách chỉ là gợi ý → dựng lại bảng theo ngày (kỳ 30 ngày, tổng công 25,5 khớp tình huống 1)."""
import sys, math
from hw_core import *
from part81 import sub_card, full_of, shot_xy, FORM_FULL, XF, F, IMG_FORM, mini_chip, badge
from part92 import lookup, examples, IMG_ID, ID_FULL
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p93.wav"
OFFSET = 1.0
VOICE_DUR = 432.93
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan9_3_Tinh_huong_2_Luong_trong_thang.mp4"
HD = dict(th2=-0.6)
SFX_AT = [0.0]

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
def form(img): fs_shot(img, IMG_FORM, FORM_FULL, FORM_FULL, 0)

# ---------- phương trình ----------
EQ = [("Lương trong tháng", NAVY, 420), ("=", None, 0), ("Mức lương chính", GREEN, 330), ("÷", None, 0),
      ("Công chuẩn kỳ lương", GREEN, 380), ("×", None, 0), ("Tổng công tính lương", BLUE, 400)]
EQX = [270, 515, 720, 925, 1145, 1375, 1620]
def equation(d, t, times, y=380):
    for (lab, col, w), x, st in zip(EQ, EQX, times):
        k = pop(t, st, 0.4)
        if k <= 0.01: continue
        if col: mini_chip(d, x, y, w, 74, lab, col, k, 26)
        else: text(d, (x, y), lab, 56 * k, ORANGE)

# ---------- bảng theo ngày ----------
DAYS = ["1", "2", "3", "4", "5", "…", "29", "30"]
CX = [520 + i * 128 for i in range(8)]; TX = 1665; X0, X1 = 170, 1830
def table(d, t, rows, head_y=300, cur=None, t0=None):
    """rows: [(nhãn, màu nhãn, [(mốc, chuỗi) | None]*8, (mốc, chuỗi tổng, màu) | None)]"""
    s_ = 1 if t0 is None else pop(t, t0)
    if s_ <= 0.01: return []
    h = 90 + len(rows) * 72
    card(d, (X0 + X1) / 2, head_y - 45 + h / 2, X1 - X0, h, s_, True, BLUE)
    if s_ < 0.95: return []
    ys = [head_y + 72 * (j + 1) for j in range(len(rows))]
    if cur is not None:
        x = CX[cur]; d.rounded_rectangle([x - 60, head_y - 32, x + 60, ys[-1] + 30], 14, fill=(255, 242, 222))
    text(d, (330, head_y), "Ngày", 26, GREY, "Bold")
    for i, dd in enumerate(DAYS): text(d, (CX[i], head_y), dd, 28, NAVY)
    text(d, (TX, head_y), "Tổng kỳ", 26, ORANGE)
    d.line([X0 + 15, head_y + 34, X1 - 15, head_y + 34], fill=LINE, width=3)
    d.line([1560, head_y - 32, 1560, ys[-1] + 30], fill=LINE, width=3)
    for (lab, lcol, cells, tot), y in zip(rows, ys):
        text(d, (330, y), lab, fit_size(d, lab, 22, "Bold", 300), lcol, "Bold")
        for i, c in enumerate(cells):
            if c is None: continue
            st, v = c
            if t >= st: text(d, (CX[i], y), v, fit_size(d, v, 24, "Bold", 118), INK if v not in ("…",) else GREY, "Bold")
        if tot:
            st, v, col = tot
            k = pop(t, st, 0.4)
            if k > 0.01: text(d, (TX, y), v, fit_size(d, v, 30, "Bold", 230) * k, col, "Bold")
    return ys

def same(v, t_first, t_rest, firsts=None):
    """8 ô: 3 ô đầu theo firsts (mốc), còn lại hiện ở t_rest"""
    out = []
    for i in range(8):
        val = "…" if i == 5 else v
        st = (firsts[i] if firsts and i < len(firsts) else t_rest)
        out.append((st, val))
    return out

TCTL = ["1", "1", "1", "0,5", "1", "…", "1", "1"]
LUONG_D = ["384.615", "384.615", "384.615", "192.308", "384.615", "…", "384.615", "384.615"]
ALL = -1  # hiện ngay

# ================= Mở đầu =================
def sc_h_th2(img, d, t): sub_card(img, d, t, HD["th2"], "TÌNH HUỐNG 2", ["TÍNH LƯƠNG", "TRONG THÁNG"], 104)

def sc_rule(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Yêu cầu: lương trong tháng theo cách tính của doanh nghiệp", 2.7, size=48)
    equation(d, t, [9.0, 10.0, 10.4, 11.4, 11.8, 13.1, 13.5])
    s_ = pop(t, 14.9)
    if s_ > 0.01:
        text(d, (W / 2, 560), "Tiếp tục áp dụng bốn yếu tố", 32 * s_, NAVY)
        for i, (lab, col) in enumerate([("01 Thành phần lương", GREEN), ("02 Công thức tính", BLUE), ("03 Cách thể hiện", ORANGE), ("04 Cách chạy", NAVY)]):
            mini_chip(d, 390 + i * 380, 660, 340, 70, lab, col, pop(t, 15.6 + i * 0.2, 0.4), 24)
    role_tag(img, d, CB, "C&B")

def sc_mlc(img, d, t):
    if t < 31.1:
        paste(img, BOARD)
        board_title(d, t, "Câu hỏi 1 · Cần dữ liệu nào?", 19.9, size=54)
        vcard(d, 560, 540, 520, 380, pop(t, 24.3), GREEN, "doc", "Mức lương chính", 32, True, "01")
        s_ = pop(t, 26.2)
        if s_ > 0.01:
            card(d, 1300, 540, 720, 260, s_, True, BLUE)
            text(d, (1300, 540), "Đã khai báo trên hợp đồng lao động\nhoặc phụ lục hợp đồng", 28 * s_, INK, "Bold")
        role_tag(img, d, CB, "C&B")
        return
    if t < 37.3:
        fs_shot(img, IMG_ID, ID_FULL, ID_FULL, 0)
        top_title(d, t, "Tra cứu file tổng hợp thành phần lương", 31.2)
        chip_bar(d, t, [(34.4, "Xác định thành phần lương tương ứng", NAVY)], size=24)
        return
    paste(img, BOARD)
    board_title(d, t, "Thành phần lương: Mức lương chính", 37.5, size=54)
    lookup(d, t, "Mức lương chính", 38.6, "Lấy giá trị khai báo tại trường Mức lương chính\ntrên hợp đồng lao động hoặc phụ lục hợp đồng", 40.6,
           "Ghi nhận theo từng ngày", 49.4)
    k = pop(t, 53.2, 0.4)
    if k > 0.01: text(d, (1450, 245), "Ví dụ: mức lương chính 10.000.000đ", 24 * k, NAVY, "Bold")
    examples(d, t, [(59.3, "Ngày 1", "10.000.000đ"), (61.5, "Ngày 2", "10.000.000đ"), (63.7, "Ngày 3", "10.000.000đ")])
    k2 = pop(t, 65.8, 0.4)
    if k2 > 0.01: text(d, (1450, 700), "… tương tự ở các ngày tiếp theo", 24 * k2, GREY, "Bold")
    role_tag(img, d, CB, "C&B")

def sc_ccl(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thành phần lương: Công chuẩn kỳ lương", 69.4, size=54)
    k0 = pop(t, 71.8, 0.4)
    if k0 > 0.01: text(d, (640, 230), "Giả sử: làm việc 6 ngày/tuần, 8 giờ/ngày", 24 * k0, NAVY, "Bold")
    lookup(d, t, "Công chuẩn kỳ lương", 87.5, "Hệ thống xác định từ giờ công chuẩn 1 ngày\nvà giờ công tối thiểu 1 tuần", 76.6,
           "Trong ví dụ: 26 công · ghi nhận theo từng ngày", 90.3)
    examples(d, t, [(97.5, "Ngày 1", "26 công"), (99.8, "Ngày 2", "26 công"), (102.2, "Ngày 3", "26 công")])
    k2 = pop(t, 104.7, 0.4)
    if k2 > 0.01: text(d, (1450, 700), "… tương tự ở các ngày còn lại trong kỳ", 24 * k2, GREY, "Bold")
    role_tag(img, d, CB, "C&B")

def sc_tctl(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu cuối cùng: Tổng công tính lương", 108.1, size=54)
    s_ = pop(t, 110.6)
    if s_ > 0.01:
        card(d, 700, 520, 1000, 480, s_, True, BLUE)
        if s_ > 0.9:
            text(d, (700, 330), "Công thức ở tình huống 1", 26, GREY, "Bold")
            mini_chip(d, 700, 400, 520, 70, "Tổng công tính lương", BLUE, 1, 28)
            k = pop(t, 114.9, 0.4)
            if k > 0.01: text(d, (700, 490), "= Ngày công + Số ngày lễ + Số ngày phép năm", 24 * k, INK, "Bold")
            mini_chip(d, 560, 600, 300, 60, "Chạy hàng ngày", NAVY, pop(t, 121.1, 0.4), 22)
            mini_chip(d, 880, 600, 300, 60, "Cách thể hiện: Tổng", ORANGE, pop(t, 122.3, 0.4), 22)
    arrow(d, 1220, 520, 1340, 520, p(t, 127.6, 0.4), ORANGE, 8)
    s2 = pop(t, 127.7)
    if s2 > 0.01:
        card(d, 1590, 520, 440, 300, s2, True, GREEN)
        text(d, (1590, 520), "Dữ liệu đầu vào\ncho công thức\nLương trong tháng", 28 * s2, GREEN)
    role_tag(img, d, CB, "C&B")

def sc_ct(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Câu hỏi 2 · Công thức được tính như thế nào?", 134.4, size=54)
    equation(d, t, [140.3, 141.5, 141.8, 142.9, 143.2, 144.5, 144.8])
    for st, x, v in [(148.7, EQX[2], "10.000.000đ"), (151.0, EQX[4], "26 công"), (154.5, EQX[6], "25,5 công")]:
        k = pop(t, st, 0.4)
        if k > 0.01: text(d, (x, 480), v, 30 * k, GREEN, "Bold")
    s_ = pop(t, 156.6)
    if s_ > 0.01:
        card(d, W / 2, 680, 1100, 170, s_, True, ORANGE)
        text(d, (W / 2, 650), "Kết quả mong muốn", 26 * s_, NAVY)
        k2 = pop(t, 158.4, 0.4)
        if k2 > 0.01: text(d, (W / 2, 715), "10.000.000 ÷ 26 × 25,5 ≈ 9.807.692đ", 38 * k2, ORANGE)
    role_tag(img, d, CB, "C&B")

def rows_base(t_mlc=ALL, t_ccl=ALL, tot_mlc=None, tot_ccl=None):
    return [("Mức lương chính", GREEN, same("10tr", 0, t_mlc), tot_mlc),
            ("Công chuẩn kỳ lương", GREEN, same("26", 0, t_ccl), tot_ccl)]

DAY_T = [(185.5, 190.0), (193.6, 197.2), (208.1, 208.1), (200.8, 204.4), (208.1, 208.1), (208.1, 208.1), (208.1, 208.1), (208.1, 208.1)]
def sc_daily(img, d, t):
    if t < 166.9:
        form(img)
        top_title(d, t, "Câu hỏi 3–4 · Cách thể hiện & cách chạy", 163.3)
        if t >= 164.6: hl(d, XF(*F["CTH"]), t)
        if t >= 165.7: hl(d, XF(*F["CHAY"]), t)
        role_tag(img, d, CB, "C&B")
        return
    paste(img, BOARD)
    board_title(d, t, "Thử 1 · Lương trong tháng chạy hàng ngày", 167.0, size=52)
    cur = None
    for i, (st, _) in enumerate(DAY_T[:4]):
        if t >= st and i != 2: cur = i
    if t >= 208.1: cur = None
    rows = rows_base() + [("Tổng công tính lương", BLUE, [(DAY_T[i][0] if i in (0, 1, 3) else 208.1, TCTL[i]) for i in range(8)], None),
                          ("Lương trong tháng", ORANGE, [(DAY_T[i][1], LUONG_D[i]) for i in range(8)], (220.5, "9.807.692", GREEN))]
    table(d, t, rows, t0=167.2)
    k = pop(t, 175.1, 0.4)
    if k > 0.01 and t < 185.4:
        pill(d, W / 2 + 40, 760, 1300, 70, NAVY, "Công thức chạy hàng ngày dùng kết quả công thức khác cũng chạy hàng ngày → lấy giá trị từng ngày", 22, k)
    if cur is not None:
        v = TCTL[cur]
        pill(d, W / 2 + 40, 760, 900, 70, NAVY, f"Ngày {DAYS[cur]}: 10.000.000 ÷ 26 × {v} = {LUONG_D[cur]}", 25, 1)
    if 211.0 <= t < 217.2:
        pill(d, W / 2 + 40, 760, 1100, 70, NAVY, "Mỗi ngày: phần tiền lương tương ứng số công tính lương của chính ngày đó", 23, pop(t, 211.0))
    if t >= 217.2:
        s_ = pop(t, 223.8)
        if s_ > 0.01:
            card(d, W / 2 + 40, 800, 1240, 170, s_, True, GREEN)
            text(d, (W / 2 + 40, 770), "Cách thể hiện Tổng: cộng tiền lương của tất cả các ngày", 24 * s_, INK, "Bold")
            text(d, (W / 2 + 40, 830), "= 10.000.000 ÷ 26 × 25,5 ≈ 9.807.692đ", 34 * s_, GREEN)
            badge(d, W / 2 + 40 + 600, 730, True, pop(t, 234.3, 0.4), 28)
    role_tag(img, d, CB, "C&B")

def sc_endcyc(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thử 2 · Lương trong tháng chạy một lần cuối chu kỳ (cách thể hiện Tổng)", 240.0, size=42)
    rows = rows_base(tot_mlc=(264.3, "300tr", RED), tot_ccl=(274.0, "780", RED))
    ys = table(d, t, rows)
    if ys:
        if 264.3 <= t < 273.9: hl(d, (1575, ys[0] - 30, 1815, ys[0] + 30), t)
        if t >= 274.0: hl(d, (1575, ys[1] - 30, 1815, ys[1] + 30), t)
    k = pop(t, 250.3, 0.4)
    if k > 0.01: text(d, (W / 2 + 40, 560), "Ngày cuối chu kỳ: tổng hợp dữ liệu từng thành phần lương trước khi tính (kỳ 30 ngày)", 22 * k, INK, "Bold")
    for st, x, lab in [(264.3, 560, "Mức lương chính: 10tr × 30 ngày = 300tr"), (274.0, 1360, "Công chuẩn kỳ lương: 26 × 30 ngày = 780")]:
        s_ = pop(t, st)
        if s_ > 0.01:
            card(d, x, 690, 740, 110, s_, True, RED)
            text(d, (x, 690), lab, 25 * s_, INK, "Bold")
    pill(d, W / 2 + 40, 830, 1260, 72, RED, "Không còn đúng giá trị cố định cần dùng (10.000.000đ & 26 công)", 25, pop(t, 278.4))
    s2 = pop(t, 287.8)
    if s2 > 0.01:
        card(d, W / 2 + 40, 950, 1000, 90, s2, True, RED)
        text(d, (W / 2 + 40, 950), "Chạy cuối kỳ + Tổng: không phù hợp với công thức này", 26 * s2, RED)
        badge(d, W / 2 + 40 + 480, 905, False, s2, 22)
    role_tag(img, d, CB, "C&B")

C3 = [(322.1, 327.2), (327.9, 332.6), (333.1, 336.1), (337.0, 337.0)]
def sc_case3(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Lưu ý: Tổng công tính lương chạy cuối kỳ, lương chạy hàng ngày", 294.8, size=46)
    def st_of(i, which):
        return C3[i][which] if i < 3 else C3[3][which]
    rows = rows_base() + [("Tổng công tính lương\n(chạy cuối kỳ)", BLUE, [(st_of(i, 0) if i < 3 else 337.0, "…" if i == 5 else "25,5") for i in range(8)], None),
                          ("Lương trong tháng\n(chạy hàng ngày)", ORANGE, [(st_of(i, 1) if i < 3 else 337.0, "…" if i == 5 else "9,8tr") for i in range(8)],
                           (342.5, "≈ 294tr", RED))]
    cur = None
    for i in range(3):
        if t >= C3[i][0]: cur = i
    if t >= 337.0: cur = None
    table(d, t, rows, cur=cur, t0=295.2)
    k = pop(t, 306.6, 0.4)
    if k > 0.01 and t < 322.0:
        pill(d, W / 2 + 40, 760, 1260, 70, NAVY, "Giá trị cuối cùng 25,5 công được đưa vào từng ngày của công thức Lương trong tháng", 22, k)
    if cur is not None:
        pill(d, W / 2 + 40, 760, 900, 70, NAVY, f"Ngày {DAYS[cur]}: 10.000.000 ÷ 26 × 25,5 ≈ 9.807.692", 25, 1)
    s_ = pop(t, 346.6)
    if s_ > 0.01:
        card(d, W / 2 + 40, 790, 1240, 120, s_, True, RED)
        text(d, (W / 2 + 40, 790), "Cộng 30 ngày ≈ 294 triệu: lớn hơn rất nhiều so với lương thực tế cần tính (≈ 9,8 triệu)", 23 * s_, RED, "Bold")
    pill(d, W / 2 + 40, 935, 1300, 70, NAVY, "Cách chạy của công thức đầu vào ảnh hưởng trực tiếp đến công thức phía sau", 24, pop(t, 350.2))
    role_tag(img, d, CB, "C&B")

def sc_setup(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thiết lập cho tình huống 2", 360.0, size=56)
    s1 = pop(t, 362.3)
    if s1 > 0.01:
        card(d, 540, 520, 720, 560, s1, True, BLUE)
        if s1 > 0.9:
            mini_chip(d, 540, 300, 520, 66, "Tổng công tính lương", BLUE, 1, 26)
            for j, (st, lab, val) in enumerate([(365.1, "Cách thể hiện", "Tổng"), (366.8, "Cách chạy", "Hàng ngày")]):
                k = pop(t, st, 0.4)
                if k > 0.01:
                    text(d, (260, 420 + j * 90), lab, 24 * k, GREY, "Bold", anchor="lm"); text(d, (820, 420 + j * 90), val, 28 * k, INK, "Bold", anchor="rm")
    s2 = pop(t, 368.6)
    if s2 > 0.01:
        card(d, 1360, 520, 840, 560, s2, True, ORANGE)
        if s2 > 0.9:
            mini_chip(d, 1360, 300, 520, 66, "Lương trong tháng", ORANGE, 1, 26)
            items = [(370.7, "Dữ liệu", "Mức lương chính · Công chuẩn kỳ lương\n· công thức Tổng công tính lương"),
                     (374.6, "Công thức", "Mức lương chính ÷ Công chuẩn kỳ lương\n× Tổng công tính lương"),
                     (381.1, "Cách thể hiện", "Tổng"), (383.5, "Cách chạy", "Hàng ngày")]
            for j, (st, lab, val) in enumerate(items):
                k = pop(t, st, 0.4)
                if k > 0.01:
                    y = 400 + j * 95
                    text(d, (980, y), lab, 22 * k, GREY, "Bold", anchor="lm"); text(d, (1750, y), val, 21 * k, INK, "Bold", anchor="rm", align="right")
    pill(d, W / 2 + 60, 900, 1400, 70, GREEN, "Tổng công chuyển sang theo từng ngày → lương tính theo từng ngày → cộng lại cả kỳ", 23, pop(t, 385.5))
    role_tag(img, d, CB, "C&B")

def sc_remember(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Điểm cần nhớ", 397.9, size=56)
    hcard(d, W / 2 + 40, 330, 1400, 130, pop(t, 399.0), BLUE, "fx", "Công thức dùng kết quả công thức khác: kiểm tra cả nội dung\ncông thức phía sau lẫn cách chạy của công thức phía trước", 24, True)
    hcard(d, W / 2 + 40, 520, 1400, 130, pop(t, 408.4), GREEN, "calendar", "Cả hai cần xử lý theo từng ngày → để công thức phía trước chạy hàng ngày\nđể công thức phía sau nhận đúng giá trị của từng ngày", 24, True)
    role_tag(img, d, CB, "C&B")

def sc_end(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Một mối quan hệ quan trọng", 418.4, size=56)
    for i, (st, lab, kind, col) in enumerate([(422.2, "Thành phần lương", "db", GREEN), (423.4, "Công thức lương", "fx", BLUE)]):
        vcard(d, 480, 340 + i * 260, 480, 220, pop(t, st), col, kind, lab, 28, True)
        arrow(d, 730, 340 + i * 260, 1010, 470, p(t, 425.0, 0.4), ORANGE, 6)
    s_ = pop(t, 425.4)
    if s_ > 0.01:
        card(d, 1340, 470, 600, 260, s_, True, ORANGE)
        text(d, (1340, 470), "Dữ liệu đầu vào\ncho công thức khác", 32 * s_, NAVY)
    pill(d, W / 2 + 60, 830, 1400, 72, NAVY, "Cách dữ liệu được đưa sang phụ thuộc vào cách công thức được thiết lập & vận hành", 24, pop(t, 427.7))
    role_tag(img, d, CB, "C&B")

SCENES = [(-OFFSET, 2.5, "h_th2"), (2.5, 19.0, "rule"), (19.0, 69.1, "mlc"), (69.1, 107.9, "ccl"), (107.9, 133.6, "tctl"),
          (133.6, 163.1, "ct"), (163.1, 239.7, "daily"), (239.7, 294.3, "endcyc"), (294.3, 359.7, "case3"),
          (359.7, 397.4, "setup"), (397.4, 418.0, "remember"), (418.0, 999, "end")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv93"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 17
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p93_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p93_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
