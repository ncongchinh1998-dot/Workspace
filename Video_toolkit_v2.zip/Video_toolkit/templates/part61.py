"""PHẦN 6 — THÀNH PHẦN LƯƠNG · đoạn 6.1
Mục: 6.1 Thành phần lương là gì · Kiểm tra thành phần lương đã có trên hệ thống ·
     Nguyên tắc vận hành của thành phần lương · Tạo mới thành phần lương.
Quy chuẩn: màn hình hệ thống full khung rồi phóng vào vùng đang nói, khoanh đỏ đúng chỗ được nhắc,
không thêm chữ trùng nội dung đã có trên màn hình, nhãn vai trò góc trái dưới, âm thanh mẫu ở mỗi tiêu đề mục.
Mốc thời gian (voice-time) lấy từ nhận dạng giọng nói từng từ (words_p61.json)."""
import sys, math
from hw_core import *
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p61.wav"
OFFSET = 1.0
VOICE_DUR = 454.45
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan6_1_Thanh_phan_luong.mp4"
HD = dict(h61=14.3, check=71.6, nt=151.6, tao=347.5)               # tiêu đề mục (voice-time)
SFX_AT = [0.0] + [OFFSET + v for v in HD.values()]

# ---------- Tư liệu ----------
IMG_3YT = U + "3_YẾU_TỐ_CÂU_THÀNH_BẢNG_LƯƠNG.png"                  # 2120x1199
IMG_CXT = U + "Chuỗi_xác_thực.png"                                 # 2805x1532 danh sách TPL
IMG_NT = U + "nguyên_tắc_vận_hành_của_Thành_phần_lương.png"        # 2879x1701 file Excel TPL hệ thống
IMG_CTCT = U + "Hình_ảnh_công_thức_chi_tiết.png"                   # 2773x1497 chỉnh sửa công thức
IMG_TPLCT = U + "TPL_dùng_trong_công_thức_lương.png"                # 2777x1526 danh sách công thức lương
REC_DS = U + "Màn_hình_thành_phần_lương.mp4"                       # 1912x1016
REC_TAO = U + "Tạo_TPL.mp4"                                        # 1912x1016
REC_XL = U + "File_excel_tổng_hợp_DS_TPL_gửi_khách.mp4"            # 1824x1078
REC_TK = U + "Tìm_kiếm_tpl_trên_excel.mp4"                         # 1824x1078

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    w_ = 6 + int(2 * abs(math.sin(t * 5)))
    if kind == "rect": d.rounded_rectangle(box, 10, outline=RED, width=w_)
    else: d.ellipse(box, outline=RED, width=w_)

def badge(d, x, y, ok, s, r0=24):
    if s <= 0.01: return
    r = r0 * s; w = max(int(6 * s), 1)
    d.ellipse([x - r, y - r, x + r, y + r], fill=GREEN if ok else RED)
    if ok: d.line([x - r * 0.45, y, x - r * 0.1, y + r * 0.4, x + r * 0.5, y - r * 0.35], fill=WHITE, width=w, joint="curve")
    else:
        d.line([x - r * 0.4, y - r * 0.4, x + r * 0.4, y + r * 0.4], fill=WHITE, width=w)
        d.line([x - r * 0.4, y + r * 0.4, x + r * 0.4, y - r * 0.4], fill=WHITE, width=w)

def sub_card(img, d, t, t0, kicker, lines, size=96):
    paste(img, SECTION)
    pill(d, 280, 280, 340, 76, BLUE, kicker, 30, pop(t, t0 + 0.05), weight="ExtraBold")
    for j, line in enumerate(lines):
        k = p(t, t0 + 0.15 + j * 0.12, 0.45)
        if k > 0: text(d, (110, 430 + j * size * 1.12 + (1 - k) * 50), line, size, NAVY, anchor="lm", align="left")
    underline(d, 115, 430 + (len(lines) - 1) * size * 1.12 + size * 0.75, 700, p(t, t0 + 0.45, 0.5))
    person(img, d, CB, 1220, 900, 340, pop(t, t0 + 0.4, 0.5), "C&B", 30)

def shot_xy(box):
    k = 1920 / (box[2] - box[0])
    return lambda x0, y0, x1, y1: ((x0 - box[0]) * k, (y0 - box[1]) * k, (x1 - box[0]) * k, (y1 - box[1]) * k)
def full_of(iw, ih): return box169(iw / 2, ih / 2, iw, iw, ih)
ZOOM_MILD = 0.0          # mức phóng: 0 = giữ nguyên màn hình, 1 = phóng sát vùng cần nói
def mild(box, full):
    return tuple(full[i] + (box[i] - full[i]) * ZOOM_MILD for i in range(4))

# Bản quay: full khung rồi phóng dần vào box1 (toạ độ khung đã ghép 1920x1080)
FULLB = (0, 0, 1920, 1080)
_clips = {}
REC_WEB = dict(crop=(0, 0, 1912, 1016), size=(1920, 1020), y0=30, sw=1912)   # bản quay web
REC_XLS = dict(crop=(0, 0, 1824, 1026), size=(1920, 1080), y0=0, sw=1824)    # bản quay Excel
def recz(img, key, path, tc, box1, k, spec=REC_WEB):
    if key not in _clips: _clips[key] = Clip(path, spec["size"], spec["crop"])
    fr = _clips[key].get(tc); bg = Image.new("RGB", (1920, 1080), WHITE)
    if fr is not None: bg.paste(fr, (0, spec["y0"]))
    box1 = mild(box1, FULLB)
    k = ease(clamp(k)); box = tuple(FULLB[i] + (box1[i] - FULLB[i]) * k for i in range(4))
    img.paste(bg.resize((1920, 1080), Image.LANCZOS, box=box), (0, 0))
    return box
def RZ(box, x0, y0, x1, y1, spec=REC_WEB):
    s_ = 1920 / spec["sw"]; kk = 1920 / (box[2] - box[0]); y_ = spec["y0"]
    return ((x0 * s_ - box[0]) * kk, (y0 * s_ + y_ - box[1]) * kk, (x1 * s_ - box[0]) * kk, (y1 * s_ + y_ - box[1]) * kk)
def piece(t, pts):
    if t <= pts[0][0]: return pts[0][1]
    for (a_, ca), (b_, cb) in zip(pts, pts[1:]):
        if a_ <= t <= b_: return ca + (t - a_) * (cb - ca) / (b_ - a_)
    return pts[-1][1]

# ================= Mở đầu =================
def sc_part(img, d, t):
    paste(img, SECTION)
    pill(d, 250, 250, 280, 84, BLUE, "PHẦN 6", 40, pop(t, -0.95), weight="ExtraBold")
    for j, line in enumerate(["THÀNH PHẦN", "LƯƠNG"]):
        k = p(t, -0.8 + j * 0.15, 0.5)
        if k > 0: text(d, (110, 400 + j * 140 + (1 - k) * 60), line, 120, NAVY, anchor="lm", align="left")
    underline(d, 115, 640, 760, p(t, -0.4, 0.6))
    person(img, d, CB, 1200, 900, 380, pop(t, -0.3, 0.5), "C&B")

Y3 = shot_xy(full_of(2120, 1199))
def sc_recap(img, d, t):
    fs_shot(img, IMG_3YT, full_of(2120, 1199), full_of(2120, 1199), 0)
    top_title(d, t, "Cấu trúc bảng lương trên Haraworks", 2.22)
    if 6.84 <= t < 7.77 or t >= 12.38: hl(d, Y3(800, 705, 1060, 1005), t)        # Thành phần lương
    if 7.77 <= t < 9.06: hl(d, Y3(1050, 705, 1315, 1008), t)                    # Nhóm công thức
    if 9.06 <= t < 12.38: hl(d, Y3(925, 490, 1190, 765), t)                     # Công thức lương
    if t >= 12.38: hl(d, Y3(6, 705, 736, 1050), t)
    role_tag(img, d, CB, "C&B")

# ================= 6.1 Thành phần lương là gì =================
def sc_h61(img, d, t): sub_card(img, d, t, HD["h61"], "PHẦN 6", ["THÀNH PHẦN LƯƠNG", "LÀ GÌ?"], 104)

SRC = [(30.99, "Công", "calendar", BLUE), (31.32, "Mức lương", "chart", GREEN), (32.00, "Số ngày phép", "doc", CYAN),
       (33.01, "Số giờ làm thêm", "clock", ORANGE), (34.16, "Phụ cấp", "grow", NAVY), (34.88, "Số người phụ thuộc", "people", BLUE)]
def sc_def(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thành phần lương là nơi chứa dữ liệu dùng để tính lương", 16.73, size=50)
    for j, (st, lab, kind, col) in enumerate(SRC):
        hcard(d, 330, 250 + j * 112, 400, 92, pop(t, st), col, kind, lab, 24)
        arrow(d, 540, 250 + j * 112, 700, 520, p(t, st + 0.3, 0.4), LINE, 4)
    pill(d, 960, 760, 460, 64, GREY, "Hình thành từ nghiệp vụ vận hành hàng ngày", 22, pop(t, 23.84))
    s_ = pop(t, 17.14)
    if s_ > 0.01:
        card(d, 960, 520, 400, 300, s_, True, GREEN)
        icon(d, "db", 960, 450, s_, GREEN, 70)
        text(d, (960, 560), "Thành phần lương", 34 * s_, INK)
        k2 = pop(t, 20.00)
        if k2 > 0.01: text(d, (960, 615), "theo từng nhân viên", 26 * k2, GREEN, "Bold")
    arrow(d, 1170, 520, 1340, 520, p(t, 43.60, 0.4), ORANGE, 7)
    s2 = pop(t, 41.00)
    if s2 > 0.01:
        card(d, 1580, 520, 400, 300, s2, True, BLUE)
        icon(d, "fx", 1580, 450, s2, BLUE, 70)
        text(d, (1580, 560), "Công thức lương", 34 * s2, INK)
        k3 = pop(t, 43.58)
        if k3 > 0.01: text(d, (1580, 615), "lấy dữ liệu để tính toán", 26 * k3, BLUE, "Bold")
    role_tag(img, d, CB, "C&B", pop(t, 15.22, 0.4))

def sc_ways(img, d, t):
    paste(img, BOARD)
    T_KEY = 64.06
    board_title(d, t, "Dữ liệu trong thành phần lương hình thành theo hai cách", 47.12, size=50)
    vcard(d, 600, 470, 640, 360, pop(t, 48.79), BLUE, "db", "Ghi nhận từ nghiệp vụ\nđang vận hành trên Haraworks", 30, t < 56.50, "01")
    vcard(d, 1320, 470, 640, 360, pop(t, 53.48), ORANGE, "doc", "C&B tạo thành phần lương\n& nhập hàng loạt dữ liệu", 30, 56.50 <= t < T_KEY, "02")
    if t >= 56.50: pill(d, 1320, 700, 500, 64, ORANGE, "Cho dữ liệu chưa có trên hệ thống", 22, pop(t, 57.48))
    s_ = pop(t, T_KEY)
    if s_ > 0.01:
        hcard(d, W / 2, 870, 1300, 130, s_, GREEN, "check", "Điểm cần nhớ: thành phần lương là nơi chứa dữ liệu\nđể công thức lương lấy và thực hiện tính toán", 28, True)
    role_tag(img, d, CB, "C&B", pop(t, 53.48, 0.4))

# ================= Kiểm tra thành phần lương đã có trên hệ thống =================
def sc_h_check(img, d, t): sub_card(img, d, t, HD["check"], "PHẦN 6", ["KIỂM TRA THÀNH PHẦN LƯƠNG", "ĐÃ CÓ TRÊN HỆ THỐNG"], 80)

def sc_exist(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Nhiều dữ liệu đã có thành phần lương tương ứng", 74.95)
    srcs = [(82.34, "Hồ sơ nhân viên", "people", BLUE), (83.58, "Hợp đồng lao động", "doc", NAVY), (84.86, "Chấm công", "calendar", CYAN),
            (85.68, "Phép", "doc", GREEN), (86.17, "Làm thêm", "clock", ORANGE)]
    for j, (st, lab, kind, col) in enumerate(srcs):
        hcard(d, 360, 270 + j * 130, 440, 104, pop(t, st), col, kind, lab, 26)
    arrow(d, 600, 530, 760, 530, p(t, 87.10, 0.4), ORANGE, 7)
    s_ = pop(t, 83.49)
    if s_ > 0.01:
        card(d, 960, 530, 340, 240, s_, True, GREEN)
        icon(d, "db", 960, 480, s_, GREEN, 60)
        text(d, (960, 575), "Thành phần lương\ntương ứng", 28 * s_, INK)
    ex = [(91.65, "Công thực tế", "← Chấm công đã duyệt", CYAN), (94.95, "Đơn vị công tác, vị trí công việc", "← Hồ sơ nhân viên", BLUE),
          (99.66, "Mức lương, phụ cấp", "← Hợp đồng lao động", NAVY)]
    if t >= 90.79: pill(d, 1550, 250, 260, 60, ORANGE, "Ví dụ", 26, pop(t, 86.91))
    for j, (st, a_, b_, col) in enumerate(ex):
        s2 = pop(t, st)
        if s2 > 0.01:
            card(d, 1550, 380 + j * 170, 640, 140, s2, True, col)
            text(d, (1550, 360 + j * 170), a_, 26 * s2, INK)
            text(d, (1550, 405 + j * 170), b_, 24 * s2, col, "Bold")
    role_tag(img, d, CB, "C&B", pop(t, 73.95, 0.4))

DS_Z = box169(1520, 300, 1100, 1920, 1080)
def sc_list(img, d, t):
    st = 103.49
    ct = min(9.5, (t - st) * 0.7)
    k = (t - 106.54) / 1.4
    box = recz(img, "ds", REC_DS, ct, DS_Z, k)
    top_title(d, t, "Tìm trên danh sách Thành phần lương", st)
    if t >= 107.85: hl(d, RZ(box, 1124, 93, 1850, 138), t)                         # Nhập để tìm kiếm
    chip_bar(d, t, [(112.90, "Đã có → dùng trực tiếp trong công thức lương, không tạo thêm", GREEN)], size=24)
    role_tag(img, d, CB, "C&B")

CXT_FULL = full_of(2805, 1532); CXT_Z = box169(2000, 760, 1600, 2805, 1532)
CXT_Z = mild(CXT_Z, CXT_FULL)
def sc_cxt(img, d, t):
    st = 116.39
    fs_shot(img, IMG_CXT, CXT_FULL, CXT_Z, (t - 121.71) / 1.6)
    X = shot_xy(CXT_Z)
    top_title(d, t, "Chuỗi xác thực: phân biệt nguồn hình thành", 118.61)
    if 123.19 <= t < 125.64: hl(d, X(2211, 370, 2537, 1176), t)                     # cột Chuỗi xác thực
    if 125.64 <= t < 129.73: hl(d, X(2211, 960, 2537, 1176), t)                     # có chuỗi -> C&B tạo thêm
    if t >= 129.73: hl(d, X(2211, 440, 2537, 958), t)                              # không có chuỗi -> hệ thống
    if t < 129.73: chip_bar(d, t, [(125.64, "Có chuỗi xác thực: thành phần lương do C&B tạo thêm", ORANGE)], size=24)
    else: chip_bar(d, t, [(129.73, "Không có chuỗi xác thực: thành phần lương do hệ thống hình thành", BLUE)], size=24)
    role_tag(img, d, CB, "C&B")

def sc_file(img, d, t):
    st = 133.45
    recz(img, "xl", REC_XL, (t - st) * 1.1, FULLB, 0, REC_XLS)
    top_title(d, t, "File Excel tổng hợp thành phần lương mặc định của hệ thống", st)
    chip_bar(d, t, [(137.32, "Haraworks gửi kèm để C&B đối chiếu khi cần", NAVY)], size=24)
    role_tag(img, d, CB, "C&B")

def sc_decide(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Chỉ tạo thêm khi hệ thống chưa có", 143.89)
    vcard(d, 560, 500, 520, 340, pop(t, 137.30), BLUE, "search", "Đối chiếu danh sách\n& file tổng hợp", 30, True, "01")
    arrow(d, 840, 500, 1060, 500, p(t, 145.50, 0.4), ORANGE, 7)
    s_ = pop(t, 138.53)
    if s_ > 0.01:
        vcard(d, 1340, 500, 520, 340, s_, ORANGE, "q", "Chưa có thành phần lương\nphù hợp?", 30, True, "02")
    pill(d, 1340, 760, 420, 70, GREEN, "Mới xem xét tạo thêm", 28, pop(t, 142.13))
    role_tag(img, d, CB, "C&B")

# ================= Nguyên tắc vận hành của thành phần lương =================
def sc_h_nt(img, d, t): sub_card(img, d, t, HD["nt"], "PHẦN 6", ["NGUYÊN TẮC VẬN HÀNH", "CỦA THÀNH PHẦN LƯƠNG"], 84)

def sc_understand(img, d, t):
    paste(img, BOARD)
    if t < 168.95:
        board_title(d, t, "Trước khi đưa thành phần lương vào công thức", 154.37)
        hcard(d, W / 2, 360, 1100, 130, pop(t, 150.28), BLUE, "db", "Dữ liệu được hình thành như thế nào?", 32, True)
        hcard(d, W / 2, 530, 1100, 130, pop(t, 153.59), CYAN, "calendar", "Giá trị được ghi nhận ra sao?", 32, True)
        pill(d, W / 2, 720, 840, 76, GREEN, "Chọn đúng dữ liệu & sử dụng đúng cách trong công thức", 26, pop(t, 157.23))
    else:
        board_title(d, t, "Ví dụ: tính công của nhân viên trong tháng", 168.95)
        hcard(d, W / 2, 330, 1100, 130, pop(t, 167.81), BLUE, "q", "1. Dữ liệu công đã có trên Haraworks hay chưa?", 30, True)
        hcard(d, W / 2, 500, 1100, 150, pop(t, 170.42), CYAN, "search", "2. Nếu đã có: đang ghi nhận tại thành phần lương nào\nvà thành phần đó trả ra giá trị gì?", 28, True)
        s_ = pop(t, 175.95)
        if s_ > 0.01:
            hcard(d, W / 2, 700, 1100, 130, s_, GREEN, "check", "Dữ liệu chấm công đã vận hành trên Haraworks\n→ không tạo thêm, tra cứu thành phần lương đã có", 26, True)
    role_tag(img, d, CB, "C&B", pop(t, 165.93, 0.4))

TK_Z1 = box169(1180, 420, 1100, 1920, 1080); TK_Z2 = box169(560, 820, 1300, 1920, 1080)
IMG_GC = U + "TPL_Giờ_công.png"                                     # 2879x1693
GC_FULL = full_of(2879, 1693); XG = shot_xy(GC_FULL)
def sc_search(img, d, t):
    st = 188.65
    ct = min(9.3, (t - st) * 0.4)
    if t < 204.39: box = recz(img, "tk", REC_TK, ct, TK_Z1, (t - 201.61) / 1.2, REC_XLS)
    else: box = recz(img, "tk", REC_TK, ct, TK_Z2, 1 - (t - 204.39) / 1.0 if t < 205.35 else (t - 207.43) / 1.2, REC_XLS)
    top_title(d, t, "Tra cứu trong file tổng hợp thành phần lương", 191.49)
    if 202.01 <= t < 204.39 and ct >= 5.0: hl(d, RZ(box, 915, 400, 1450, 440, REC_XLS), t)     # Find what: công
    if t >= 208.54:                     # các thành phần lương được gợi ý: chuyển sang ảnh TPL Giờ công (không bị icon che)
        fs_shot(img, IMG_GC, GC_FULL, GC_FULL, 0)
        top_title(d, t, "Tra cứu trong file tổng hợp thành phần lương", 208.54)
        hl(d, XG(45, 621, 1660, 883), t); hl(d, XG(45, 917, 1660, 1184), t)       # Ngày công · Giờ công
    role_tag(img, d, CB, "C&B")

NT_FULL = full_of(2879, 1701)
NT_ZG = box169(1000, 1300, 2000, 2879, 1701); NT_ZM = box169(1000, 800, 2000, 2879, 1701)
NT_ZM = mild(NT_ZM, NT_FULL)
NT_ZG = mild(NT_ZG, NT_FULL)
def sc_giocong(img, d, t):
    st = 213.41
    fs_shot(img, IMG_GC, GC_FULL, GC_FULL, 0)
    top_title(d, t, "Thành phần lương Giờ công", st)
    if t >= 215.91: hl(d, XG(100, 897, 263, 1188), t)                                 # Giờ công
    if t >= 218.22: hl(d, XG(556, 897, 1115, 1188), t)                                # Mục đích sử dụng
    if t >= 222.07: hl(d, XG(1115, 897, 1660, 1188), t)                               # Giá trị trả ra
    role_tag(img, d, CB, "C&B")

def day_grid(d, t, y, label, vals, starts, col, unit=""):
    text(d, (230, y), label, 30, INK, anchor="lm")
    for i in range(10):
        x = 520 + i * 135; s_ = pop(t, starts[i] if i < len(starts) else starts[-1] + (i - len(starts) + 1) * 0.15, 0.3)
        d.rounded_rectangle([x - 60, y - 120, x + 60, y - 70], 12, fill=(238, 242, 252))
        text(d, (x, y - 95), f"Ngày {i + 1}", 22, GREY)
        if s_ > 0.01:
            d.rounded_rectangle([x - 60 * s_, y - 40 * s_, x + 60 * s_, y + 40 * s_], 14, fill=WHITE, outline=col, width=4)
            text(d, (x, y), f"{vals[i]}{unit}", fit_size(d, f"{vals[i]}{unit}", 30, "ExtraBold", 110) * s_, col)

def sc_day_gio(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Giờ công: giá trị thay đổi theo dữ liệu công từng ngày", 224.96, size=50)
    day_grid(d, t, 500, "Giờ công", [8, 4, 8, 8, 8, 8, 8, 8, 8, 8], [233.49, 237.44, 241.38, 244.03], BLUE)
    pill(d, W / 2, 720, 1000, 76, NAVY, "Mỗi ngày ghi nhận đúng số giờ công đã duyệt của ngày đó", 26, pop(t, 234.94))
    role_tag(img, d, CB, "C&B")

def sc_luong(img, d, t):
    T_DAY = 264.75
    if t < T_DAY:
        fs_shot(img, IMG_NT, NT_FULL, NT_ZM, (t - 257.50) / 1.6)
        X = shot_xy(NT_ZM)
        top_title(d, t, "Thành phần lương Mức lương chính", 252.37)
        if t >= 259.20: hl(d, X(101, 619, 264, 963), t)                               # Mức lương chính
        if t >= 260.09: hl(d, X(558, 619, 1114, 963), t)                              # lấy từ HĐLĐ / phụ lục
        role_tag(img, d, CB, "C&B")
        return
    paste(img, BOARD)
    board_title(d, t, "Mức lương chính: giữ nguyên trong thời gian có hiệu lực", T_DAY, size=50)
    day_grid(d, t, 500, "Mức lương\nchính", ["10tr"] * 10, [271.36 + i * 0.12 for i in range(10)], GREEN)
    pill(d, W / 2, 720, 900, 76, NAVY, "Nhân viên A: mức lương chính 10.000.000 đ", 26, pop(t, 253.42))
    role_tag(img, d, CB, "C&B")

def sc_compare(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thành phần lương ghi nhận dữ liệu theo từng ngày", 275.46)
    s1 = pop(t, 271.21)
    if s1 > 0.01:
        card(d, 560, 520, 700, 380, s1, True, BLUE)
        icon(d, "clock", 560, 400, s1, BLUE, 60)
        text(d, (560, 490), "Giờ công", 36 * s1, INK)
        text(d, (560, 560), "Thay đổi theo giờ công\nđược duyệt thực tế từng ngày", 26 * s1, BLUE, "Bold")
        for i, v in enumerate([8, 4, 8, 8, 6]): text(d, (380 + i * 90, 660), str(v), 30 * s1, BLUE)
    s2 = pop(t, 275.45)
    if s2 > 0.01:
        card(d, 1360, 520, 700, 380, s2, True, GREEN)
        icon(d, "chart", 1360, 400, s2, GREEN, 60)
        text(d, (1360, 490), "Mức lương chính", 36 * s2, INK)
        text(d, (1360, 560), "Giữ nguyên qua nhiều ngày\nnếu không đổi mức lương", 26 * s2, GREEN, "Bold")
        for i in range(5): text(d, (1180 + i * 90, 660), "10tr", 26 * s2, GREEN)
    pill(d, W / 2, 820, 860, 76, ORANGE, "C&B cần hiểu điểm này trước khi đưa vào công thức", 26, pop(t, 281.90))
    role_tag(img, d, CB, "C&B", pop(t, 281.90, 0.4))

CT_FULL = full_of(2773, 1497); CT_Z = box169(1480, 1000, 1500, 2773, 1497)
CT_Z = mild(CT_Z, CT_FULL)
def sc_cachthe(img, d, t):
    T_EX = 309.91
    if t < T_EX:
        fs_shot(img, IMG_CTCT, CT_FULL, CT_Z, (t - 301.28) / 1.6)
        X = shot_xy(CT_Z)
        top_title(d, t, "Cách thể hiện trên bảng lương", 300.82)
        if t >= 303.67: hl(d, X(1188, 832, 1768, 1398), t)                             # Cách thể hiện: Tổng, Giá trị cuối cùng...
        role_tag(img, d, CB, "C&B")
        return
    paste(img, BOARD)
    board_title(d, t, "Chọn cách lấy dữ liệu ảnh hưởng trực tiếp kết quả", T_EX, size=50)
    s1 = pop(t, 295.70)
    if s1 > 0.01:
        card(d, 560, 500, 720, 420, s1, True, GREEN)
        text(d, (560, 360), "Giờ công", 36 * s1, INK)
        text(d, (560, 450), "8 + 4 + 8 + … ", 34 * s1, BLUE)
        text(d, (560, 530), "→ Tổng số giờ trong kỳ", 30 * s1, GREEN, "ExtraBold")
        badge(d, 560, 640, True, pop(t, 298.94, 0.4), 40)
    s2 = pop(t, 300.73)
    if s2 > 0.01:
        card(d, 1360, 500, 720, 420, s2, True, RED, (255, 240, 240))
        text(d, (1360, 360), "Mức lương chính 10tr", 36 * s2, INK)
        text(d, (1360, 450), "10tr + 10tr + 10tr + …", 34 * s2, RED)
        text(d, (1360, 530), "→ Cộng toàn bộ: sai mức lương", 30 * s2, RED, "ExtraBold")
        badge(d, 1360, 640, False, pop(t, 306.02, 0.4), 40)
    role_tag(img, d, CB, "C&B")

def sc_3q(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ba câu hỏi trước khi dùng một thành phần lương", 324.73)
    qs = [(330.18, "Dữ liệu này\nđến từ đâu?", "db", BLUE), (331.88, "Giá trị được ghi nhận\nthế nào theo từng ngày?", "calendar", CYAN),
          (334.80, "Đưa vào công thức cần\nlấy theo cách nào?", "fx", ORANGE)]
    for i, (st, lab, kind, col) in enumerate(qs):
        vcard(d, 500 + i * 460, 500, 420, 380, pop(t, st), col, kind, lab, 28, True, f"0{i + 1}")
    pill(d, W / 2, 800, 860, 76, GREEN, "Dễ phân tích & xây dựng công thức phù hợp thực tế", 26, pop(t, 323.22))
    role_tag(img, d, CB, "C&B", pop(t, 311.66, 0.4))

# ================= Tạo mới thành phần lương =================
def sc_h_tao(img, d, t): sub_card(img, d, t, HD["tao"], "PHẦN 6", ["TẠO MỚI", "THÀNH PHẦN LƯƠNG"], 104)

TAO_Z = box169(1170, 330, 1000, 1920, 1080)
F_TEN = (828, 146, 1162, 212); F_MA = (828, 218, 1162, 282); F_TT = (828, 288, 1162, 352)
F_REST = (1180, 292, 1516, 645); F_REST2 = (828, 442, 1180, 645)
def sc_tao(img, d, t):
    ct = piece(t, [(349.34, 0.0), (352.10, 6.8), (354.71, 11.5), (363.83, 11.6), (379.11, 20.5)])
    box = recz(img, "tao", REC_TAO, ct, TAO_Z, (ct - 5.0) / 1.5)
    top_title(d, t, "Tạo mới thành phần lương", 349.52)
    if ct >= 6.0:
        if t < 353.15 or 355.86 <= t < 363.83 or 371.70 <= t < 380.2: hl(d, RZ(box, *F_TEN), t)     # Tên thành phần lương
        if 353.15 <= t < 354.71: hl(d, RZ(box, *F_MA), t)                                  # Mã thành phần lương
        if 354.71 <= t < 355.86: hl(d, RZ(box, *F_TT), t)                                  # Trạng thái
    if t < 363.83: chip_bar(d, t, [(356.90, "Tên thể hiện rõ dữ liệu → dễ tìm kiếm, kiểm tra & sử dụng", NAVY)], size=24)
    elif t < 374.74: chip_bar(d, t, [(363.83, "Khoản bổ sung từ nguồn bên ngoài, chưa có trên Haraworks", ORANGE)], size=24)
    elif t < 380.2: chip_bar(d, t, [(374.74, "Tương tự: khoản khấu trừ từ bên ngoài → \"Khoản trừ khác\"", RED)], size=24)
    else: chip_bar(d, t, [(380.2, "Mã: không dấu · không khoảng trắng · không thể chỉnh sửa sau khi tạo", RED)], size=24)
    if t >= 380.2 and ct >= 6.0: hl(d, RZ(box, *F_MA), t)                                   # Mã thành phần lương
    role_tag(img, d, CB, "C&B")

def sc_warn(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Lưu ý: thành phần lương sau khi tạo không thể xóa", 389.79, size=50)
    s_ = pop(t, 372.36)
    if s_ > 0.01:
        card(d, W / 2, 330, 1000, 170, s_, True, RED, (255, 238, 238))
        icon(d, "warn", W / 2 - 410 * s_, 330, s_, RED, 60)
        text(d, (W / 2 + 40, 330), "Không thể xóa khỏi danh sách", 40 * s_, RED)
    hcard(d, 560, 600, 760, 140, pop(t, 377.68), BLUE, "search", "Kiểm tra thành phần lương\ntương ứng đã có hay chưa", 28, True)
    hcard(d, 1360, 600, 760, 140, pop(t, 390.46), NAVY, "doc", "Xác định rõ tên & mã\nngay từ đầu", 28, True)
    pill(d, W / 2, 790, 900, 76, ORANGE, "Tránh tạo trùng hoặc tạo thành phần không còn dùng về sau", 26, pop(t, 392.80))
    role_tag(img, d, CB, "C&B", pop(t, 376.79, 0.4))

def sc_tt(img, d, t):
    box = recz(img, "tao", REC_TAO, 20.5, TAO_Z, 1.0)
    top_title(d, t, "Trạng thái thành phần lương", 407.88)
    hl(d, RZ(box, *F_TT), t)
    if t < 415.32: chip_bar(d, t, [(409.17, "Đang sử dụng: còn ghi nhận dữ liệu hoặc tham gia công thức lương", GREEN)], size=24)
    else: chip_bar(d, t, [(415.32, "Không còn sử dụng → chuyển sang Ngưng sử dụng", GREY)], size=24)
    role_tag(img, d, CB, "C&B")

TC_FULL = full_of(2777, 1526); TC_Z = box169(1600, 900, 1800, 2777, 1526)
TC_Z = mild(TC_Z, TC_FULL)
def sc_ref(img, d, t):
    st = 419.94
    fs_shot(img, IMG_TPLCT, TC_FULL, TC_Z, (t - st - 1.6) / 1.6)
    X = shot_xy(TC_Z)
    top_title(d, t, "Trước khi ngưng: kiểm tra công thức lương đang tham chiếu", st)
    if t >= 423.00: hl(d, X(1345, 555, 1924, 1374), t)                                 # cột Công thức lương
    if t < 434.96:
        chip_bar(d, t, [(429.31, "Loại bỏ / thay thế tham chiếu trong công thức trước, rồi mới ngưng sử dụng", ORANGE)], size=22)
    else:
        chip_bar(d, t, [(434.96, "Công thức còn tham chiếu thành phần đã ngưng → tính lương có thể lỗi", RED)], size=22)
    role_tag(img, d, CB, "C&B")

def sc_next(img, d, t):
    if t >= 446.63:
        box = recz(img, "tao", REC_TAO, 20.5, TAO_Z, 1.0)
        top_title(d, t, "Các trường thông tin còn lại", 446.63)
        hl(d, RZ(box, *F_REST), t); hl(d, RZ(box, *F_REST2), t)
        chip_bar(d, t, [(448.90, "Chỉ sử dụng khi có hướng dẫn từ Haraworks trong tình huống cụ thể", NAVY)], size=24)
        role_tag(img, d, CB, "C&B")
        return
    paste(img, BOARD)
    k = pop(t, 426.56)
    pill(d, W / 2, 300, 360, 76, NAVY, "Bước tiếp theo", 32, k)
    s_ = pop(t, 428.38, 0.6)
    if s_ > 0.01:
        card(d, W / 2, 560, 1100, 320, s_, True, GREEN)
        icon(d, "db", W / 2 - 420 * s_, 560, s_, GREEN, 90)
        text(d, (W / 2 + 90, 520), "ĐƯA DỮ LIỆU VÀO", 54 * s_, NAVY)
        text(d, (W / 2 + 90, 600), "THÀNH PHẦN LƯƠNG", 54 * s_, GREEN)
    role_tag(img, d, CB, "C&B", k)

SCENES = [(-OFFSET, 2.22, "part"), (2.22, HD["h61"], "recap"), (HD["h61"], 16.73, "h61"), (16.73, 47.12, "def"),
          (47.12, HD["check"], "ways"), (HD["check"], 74.95, "h_check"), (74.95, 103.49, "exist"), (103.49, 116.39, "list"),
          (116.39, 133.45, "cxt"), (133.45, 143.89, "file"), (143.89, HD["nt"], "decide"), (HD["nt"], 154.37, "h_nt"),
          (154.37, 188.65, "understand"), (188.65, 213.41, "search"), (213.41, 224.96, "giocong"), (224.96, 251.57, "day_gio"),
          (251.57, 275.46, "luong"), (275.46, 300.82, "compare"), (300.82, 324.73, "cachthe"), (324.73, HD["tao"], "3q"),
          (HD["tao"], 349.34, "h_tao"), (349.34, 389.79, "tao"), (389.79, 407.88, "warn"), (407.88, 419.94, "tt"),
          (419.94, 440.39, "ref"), (440.39, 999, "next")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times):
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.resize((960, 540)).save(f"/tmp/pv61_{tv}.png")

N = 12
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p61_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p61_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
