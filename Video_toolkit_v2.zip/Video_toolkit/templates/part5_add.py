# Phần bổ sung của 5.1 (chạy trong không gian tên của part5.py):
# "Trước khi xây dựng bảng lương cần chuẩn bị gì" · "Hồ sơ nhân viên" · "Hợp đồng lao động"
IMG_TQ = U + "sỰ_TƯƠNG_QUAN_GIỮA_BẢNG_LƯƠNG_excel_và_hệ_thống.png"   # 2118x1191
IMG_LDNN = U + "Lao_động_nước_ngoài.png"                               # 2801x1533
IMG_TTCV = U + "Thông_tin_công_việc___áp_dụng_tính_lương_tự_động__tham_gia_công_đoàn.png"  # 2806x1526
REC_NPT = U + "Người_phụ_thuộc.mp4"                                    # 1910x1032

def sub_card(img, d, t, t0, kicker, lines, size=96):
    paste(img, SECTION)
    pill(d, 280, 280, 340, 76, BLUE, kicker, 30, pop(t, t0 + 0.05), weight="ExtraBold")
    for j, line in enumerate(lines):
        k = p(t, t0 + 0.15 + j * 0.12, 0.45)
        if k > 0: text(d, (110, 430 + j * size * 1.12 + (1 - k) * 50), line, size, NAVY, anchor="lm", align="left")
    underline(d, 115, 430 + (len(lines) - 1) * size * 1.12 + size * 0.75, 700, p(t, t0 + 0.45, 0.5))
    person(img, d, CB, 1220, 900, 340, pop(t, t0 + 0.4, 0.5), "C&B", 30)

def shot_xy(box):
    """Hàm đổi toạ độ ảnh gốc -> khung hình khi ảnh hiển thị theo box (16:9)."""
    k = 1920 / (box[2] - box[0])
    return lambda x0, y0, x1, y1: ((x0 - box[0]) * k, (y0 - box[1]) * k, (x1 - box[0]) * k, (y1 - box[1]) * k)

def badge2(d, x, y, ok, s, r0=24):
    if s <= 0.01: return
    r = r0 * s
    d.ellipse([x - r, y - r, x + r, y + r], fill=GREEN if ok else RED)
    w = max(int(6 * s), 1)
    if ok: d.line([x - r * 0.45, y, x - r * 0.1, y + r * 0.4, x + r * 0.5, y - r * 0.35], fill=WHITE, width=w, joint="curve")
    else:
        d.line([x - r * 0.4, y - r * 0.4, x + r * 0.4, y + r * 0.4], fill=WHITE, width=w)
        d.line([x - r * 0.4, y + r * 0.4, x + r * 0.4, y - r * 0.4], fill=WHITE, width=w)

_c2 = {}
def rec2(img, key, path, tc, crop, size=(1920, 1080), pos=(0, 0)):
    if key not in _c2: _c2[key] = Clip(path, size, crop)
    fullscreen(img, _c2[key].get(tc), pos)

# ================= Trước khi xây dựng bảng lương cần chuẩn bị gì =================
def sc_h_prep(img, d, t): sub_card(img, d, t, H_PREP, "PHẦN 5", ["TRƯỚC KHI XÂY DỰNG", "BẢNG LƯƠNG", "CẦN CHUẨN BỊ GÌ?"], 84)

def sc_prep3(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ba nhóm thông tin cần chuẩn bị", c("trước khi bắt", 156.43))
    items = [(c("bảng lương ishow", 161.7), "Bảng lương Excel\nđang sử dụng", "sheet", GREEN),
             (c("chính sách", 163.00), "Chính sách lương\nđã thống nhất", "shield", NAVY),
             (c("dữ liệu nguồn", 165.01), "Dữ liệu nguồn\ndùng để tính lương", "db", BLUE)]
    for i, (st, lab, kind, col) in enumerate(items):
        vcard(d, 520 + i * 440, 540, 380, 360, pop(t, st), col, kind, lab, 30, True, f"0{i + 1}")
    role_tag(img, d, CB, "C&B", pop(t, c("con cần chuẩn", 159.2), 0.4))

TQ_BOX = (0, 0, 2118, 1191)
def sc_prep_excel(img, d, t):
    fs_shot(img, IMG_TQ, TQ_BOX, TQ_BOX, 0)
    T = shot_xy(TQ_BOX)
    top_title(d, t, "Bảng lương Excel đang sử dụng", c("đầu tiên", 167.14))
    t1, t2, t3 = c("dữ liệu doanh", 173.10), c("các khoản", 174.93), c("quy tắc", 176.29)
    if t1 <= t < t2: hl(d, T(70, 330, 2047, 480), t)                                  # dữ liệu đang sử dụng
    elif t2 <= t < t3: hl(d, T(532, 280, 2050, 336), t)                              # các khoản cần tính
    elif t >= t3:
        for x0, x1 in [(885, 1001), (1117, 1233), (1582, 2047)]: hl(d, T(x0, 335, x1, 480), t)   # quy tắc hình thành kết quả
    role_tag(img, d, CB, "C&B")

def sc_prep_policy(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Chính sách lương đã được xác định rõ", c("tiếp theo", 178.63))
    for j, (w, af) in enumerate([("điều kiện", 187.84), ("cách tính", 190.37), ("trường hợp", 191.71)]):
        hcard(d, 560, 330 + j * 150, 760, 120, pop(t, c(w, af)), NAVY, ["check", "fx", "people"][j],
              ["Điều kiện hưởng của từng khoản thu nhập", "Cách tính như thế nào", "Trường hợp được hưởng / không được hưởng"][j], 28, True)
    s1 = pop(t, c("vẫn đang", 195.99))
    if s1 > 0.01:
        card(d, 1430, 380, 700, 230, s1, True, RED, (255, 238, 238))
        icon(d, "warn", 1430 - 270 * s1, 380, s1, RED, 50)
        text(d, (1480, 380), "Chính sách còn thay đổi\n→ công thức phải điều chỉnh\nliên tục", 28 * s1, RED)
    s2 = pop(t, c("thống nhất chính", 200.83))
    if s2 > 0.01:
        card(d, 1430, 700, 700, 230, s2, True, GREEN)
        icon(d, "check", 1430 - 270 * s2, 700, s2, GREEN, 50)
        text(d, (1480, 700), "Thống nhất trước khi thiết lập\n→ bảng lương ổn định,\ndễ kiểm soát", 28 * s2, GREEN)
    role_tag(img, d, CB, "C&B", pop(t, c("cnb cần", 184.2), 0.4))

def sc_prep_data(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu nguồn dùng để tính lương", c("điều thứ", 206.58))
    srcs = ["Hồ sơ nhân viên", "Hợp đồng lao động", "Công & phép", "Làm thêm giờ"]
    for j, lab in enumerate(srcs):
        hcard(d, 330, 300 + j * 120, 420, 96, pop(t, c("nghiệp vụ", 216.78) + j * 0.15), BLUE, "db", lab, 26)
    arrow(d, 560, 480, 760, 480, p(t, c("công thức lương sử", 212.34), 0.4), ORANGE, 7)
    s_ = pop(t, c("công thức lương sử", 212.34))
    if s_ > 0.01:
        card(d, 960, 480, 360, 200, s_, True, ORANGE)
        icon(d, "fx", 960, 440, s_, ORANGE, 50)
        text(d, (960, 530), "Công thức lương", 30 * s_, INK)
    qs = [(c("dữ liệu nào", 221.66), "Dữ liệu nào tham gia tính lương?"), (c("trong trường", 224.79), "Được dùng trong trường hợp nào?"),
          (c("khai báo sai", 226.37), "Khai báo sai ảnh hưởng thế nào?")]
    for j, (st, lab) in enumerate(qs):
        hcard(d, 1500, 330 + j * 150, 620, 115, pop(t, st), [BLUE, CYAN, RED][j], "q", lab, 26, True)
    role_tag(img, d, CB, "C&B", pop(t, c("cb cần", 220.9), 0.4))

# ================= Hồ sơ nhân viên =================
def sc_h_hsnv(img, d, t): sub_card(img, d, t, H_HSNV, "PHẦN 5", ["HỒ SƠ NHÂN VIÊN"], 110)

LD_BOX0 = box169(1400, 766, 2801, 2801, 1533); LD_BOX1 = box169(1900, 1000, 1600, 2801, 1533)
TT_BOX0 = box169(1403, 763, 2806, 2806, 1526)
TT_BOX_DV = box169(1320, 600, 2000, 2806, 1526); TT_BOX_CK = box169(1650, 760, 1600, 2806, 1526)
def sc_hsnv(img, d, t):
    T_LD, T_DV, T_AD, T_CD = c("ví dụ", 240.53), c("đơn vị công", 255.09), c("thiết lập cn", 273.4), c("với nhân viên", 299.40)
    if t < T_DV:          # thông tin chung -> lao động nước ngoài
        k = (t - c("nhân sự nước", 241.75)) / 2.5 if t >= T_LD else 0
        fs_shot(img, IMG_LDNN, LD_BOX0, LD_BOX1, k)
        if t >= c("tích chọn", 243.85): hl(d, shot_xy(LD_BOX1)(2045, 1188, 2340, 1242), t)          # Lao động nước ngoài
        top_title(d, t, "Hồ sơ nhân viên: thông tin dùng làm điều kiện tính lương", 218.3)
        chip_bar(d, t, [(c("thuế thu", 251.87), "Phân biệt trong nước / nước ngoài → thuế TNCN, bảo hiểm", NAVY)], size=24)
    elif t < T_AD:        # đơn vị công tác & vị trí công việc
        fs_shot(img, IMG_TTCV, TT_BOX0, TT_BOX_DV, (t - T_DV) / 2.0)
        if t > T_DV + 2.0: hl(d, shot_xy(TT_BOX_DV)(870, 368, 1770, 448), t)                      # Đơn vị công tác / Vị trí công việc
        top_title(d, t, "Đơn vị công tác & vị trí công việc", T_DV)
        chip_bar(d, t, [(c("khối văn", 263.82), "Khối văn phòng / khối cửa hàng: cách tính khác nhau", ORANGE)], size=24)
    else:                 # áp dụng tính lương tự động -> tham gia công đoàn
        k = (t - T_AD) / 2.0
        fs_shot(img, IMG_TTCV, TT_BOX_DV, TT_BOX_CK, k)
        X = shot_xy(TT_BOX_CK)
        if T_AD + 2.0 < t < T_CD: hl(d, X(1462, 728, 1815, 776), t)                               # Áp dụng tính lương tự động
        if t >= c("tích chọn tham", 302.24): hl(d, X(2045, 728, 2328, 776), t)                       # Tham gia công đoàn
        top_title(d, t, "Áp dụng tính lương tự động" if t < T_CD else "Tham gia công đoàn", T_AD if t < T_CD else T_CD)
        if t < c("ngược lại", 290.27):
            chip_bar(d, t, [(c("cố vấn", 282.84), "Cố vấn / chuyên gia không nhận lương → bỏ chọn", ORANGE)], size=24)
        elif t < T_CD:
            chip_bar(d, t, [(c("ngược lại", 290.27), "Chạy lương thiếu nhân viên → kiểm tra mục này", RED)], size=24)
        else:
            chip_bar(d, t, [(c("ví dụ hai", 310.57), "Cùng mức lương, chỉ người tham gia công đoàn phát sinh khoản công đoàn", NAVY)], size=22)
    role_tag(img, d, CB, "C&B")

def sc_npt(img, d, t):
    st = c("thông tin người", 319.34)
    ct = min(10.4, t - st + 0.2)
    rec2(img, "npt", REC_NPT, ct, (0, 0, 1910, 1032), (1920, 1037), (0, 21))
    K = 1920 / 1910
    def N(x0, y0, x1, y1): return (x0 * K, y0 * K + 21, x1 * K, y1 * K + 21)
    if 0.6 < ct < 5.6: hl(d, N(1318, 252, 1812, 445), t)                    # Là người phụ thuộc / Thời gian tính giảm trừ
    if 7.0 <= ct < 8.6: hl(d, N(1012, 402, 1205, 446), t)                   # checkbox Là người phụ thuộc
    if ct >= 8.6: hl(d, N(560, 438, 1400, 505), t)                          # Ngày bắt đầu / kết thúc tính giảm trừ
    top_title(d, t, "Người phụ thuộc: giảm trừ gia cảnh khi tính thuế TNCN", st)
    role_tag(img, d, CB, "C&B")

def sc_npt_ex(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ví dụ: người con đủ điều kiện giảm trừ từ tháng 3", c("ví dụ", 330.42))
    x0, cw, y = 260, 118, 560
    for i in range(12):
        x = x0 + i * cw
        d.rounded_rectangle([x + 4, y, x + cw - 4, y + 70], 12, fill=(238, 242, 252))
        text(d, (x + cw / 2, y + 35), f"T{i + 1}", 28, GREY)
    person(img, d, EMP, 160, 520, 200, pop(t, c("nhân viên có", 331.09)), "Nhân viên", 24)
    T_END = c("khi người", 347.67)
    k = p(t, c("từ tháng", 339.71), 0.8)
    end_m = 12 if t < c("cập nhật ngày", 350.91) else 9
    if k > 0:
        xa, xb = x0 + 2 * cw + 4, x0 + end_m * cw - 4
        d.rounded_rectangle([xa, y - 70, xa + (xb - xa) * k, y - 20], 25, fill=GREEN)
        if k > 0.9: text(d, ((xa + xb) / 2, y - 45), "Tính giảm trừ người phụ thuộc", 24, WHITE)
        if end_m == 12 and t >= T_END:
            d.rounded_rectangle([x0 + 9 * cw + 4, y - 70, xb, y - 20], 25, fill=RED)
            text(d, (x0 + 10.5 * cw, y - 45), "Không còn đủ ĐK", 22, WHITE)
    hcard(d, 520, 800, 600, 110, pop(t, c("chọn người phụ thuộc", 336.86)), GREEN, "check", "Chọn người phụ thuộc\n+ thời gian áp dụng từ tháng 3", 24, True)
    s_ = pop(t, c("nếu không", 340.65))
    if s_ > 0.01 and t < T_END:
        hcard(d, 1300, 800, 760, 120, s_, RED, "warn", "Không chọn / không khai thời gian\n→ không tính vào số người phụ thuộc", 24, True)
    s2 = pop(t, c("cập nhật ngày", 350.91))
    if s2 > 0.01:
        hcard(d, 1300, 800, 760, 120, s2, NAVY, "calendar", "Cập nhật ngày kết thúc\n→ dừng áp dụng đúng thời điểm", 24, True)
    role_tag(img, d, CB, "C&B")

CERT_IMG = A + "cert_compose.png"; CERT_FULL = (0, 0, 1920, 1080); CERT_ZOOM = box169(1200, 950, 1400, 1920, 1080)
CERT_IMG = U + "Chứng_chỉ.png"; CERT_FULL = box169(1440, 762, 2879, 2879, 1523); CERT_ZOOM = box169(1757, 420, 2000, 2879, 1523)
def sc_cert(img, d, t):
    st = c("thông tin chứng", 365.66)
    k = (t - st - 0.8) / 2.2                       # full màn hình hồ sơ, rồi phóng vào Chứng chỉ/Kỹ năng
    fs_shot(img, CERT_IMG, CERT_FULL, CERT_ZOOM, k)
    if k >= 1.0: hl(d, shot_xy(CERT_ZOOM)(846, 235, 2669, 592), t)          # Chứng chỉ/Kỹ năng
    top_title(d, t, "Chứng chỉ: điều kiện tính phụ cấp", st)
    chip_bar(d, t, [(c("tiếng anh", 373.23), "Phụ cấp chứng chỉ tiếng Anh / chuyên môn", GREEN)], x0=560, size=24)
    role_tag(img, d, CB, "C&B")


# ---------- Màn hình hợp đồng lao động (bản quay Mức lương & PC, Mức đóng bảo hiểm) ----------
REC_ML = U + "Mức_lương_và_PC.mp4"; REC_BH = U + "Mức_đóng_bảo_hiểm.mp4"; REC_PCCT = U + "PC_công_tác.mp4"
CTR_PC3 = box169(1250, 740, 1400, 1920, 1080)
F_PC3 = (612, 662, 1470, 722); F_PC3_HL = (612, 732, 805, 792); F_PC3_HH = (612, 797, 805, 857)
FULLB = (0, 0, 1920, 1080)
CTR_INFO = box169(1057, 570, 1300, 1920, 1080)          # vùng Thông tin hợp đồng
CTR_BOSUNG = box169(1250, 600, 1400, 1920, 1080)        # vùng Các khoản bổ sung

# ---------- Sửa đè chữ trên bản quay để khớp ví dụ trong voice (font Inter như giao diện Haraworks) ----------
_inter = ImageFont.truetype(A + "Inter.ttf", 15); _inter.set_variation_by_name("Regular")
TXT = (24, 24, 27)
def ov_draw(bg, items):
    """items: [(erase_box, (x, y), text)] theo toạ độ bản quay gốc 1912x1016; bg là khung đã ghép (dư trên 30px)."""
    dd = ImageDraw.Draw(bg); s = 1920 / 1912
    for (x0, y0, x1, y1), (tx, ty), txt in items:
        col = bg.getpixel((int(x1 * s) + 3, int(y0 * s + 30)))          # màu nền thực tế của thẻ
        dd.rectangle([x0 * s, y0 * s + 30, x1 * s, y1 * s + 30], fill=col)
        dd.text((tx * s - 2, ty * s + 30), txt, font=_inter, fill=TXT)
OV_BOSUNG = [((620, 403, 1000, 431), (626, 408), "Phụ cấp xăng"), ((1260, 403, 1640, 433), (1265, 407), "10,000,000/Tháng"),
             ((620, 696, 1000, 724), (626, 701), "Phụ cấp trách nhiệm"), ((1260, 697, 1640, 723), (1265, 700), "10,000,000/Tháng"),
             ((1260, 765, 1500, 789), (1265, 766), "0/Tháng")]
OV_INFO = [((1260, 862, 1500, 890), (1265, 864), "50,000,000/Tháng")]
OV_PCCT = [((620, 403, 1000, 431), (626, 408), "Phụ cấp trách nhiệm"), ((1260, 404, 1640, 430), (1265, 408), "10,000,000/Tháng"),
           ((1260, 472, 1500, 494), (1265, 474), "0/Tháng")]
def ov_for(key, tc):
    if key in ("ml", "hd", "gio"):
        if tc <= 1.7: return OV_INFO
        if tc >= 4.4: return OV_BOSUNG
    if key == "bh":
        if tc <= 1.7: return OV_INFO
        if tc >= 4.6: return OV_BOSUNG
    if key == "pcct" and tc >= 5.6: return OV_PCCT
    return []
_cf = {}
def ctr_frame(key, path, tc):
    if key not in _cf: _cf[key] = Clip(path, (1920, 1020), (0, 0, 1912, 1016))
    fr = _cf[key].get(tc); bg = Image.new("RGB", (1920, 1080), WHITE)
    if fr is not None: bg.paste(fr, (0, 30))
    ov_draw(bg, ov_for(key, tc))
    return bg
def ctr_show(img, key, path, tc, box1, k):
    """Màn hình hợp đồng full khung, rồi phóng dần (k: 0 -> 1) vào box1."""
    k = ease(clamp(k)); box = tuple(FULLB[i] + (box1[i] - FULLB[i]) * k for i in range(4))
    img.paste(ctr_frame(key, path, tc).resize((W, H), Image.LANCZOS, box=box), (0, 0))
    return box
def CT(box, x0, y0, x1, y1):
    """Toạ độ bản quay gốc -> khung hình theo box zoom hiện tại."""
    s = 1920 / 1912; kk = 1920 / (box[2] - box[0])
    return ((x0 * s - box[0]) * kk, (y0 * s + 30 - box[1]) * kk, (x1 * s - box[0]) * kk, (y1 * s + 30 - box[1]) * kk)
F_LOAI = (632, 240, 1015, 300); F_LUONG = (1250, 438, 1470, 502); F_BH = (1250, 503, 1470, 567)
F_GIO1 = (1250, 633, 1455, 702); F_GIOT = (632, 763, 875, 832)
F_PC1 = (612, 372, 1470, 430); F_PC2 = (612, 664, 1470, 722)
F_PC1_BH = (1250, 440, 1470, 500); F_PC2_BH = (1250, 732, 1470, 792)
F_PC1_HL = (612, 440, 805, 500); F_PC1_HH = (612, 505, 805, 565)
def lerpbox(b0, b1, k):
    k = ease(clamp(k)); return tuple(b0[i] + (b1[i] - b0[i]) * k for i in range(4))
def piece(t, pts):
    if t <= pts[0][0]: return pts[0][1]
    for (a_, ca), (b_, cb) in zip(pts, pts[1:]):
        if a_ <= t <= b_: return ca + (t - a_) * (cb - ca) / (b_ - a_)
    return pts[-1][1]

# ================= Hợp đồng lao động =================
def sc_h_hd(img, d, t): sub_card(img, d, t, H_HD, "PHẦN 5", ["HỢP ĐỒNG", "LAO ĐỘNG"], 110)

def sc_hd(img, d, t):
    T_VD = c("ví dụ", 402.96)
    if t < T_VD:
        st = c("nguồn dữ", 383.88)
        box = ctr_show(img, "hd", REC_ML, 0.5, CTR_INFO, (t - st - 1.0) / 2.0)
        top_title(d, t, "Hợp đồng lao động ghi nhận", st)
        if t >= c("loại hợp", 389.26) and (t < c("mức lương chính", 390.11) or t >= c("đầu tiên", 395.84)): hl(d, CT(box, *F_LOAI), t)
        if c("mức lương chính", 390.11) <= t < c("mức đóng", 391.07): hl(d, CT(box, *F_LUONG), t)
        if c("mức đóng", 391.07) <= t < c("các khoản bổ", 392.40): hl(d, CT(box, *F_BH), t)
        if c("các khoản bổ", 392.40) <= t < c("đầu tiên", 395.84):
            chip_bar(d, t, [(c("các khoản bổ", 392.40), "Các khoản bổ sung (phụ cấp) cũng nằm trên hợp đồng", ORANGE)], size=24)
    else:
        paste(img, BOARD)
        board_title(d, t, "Loại hợp đồng làm điều kiện trong công thức", T_VD)
        for j, (w, af) in enumerate([("thử việc", 403.96), ("xác định", 407.44)]):
            x = 560 + j * 800; s_ = pop(t, c(w, af))
            card(d, x, 470, 640, 300, s_, True, BLUE if j == 0 else NAVY)
            if s_ > 0.01:
                icon(d, "doc", x, 400, s_, BLUE if j == 0 else NAVY, 56)
                text(d, (x, 500), ["Hợp đồng thử việc", "HĐLĐ xác định thời hạn 1 năm"][j], 30 * s_, INK)
                text(d, (x, 560), "Không đóng BHXH" if j == 0 else "Có đóng BHXH", 30 * s_, RED if j == 0 else GREEN, "ExtraBold")
        pill(d, W / 2, 800, 760, 76, ORANGE, "Công thức phân biệt từng trường hợp theo loại hợp đồng", 26, pop(t, c("làm điều", 413.66)))
    role_tag(img, d, CB, "C&B", pop(t, c("con cần", 385.09), 0.4))

def sc_salary(img, d, t):
    T_HD, T_BH = c("khi khai báo trên hợp", 436.53), c("nhập mức lương đóng", 462.89)
    if t < T_HD:
        paste(img, BOARD)
        board_title(d, t, "Mức lương & cơ cấu thu nhập", c("tiếp theo", 417.06))
        hcard(d, 640, 420, 760, 140, pop(t, c("năm mươi", 432.60)), BLUE, "chart", "Lương gross thỏa thuận\n50.000.000 đ / tháng", 32, True)
        hcard(d, 1300, 420, 760, 140, pop(t, c("ba mươi", 435.58)), NAVY, "shield", "Mức đóng BHXH\n30.000.000 đ", 32, True)
        role_tag(img, d, CB, "C&B")
        return
    if t < T_BH:   # nhập mức lương chính & phụ cấp
        T_PC = c("phụ cấp xăng", 446.05)
        ct = piece(t, [(T_HD, 0.2), (T_PC - 0.3, 1.2), (T_PC + 0.9, 4.6), (T_BH, 9.5)])
        if ct < 2.0: box = ctr_show(img, "ml", REC_ML, ct, CTR_INFO, (t - T_HD - 1.0) / 2.0)
        else: box = ctr_show(img, "ml", REC_ML, ct, lerpbox(CTR_INFO, CTR_BOSUNG, (ct - 2.0) / 2.6), 1.0)
        top_title(d, t, "Khai báo mức lương & phụ cấp trên Hợp đồng lao động", T_HD)
        if ct < 2.0 and t >= c("mức lương chính", 443.84): hl(d, CT(box, *F_LUONG), t)
        if ct >= 4.6:
            if t < c("phụ cấp trách", 447.85): hl(d, CT(box, *F_PC1), t)
            else: hl(d, CT(box, *F_PC1), t); hl(d, CT(box, *F_PC2), t)
        # thanh cơ cấu thu nhập theo ví dụ
        x0, y, wt = 300, 905, 1320
        k0 = pop(t, c("mức lương chính", 443.84))
        if k0 > 0.01: d.rounded_rectangle([x0 - 30, y - 30, x0 + wt + 270, y + 140], 24, fill=WHITE, outline=LINE, width=3)
        parts = [(c("mức lương chính", 443.84), "Lương chính 30tr", 30, BLUE), (c("phụ cấp xăng", 446.05), "PC xăng 10tr", 10, CYAN),
                 (c("phụ cấp trách", 447.85), "PC trách nhiệm 10tr", 10, ORANGE)]
        x = x0
        for st, lab, v, col in parts:
            k = p(t, st, 0.5); w = wt * v / 50
            if k > 0:
                d.rounded_rectangle([x, y, x + w * k, y + 80], 14, fill=col)
                if k > 0.9: text(d, (x + w / 2, y + 40), lab, fit_size(d, lab, 24, "ExtraBold", w - 16), WHITE)
            x += w
        kk = pop(t, c("tổng các", 450.09))
        if kk > 0.01:
            text(d, (x0 + wt + 130, y + 40), "= 50tr", 34 * max(kk, 0.3), INK)
            badge2(d, x0 + wt + 230, y + 40, True, pop(t, c("khớp với", 458.35)), 26)
    else:          # nhập mức đóng bảo hiểm
        T_PCBH = c("đối với các", 466.33)
        ct = piece(t, [(T_BH, 0.3), (T_PCBH - 0.4, 1.8), (T_PCBH + 0.8, 4.6), (T_PCBH + 9.0, 8.5)])
        if ct < 2.0: box = ctr_show(img, "bh", REC_BH, ct, CTR_INFO, (t - T_BH) / 1.2)
        else: box = ctr_show(img, "bh", REC_BH, ct, lerpbox(CTR_INFO, CTR_BOSUNG, (ct - 2.0) / 2.6), 1.0)
        top_title(d, t, "Khai báo mức đóng bảo hiểm", T_BH)
        if ct < 2.0 and t >= T_BH + 1.0: hl(d, CT(box, *F_BH), t)
        if ct >= 4.6: hl(d, CT(box, *F_PC1_BH), t); hl(d, CT(box, *F_PC2_BH), t)
        chip_bar(d, t, [(c("hệ thống ghi", 469.57), "Hệ thống ghi nhận đúng căn cứ đóng bảo hiểm khi tính lương tự động", NAVY)], size=24)
    role_tag(img, d, CB, "C&B")

def sc_allow(img, d, t):
    T_SCR = c("thì con", 498.00)
    if t >= T_SCR:
        ct = min(9.4, 5.8 + (t - T_SCR) * 0.8)
        box = ctr_show(img, "pcct", REC_PCCT, ct, CTR_PC3, (t - T_SCR - 0.4) / 1.6)
        top_title(d, t, "Khai báo phụ cấp có thời hạn", T_SCR)
        if t < c("ngày có hiệu", 500): hl(d, CT(box, *F_PC3), t)                                   # Phụ cấp công tác
        elif t < c("ngày hết hạn", 502.2): hl(d, CT(box, *F_PC3_HL), t)                             # Ngày có hiệu lực
        else: hl(d, CT(box, *F_PC3_HL), t); hl(d, CT(box, *F_PC3_HH), t)                          # + Ngày hết hạn
        chip_bar(d, t, [(c("hệ thống chỉ", 505), "Hệ thống chỉ ghi nhận phụ cấp trong khoảng thời gian đã khai báo", NAVY)], size=24)
        role_tag(img, d, CB, "C&B")
        return
    paste(img, BOARD)
    board_title(d, t, "Phụ cấp áp dụng trong một khoảng thời gian", c("ngoài các", 474.88))
    x0, cw, y = 260, 118, 560
    for i in range(12):
        x = x0 + i * cw
        d.rounded_rectangle([x + 4, y, x + cw - 4, y + 70], 12, fill=(238, 242, 252))
        text(d, (x + cw / 2, y + 35), f"T{i + 1}", 28, GREY)
    hcard(d, 560, 330, 640, 120, pop(t, c("phụ cấp công", 485.94)), ORANGE, "chart", "Phụ cấp công tác\n(cử đi công tác 2 tháng)", 26, True)
    k = p(t, c("từ ngày một", 494.90), 1.0)
    if k > 0:
        xa, xb = x0 + 5 * cw + 4, x0 + 7 * cw - 4
        d.rounded_rectangle([xa, y - 70, xa + (xb - xa) * k, y - 20], 25, fill=ORANGE)
    pill(d, x0 + 5 * cw, y + 130, 300, 64, GREEN, "Từ 01/06", 26, pop(t, c("từ ngày một", 494.90)))
    pill(d, x0 + 7 * cw, y + 210, 300, 64, RED, "Đến 31/07", 26, pop(t, c("ba mốt", 497)))
    role_tag(img, d, CB, "C&B", pop(t, c("cb nhập", 489.48), 0.4))

def week_row(d, x0, y, days, offs, cw=150, k=1.0):
    for i, dn in enumerate(days):
        x = x0 + i * cw; off = i in offs
        d.rounded_rectangle([x + 6, y, x + cw - 6, y + 90], 16, fill=(255, 228, 228) if off else (215, 245, 225),
                            outline=RED if off else GREEN, width=3)
        text(d, (x + cw / 2, y + 45), dn, 30, RED if off else GREEN)

DAYS = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]
def sc_std(img, d, t):
    paste(img, BOARD)
    T_LINH = c("trong thực", 541.88); T_VDG = c("ví dụ", 517.80)
    if t < T_VDG:
        st = 510.90
        box = ctr_show(img, "gio", REC_ML, 0.5, CTR_INFO, (t - st - 0.6) / 1.8)
        top_title(d, t, "Giờ công chuẩn một ngày & giờ công tối thiểu một tuần", st)
        if t >= st + 2.4: hl(d, CT(box, *F_GIO1), t); hl(d, CT(box, *F_GIOT), t)
        chip_bar(d, t, [(c("số ngày công", 515.90), "Dùng để xác định số ngày công chuẩn của kỳ lương", NAVY)], size=24)
        role_tag(img, d, CB, "C&B")
        return
    if t < T_LINH:
        board_title(d, t, "Giờ công chuẩn một ngày & giờ công tối thiểu một tuần", c("giờ công chuẩn", 510.53), size=50)
        pill(d, W / 2, 200, 900, 70, NAVY, "Hệ thống dùng để xác định số ngày công chuẩn của kỳ lương", 26, pop(t, c("số ngày công", 515.90)))
        s1 = pop(t, c("năm ngày", 519.63))
        if s1 > 0.01:
            text(d, (230, 360), "5 ngày/tuần", 32, INK, anchor="lm")
            week_row(d, 470, 315, DAYS, {5, 6})
            pill(d, 1700, 360, 320, 70, BLUE, "8 giờ/ngày · 40 giờ/tuần", 24, pop(t, c("tám giờ", 523.87)))
        s2 = pop(t, c("sáu ngày", 528.06))
        if s2 > 0.01:
            text(d, (230, 500), "6 ngày/tuần", 32, INK, anchor="lm")
            week_row(d, 470, 455, DAYS, {6})
            pill(d, 1700, 500, 320, 70, BLUE, "8 giờ/ngày · 48 giờ/tuần", 24, pop(t, c("tám giờ", 531.83)))
        s3 = pop(t, c("ưu tiên", 538.91))
        if s3 > 0.01:
            hcard(d, W / 2, 720, 1080, 130, s3, ORANGE, "calendar", "Xác định ngày nghỉ tuần theo giờ công tối thiểu:\nưu tiên loại Chủ nhật trước, rồi mới đến thứ Bảy", 26, True)
    else:
        board_title(d, t, "Khối cửa hàng: ngày nghỉ tuần linh hoạt", T_LINH)
        week_row(d, 435, 360, DAYS, {(int(t * 0.8)) % 7})
        pill(d, W / 2, 560, 700, 76, ORANGE, "Ngày nghỉ có thể rơi vào bất kỳ ngày nào", 28, pop(t, c("bất kỳ", 547.79)))
    role_tag(img, d, CB, "C&B", pop(t, c("cnb có", 522.27), 0.4))

def sc_std26(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Công chuẩn cố định 26 công cho khối cửa hàng", c("trường hợp này", 551.6))
    hcard(d, W / 2, 250, 1200, 120, pop(t, c("thay vì", 560)), ORANGE, "db", "Thay vì dùng TPL Công chuẩn kỳ lương (lấy từ giờ công chuẩn & giờ công tối thiểu)", 26, True)
    s_ = pop(t, c("xây dựng công", 566.7))
    if s_ > 0.01:
        card(d, W / 2, 440, 1200, 200, s_, True, BLUE)
        icon(d, "fx", W / 2 - 520 * s_, 440, s_, BLUE, 56)
        text(d, (W / 2 + 40, 405), "Công thức lương:", 28 * s_, GREY, "Bold")
        k2 = pop(t, c("nếu là", 567.8))
        if k2 > 0.01: text(d, (W / 2 + 40, 460), "Nếu là khối cửa hàng → Công chuẩn = 26, ngược lại = 0", 30 * k2, INK)
    hcard(d, W / 2, 640, 1200, 120, pop(t, c("khi đó", 573.5)), GREEN, "check", "Công chuẩn khối cửa hàng = 26 công theo điều kiện trong công thức lương", 26, True)
    hcard(d, W / 2, 820, 1200, 150, pop(t, c("trên hợp đồng giờ", 580.2)), NAVY, "doc",
          "Trên hợp đồng: giờ công chuẩn & giờ công tối thiểu vẫn khai báo theo lịch thực tế,\nnhưng không dùng để xác định công chuẩn khối cửa hàng", 24, True)
    role_tag(img, d, CB, "C&B", pop(t, c("con thiết", 557), 0.4))

SCENES_ADD = [(H_PREP, 156.98, "h_prep"), (156.98, 167.78, "prep3"), (167.78, 179.30, "prep_excel"), (179.30, 207.25, "prep_policy"),
              (207.25, H_HSNV, "prep_data"), (H_HSNV, 232.76, "h_hsnv"), (232.76, 319.87, "hsnv"), (319.87, 330.98, "npt"),
              (330.98, 365.93, "npt_ex"), (365.93, H_HD, "cert"), (H_HD, 385.12, "h_hd"), (385.12, 417.31, "hd"),
              (417.31, 474.71, "salary"), (474.71, 510.83, "allow"), (510.83, 551.49, "std"), (551.49, 999, "std26")]
FN_ADD = dict(h_prep=sc_h_prep, prep3=sc_prep3, prep_excel=sc_prep_excel, prep_policy=sc_prep_policy, prep_data=sc_prep_data,
              h_hsnv=sc_h_hsnv, hsnv=sc_hsnv, npt=sc_npt, npt_ex=sc_npt_ex, cert=sc_cert, h_hd=sc_h_hd, hd=sc_hd,
              salary=sc_salary, allow=sc_allow, std=sc_std, std26=sc_std26)
