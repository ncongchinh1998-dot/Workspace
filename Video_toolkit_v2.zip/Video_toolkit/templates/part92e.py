"""PHẦN 9.2 (voice 04/11/2026) — giữ cảnh part92c (đã có ví dụ 8/8 = 1 công, 4/8 = 0,5 công),
ánh xạ voice_p92e → voice 04/11; cắt thêm 1 chữ "ngày" còn lặp trong "số ngày ngày lễ" (≈2:16)."""
import sys, math, json
from hw_core import *
from remap_voice import make_maps
import part92c as C

M2, M2inv = make_maps(A + "words_p92e.json", A + "words_p92g.json")
CUTS = json.load(open(A + "cuts_p92h.json"))
def G(t):
    sh = 0
    for s, e in CUTS:
        if t >= e: sh += e - s
        elif t > s: return s - sh
    return t - sh
def Ginv(t):
    for s, e in CUTS:
        if t >= G(s): t += e - s
    return t
VOICE = A + "voice_p92h.wav"
OFFSET = 1.0
VOICE_DUR = 303.04
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = C.OUT
SFX_AT = [0.0]
hl = C.hl
SCENES = [(s if s < 0 else G(M2(s)), 999 if e >= 999 else G(M2(e)), n) for s, e, n in C.SCENES]
FN = {n: (lambda f: (lambda img, d, t: f(img, d, M2inv(Ginv(t)) if t >= 0 else t)))(C.FN[n]) for _, _, n in SCENES}

def preview(times, out="/tmp/pv92e"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 11
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p92e_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p92e_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
