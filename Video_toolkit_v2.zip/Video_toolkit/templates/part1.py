"""PHẦN 1 — BÀI TOÁN THỰC TẾ: VÌ SAO DOANH NGHIỆP CẦN TỰ ĐỘNG HÓA TÍNH LƯƠNG
Mốc thời gian (giây, theo voice) lấy từ khoảng lặng của file voice Phần 1."""
import sys, math
from hw_core import *
from cues import Cues
c = Cues(A + "words_p1.json")

VOICE = A + "voice_p1.wav"          # voice mới (đã đọc lại)
OFFSET = 1.5                      # slide tiêu đề phần (có âm thanh chuyển phần ngay giây đầu)
SFX_AT = [0.0]                    # âm thanh mẫu: bắt đầu phần mới
VOICE_DUR = 170.49
TOTAL = OFFSET + VOICE_DUR + 0.8
OUT = "/mnt/user-data/outputs/Phan1_Bai_toan_thuc_te.mp4"

# ================= Scenes =================
def sc_part(img, d, t):
    paste(img, SECTION)
    a = p(t, -1.45, 0.5)
    pill(d, 250, 250, 280, 84, BLUE, "PHẦN 1", 40, pop(t, -1.45), weight="ExtraBold")
    for j, line in enumerate(["BÀI TOÁN", "THỰC TẾ"]):
        k = p(t, -1.3 + j * 0.15, 0.5)
        if k > 0: text(d, (110, 400 + j * 140 + (1 - k) * 60), line, 120, NAVY, anchor="lm", align="left")
    underline(d, 115, 640, 760, p(t, -0.9, 0.6))
    k = p(t, -0.75, 0.5)
    if k > 0: text(d, (110, 730 + (1 - k) * 30), "Vì sao doanh nghiệp cần\ntự động hóa tính lương?", 46, NAVY, "Bold", anchor="lm", align="left")
    for j, (idx, lab) in enumerate([(CEO, "Giám đốc\nđiều hành"), (HR_LEAD, "Trưởng phòng\nnhân sự"), (EMP, "Nhân viên")]):
        person(img, d, idx, 900 + j * 210, 860, 250, pop(t, -1.0 + j * 0.15, 0.5), lab, 28)

def sc_title(img, d, t):
    paste(img, SECTION)
    section_title(d, t, c("trong video"), "QUY TRÌNH", ["TÍNH LƯƠNG", "TỰ ĐỘNG"], 128)
    pill(d, 330, 760, 400, 100, NAVY, "C&B", 48, pop(t, c("cnb")))
    person(img, d, CB, 1210, 930, 380, pop(t, c("thiết lập"), 0.55), "C&B")
    sparks(d, 1020, 690, -1, p(t, c("thiết lập", shift=0.25), 0.3), t); sparks(d, 1400, 690, 1, p(t, c("thiết lập", shift=0.25), 0.3), t)

def sc_mock(img, d, t, label="Tính lương tự động", start=None, show_logo=True):
    start = c("harw", shift=-0.45) if start is None else start
    i = max(0, min(int((t - start) * FPS), len(MOCK) - 1))
    img.paste(MOCK[i], (0, 0)); d = ImageDraw.Draw(img)
    x0, y0, x1, y1 = SCREEN; cx = (x0 + x1) / 2
    s = pop(t, start + 0.4, 0.6)
    if s > 0.01 and show_logo:
        lw, lh = int(LOGO_IMG.width * 1.9 * s), int(LOGO_IMG.height * 1.9 * s)
        lg = LOGO_IMG.resize((max(lw, 1), max(lh, 1)), Image.LANCZOS)
        img.paste(lg, (int(cx - lw / 2), int(430 - lh / 2)), lg)
    k = p(t, start + 0.8, 0.5)
    if k > 0:
        text(d, (cx, 600 + (1 - k) * 30), label, 56, NAVY)
        underline(d, cx - 220, 670, 440, p(t, start + 1.1, 0.5))

def sc_steps(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Quy trình 4 bước", c("từ chuẩn", shift=-0.1))
    st = [c("chuẩn bị"), c("xây dựng"), c("chạy lương"), c("kiểm tra", 12)]
    labels = ["Chuẩn bị\ndữ liệu", "Xây dựng quy tắc\nbảng lương", "Chạy lương", "Kiểm tra\nkết quả"]
    kinds = ["db", "logic", "run", "check"]; cols = [BLUE, NAVY, ORANGE, CYAN]
    cw, gap = 340, 80; x0 = (W - (4 * cw + 3 * gap)) / 2 + cw / 2; cy = 560
    for i in range(4):
        cx = x0 + i * (cw + gap)
        if i < 3: arrow(d, cx + cw / 2 + 14, cy, cx + cw / 2 + gap - 14, cy, p(t, st[i + 1] - 0.25, 0.3))
        s = pop(t, st[i]); active = st[i] <= t < (st[i + 1] if i < 3 else 99)
        vcard(d, cx, cy, cw, 400, s, cols[i], kinds[i], labels[i], 34, active, f"0{i + 1}")
        if active and s > 0.5:
            sparks(d, cx - cw / 2 - 6, cy - 160, -1, p(t, st[i] + 0.2, 0.3), t, 0.8)
            sparks(d, cx + cw / 2 + 6, cy - 160, 1, p(t, st[i] + 0.2, 0.3), t, 0.8)

def sc_problem(img, d, t):
    paste(img, SECTION)
    k = p(t, c("trước khi", 14), 0.5); out = p(t, c("bài toán", shift=-0.45), 0.5)
    if k > 0 and out < 1:
        for i, (kind, col) in enumerate(zip(["db", "logic", "run", "check"], [BLUE, NAVY, ORANGE, CYAN])):
            x = 200 + i * 230 - out * 1500
            if i < 3: d.line([x + 75, 420, x + 155, 420], fill=ORANGE, width=5)
            icon(d, kind, x, 420, 0.9 * pop(t, c("từng bước") + i * 0.12), col)
        text(d, (130 - out * 1500, 560), "Từng bước thiết lập", 48, NAVY, anchor="lm", align="left")
    a = p(t, c("bài toán"), 0.5)
    if a > 0:
        text(d, (110, 330 + (1 - a) * 60), "BÀI TOÁN", 130, NAVY, anchor="lm", align="left")
        text(d, (110, 490 + (1 - a) * 60), "THỰC TẾ", 130, NAVY, anchor="lm", align="left")
        underline(d, 115, 600, 700, p(t, c("thực tế", 17), 0.6))
    s = pop(t, c("mà con"), 0.55)
    person(img, d, CB, 1180, 900, 420, s, "C&B")
    for j, (qx, qy) in enumerate([(990, 470), (1380, 440)]):
        q = pop(t, c("thường gặp") + j * 0.3, 0.5)
        icon(d, "q", qx, qy + 10 * math.sin(t * 3 + j), q, ORANGE if j else BLUE, 60)
    sparks(d, 1000, 650, -1, p(t, c("thường gặp"), 0.3), t); sparks(d, 1360, 650, 1, p(t, c("thường gặp"), 0.3), t)

CX, CY = W / 2, 600
def hub(d, t, start, label="Bảng\nlương", col=NAVY, cx=CX, cy=CY, r0=140, pulse_at=None, fs=48):
    s = pop(t, start, 0.6)
    if s <= 0.01: return
    r = r0 * s * (1 + (0.04 * math.sin(t * 6) * p(t, pulse_at, 0.4) if pulse_at else 0))
    d.ellipse([cx - r + 6, cy - r + 10, cx + r + 6, cy + r + 10], fill=SHADOW)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=col)
    text(d, (cx, cy), label, fs * s, WHITE)

def sc_reality(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Trong thực tế…", c("trong thực tế", 21, -0.4))
    hub(d, t, c("tính lương hiếm"))
    s = pop(t, c("bắt đầu", 24), 0.5)
    if s > 0.01:
        bx = CX - 560
        card(d, bx, CY, 420, 130, s, True, BLUE)
        text(d, (bx, CY), "1 nguồn dữ liệu", 38 * s, INK, "Bold")
        arrow(d, bx + 220, CY, bx + 410, CY, p(t, c("bắt đầu", 24, 0.3), 0.5), BLUE, 8, False)
        x, x2 = p(t, c("một nguồn", 24), 0.3), p(t, c("một nguồn", 24, 0.2), 0.3)
        if x > 0: d.line([bx - 230, CY - 85, bx - 230 + 460 * x, CY - 85 + 170 * x], fill=RED, width=14)
        if x2 > 0: d.line([bx - 230, CY + 85, bx - 230 + 460 * x2, CY + 85 - 170 * x2], fill=RED, width=14)
        if x > 0: text(d, (bx, CY + 160), "Hiếm khi đủ!", 42, RED)

SRC = ["Công", "Phép", "Làm thêm", "Mức lương", "Phụ cấp", "Thưởng", "Khấu trừ", "Chính sách"]
SRC_T = [c("công phép"), c("phép làm"), c("làm thêm", 28), c("mức lương", 29), c("phụ cấp", 30), c("thưởng", 30.5), c("trừ", 31, -0.35), c("chính sách", 32)]
SRC_COL = [BLUE, CYAN, ORANGE, NAVY, BLUE, CYAN, ORANGE, NAVY]
def src_pos(i):
    a = -math.pi / 2 + i * 2 * math.pi / 8
    return CX + 640 * math.cos(a), CY + 290 * math.sin(a)

def sc_sources(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "C&B tổng hợp nhiều nguồn dữ liệu", c("p phải", shift=-0.4))
    for i in range(8):
        px, py = src_pos(i); k = p(t, SRC_T[i] + 0.15, 0.5)
        if k > 0:
            d.line([px, py, px + (CX - px) * 0.8 * k, py + (CY - py) * 0.8 * k], fill=SRC_COL[i], width=6)
            if k >= 1:
                f = (t * 0.9 + i * 0.17) % 1
                dx, dy = px + (CX - px) * 0.8 * f, py + (CY - py) * 0.8 * f
                d.ellipse([dx - 10, dy - 10, dx + 10, dy + 10], fill=ORANGE if SRC_COL[i] != ORANGE else NAVY)
    hub(d, t, c("p phải", shift=-0.2), pulse_at=c("nhóm nhân sự"))
    for i in range(8):
        px, py = src_pos(i)
        pill(d, px, py, 300 if i == 7 else 280, 96, SRC_COL[i], SRC[i], 36, pop(t, SRC_T[i]))
    px, py = src_pos(7)
    gs = pop(t, c("nhóm nhân sự"), 0.5)
    for j, idx in enumerate([STAFF, EMP, CEO]):
        char(img, idx, 190 + j * 115, 270, 125, pop(t, c("nhóm nhân sự") + j * 0.15, 0.5))
    if gs > 0.01: text(d, (305, 285), "Từng nhóm nhân sự", 26 * max(gs, 0.3), INK, anchor="ma")
    sparks(d, 100, 210, -1, p(t, c("nhân sự", 34), 0.3), t, 0.6); sparks(d, 510, 210, 1, p(t, c("nhân sự", 34), 0.3), t, 0.6)

def sc_excel(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Khi quy trình phụ thuộc nhiều vào Excel", c("khi quy trình", 34))
    # Excel badge + nhiều file
    for j in range(3):
        s = pop(t, c("xo") + j * 0.15, 0.5)
        x = 820 + j * 110
        if s > 0.01:
            card(d, x, 260, 150, 120, s, True, GREEN)
            icon(d, "sheet", x, 260, s * 0.75, GREEN)
    k = p(t, c("xo", shift=0.5), 0.4)
    if k > 0: text(d, (1210, 260), ".xlsx", 40, mix_color(GREEN, k), "Bold", anchor="lm")
    st = [c("gom"), c("xử lý", 40), c("kiểm tra công", 41), c("đối trước"), c("chót lương", 43)]
    labels = ["Gom dữ liệu\nnhiều nguồn", "Xử lý qua\nnhiều sheet", "Kiểm tra\ncông thức", "Đối soát", "Chốt lương"]
    kinds = ["funnel", "tabs", "fx", "compare", "lock"]; cols = [BLUE, GREEN, ORANGE, CYAN, NAVY]
    cw, gap = 290, 50; x0 = (W - (5 * cw + 4 * gap)) / 2 + cw / 2; cy = 560
    for i in range(5):
        cx = x0 + i * (cw + gap)
        if i < 4: arrow(d, cx + cw / 2 + 8, cy, cx + cw / 2 + gap - 8, cy, p(t, st[i + 1] - 0.2, 0.25))
        active = st[i] <= t < (st[i + 1] if i < 4 else 99)
        vcard(d, cx, cy, cw, 300, pop(t, st[i]), cols[i], kinds[i], labels[i], 30, active)
    s = pop(t, c("con phải", 37), 0.55)
    person(img, d, CB, x0, 990, 230, s, "C&B", 28)

def mix_color(c, a, base=(225, 232, 248)):
    a = clamp(a); return tuple(int(c[i] * a + base[i] * (1 - a)) for i in range(3))

def sc_scale(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Khi quy mô nhân sự tăng", c("khi quy mô", shift=0.25))
    base_y = 860; labels = ["Nhân sự", "Dữ liệu", "Phép tính", "Trường hợp\ncần kiểm tra"]
    st = [c("nhân sự tăng"), c("dữ liệu phép"), c("phép tính", 48), c("trường hợp", 49)]; cols = [BLUE, CYAN, ORANGE, NAVY]
    d.line([150, base_y, 1080, base_y], fill=GREY, width=4)
    for i in range(4):
        x = 270 + i * 230; g = p(t, st[i], 1.2); hh = (180 + i * 110) * g * (1 + 0.03 * math.sin(t * 3 + i))
        if g > 0:
            d.rounded_rectangle([x - 70, base_y - hh, x + 70, base_y], 16, fill=cols[i])
            text(d, (x, base_y + 55), labels[i], 28, INK, "Bold")
            icon(d, "up", x, base_y - hh - 55, pop(t, st[i] + 0.8, 0.4), cols[i], 34)
    s = pop(t, c("thời gian chót"), 0.55)
    if s > 0.01:
        card(d, 1470, 520, 600, 420, s, True, RED)
        icon(d, "calendar", 1470, 420 - (1 - s) * 20, s, RED)
        text(d, (1470, 560), "Thời gian chạy lương\n& thưởng", 36 * s, INK, "Bold")
    e = pop(t, c("không thay đổi", 54), 0.5)
    pill(d, 1470, 670, 300, 80, RED, "Không đổi", 34, e)

def sc_pressure(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Áp lực dồn lên C&B", 55.8)
    cx = W / 2
    shake = 6 * math.sin(t * 40) * sum(p(t, x, 0.2) - p(t, x + 0.45, 0.2) for x in (c("áp lực", 60), c("quá tải"), c("chậm tiến")))
    s = pop(t, 55.8, 0.55)
    person(img, d, CB, cx, 900, 400, s, "C&B", dx=shake)
    # khối lượng công việc: chồng tài liệu tăng dần
    n = int(clamp((t - c("khối lượng")) / 1.6) * 7)
    for i in range(n):
        x, y = 560, 830 - i * 46
        d.rounded_rectangle([x - 120, y - 20, x + 120, y + 20], 8, fill=WHITE, outline=BLUE, width=4)
        d.line([x - 90, y, x + 60, y], fill=LINE, width=6)
    if n:
        text(d, (540, 300), "Khối lượng\ncông việc", 38, NAVY, "ExtraBold")
        icon(d, "up", 690, 300, pop(t, c("lớn hơn", 58), 0.4), BLUE, 30)
    k = pop(t, c("cùng một khoảng"), 0.5)
    if k > 0.01:
        icon(d, "clock", 1360, 330, k, ORANGE, 80)
        ang = t * 6; d.line([1360, 330, 1360 + 50 * math.cos(ang), 330 + 50 * math.sin(ang)], fill=ORANGE, width=6)
        text(d, (1360, 450), "Cùng một khoảng thời gian", 32 * k, INK, "Bold")
    tags = [(c("áp lực", 60), "Áp lực đối soát tăng", 1360, 560), (c("quá tải"), "Quá tải", 1290, 680), (c("chậm tiến"), "Chậm tiến độ", 1450, 790), (c("sai sót", 64), "Sai sót", 1270, 900)]
    for st_, lab, x, y in tags:
        pill(d, x, y, 40 + len(lab) * 22, 84, RED, lab, 34, pop(t, st_))

def sc_risk(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Rủi ro tăng theo độ phức tạp bảng tính", c("rủi ro", shift=0.2))
    gx, gy, cw, ch, cols_, rows = 170, 260, 130, 72, 6, 7
    g = p(t, 67.4, 2.0)
    for r in range(rows):
        for cc in range(cols_):
            k = clamp(g * (rows * cols_) - (r * cols_ + cc))
            if k <= 0: continue
            x, y = gx + cc * cw, gy + r * ch
            hdr = r == 0
            d.rectangle([x, y, x + cw, y + ch], fill=GREEN if hdr else WHITE, outline=(190, 200, 225), width=2)
            if not hdr: d.line([x + 20, y + ch / 2, x + 20 + (cw - 50) * k * ((r * 7 + cc * 3) % 5 + 3) / 7, y + ch / 2], fill=LINE, width=8)
    # công thức chằng chịt
    lk = p(t, c("phức tạp"), 1.2)
    if lk > 0:
        links = [((1, 1), (4, 3)), ((2, 0), (5, 4)), ((1, 4), (6, 2)), ((3, 2), (6, 5)), ((2, 5), (5, 1))]
        for (r1, c1), (r2, c2) in links:
            x1, y1 = gx + c1 * cw + cw / 2, gy + r1 * ch + ch / 2; x2, y2 = gx + c2 * cw + cw / 2, gy + r2 * ch + ch / 2
            arrow(d, x1, y1, x2, y2, lk, (150, 160, 200), 3, False)
    def cell(r, col_i, col, label, s):
        if s <= 0.01: return
        x, y = gx + col_i * cw, gy + r * ch
        d.rectangle([x, y, x + cw, y + ch], fill=(255, 228, 228), outline=col, width=6)
        text(d, (x + cw / 2, y + ch / 2), label, 30 * max(s, 0.3), col)
    cell(2, 1, RED, "sai", pop(t, c("dữ liệu đầu", 70))); pill(d, gx + 1.5 * cw, gy - 50, 270, 64, RED, "Dữ liệu sai", 28, pop(t, c("sai hoặc", 71)))
    cell(4, 3, RED, "fx", pop(t, c("công thức chưa"))); pill(d, gx + 3.5 * cw + 150, gy - 50, 330, 64, RED, "Công thức chưa đúng", 28, pop(t, c("chưa đúng")))
    # ảnh hưởng tới kết quả lương
    rs = pop(t, c("kết quả lương", 74), 0.5)
    if rs > 0.01:
        x, y = gx + 5 * cw, gy + 6 * ch
        arrow(d, gx + 3.5 * cw, gy + 4.5 * ch, x + cw / 2, y, p(t, c("ảnh hưởng", 73), 0.6), RED, 5)
        d.rectangle([x, y, x + cw, y + ch], fill=RED)
        icon(d, "warn", x + cw / 2, y + ch / 2, rs, RED, 28)
        text(d, (gx + 3 * cw, gy + rows * ch + 50), "Kết quả lương bị ảnh hưởng", 34 * rs, RED)
    # vòng lặp xử lý thủ công
    lx, ly, R = 1460, 590, 230
    ls = pop(t, c("quay lại", 76, -0.3), 0.5)
    if ls > 0.01:
        d.ellipse([lx - R, ly - R, lx + R, ly + R], outline=ORANGE, width=6)
        a = t * 1.6
        hx, hy = lx + R * math.cos(a), ly + R * math.sin(a)
        d.ellipse([hx - 14, hy - 14, hx + 14, hy + 14], fill=ORANGE)
        person(img, d, CB, lx, ly + 80, 170, ls, "C&B", 26)
    nodes = [(c("tìm nguyên", 77), "Tìm nguyên nhân", "search", -90), (c("đối chiếu", 78), "Đối chiếu", "compare", 30), (c("điều chỉnh", 79), "Điều chỉnh\nthủ công", "edit", 150)]
    for st_, lab, kind, deg in nodes:
        s = pop(t, st_); a = math.radians(deg)
        x, y = lx + R * math.cos(a), ly + R * math.sin(a)
        icon(d, kind, x, y, s, NAVY, 52)
        if s > 0.01: text(d, (x + (0 if deg == -90 else (130 if deg == 30 else -130)), y + (-90 if deg == -90 else 80)), lab, 28 * s, INK, "Bold")

def sc_hr(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Với Trưởng phòng & Giám đốc nhân sự", c("trưởng phòng", shift=-0.25))
    s = pop(t, c("trưởng phòng"), 0.55)
    person(img, d, HR_LEAD, 380, 880, 410, s, "Trưởng phòng /\nGiám đốc nhân sự")
    sparks(d, 190, 600, -1, p(t, c("giám đốc nhân", 82), 0.3), t); sparks(d, 570, 600, 1, p(t, c("giám đốc nhân", 82), 0.3), t)
    # không chỉ là thời gian
    a = pop(t, c("thời gian cnb"), 0.5); out = p(t, c("điều cần", shift=-0.2), 0.4)
    if a > 0.01 and out < 1:
        y = 560 - out * 40
        hcard(d, 1150, y, 760, 150, a * (1 - out), ORANGE, "clock", "Thời gian C&B dành\ncho kỳ lương", 36)
        if out < 0.5: pill(d, 1150, y - 130, 360, 70, NAVY, "Không chỉ là…", 30, pop(t, c("thời gian cnb", shift=0.3)))
    qs = [(c("dữ liệu đang", 88), "Dữ liệu đến từ đâu?", "db", BLUE), (c("logic tính"), "Quy tắc tính nằm ở đâu?", "logic", NAVY),
          (c("ai đang"), "Ai đang phụ trách?", "people", ORANGE), (c("chính sách thay"), "Chính sách thay đổi:\ncập nhật nhất quán?", "shield", CYAN)]
    for i, (st_, lab, kind, col) in enumerate(qs):
        x = 960 + (i % 2) * 560; y = 420 + (i // 2) * 300
        active = st_ <= t < (qs[i + 1][0] if i < 3 else 99)
        hcard(d, x, y, 520, 220, pop(t, st_), col, kind, lab, 30, active)

def sc_ceo1(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Với Giám đốc điều hành", c("giám đốc điều", 98, -0.2))
    s = pop(t, c("giám đốc điều", 98), 0.55)
    person(img, d, CEO, 380, 880, 410, s, "Giám đốc\nđiều hành")
    # biểu đồ chi phí nhân sự theo đơn vị & kỳ lương
    k = pop(t, c("theo dõi chi", 101), 0.5)
    if k > 0.01:
        card(d, 1180, 560, 1100, 640, k, False, BLUE)
        text(d, (1180, 290), "Chi phí nhân sự", 40 * k, NAVY)
    bx0, by = 780, 790
    if k > 0.9:
        d.line([bx0, by, 1600, by], fill=GREY, width=3)
        units = ["Đơn vị A", "Đơn vị B", "Đơn vị C"]
        vals = [(260, 300), (190, 230), (330, 360)]
        for u in range(3):
            ux = bx0 + 140 + u * 270
            for sidx, (st_, col) in enumerate([(c("chi phí nhân", 101), BLUE), (c("kỳ lương", 104), ORANGE)]):
                g = p(t, st_ + u * 0.15, 0.8)
                hh = vals[u][sidx] * g
                if g > 0: d.rounded_rectangle([ux - 60 + sidx * 70, by - hh, ux + 0 + sidx * 70, by], 10, fill=col)
            kk = p(t, c("đơn vị", 103) + u * 0.2, 0.3)
            if kk > 0: text(d, (ux + 5, by + 40), units[u], 28, mix_color(INK, kk), "Bold")
        for sidx, (st_, col, lab) in enumerate([(c("chi phí nhân", 101), BLUE, "Kỳ lương trước"), (c("kỳ lương", 104), ORANGE, "Kỳ lương này")]):
            kk = p(t, st_, 0.3)
            if kk > 0:
                lx = 880 + sidx * 360
                d.rounded_rectangle([lx, 340, lx + 30, 370], 6, fill=col)
                text(d, (lx + 45, 355), lab, 26, mix_color(INK, kk), "Bold", anchor="lm")

def sc_ceo2(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Cần một góc nhìn tổng thể", c("khi dữ liệu", 105))
    person(img, d, CEO, 260, 920, 270, 1.0, "Giám đốc\nđiều hành", 28)
    # Luồng thủ công: tài liệu → Nhân sự (tắc) → góc nhìn tổng thể
    out = p(t, c("nguồn dữ liệu", 115, -0.5), 0.5)
    if out < 1:
        y = 430 - out * 20; al = 1 - out
        s1 = pop(t, c("tổng hợp thủ")) * al
        for j in range(3):
            if s1 > 0.01:
                x = 330 + j * 40; yy = y - 40 + j * 30
                d.rounded_rectangle([x - 70 * s1, yy - 45 * s1, x + 70 * s1, yy + 45 * s1], 10, fill=WHITE, outline=GREEN, width=4)
        if s1 > 0.01: text(d, (370, y + 110), "Tổng hợp thủ công", 30 * s1, INK, "Bold")
        arrow(d, 480, y, 720, y, p(t, c("quá trình tổng", 110, -0.4), 0.5) * al)
        s2 = pop(t, c("quá trình tổng", 110)) * al
        if s2 > 0.01:
            hcard(d, 980, y, 460, 150, s2, ORANGE, "hourglass", "Tổng hợp & đối\nchiếu của Nhân sự", 28, True)
        arrow(d, 1220, y, 1430, y, p(t, c("đối chiếu", 112), 0.5) * al)
        s3 = pop(t, c("góc nhìn", 108)) * al
        if s3 > 0.01: hcard(d, 1640, y, 400, 150, s3, BLUE, "search", "Góc nhìn\ntổng thể", 30)
        if s2 > 0.5:
            for j in range(3):
                ph = (t * 2 + j * 0.33) % 1
                d.ellipse([740 + ph * 0 - 6, y - 6 + (j - 1) * 30, 740 + 12, y + 6 + (j - 1) * 30], fill=mix_color(ORANGE, 1 - ph))
    # Nguồn dữ liệu tập trung
    h = pop(t, c("nguồn dữ liệu", 115), 0.6)
    if h > 0.01:
        hub(d, t, c("nguồn dữ liệu", 115), "Nguồn dữ liệu\ntập trung", NAVY, 960, 600, 180, fs=36)
        for j, (st_, lab, kind, col, x) in enumerate([(c("chi phí lương", 118), "Chi phí lương", "chart", BLUE, 1530), (c("biến động"), "Biến động\nphát sinh", "grow", ORANGE, 1530)]):
            y = 470 + j * 260
            arrow(d, 1140, 600, x - 230, y, p(t, st_ - 0.1, 0.4), col, 5)
            hcard(d, x, y, 420, 150, pop(t, st_), col, kind, lab, 32)
        for j in range(3):
            y = 470 + j * 130
            arrow(d, 560, y, 780, 600 + (y - 600) * 0.3, p(t, c("tập trung", 116) + j * 0.15, 0.4), CYAN, 5)

def sc_emp1(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ở phía nhân viên", c("ở phía", shift=0.2))
    s = pop(t, c("nhân viên", 122), 0.55)
    person(img, d, EMP, 330, 890, 410, s, "Nhân viên")
    # lịch tháng – chỉ nhận kết quả cuối kỳ
    k0 = pop(t, c("nhận kết quả", 123), 0.5)
    if k0 > 0.01:
        card(d, 900, 560, 560, 520, k0, False, BLUE)
        if k0 > 0.9:
            d.rounded_rectangle([640, 320, 1160, 390], 18, fill=BLUE)
            text(d, (900, 355), "Tháng này", 32, WHITE)
            for i in range(30):
                r, cc = divmod(i, 6); x = 670 + cc * 78; y = 420 + r * 82
                last = i == 29
                fillc = ORANGE if last else (238, 242, 252)
                d.rounded_rectangle([x, y, x + 66, y + 66], 12, fill=fillc)
                text(d, (x + 33, y + 33), str(i + 1), 24, WHITE if last else GREY, "Bold")
            pill(d, 1100, 860, 220, 64, ORANGE, "Cuối kỳ", 28, pop(t, c("cuối kỳ", 124)))
    items = [(c("ngày công", 126), "Ngày công", "calendar", BLUE), (c("khoản thưởng", 127), "Thưởng", "chart", CYAN), (c("thu nhập", 128), "Thu nhập\ntích lũy", "grow", NAVY)]
    for j, (st_, lab, kind, col) in enumerate(items):
        y = 360 + j * 200
        hcard(d, 1530, y, 460, 160, pop(t, st_), col, kind, lab, 32)
        q = pop(t, st_ + 0.4)
        icon(d, "q", 1720, y + 4 * math.sin(t * 4 + j), q, ORANGE, 34)

def sc_emp2(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Khi có chênh lệch", c("khi có chênh", 130))
    person(img, d, EMP, 330, 890, 410, 1.0, "Nhân viên")
    w = pop(t, c("chênh lệch", 131))
    icon(d, "warn", 470, 470, w, RED, 46)
    # bảng lương đã hoàn tất → mới kiểm tra
    s = pop(t, c("bảng lương đã", 133), 0.5)
    if s > 0.01:
        card(d, 960, 470, 420, 300, s, True, GREEN)
        icon(d, "doc", 960, 430, s, GREEN, 70)
        text(d, (960, 560), "Bảng lương\nđã hoàn tất", 30 * s, INK, "Bold")
    k = pop(t, c("hoàn tất", 134), 0.5)
    pill(d, 960, 700, 420, 74, ORANGE, "Sau đó mới kiểm tra", 28, k)
    # trao đổi với Nhân sự
    h = pop(t, c("trao đổi", 135), 0.55)
    person(img, d, CB, 1600, 890, 410, h, "Bộ phận\nNhân sự")
    for j, (bx, by) in enumerate([(700, 810), (1230, 810), (720, 900), (1210, 900)]):
        b = pop(t, c("trao đổi", 135, 0.3) + j * 0.45, 0.4)
        if b > 0.01:
            col = BLUE if j % 2 == 0 else NAVY
            d.rounded_rectangle([bx - 90 * b, by - 36 * b, bx + 90 * b, by + 36 * b], 30, fill=col)
            for dd in range(3):
                x = bx + (dd - 1) * 30 * b
                d.ellipse([x - 7 * b, by - 7 * b, x + 7 * b, by + 7 * b], fill=WHITE)

def sc_goal(img, d, t):
    paste(img, SECTION)
    pill(d, 330, 170, 440, 76, CYAN, "Tăng tốc độ tính toán", 28, pop(t, c("tăng tốc", 139)))
    a = p(t, c("mục tiêu", 141), 0.5)
    if a > 0:
        text(d, (110, 290 + (1 - a) * 40), "MỤC TIÊU CỐT LÕI", 100, NAVY, anchor="lm", align="left")
        underline(d, 115, 370, 900, p(t, c("cốt lõi", 141), 0.6))
        text(d, (110, 440), "của tự động hóa tính lương", 40, BLUE, "Bold", anchor="lm", align="left")
    items = [(c("quy trình rõ", 145), "Quy trình\nrõ ràng", "logic", BLUE), (c("con có", 147), "C&B\nkiểm soát", "shield", NAVY),
             (c("giảm", 148.5), "Giảm thao tác\nthủ công", "edit", ORANGE), (c("duy trì", 150), "Ổn định khi\nmở rộng quy mô", "grow", CYAN)]
    for i, (st_, lab, kind, col) in enumerate(items):
        cx = 260 + i * 320
        active = st_ <= t < (items[i + 1][0] if i < 3 else 99)
        vcard(d, cx, 660, 290, 300, pop(t, st_), col, kind, lab, 28, active)

def sc_teaser(img, d, t):
    """Nhìn trước kết quả: thẻ bảng lương 'hé lộ' + bộ phận Nhân sự + dấu hoàn tất."""
    paste(img, BOARD)
    t0, t1, t2, t3 = c("trước khi", 153), c("nhìn trước", 155), c("bộ phận nhân", 157), c("hoàn tất thiết", 159)
    # Tiêu đề chuyển: "Trước khi vào thiết lập…" -> "Nhìn trước kết quả cuối cùng"
    o = p(t, t1 - 0.3, 0.3)
    if o < 1: board_title(d, t, "Trước khi vào cách thiết lập…", t0)
    if o > 0: board_title(d, t, "Nhìn trước kết quả cuối cùng", t1 - 0.1)
    # các bước thiết lập lướt qua phía sau (mờ dần)
    for i, (kind, col) in enumerate(zip(["db", "logic", "run", "check"], [BLUE, NAVY, ORANGE, CYAN])):
        k = pop(t, t0 + 0.2 + i * 0.1) * (1 - o)
        x = 600 + i * 240 + o * 400
        if i < 3 and k > 0.5: d.line([x + 70, 560, x + 170, 560], fill=ORANGE, width=5)
        icon(d, kind, x, 560, k, col, 60)
    # thẻ kết quả: bảng lương được "mở màn"
    rv = p(t, t1, 0.8)
    if rv > 0:
        cx, cy, w, h = 1000, 580, 760, 560
        fy = 6 * math.sin(t * 2)
        card(d, cx, cy + fy, w, h, 1.0, True, BLUE)
        top = cy - h / 2 + fy
        d.rounded_rectangle([cx - w / 2, top, cx + w / 2, top + 90], 28, fill=BLUE)
        d.rectangle([cx - w / 2, top + 60, cx + w / 2, top + 90], fill=BLUE)
        text(d, (cx - w / 2 + 40, top + 45), "Bảng lương", 36, WHITE, anchor="lm")
        rows = 5
        for r in range(rows):
            k = p(t, t1 + 0.3 + r * 0.25, 0.4)
            if k <= 0: continue
            y = top + 130 + r * 78
            d.rounded_rectangle([cx - w / 2 + 40, y, cx - w / 2 + 40 + (w - 80) * k, y + 58], 12, fill=(240, 244, 252))
            if k > 0.9:
                for cc, ww in enumerate([170, 120, 140]):
                    xx = cx - w / 2 + 70 + cc * 200
                    d.rounded_rectangle([xx, y + 22, xx + ww, y + 36], 7, fill=(200, 210, 232))
                ck = pop(t, t3 + r * 0.12, 0.4)
                if ck > 0.01:
                    rr = 22 * ck; ex = cx + w / 2 - 80
                    d.ellipse([ex - rr, y + 29 - rr, ex + rr, y + 29 + rr], fill=GREEN)
                    if ck > 0.8: d.line([ex - 10, y + 29, ex - 3, y + 37, ex + 11, y + 21], fill=WHITE, width=4)
        # rèm hé lộ (che phần còn lại của thẻ, kéo sang phải)
        if rv < 1:
            d.rectangle([cx - w / 2 + (w + 20) * rv, top - 10, cx + w / 2 + 20, top + h + 20], fill=(222, 230, 246))
    # Bộ phận Nhân sự
    person(img, d, CB, 330, 880, 400, pop(t, t2, 0.55), "Bộ phận\nNhân sự")
    sparks(d, 140, 600, -1, p(t, t2 + 0.3, 0.3), t); sparks(d, 520, 600, 1, p(t, t2 + 0.3, 0.3), t)
    # Dấu hoàn tất
    s = pop(t, t3, 0.6)
    if s > 0.01:
        r = 95 * s; x, y = 1640, 330          # tách khỏi thẻ Bảng lương để chữ không đè lên
        d.ellipse([x - r + 6, y - r + 10, x + r + 6, y + r + 10], fill=SHADOW)
        d.ellipse([x - r, y - r, x + r, y + r], fill=GREEN)
        d.line([x - 40 * s, y, x - 10 * s, y + 32 * s, x + 44 * s, y - 30 * s], fill=WHITE, width=max(int(16 * s), 1), joint="curve")
        text(d, (x, y + 130), "Hoàn tất tính lương\ntự động", 30 * max(s, 0.3), GREEN, anchor="ma")
        sparks(d, x - 120, y - 40, -1, p(t, t3 + 0.3, 0.3), t, 0.8); sparks(d, x + 120, y - 40, 1, p(t, t3 + 0.3, 0.3), t, 0.8)

SCENES = [(-OFFSET, 1.3, "part"), (1.3, c("harw", shift=-0.45), "title"), (c("harw", shift=-0.45), 8.75, "mock"), (8.75, 14.5, "steps"),
          (14.5, 22.0, "problem"), (22.0, 26.3, "reality"), (26.3, 35.05, "sources"), (35.05, 45.3, "excel"),
          (45.3, 55.5, "scale"), (55.5, 66.95, "pressure"), (66.95, 80.7, "risk"), (80.7, 98.1, "hr"),
          (98.1, 105.5, "ceo1"), (105.5, 121.45, "ceo2"), (121.45, 130.75, "emp1"), (130.75, 138.4, "emp2"),
          (138.4, 153.4, "goal"), (153.4, 999, "teaser")]
FN = dict(part=sc_part, title=sc_title, mock=sc_mock, steps=sc_steps, problem=sc_problem, reality=sc_reality,
          sources=sc_sources, excel=sc_excel, scale=sc_scale, pressure=sc_pressure, risk=sc_risk, hr=sc_hr,
          ceo1=sc_ceo1, ceo2=sc_ceo2, emp1=sc_emp1, emp2=sc_emp2, goal=sc_goal, teaser=sc_teaser)

# ---- Voice mới (đã đọc lại): giữ nguyên các cảnh, chạy theo nhịp voice mới ----
# Voice mới đọc thêm tiêu đề phần ở đầu, nên slide "PHẦN 1" giữ tới hết câu tiêu đề (chạy theo thời gian thật).
import sys as _sys; _sys.path.insert(0, "/home/claude")
from remap_voice import make_maps
M, Minv = make_maps(A + "words_p1.json", A + "words_p1_v3.json")   # voice 05/11 (bỏ câu đọc tiêu đề)
_OLD_SCENES = SCENES
SCENES = [(-OFFSET, M(1.3), "part")] + [(M(s_) if s_ > -OFFSET else s_, M(e_) if e_ < 900 else 999, n_) for s_, e_, n_ in _OLD_SCENES[1:]]
_FN_OLD = FN
FN = {n_: (_FN_OLD[n_] if n_ == "part" else (lambda f: (lambda img, d, t: f(img, d, Minv(t))))(_FN_OLD[n_])) for n_ in _FN_OLD}

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "preview":
        # xuất khung hình xem trước tại các mốc voice-time
        from hw_core import render as _r
        times = [float(x) for x in sys.argv[2:]]
        def frame(tv):
            img = BG.copy()
            for s, e, name in SCENES:
                if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
            return img
        for tv in times: frame(tv).resize((960, 540)).save(f"/tmp/pv_{tv}.png")
    elif len(sys.argv) == 1:
        render(SCENES, FN, VOICE, OUT, OFFSET, TOTAL)

def seg_main(argv):
    n = int(TOTAL * FPS); N = 6; size = math.ceil(n / N)
    if argv[1] == "seg":
        k = int(argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p1_seg{k}.mp4")
    elif argv[1] == "mux":
        mux([f"/tmp/p1_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)

if len(sys.argv) > 1 and sys.argv[1] in ("seg", "mux"): seg_main(sys.argv)
