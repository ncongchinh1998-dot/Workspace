"""PHẦN 5 — đoạn 5.2: Công, phép & làm ngoài giờ · Từ bảng lương Excel đến cấu trúc trên Haraworks ·
Ba cấu phần của bảng lương · Cách tiếp cận khi bắt đầu.
Quy chuẩn: màn hình hệ thống full khung, khoanh đỏ đúng chỗ được nhắc, không thêm chữ trùng với màn hình,
nhãn vai trò góc trái dưới, âm thanh mẫu ở mỗi tiêu đề mục."""
import sys, math
from hw_core import *
from cues import Cues
c = Cues(A + "words_p52.json")
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p52.wav"
OFFSET = 1.0
VOICE_DUR = 264.85
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan5_2_Du_lieu_cong_phep_va_cau_truc_bang_luong.mp4"
H = dict(excel=143.5, cp3=189.3, cach=235.5)                      # tiêu đề mục (voice-time)
SFX_AT = [0.0] + [OFFSET + v for v in H.values()]

REC_CONG = U + "Màn_hình_công.mp4"; REC_PHEP = U + "Phép.mp4"; REC_LE = U + "Nghỉ_lễ.mp4"; REC_OT = U + "Làm_thêm.mp4"
APP_OLD = U + "Phần_2__Bảng_lương_trên_App.MP4"
# Bản quay phiếu lương mới (số liệu cộng/trừ đúng logic). Ánh xạ mốc của bản cũ -> bản mới để giữ nguyên nhịp các cảnh.
APP = U + "Phiếu_lương_nhân_viên_xem_1.MP4"
_APP_PTS = [(0.0, 0.0), (5.8, 6.0), (7.8, 10.6), (9.7, 12.7), (13.6, 16.5), (17.5, 19.5), (19.5, 21.8), (23.3, 21.8)]
def app_t(t_old):
    if t_old <= 0: return 0.0
    for (a_, ca), (b_, cb) in zip(_APP_PTS, _APP_PTS[1:]):
        if a_ <= t_old <= b_: return ca + (t_old - a_) * (cb - ca) / (b_ - a_)
    return 21.8

IMG_TQ = A + "tq_clean.png"            # 2118x1191 · đã xóa logo haraworks ở dải nền dưới
IMG_3YT = A + "yt_clean.png"           # 2120x1199 · đã xóa logo haraworks ở dải nền dưới
IMG_PP = U + "PP_thiết_lập_TPL__CTL__Nhóm_CT.png"                      # 2122x1197

FULL_CROP = (0, 0, 1912, 1016)
_clips = {}
def rec(img, key, path, t_clip, crop=FULL_CROP, size=(1920, 1020), pos=(0, 30)):
    if key not in _clips: _clips[key] = Clip(path, size, crop)
    fullscreen(img, _clips[key].get(t_clip), (pos[0], pos[1]))
FULLB = (0, 0, 1920, 1080)
def recz(img, key, path, tc, box1, k, crop=FULL_CROP):
    """Bản quay hiển thị full khung (dư trên 30px tô trắng), rồi phóng dần (k: 0 -> 1) vào box1 (toạ độ khung đã ghép)."""
    if key not in _clips: _clips[key] = Clip(path, (1920, 1020), crop)
    fr = _clips[key].get(tc); bg = Image.new("RGB", (1920, 1080), WHITE)
    if fr is not None: bg.paste(fr, (0, 30))
    k = ease(clamp(k)); box = tuple(FULLB[i] + (box1[i] - FULLB[i]) * k for i in range(4))
    img.paste(bg.resize((1920, 1080), Image.LANCZOS, box=box), (0, 0))
    return box
def RZ(box, x0, y0, x1, y1, sw=1912):
    """Toạ độ bản quay gốc -> khung hình theo box zoom hiện tại."""
    s_ = 1920 / sw; kk = 1920 / (box[2] - box[0])
    return ((x0 * s_ - box[0]) * kk, (y0 * s_ + 30 - box[1]) * kk, (x1 * s_ - box[0]) * kk, (y1 * s_ + 30 - box[1]) * kk)

def F(x0, y0, x1, y1):                     # toạ độ bản quay gốc -> khung hình (full, dư trên 30px)
    k = 1920 / 1912
    return (x0 * k, y0 * k + 30, x1 * k, y1 * k + 30)

def hl(d, box, t=0.0, kind="rect"):
    w_ = 6 + int(2 * abs(math.sin(t * 5)))
    if kind == "rect": d.rounded_rectangle(box, 10, outline=RED, width=w_)
    else: d.ellipse(box, outline=RED, width=w_)

def sub_card(img, d, t, t0, kicker, lines, size=96):
    paste(img, SECTION)
    pill(d, 280, 280, 340, 76, BLUE, kicker, 30, pop(t, t0 + 0.05), weight="ExtraBold")
    for j, line in enumerate(lines):
        k = p(t, t0 + 0.15 + j * 0.12, 0.45)
        if k > 0: text(d, (110, 430 + j * size * 1.12 + (1 - k) * 50), line, size, NAVY, anchor="lm", align="left")
    underline(d, 115, 430 + (len(lines) - 1) * size * 1.12 + size * 0.75, 700, p(t, t0 + 0.45, 0.5))
    person(img, d, CB, 1220, 900, 340, pop(t, t0 + 0.4, 0.5), "C&B", 30)

def badge(d, x, y, ok, s, r0=24):
    if s <= 0.01: return
    r = r0 * s
    d.ellipse([x - r, y - r, x + r, y + r], fill=GREEN if ok else RED)
    w = max(int(6 * s), 1)
    if ok: d.line([x - r * 0.45, y, x - r * 0.1, y + r * 0.4, x + r * 0.5, y - r * 0.35], fill=WHITE, width=w, joint="curve")
    else:
        d.line([x - r * 0.4, y - r * 0.4, x + r * 0.4, y + r * 0.4], fill=WHITE, width=w)
        d.line([x - r * 0.4, y + r * 0.4, x + r * 0.4, y - r * 0.4], fill=WHITE, width=w)

# ================= Công, phép & làm ngoài giờ =================
def sc_h_cpl(img, d, t): sub_card(img, d, t, -0.9, "PHẦN 5", ["CÔNG, PHÉP", "& LÀM NGOÀI GIỜ"], 104)

def sc_intro(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu thay đổi theo quá trình làm việc", c("nhóm dữ", 2.5))
    for j, (w, af, lab, kind, col) in enumerate(
            [("công phép", 4.4, "Công", "calendar", BLUE), ("phép và", 4.9, "Phép", "doc", CYAN), ("làm ngoài", 5.5, "Làm ngoài giờ", "clock", ORANGE)]):
        vcard(d, 620 + j * 400, 470, 340, 300, pop(t, c(w, af)), col, kind, lab, 34, True)
    person(img, d, EMP, 1660, 880, 330, pop(t, c("nhân viên", 9.9)), "Nhân viên")
    pill(d, 1020, 800, 520, 76, NAVY, "Thay đổi trong từng kỳ lương", 28, pop(t, c("từng kỳ", 10.8)))

def sc_cong(img, d, t):
    st = 12.1; T_Z = c("xác định giờ", 17)
    box = recz(img, "cong", REC_CONG, (t - st) * 1.0, box169(650, 610, 1400, 1920, 1080), (t - T_Z + 0.8) / 1.5)
    top_title(d, t, "Chấm công · Duyệt công", st)
    if t >= T_Z + 0.7: hl(d, RZ(box, 392, 200, 505, 965), t)                     # Công đã duyệt / Công đã chấm
    if c("quản lý", 15) <= t < c("sử dụng", 16.4): role_tag(img, d, MANAGER, "Quản lý")
    else: role_tag(img, d, CB, "C&B", pop(t, c("sử dụng", 16.4), 0.4))

def sc_cong_ex(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ví dụ: phụ cấp ăn trưa", c("ví dụ", 20))
    hcard(d, 520, 270, 700, 130, pop(t, c("phụ cấp ăn", 22)), ORANGE, "chart", "Phụ cấp ăn trưa\n30.000 đ / ngày", 34, True)
    fs_chip = fit_size(d, "Có chấm công", 24, "Bold", 282 - 28 - (2 * 86 * 0.33 + 48))   # cùng một cỡ chữ cho cả 3 thẻ
    for j, (w, af) in enumerate([("đi làm", 25.3), ("chấm công", 26.3), ("đã được duyệt", 28)]):
        s_ = pop(t, c(w, af))
        hcard(d, 300 + j * 292, 430, 282, 86, s_, GREEN, "check", ["Có đi làm", "Có chấm công", "Đã duyệt"][j], fs_chip)   # cùng cỡ chữ cho 3 thẻ
    # công thức
    k = pop(t, c("số tiền", 29.5))
    if k > 0.01:
        card(d, 1430, 350, 760, 240, k, True, BLUE)
        text(d, (1430, 300), "Phụ cấp = 30.000 đ ×", 34 * k, INK)
        text(d, (1430, 355), "Số ngày công thực tế", 34 * k, INK)
        k2 = pop(t, c("đã được ghi", 34.5))
        if k2 > 0.01: text(d, (1430, 415), "đã được ghi nhận", 28 * k2, BLUE, "Bold")
    # lịch tháng: ngày công đã duyệt
    T_BAD = c("còn thiếu", 36.5)
    for i in range(20):
        r, cc = divmod(i, 10); x = 260 + cc * 76; y = 640 + r * 90
        s_ = pop(t, c("số ngày", 32.8) + i * 0.03, 0.3)
        if s_ <= 0.01: continue
        bad = t >= T_BAD and i in (6, 13, 17)
        col = (255, 225, 225) if bad else (215, 245, 225)
        d.rounded_rectangle([x - 34 * s_, y - 34 * s_, x + 34 * s_, y + 34 * s_], 10, fill=col, outline=RED if bad else GREEN, width=3)
        text(d, (x, y), "?" if bad else str(i + 1), 22 * s_, RED if bad else GREEN)
    if t >= T_BAD:
        hcard(d, 1480, 720, 700, 160, pop(t, T_BAD), RED, "warn", "Công còn thiếu / chưa duyệt\n→ phụ cấp tính theo công bị ảnh hưởng", 28, True)
    else:
        k3 = pop(t, c("số ngày", 32.8))
        if k3 > 0.01: hcard(d, 1480, 720, 700, 130, k3, GREEN, "calendar", "Ví dụ: 20 ngày công\n= 600.000 đ", 30, True)

PHEP_Z = box169(1550, 520, 1100, 1920, 1080)
def sc_phep(img, d, t):
    st = 42.4
    ct = 12.0 + (t - st) * 1.0
    if ct < 14.4: k = 0.0
    elif ct < 17.4: k = (ct - 14.4) / 1.2
    elif ct < 21.5: k = 1 - (ct - 17.4) / 1.0
    else: k = (ct - 23.2) / 1.0
    box = recz(img, "phep", REC_PHEP, ct, PHEP_Z, k)
    top_title(d, t, "Nghỉ phép: loại ngày nghỉ & tính chất", st)
    if 15.6 <= ct < 17.4: hl(d, RZ(box, 1210, 650, 1545, 715), t)               # Loại phép trên chi tiết đơn
    if ct >= 24.2: hl(d, RZ(box, 1212, 350, 1892, 572), t)                       # danh sách loại phép
    role_tag(img, d, CB, "C&B")

LE_CROP = (380, 80, 1200, 675)
def Z(x0, y0, x1, y1):                     # toạ độ bản quay ngày lễ -> khung hình (đã phóng form)
    k = 1920 / 1200
    return ((x0 - 380) * k, (y0 - 80) * k, (x1 - 380) * k, (y1 - 80) * k)

LE_Z = box169(1170, 300, 1300, 1920, 1080)
def sc_le(img, d, t):
    st = 56.2
    ct = min(9.3, (t - st) * 0.8)
    box = recz(img, "le", REC_LE, ct, LE_Z, (ct - 5.5) / 1.2 if ct >= 5.5 else 0.0)
    if 2.6 < ct < 4.4: hl(d, RZ(box, 75, 14, 372, 54), t)                       # Danh sách ngày lễ và nghỉ bù
    top_title(d, t, "Ngày nghỉ lễ & nghỉ bù: khai báo đúng thời điểm", st)
    role_tag(img, d, CB, "Bộ phận nhân sự")

def sc_le_ex(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Nếu khai báo ngày lễ quá muộn", c("ví dụ", 66.5))
    T_OK = c("vì vậy", 77)
    if t < T_OK:
        person(img, d, EMP, 330, 560, 280, pop(t, c("nhân viên đã", 69.4)), "Nhân viên")
        hcard(d, 330, 690, 440, 110, pop(t, c("tạo đơn", 70)), CYAN, "doc", "1. Tạo đơn nghỉ\ncho ngày đó", 26, True)
        arrow(d, 580, 690, 760, 690, p(t, c("được bổ", 68.2), 0.4), ORANGE, 6)
        person(img, d, CB, 960, 560, 280, pop(t, c("được bổ", 68.2)), "Bộ phận nhân sự")
        hcard(d, 960, 690, 440, 110, pop(t, c("bổ sung sau", 68.4)), ORANGE, "calendar", "2. Bổ sung ngày lễ\nsau đó", 26, True)
        arrow(d, 1210, 690, 1390, 690, p(t, c("chưa nhận", 72.6), 0.4), RED, 6)
        s_ = pop(t, c("chưa nhận", 72.6))
        if s_ > 0.01:
            card(d, 1620, 600, 420, 340, s_, True, RED, (255, 238, 238))
            icon(d, "warn", 1620, 510, s_, RED, 56)
            text(d, (1620, 620), "Chưa nhận diện\nlà ngày lễ", 30 * s_, RED)
            k = pop(t, c("trừ vào", 74.8))
            if k > 0.01: text(d, (1620, 715), "→ Trừ vào quỹ phép năm", 26 * k, RED, "Bold")
    else:
        for j, (lab, kind, col, af) in enumerate([("Chuẩn bị lịch\nnghỉ lễ", "calendar", BLUE, 78), ("Phát sinh dữ liệu\ncông & phép", "doc", CYAN, 80.3)]):
            x = 700 + j * 520; s_ = pop(t, T_OK + j * 1.2 if j == 0 else c("phát sinh", af))
            vcard(d, x, 520, 420, 320, s_, col, kind, lab, 30, True, f"0{j + 1}")
        arrow(d, 920, 520, 1000, 520, p(t, c("phát sinh", 80.3), 0.3), ORANGE, 7)
        badge(d, 1440, 380, True, pop(t, c("phát sinh", 80.3, 0.4)), 34)
        pill(d, 960, 820, 520, 76, GREEN, "Khai báo trước, dữ liệu mới đúng", 28, pop(t, c("trước khi", 79.5)))

OT_Z1 = box169(1540, 420, 1000, 1920, 1080); OT_Z2 = box169(1520, 680, 1100, 1920, 1080)
def sc_ot(img, d, t):
    # ánh xạ nhiều đoạn: danh sách -> chi tiết (quy trình duyệt) -> xác nhận loại OT
    pts = [(82.4, 0.0), (84.4, 4.9), (85.5, 5.7), (89.6, 6.25), (93.0, 9.8), (107.0, 11.9)]   # zoom xong sớm, giữ lâu ở quy trình duyệt
    if t <= pts[0][0]: ct = 0.0
    elif t >= pts[-1][0]: ct = 11.9
    else:
        for (a, ca), (b, cb) in zip(pts, pts[1:]):
            if a <= t <= b: ct = ca + (t - a) * (cb - ca) / (b - a); break
    k = 0.0; bz = OT_Z1 if ct < 6.3 else OT_Z2          # không zoom: giữ toàn màn hình, chỉ khoanh khung đỏ
    box = recz(img, "ot", REC_OT, ct, bz, k, (0, 0, 1910, 1016))
    top_title(d, t, "Làm ngoài giờ: xác nhận đúng loại làm thêm", 82.6)
    if 5.6 <= ct < 6.25:
        if t < c("con xác", 87.2): hl(d, RZ(box, 1308, 290, 1885, 445, 1910), t)   # Quản lý duyệt
        else: hl(d, RZ(box, 1308, 448, 1885, 530, 1910), t)                         # Nhân sự xác nhận
    if ct >= 10.5: hl(d, RZ(box, 1212, 490, 1890, 882, 1910), t)                    # Loại OT
    if c("quản lý", 85.8) <= t < c("con xác", 87.2): role_tag(img, d, MANAGER, "Quản lý")
    else: role_tag(img, d, CB, "C&B", pop(t, c("con xác", 87.2), 0.4))
    chip_bar(d, t, [(c("một trăm", 100.6), "Ngày thường · 150%", BLUE), (c("hai trăm", 102), "Ngày nghỉ · 200%", ORANGE),
                    (c("ba trăm", 103.5), "Ngày lễ · 300%", RED)], size=26)

def sc_recap(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu nghiệp vụ nhân sự ảnh hưởng tính lương", c("trên đây", 110.3))
    items = [("Chấm công", "calendar", BLUE), ("Nghỉ phép", "doc", CYAN), ("Ngày lễ & nghỉ bù", "calendar", ORANGE), ("Làm ngoài giờ", "clock", NAVY)]
    for j, (lab, kind, col) in enumerate(items):
        hcard(d, 330 + j * 420, 300, 390, 110, pop(t, c("nghiệp vụ", 112) + j * 0.2), col, kind, lab, 26, True)
    k = pop(t, c("trong phạm", 116.8))
    if k > 0.01:
        card(d, 720, 640, 1000, 260, k, True, BLUE)
        text(d, (720, 590), "Video tập trung vào thông tin C&B cần lưu ý", 32 * k, INK)
        text(d, (720, 660), "khi xây dựng & kiểm tra bảng lương", 32 * k, BLUE)
    s_ = pop(t, c("tham khảo", 129))
    if s_ > 0.01:
        hcard(d, 1560, 640, 520, 200, s_, GREEN, "doc", "Chi tiết khai báo & vận hành:\nTài liệu hướng dẫn sử dụng\nỨng dụng Nhân sự", 24, True)
    role_tag(img, d, CB, "C&B", pop(t, c("cn cần", 120.4), 0.4))

def sc_next(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Bước tiếp theo", c("khi đã", 133))
    steps = [(c("đến từ", 135.7), "Dữ liệu tính lương\nđến từ đâu", "db", GREEN, True),
             (c("làm rõ", 137.5), "Từng khoản trên bảng lương\nhình thành thế nào", "search", ORANGE, False),
             (c("thiết lập trên", 141.9), "Thiết lập\ntrên Haraworks", "logic", BLUE, False)]
    for j, (st, lab, kind, col, done) in enumerate(steps):
        x = 440 + j * 520
        vcard(d, x, 540, 440, 340, pop(t, st), col, kind, lab, 28, j == 1 and t >= st, f"0{j + 1}")
        if done: badge(d, x + 180, 390, True, pop(t, st + 0.5, 0.4), 30)
        if j < 2: arrow(d, x + 230, 540, x + 290, 540, p(t, steps[j + 1][0] - 0.2, 0.3), ORANGE, 7)

# ================= Từ bảng lương Excel đến cấu trúc trên Haraworks =================
def sc_h_excel(img, d, t): sub_card(img, d, t, H["excel"], "PHẦN 5", ["TỪ BẢNG LƯƠNG EXCEL", "ĐẾN CẤU TRÚC", "TRÊN HARAWORKS"], 80)

KT = 1920 / 2118
def T(x0, y0, x1, y1): return (x0 * KT, y0 * KT - 0, x1 * KT, y1 * KT)
def sc_tq(img, d, t):
    fs_shot(img, IMG_TQ, (0, 0, 2118, 1191), (0, 0, 2118, 1191), 0)
    T_TPL, T_CTL, T_NH, T_SUM = c("những ô", 157), c("những ô có", 164.5), c("các cột", 169.5), c("phân rõ", 182.6)
    # các nhãn "Thành phần lương"
    CY0, CY1 = 335, 480                    # dòng tiêu đề + dòng số liệu trên bảng
    def tpl():
        for b in [(300, 522, 890, 595), (998, 522, 1121, 595), (1230, 522, 1588, 595)]: hl(d, T(*b), t)
        for x0, x1 in [(537, 885), (1001, 1117), (1233, 1582)]: hl(d, T(x0, CY0, x1, CY1), t)
    def ctl():
        for b in [(882, 588, 1005, 668), (1114, 588, 1237, 668), (1579, 588, 2050, 668)]: hl(d, T(*b), t)
        for x0, x1 in [(885, 1001), (1117, 1233), (1582, 2047)]: hl(d, T(x0, CY0, x1, CY1), t)
    def nh(): hl(d, T(532, 180, 2050, 336), t)
    if T_TPL <= t < T_CTL: tpl()
    elif T_CTL <= t < T_NH: ctl()
    elif T_NH <= t < c("như vậy", 173.3): nh()
    elif t >= T_SUM:
        if t < c("đâu là phép", 184.8): tpl()
        elif t < c("đâu là cách", 186.3): ctl()
        else: nh()
    role_tag(img, d, CB, "C&B", pop(t, c("con không", 174), 0.4))

# ================= Ba cấu phần của bảng lương =================
def sc_h_3cp(img, d, t): sub_card(img, d, t, H["cp3"], "PHẦN 5", ["BA CẤU PHẦN", "CỦA BẢNG LƯƠNG"], 104)

K3 = 1920 / 2120
def Y(x0, y0, x1, y1): return (x0 * K3, y0 * K3, x1 * K3, y1 * K3)
def sc_yt3(img, d, t):
    fs_shot(img, IMG_3YT, (0, 0, 2120, 1192), (0, 0, 2120, 1192), 0)
    T1, T2, T3 = c("thành phần lương là", 194), c("công thức lương là", 198), c("nhóm công thức dùng", 201)
    if T1 <= t < T2:
        hl(d, Y(800, 705, 1060, 1005), t); hl(d, Y(6, 705, 736, 1050), t)          # Thành phần lương
    elif T2 <= t < T3:
        hl(d, Y(925, 490, 1190, 765), t); hl(d, Y(535, 88, 1414, 465), t)          # Công thức lương
    elif t >= T3:
        hl(d, Y(1050, 705, 1315, 1008), t); hl(d, Y(1412, 685, 2120, 1068), t)     # Nhóm công thức
    role_tag(img, d, CB, "C&B")

PH = (380, 840)
def sc_payslip(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Nhóm công thức tổ chức phiếu lương", c("nhóm công thức còn", 206.7))
    st = c("phiếu lương", 209.2); ps = pop(t, st, 0.6)
    scr = clip_app(app_t(min(15.5, 13.0 + (t - st) * 0.4))) if ps > 0.98 else None
    phone(img, d, 960, 150, PH[0], PH[1], scr, ps)
    for j, (w, af, lab, col) in enumerate([("công lương", 213, "Công & Lương", BLUE), ("phụ cấp", 214, "Phụ cấp", CYAN), ("thưởng", 214.8, "Thưởng", ORANGE), ("khấu trừ", 215.5, "Khấu trừ", RED)]):
        pill(d, 430, 380 + j * 100, 300, 76, col, lab, 30, pop(t, c(w, af)))
    k1 = pop(t, c("dễ kiểm", 219.8))
    if k1 > 0.01:
        role_badge(img, d, CB, "C&B", 1520, 470, k1, 200)
        pill(d, 1520, 540, 300, 70, NAVY, "Dễ kiểm tra", 30, k1)
    k2 = pop(t, c("nhân viên dễ", 220.8))
    if k2 > 0.01:
        role_badge(img, d, EMP, "Nhân viên", 1520, 830, k2, 200)
        pill(d, 1520, 900, 300, 70, GREEN, "Dễ đọc", 30, k2)

_appc = {}
def clip_app(tc):
    if "a" not in _appc: _appc["a"] = Clip(APP, PH)
    return _appc["a"].get(tc)

def sc_flow(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Luồng tổng thể", c("có thể hình", 222))
    items = [(c("được ghi", 225.2), "Dữ liệu ghi nhận tại\nThành phần lương", "db", GREEN),
             (c("công thức lương sử", 227), "Công thức lương\ntạo kết quả", "fx", BLUE),
             (c("được tổ chức", 230.8), "Nhóm công thức\ntổ chức các công thức", "logic", ORANGE),
             (c("cấu trúc bảng", 233.4), "Bảng lương &\nPhiếu lương", "doc", NAVY)]
    cw, gap = 360, 60; x0 = (W - (4 * cw + 3 * gap)) / 2 + cw / 2
    for i, (st, lab, kind, col) in enumerate(items):
        x = x0 + i * (cw + gap)
        if i < 3: arrow(d, x + cw / 2 + 8, 540, x + cw / 2 + gap - 8, 540, p(t, items[i + 1][0] - 0.2, 0.3), ORANGE, 7)
        active = st <= t < (items[i + 1][0] if i < 3 else 999)
        vcard(d, x, 540, cw, 360, pop(t, st), col, kind, lab, 28, active, f"0{i + 1}")

# ================= Cách tiếp cận khi bắt đầu =================
def sc_h_cach(img, d, t): sub_card(img, d, t, H["cach"], "PHẦN 5", ["CÁCH TIẾP CẬN", "KHI BẮT ĐẦU"], 104)

def sc_steps5(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "5 bước khi bắt đầu", c("năm bước", 239.5))
    items = [(c("chuẩn bị bảng", 240.3), "Chuẩn bị\nbảng lương Excel", "sheet", GREEN),
             (c("xác định chính", 242), "Xác định chính sách\nlương đã thống nhất", "shield", NAVY),
             (c("kiểm tra dữ", 244), "Kiểm tra\ndữ liệu đầu vào", "db", CYAN),
             (c("phân tích", 245.8), "Phân tích từng khoản:\ndữ liệu & quy tắc", "search", ORANGE),
             (c("chuyển các", 251.3), "Chuyển thành cấu trúc\ntrên Haraworks", "logic", BLUE)]
    cw, gap = 320, 40; x0 = (W - (5 * cw + 4 * gap)) / 2 + cw / 2
    for i, (st, lab, kind, col) in enumerate(items):
        x = x0 + i * (cw + gap)
        if i < 4: arrow(d, x + cw / 2 + 4, 540, x + cw / 2 + gap - 4, 540, p(t, items[i + 1][0] - 0.2, 0.3), ORANGE, 5)
        active = st <= t < (items[i + 1][0] if i < 4 else 999)
        vcard(d, x, 540, cw, 360, pop(t, st), col, kind, lab, 24, active, f"0{i + 1}")
        if active: sparks(d, x - cw / 2 - 4, 380, -1, p(t, st + 0.2, 0.3), t, 0.6); sparks(d, x + cw / 2 + 4, 380, 1, p(t, st + 0.2, 0.3), t, 0.6)
    role_tag(img, d, CB, "C&B", pop(t, c("cnb", 238.5), 0.4))

KP = 1920 / 2122
def P(x0, y0, x1, y1): return (x0 * KP, y0 * KP, x1 * KP, y1 * KP)
IMG_MCH = U + "Menu_cấu_hình_Lương_thưởng.png"                        # 2807x1629
MCH_FULL = box169(1403, 814, 2807, 2807, 1629); MCH_Z = box169(500, 900, 1300, 2807, 1629)
def sc_pp(img, d, t):
    st = c("chuyển các", 251.3)
    fs_shot(img, IMG_MCH, MCH_FULL, MCH_Z, (t - st - 0.3) / 1.4)
    X = shot_xy(MCH_Z)
    T1, T2, T3 = c("thành phần lương", 252.7), c("nhóm công", 253.8), c("công thức lương", 255)
    if T1 <= t < T2: hl(d, X(85, 835, 330, 885), t)               # Thành phần lương
    elif T2 <= t < T3: hl(d, X(85, 975, 330, 1025), t)            # Nhóm công thức
    elif t >= T3: hl(d, X(85, 905, 330, 955), t)                  # Công thức lương
    top_title(d, t, "Chuyển quy tắc thành cấu trúc trên Haraworks", st)
    role_tag(img, d, CB, "C&B")

def shot_xy(box):
    k = 1920 / (box[2] - box[0])
    return lambda x0, y0, x1, y1: ((x0 - box[0]) * k, (y0 - box[1]) * k, (x1 - box[0]) * k, (y1 - box[1]) * k)

def sc_teaser(img, d, t):
    paste(img, BOARD)
    k = pop(t, c("từ đây", 257))
    pill(d, W / 2, 300, 360, 76, NAVY, "Tiếp theo", 32, k)
    s_ = pop(t, c("thành phần lương", 260.5), 0.6)
    if s_ > 0.01:
        card(d, W / 2, 560, 1100, 320, s_, True, GREEN)
        icon(d, "db", W / 2 - 420 * s_, 560, s_, GREEN, 90)
        text(d, (W / 2 + 90, 520), "THÀNH PHẦN LƯƠNG", 58 * s_, NAVY)
        k2 = pop(t, c("nơi chứa", 261.6))
        if k2 > 0.01: text(d, (W / 2 + 90, 600), "Nơi chứa dữ liệu dùng trong công thức lương", 26 * k2, GREEN, "Bold")
        sparks(d, W / 2 - 500, 440, -1, p(t, c("thành phần lương", 260.5, 0.3), 0.3), t); sparks(d, W / 2 + 500, 440, 1, p(t, c("thành phần lương", 260.5, 0.3), 0.3), t)

SCENES = [(-OFFSET, 2.5, "h_cpl"), (2.5, 12.0, "intro"), (12.0, 20.2, "cong"), (20.2, 42.4, "cong_ex"),
          (42.4, 56.2, "phep"), (56.2, 66.6, "le"), (66.6, 82.4, "le_ex"), (82.4, 110.3, "ot"),
          (110.3, 133.2, "recap"), (133.2, H["excel"], "next"), (H["excel"], 147.2, "h_excel"), (147.2, H["cp3"], "tq"),
          (H["cp3"], 192.2, "h_3cp"), (192.2, 206.6, "yt3"), (206.6, 223.8, "payslip"), (223.8, H["cach"], "flow"),
          (H["cach"], 238.5, "h_cach"), (238.5, 251.4, "steps5"), (251.4, 257.1, "pp"), (257.1, 999, "teaser")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times):
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.resize((960, 540)).save(f"/tmp/pv52_{tv}.png")

N = 6
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p52_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p52_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
