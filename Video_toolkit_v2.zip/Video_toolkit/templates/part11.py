"""PHẦN 11 (+ phiếu lương, tổng kết, báo cáo, kết thúc) — video cuối.
Tư liệu: Xem_thu_nhập_nhân_viên.mp4, Phiếu_lương.MP4 (app), Báo_cáo_lương_theo_đơn_vị.mp4, Báo_cáo_lương_cá_nhân__thuế_TNCN_.mp4."""
import sys, math
from hw_core import *
from part81 import sub_card, mini_chip, badge
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p11.wav"
OFFSET = 1.0
VOICE_DUR = 297.93
TOTAL = OFFSET + VOICE_DUR + 1.5
OUT = "/mnt/user-data/outputs/Phan11_Kiem_tra_ket_qua_va_tong_ket.mp4"
HD = dict(p11=-0.6, tk=145.3)
SFX_AT = [0.0, OFFSET + HD["tk"]]

REC_TN = U + "Xem_thu_nhập_nhân_viên.mp4"            # 1824x1078
REC_DV = U + "Báo_cáo_lương_theo_đơn_vị.mp4"          # 1824x1078
REC_NV = U + "Báo_cáo_lương_cá_nhân__thuế_TNCN_.mp4"  # 1824x1078
REC_APP = U + "Phiếu_lương.MP4"                       # 576x1280

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))

_clips = {}
REC_BR = dict(crop=(0, 0, 1824, 1078), size=(1920, 1135), y0=-55, sw=1824)
def scr(img, key, path, tc, spec=REC_BR):
    if key not in _clips: _clips[key] = Clip(path, spec["size"], spec["crop"])
    fr = _clips[key].get(tc); bg = Image.new("RGB", (1920, 1080), WHITE)
    if fr is not None: bg.paste(fr, (0, spec["y0"]))
    img.paste(bg, (0, 0))
def B(x0, y0, x1, y1, spec=REC_BR):
    s_ = 1920 / spec["sw"]; y_ = spec["y0"]
    return (x0 * s_, y0 * s_ + y_, x1 * s_, y1 * s_ + y_)
def piece(t, pts):
    if t <= pts[0][0]: return pts[0][1]
    for (a_, ca), (b_, cb) in zip(pts, pts[1:]):
        if a_ <= t <= b_: return ca + (t - a_) * (cb - ca) / (b_ - a_)
    return pts[-1][1]
def app_phone(img, d, cx, top, sw, tc, s=1.0):
    sh = int(sw * 1280 / 576); k2 = f"app_{sw}"
    if k2 not in _clips: _clips[k2] = Clip(REC_APP, (sw, sh))
    phone(img, d, cx, top, sw, sh, _clips[k2].get(tc) if s > 0.98 else None, s)
    sx, sy = cx - sw / 2, top + 14; k = sw / 576
    return lambda x0, y0, x1, y1: (sx + x0 * k, sy + y0 * k, sx + x1 * k, sy + y1 * k)

# ---------- toạ độ (ảnh gốc 1824x1078) ----------
T_NV = (128, 262, 560, 335); T_DV = (952, 262, 1385, 335); T_VT = (1366, 262, 1800, 335)
T_TABLE = (140, 352, 1792, 945)
T_GROUP = (160, 636, 642, 935)          # Tổng thu nhập theo nhóm (LƯƠNG, PHỤ CẤP, BHXH, THUẾ, THỰC LÃNH)
D_TITLE = (106, 190, 680, 236); D_TABLE = (90, 262, 1806, 1040)
X_MENU = (1556, 248, 1822, 352)
DV_DIALOG = (150, 312, 912, 696); DV_TITLE = (690, 214, 1142, 260)
NV_OPT = (176, 432, 900, 476); NV_TITLE = (720, 212, 1214, 260); NV_TABLE = (140, 380, 1800, 1050); NV_XUAT = (1586, 262, 1722, 306)
A_GROUPS = (8, 250, 568, 704); A_PERIOD = (8, 150, 568, 245); A_DAILY = (8, 270, 568, 1240)

# ================= Phần 11: Thu nhập nhân viên =================
def sc_h_p11(img, d, t): sub_card(img, d, t, HD["p11"], "PHẦN 11", ["KIỂM TRA KẾT QUẢ TẠI", "THU NHẬP NHÂN VIÊN"], 84)

def sc_tn(img, d, t):
    if t < 18.6: ct = piece(t, [(4.4, 0.0), (6.5, 0.2), (8.0, 1.6), (9.0, 2.0)])
    elif t < 22.4: ct = 2.0
    elif t < 24.4: ct = 12.0
    elif t < 30.3: ct = 22.0
    elif t < 46.4: ct = 34.0
    elif t < 60.0: ct = 40.5
    elif t < 63.4: ct = 46.5
    elif t < 64.7: ct = 47.2
    else: ct = piece(t, [(64.7, 55.0), (70.0, 60.0)])
    scr(img, "tn", REC_TN, ct)
    if t < 18.6:
        top_title(d, t, "Thu nhập nhân viên: kiểm tra kết quả sau khi chạy lương", 6.9)
        if 11.7 <= t < 13.5: hl(d, B(*T_NV), t)
        if 13.6 <= t < 14.5: hl(d, B(*T_DV), t)
        if 14.5 <= t < 18.6: hl(d, B(*T_VT), t)
        if t >= 15.5: chip_bar(d, t, [(15.5, "Chọn từng nhân viên hoặc lọc theo đơn vị, vị trí công việc để thu hẹp phạm vi cần xem", NAVY)], size=21)
    elif t < 30.3:
        top_title(d, t, "Bảng lương: theo dõi tổng thể nhiều nhân viên trên một màn hình", 18.7)
        if t >= 19.6: hl(d, B(*T_TABLE), t)
        chip_bar(d, t, [(22.4, "Công", BLUE), (23.0, "Lương", BLUE), (23.6, "Phụ cấp", BLUE), (24.4, "Thưởng", BLUE), (25.4, "Khấu trừ", BLUE), (26.2, "Kết quả khác", GREY)], size=24)
    elif t < 46.4:
        top_title(d, t, "Bảng lương theo góc nhìn từng nhân viên", 30.4)
        if 34.0 <= t < 46.4: hl(d, B(*T_GROUP), t)
        chip_bar(d, t, [(37.6, "Kiểm tra đồng thời kết quả tính & thông tin sẽ hiển thị cho nhân viên", GREEN)], size=23)
    elif t < 60.0:
        top_title(d, t, "Nhấn vào công thức để xem chi tiết", 46.5)
        if 47.2 <= t < 50.8: hl(d, B(*D_TITLE), t)
        if t >= 50.9: hl(d, B(*D_TABLE), t)
        if t >= 49.0: chip_bar(d, t, [(49.0, "Công thức chạy hàng ngày: hiển thị kết quả theo từng ngày", NAVY)] if t < 53.7 else
                               [(53.8, "Đối chiếu dữ liệu phát sinh, xác định nhanh ngày tạo ra kết quả đang kiểm tra", GREEN)], size=22)
    else:
        top_title(d, t, "Xuất bảng lương ra file Excel", 60.4)
        if 63.4 <= t < 64.7: hl(d, B(*X_MENU), t)
        if t >= 65.2: chip_bar(d, t, [(65.2, "Phục vụ kiểm tra, đối chiếu hoặc lưu trữ theo quy trình nội bộ", NAVY)], size=24)
    role_tag(img, d, CB, "C&B")

def sc_recap1(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Tại Thu nhập nhân viên, C&B có thể", 70.4, size=56)
    for i, (st, lab, kind, col) in enumerate([(73.3, "Kiểm tra tổng thể\nbảng lương", "sheet", BLUE), (75.2, "Xem chi tiết\ntừng nhân viên", "people", GREEN),
                                              (77.0, "Xem chi tiết\ntừng công thức", "fx", ORANGE)]):
        vcard(d, 500 + i * 460, 540, 420, 360, pop(t, st), col, kind, lab, 28, True, f"0{i + 1}")
    role_tag(img, d, CB, "C&B")

# ================= Phiếu lương trên App =================
GCHIPS = [(91.7, "Lương", BLUE), (92.2, "Phụ cấp", BLUE), (93.0, "Thưởng", BLUE), (94.0, "Khấu trừ", BLUE), (94.8, "Thực nhận", GREEN)]
def sc_app(img, d, t):
    paste(img, BOARD)
    if t < 86.5: ct = piece(t, [(78.6, 0.0), (86.4, 6.5)])
    elif t < 96.9: ct = 10.0
    elif t < 103.0: ct = piece(t, [(96.9, 28.6), (101.2, 32.8)])
    elif t < 112.3: ct = 14.0
    else: ct = piece(t, [(112.3, 17.0), (118.4, 23.0)])
    P = app_phone(img, d, 640, 78, 432, ct)
    if t < 86.5: top_title(d, t, "Nhân viên xem thu nhập trên App Haraworks", 79.3)
    elif t < 96.9: top_title(d, t, "Phiếu lương: trình bày theo cấu trúc C&B đã thiết lập", 86.6)
    elif t < 103.0: top_title(d, t, "Chủ động xem lại kết quả của từng chu kỳ lương", 96.5)
    else: top_title(d, t, "Theo dõi thu nhập trong kỳ", 103.2)
    if 87.6 <= t < 96.9: hl(d, P(*A_GROUPS), t)
    if 101.3 <= t < 102.9: hl(d, P(*A_PERIOD), t)
    if t >= 118.4: hl(d, P(*A_DAILY), t)
    if 86.6 <= t < 96.9:
        for j, (st, lab, col) in enumerate(GCHIPS):
            mini_chip(d, 1300, 300 + j * 95, 360, 70, lab, col, pop(t, st, 0.4), 28)
    if 99.8 <= t < 103.0:
        s_ = pop(t, 99.8)
        if s_ > 0.01:
            card(d, 1340, 520, 680, 220, s_, True, ORANGE)
            text(d, (1340, 520), "Thay vì chờ C&B gửi phiếu lương\nriêng cho từng người", 28 * s_, INK, "Bold")
    if t >= 103.0:
        hcard(d, 1340, 360, 760, 150, pop(t, 104.3), NAVY, "calendar", "Kỳ lương ở trạng thái công khai\n+ công thức chạy hàng ngày", 26, True)
        hcard(d, 1340, 560, 760, 150, pop(t, 108.4), GREEN, "check", "Một số kết quả thu nhập được\ncập nhật trong quá trình diễn ra kỳ", 26, True)
        hcard(d, 1340, 760, 760, 150, pop(t, 119.6), BLUE, "people", "Nhân viên chủ động theo dõi\n& kiểm tra lại khi cần", 26, True)
    role_badge(img, d, EMP, "Nhân viên", 1700, 1000, pop(t, 79.6, 0.5), 230) if t < 86.5 else None

FLOW = [(137.5, "Ghi nhận\ndữ liệu", "db", GREEN), (139.1, "Thực hiện\ncông thức", "fx", BLUE), (139.8, "Chạy lương", "run", NAVY),
        (140.5, "Kiểm tra\nkết quả", "search", ORANGE), (142.6, "Phiếu lương\nnhân viên", "doc", CYAN)]
def sc_flow(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Về phía C&B: giảm thao tác gửi phiếu lương thủ công", 126.6, size=50)
    k = pop(t, 134.4, 0.4)
    if k > 0.01: text(d, (W / 2, 290), "Dữ liệu xuyên suốt từ lúc ghi nhận đến thông tin cuối cùng nhân viên nhìn thấy", 26 * k, INK, "Bold")
    for i, (st, lab, kind, col) in enumerate(FLOW):
        x = 290 + i * 345
        vcard(d, x, 560, 300, 300, pop(t, st), col, kind, lab, 26, True)
        if i: arrow(d, x - 345 + 155, 560, x - 155, 560, p(t, st - 0.2, 0.3), ORANGE, 6)
    role_tag(img, d, CB, "C&B")

# ================= Tổng kết =================
def sc_h_tk(img, d, t): sub_card(img, d, t, HD["tk"], "TỔNG KẾT", ["TOÀN BỘ QUY TRÌNH &", "NGUYÊN TẮC CẦN GHI NHỚ"], 80)

def sc_tk1(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Để kết quả tính lương chính xác", 159.8, size=56)
    vcard(d, 680, 540, 560, 400, pop(t, 163.0), GREEN, "db", "Dữ liệu đầu vào\nkhai báo đúng & đầy đủ", 30, True, "01")
    vcard(d, 1240, 540, 560, 400, pop(t, 166.7), BLUE, "fx", "Cách tính trên hệ thống\nphản ánh đúng chính sách lương", 28, True, "02")
    role_tag(img, d, CB, "C&B")

FOUR = [(175.9, "Thành phần lương\nđúng dữ liệu cần tính?", "db", GREEN), (179.5, "Nội dung công thức\nđúng cách tính?", "fx", BLUE),
        (182.6, "Cách thể hiện phù hợp\ntính chất dữ liệu?", "chart", ORANGE), (186.4, "Chạy hàng ngày hay\nmột lần cuối chu kỳ?", "run", NAVY)]
def sc_tk2(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Khi xây dựng hoặc kiểm tra công thức lương: nhớ bốn yếu tố", 171.3, size=46)
    for i, (st, lab, kind, col) in enumerate(FOUR):
        vcard(d, 330 + i * 420, 500, 380, 360, pop(t, st), col, kind, lab, 24, True, f"0{i + 1}")
    pill(d, W / 2 + 60, 830, 1500, 76, NAVY, "Chính sách lương thay đổi → quay lại bốn yếu tố để xác định phần cần điều chỉnh", 24, pop(t, 190.4))
    k = pop(t, 196.9, 0.4)
    if k > 0.01: text(d, (W / 2 + 60, 920), "thay vì xây dựng lại toàn bộ bảng lương từ đầu", 26 * k, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B")

def sc_bc(img, d, t):
    if t < 210.5:
        paste(img, BOARD)
        board_title(d, t, "Sau khi chạy lương hoàn tất, dữ liệu được dùng cho", 200.4, size=50)
        for i, (st, lab, kind, col) in enumerate([(203.6, "Bảng lương", "sheet", BLUE), (204.3, "Phiếu lương", "doc", GREEN), (206.0, "Báo cáo", "chart", ORANGE)]):
            vcard(d, 500 + i * 460, 540, 400, 320, pop(t, st), col, kind, lab, 32, True)
        k = pop(t, 207.5, 0.4)
        if k > 0.01: text(d, (W / 2, 790), "Phục vụ kiểm tra & đối chiếu sau tính lương", 28 * k, INK, "Bold")
        role_tag(img, d, CB, "C&B")
        return
    if t < 221.6:
        ct = piece(t, [(210.5, 3.0), (212.5, 6.0), (215.5, 10.5), (216.5, 12.0)])
        scr(img, "dv", REC_DV, ct)
        top_title(d, t, "Báo cáo tổng hợp lương theo đơn vị", 210.6)
        if 213.6 <= t < 215.4: hl(d, B(*DV_DIALOG), t)
        if t >= 216.6: hl(d, B(*DV_TITLE), t)
        if t >= 217.9: chip_bar(d, t, [(217.9, "Theo dõi & đối chiếu số liệu giữa các đơn vị công tác theo kỳ lương", NAVY)], size=23)
    else:
        ct = piece(t, [(221.6, 3.5), (223.4, 5.0), (225.2, 5.0), (226.2, 10.0), (227.0, 12.0)])
        scr(img, "nv", REC_NV, ct)
        top_title(d, t, "Báo cáo tổng hợp lương theo nhân viên", 221.7)
        if 223.5 <= t < 225.2: hl(d, B(*NV_OPT), t)
        if 227.0 <= t < 230.1: hl(d, B(*NV_TITLE), t)
        if t >= 230.1: hl(d, B(*NV_XUAT), t)
        if t >= 228.8: chip_bar(d, t, [(228.8, "Kết quả lương tổng hợp theo từng nhân viên trong kỳ: kiểm tra & xuất dữ liệu", NAVY)], size=22)
    role_tag(img, d, CB, "C&B")

def sc_central(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu tiếp tục được sử dụng sau khi kỳ lương hoàn tất", 232.5, size=50)
    s_ = pop(t, 238.6)
    if s_ > 0.01:
        card(d, 560, 520, 680, 340, s_, True, (130, 140, 160))
        text(d, (560, 470), "Không cần tập hợp lại từ", 28 * s_, GREY, "Bold")
        text(d, (560, 540), "nhiều bảng lương\nhoặc file Excel riêng lẻ", 32 * s_, INK)
        badge(d, 870, 370, False, s_, 28)
    s2 = pop(t, 236.3)
    if s2 > 0.01:
        card(d, 1340, 520, 680, 340, s2, True, GREEN)
        text(d, (1340, 520), "Tổng hợp\nkiểm tra & đối chiếu", 36 * s2, GREEN)
        badge(d, 1650, 370, True, s2, 28)
    role_tag(img, d, CB, "C&B")

def sc_benefit(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dữ liệu, công thức & kết quả trong cùng một quy trình", 242.8, size=50)
    for i, (st, lab, kind, col, who) in enumerate([(247.6, "Giảm thao tác tổng hợp\n& xử lý lặp lại", "check", BLUE, "C&B"),
                                                   (250.4, "Chủ động theo dõi\nthu nhập của mình", "people", GREEN, "Nhân viên"),
                                                   (253.3, "Nguồn dữ liệu tập trung,\nsẵn sàng khi quy mô tăng", "db", ORANGE, "Doanh nghiệp")]):
        x = 500 + i * 460
        vcard(d, x, 560, 420, 380, pop(t, st), col, kind, lab, 26, True)
        k = pop(t, st + 0.2, 0.4)
        if k > 0.01: mini_chip(d, x, 330, 260, 56, who, col, k, 24)
    role_tag(img, d, CB, "C&B")

def sc_shift(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Chuyển đổi tính lương lên Haraworks", 259.2, size=56)
    s_ = pop(t, 262.0)
    if s_ > 0.01:
        card(d, 560, 520, 680, 360, s_, True, (130, 140, 160))
        text(d, (560, 440), "Không chỉ là", 26 * s_, GREY, "Bold")
        text(d, (560, 530), "Đưa công thức từ Excel\nlên hệ thống", 34 * s_, INK)
    arrow(d, 920, 520, 1040, 520, p(t, 265.0, 0.4), ORANGE, 8)
    s2 = pop(t, 265.2)
    if s2 > 0.01:
        card(d, 1380, 520, 640, 420, s2, True, GREEN)
        text(d, (1380, 380), "Quan trọng hơn", 26 * s2, GREEN, "Bold")
        text(d, (1380, 480), "Vận hành một quy trình\ntính lương rõ ràng", 32 * s2, INK)
        for j, (st, lab) in enumerate([(272.8, "Kiểm tra"), (273.4, "Điều chỉnh"), (274.3, "Sử dụng lại dữ liệu")]):
            mini_chip(d, [1180, 1380, 1590][j], 620, [180, 180, 200][j], 56, lab, GREEN, pop(t, st, 0.4), 22)
    role_tag(img, d, CB, "C&B")

def sc_end(img, d, t):
    paste(img, SECTION)
    k = pop(t, 277.9)
    pill(d, 330, 260, 440, 76, BLUE, "HOÀN TẤT", 30, k, weight="ExtraBold")
    for j, line in enumerate(["THIẾT LẬP & VẬN HÀNH", "TÍNH LƯƠNG TRÊN HARAWORKS"]):
        kk = p(t, 278.2 + j * 0.15, 0.45)
        if kk > 0: text(d, (110, 400 + j * 90 + (1 - kk) * 40), line, 72, NAVY, anchor="lm", align="left")
    k2 = pop(t, 294.2, 0.5)
    if k2 > 0.01: text(d, (110, 640), "Cảm ơn bạn đã đồng hành cùng Haraworks!", 40 * k2, ORANGE, anchor="lm", align="left")
    person(img, d, CB, 1220, 900, 340, pop(t, 278.6, 0.5), "C&B", 30)

SCENES = [(-OFFSET, 4.4, "h_p11"), (4.4, 70.0, "tn"), (70.0, 78.5, "recap1"), (78.5, 126.3, "app"), (126.3, HD["tk"], "flow"),
          (HD["tk"], 154.4, "h_tk"), (154.4, 170.8, "tk1"), (170.8, 199.9, "tk2"), (199.9, 232.3, "bc"), (232.3, 242.6, "central"),
          (242.6, 259.0, "benefit"), (259.0, 277.7, "shift"), (277.7, 999, "end")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv11"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 12
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p11_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p11_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
