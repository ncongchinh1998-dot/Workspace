"""PHẦN 4 — CHU KỲ LƯƠNG & THAM SỐ LƯƠNG (voice mới 23/10)
Các cảnh cũ giữ nguyên bố cục, chạy theo nhịp voice mới (ánh xạ thời gian theo từng từ).
Cảnh dựng mới: thu nhập thay đổi theo ngày, phạm vi xem phiếu lương (màn hình hệ thống), chu kỳ chạy thử,
thời điểm khóa dữ liệu, thời gian duyệt công tối đa (màn hình + ví dụ + phân biệt 2 quy tắc)."""
import sys, math
sys.path.insert(0, "/home/claude")

# ---- nạp các cảnh cũ của Phần 4, sửa chữ cho khớp lời đọc mới ----
SRC = open("/home/claude/part4.py").read()
SRC = SRC[:SRC.index("SCENES = [")]
PATCH = [
    ('"Hai phần nền tảng"', '"Hai nội dung cần xác định trước"'),
    ('    s_ = pop(t, c("không đi"))\n    if s_ > 0.01:\n        hcard(d, 400, 330, 560, 120, s_, GREY, "edit", "Thiết lập từ đầu", 34)', '    s_ = 0.0\n    if s_ > 0.01:\n        pass'),
    ('"Hiểu ý nghĩa\\ncủa từng phần"', '"Ý nghĩa của\\ntừng thiết lập"'),
    ('"Biết thông tin nào\\ncần kiểm tra"', '"Thông tin C&B\\ncần kiểm tra"'),
    ('"Hiểu liên quan thế nào\\nđến dữ liệu tính lương"', '"Ảnh hưởng đến dữ liệu\\ndùng trong tính lương"'),
    ('        pill(d, 1260, 900, 300, 64, RED, "Quan trọng nhất", 26, k)\n        sparks(', '        pass\n        if False: sparks('),
    ('"Không tách rời khỏi bảng lương"', '"Liên quan trực tiếp đến dữ liệu tính lương"'),
    ('        if k > 0.01: pill(d, W / 2, 200, 460, 66, RED, "Điểm quan trọng cần ghi nhớ", 26, k)', '        pass'),
    ('"Chu kỳ lương\\nTính lương cho kỳ nào"', '"Chu kỳ lương\\nKhoảng thời gian lấy dữ liệu để tính"'),
    ('"Tham số lương\\nMốc thời gian & dữ liệu đầu vào"', '"Tham số lương\\nMốc cập nhật & phê duyệt dữ liệu"'),
    ('"Đúng phạm vi áp dụng"', '"Đúng phạm vi nhân viên được xem phiếu lương"'),
    ('"Dữ liệu đầu vào đã cập nhật, duyệt & khóa"', '"Dữ liệu đầu vào đã cập nhật & phê duyệt"'),
    ('"Dùng sau khi doanh nghiệp\\ngo-live tính lương tự động"', '"Dùng khi doanh nghiệp đã chính thức\\nvận hành tính lương tự động"'),
    ('"Hệ thống tự động\\nchạy lương hằng ngày"', '"Nếu thiết lập chạy lương\\ntự động hàng ngày"'),
    ('"Hoàn tất kỳ lương &\\nthanh toán cho nhân viên"', '"Hoàn tất tính lương &\\nchi lương cho nhân viên"'),
    ('"Số liệu là kết quả cuối cùng\\ntại thời điểm chi lương"', '"Số liệu giữ theo kết quả\\nđã xác định khi chi lương"'),
    ('"Vẫn xem được thu nhập kỳ đã chốt"', '"Vẫn xem được phiếu lương kỳ đã chốt"'),
    ('"Kiểm tra khi xây dựng &\\nđiều chỉnh công thức mới"', '"Kiểm tra công thức lương mới\\ntrước khi dùng chính thức"'),
    ('"Được cấp quyền xem"', '"Người có quyền vẫn xem"'),
    ('icon(d, "run", 1530, 380, k, CYAN, 46)', 'pass'),
    ('pill(d, 1530, 470, 200, 60, CYAN, f"Ngày {day:02d}", 26, k)', 'pass'),
    ('pill(d, 1250, 990, 560, 70, GREEN, "Thấy thu nhập thay đổi theo từng ngày", 26, pop(t, c("thay đổi", 89.35)))', 'pass'),
    ('.get(app_t(13.0 + (t - 80) * 0.6))', '.get(min(12.2, 10.6 + max(0.0, t - 80) * 0.15))'),
    ('"Một nguyên tắc kiểm soát dữ liệu"', '"Các mốc kiểm soát cập nhật dữ liệu"'),
    ('"Các mốc thời gian không tồn tại riêng lẻ"', '"Các mốc thời gian phối hợp với nhau"'),
    ('"Quản lý được duyệt\\nđến khi nào?"', '"Quản lý được duyệt\\ntrong phạm vi nào?"'),
]
for a, b in PATCH:
    if a in SRC: SRC = SRC.replace(a, b)
    else: print("PATCH MISS:", a[:40])
G = {"__name__": "p4old"}
_argv = sys.argv; sys.argv = ["p4old"]
exec(compile(SRC, "part4_old", "exec"), G)
sys.argv = _argv
globals().update({k: v for k, v in G.items() if not k.startswith("__")})
H_OLD = dict(H)

VOICE = A + "voice_p4_new.wav"
OFFSET = 1.5
VOICE_DUR = 456.09
TOTAL = OFFSET + VOICE_DUR + 0.8
OUT = "/mnt/user-data/outputs/Phan4_Chu_ky_luong_va_Tham_so_luong.mp4"
HN = dict(ckl=33.9, scope=132.4, delete=188.1, tsl=221.7, lock=254.4, approve=281.1, after=339.5, link=395.9)
SFX_AT = [0.0] + [OFFSET + v for v in HN.values()]
U = "/mnt/user-data/uploads/"

from cues import Cues
cn = Cues(A + "words_p4_new.json")
from remap_voice import make_maps
M, Minv = make_maps(A + "words_p4.json", A + "words_p4_new.json")
def old(fn): return lambda img, d, t: fn(img, d, Minv(t))

HL_PAD = 10
def hl(d, box, t=0.0):
    b = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(b, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))

_shots = {}
_BOARD_FULL = BG.copy(); paste(_BOARD_FULL, BOARD)        # nền BOARD hoàn chỉnh để che vùng cũ
def panel(img, d, path, crop, x, y, w, s=1.0):
    """Đặt một vùng ảnh hệ thống (crop) vào khung tại (x, y) rộng w. Trả về hàm đổi toạ độ ảnh gốc -> khung hình."""
    if path not in _shots: _shots[path] = Image.open(path).convert("RGB")
    im = _shots[path].crop(crop); k = w / im.width; h = int(im.height * k)
    if s > 0.01:
        d.rounded_rectangle([x - 8, y - 8, x + w + 8, y + h + 8], 16, fill=WHITE, outline=LINE, width=3)
        img.paste(im.resize((int(w), h), Image.LANCZOS), (int(x), int(y)))
    return lambda x0, y0, x1, y1: (x + (x0 - crop[0]) * k, y + (y0 - crop[1]) * k, x + (x1 - crop[0]) * k, y + (y1 - crop[1]) * k)

# ================= Trạng thái chu kỳ lương: thu nhập thay đổi theo từng ngày =================
def sc_states_new(img, d, t):
    to = Minv(t)
    G["sc_states"](img, d, to)
    if to < 92.54:                      # pha Công khai: thay nhãn cũ bằng thẻ thu nhập tạm tính theo ngày
        T0 = cn("hàng ngày", 74); k = pop(t, T0)
        if k > 0.01:
            day = 5 + int(clamp((t - T0) / 9.0) * 4)                 # ngày chạy tăng dần, thu nhập tạm tính tăng theo
            val = 8_950_000 + (day - 5) * 1_790_000
            card(d, 1640, 390, 380, 200, k, True, CYAN)
            text(d, (1640, 330), f"Ngày {day:02d}", 34 * k, CYAN)
            text(d, (1640, 385), "Thu nhập tạm tính", 22 * k, GREY, "Bold")
            text(d, (1640, 440), f"{val:,.0f} đ".replace(",", "."), 32 * k, GREEN)
            arrow(d, 1400, 390, 1445, 390, k, CYAN, 5)
        pill(d, 1250, 990, 640, 70, GREEN, "Nhân viên theo dõi kết quả thu nhập trong kỳ", 26, pop(t, cn("theo dõi", 80)))

# ================= Phạm vi nhân viên được xem phiếu lương: màn hình hệ thống =================
IMG_TC = U + "Tùy_chỉnh.png"           # 2879x1533 · Chỉnh sửa chu kỳ lương
TC_CROP = (1190, 230, 2420, 1040)
def sc_scope_new(img, d, t):
    to = Minv(t)
    G["sc_scope"](img, d, to)
    # che phần thẻ minh hoạ cũ bên trái bằng màn hình hệ thống thật
    img.paste(_BOARD_FULL.crop((40, 200, 740, 980)), (40, 200))
    s_ = pop(t, 137.0)
    if s_ > 0.01:
        X = panel(img, d, IMG_TC, TC_CROP, 60, 230, 640, s_)
        if t >= cn("đơn vị trí", 136):
            if t < cn("chọn tất", 145): hl(d, X(1830, 750, 2395, 1015), t)       # Đơn vị, VTCV muốn mở kì lương
            elif t < cn("chọn tùy", 150): hl(d, X(1830, 815, 2395, 862), t)       # Tất cả
            else: hl(d, X(1830, 860, 2390, 1015), t)                               # Tùy chỉnh + Chọn đối tượng
    hcard(d, 380, 820, 640, 110, pop(t, cn("nhân viên nào", 139)), NAVY, "people", "Xác định nhân viên nào được xem phiếu lương", 24)
    if t >= cn("theo từng giai", 172) - 0.3: pill(d, 380, 935, 600, 66, ORANGE, "Triển khai theo từng giai đoạn", 26, pop(t, cn("theo từng giai", 172)))

# ================= Xóa chu kỳ lương: chu kỳ chạy thử / kiểm tra kết quả =================
def sc_delete_new(img, d, t):
    to = Minv(t)
    if to >= c("tuy nhiên", 204.85):
        G["sc_delete"](img, d, to); return
    G["sc_delete"](img, d, to)
    # vẽ lại cột phải: 2 loại chu kỳ theo voice mới
    img.paste(_BOARD_FULL.crop((1220, 260, 1800, 790)), (1220, 260))
    img.paste(_BOARD_FULL.crop((0, 0, W, 140)), (0, 0)); d2 = ImageDraw.Draw(img)
    board_title(d2, t, "Chu kỳ dùng để chạy thử, kiểm tra kết quả", 190.3)
    fade = p(t, cn("được xóa", 196), 0.5)
    for j, (st, lab) in enumerate([(cn("chạy thử", 193), "Kỳ chạy thử"), (cn("kiểm tra kết", 193), "Kỳ kiểm tra kết quả")]):
        hcard(d2, 1500, 400 + j * 170, 440, 120, pop(t, st), mix_color(BLUE, 1 - 0.6 * fade), "calendar", lab, 30)

# ================= Thời điểm khóa dữ liệu công phép =================
IMG_LOCK = U + "1791534669138_image.png"   # 1280x696, có sẵn khung đỏ ở trường khóa công, phép
IMG_TIP = U + "1791534676218_image.png"    # 1280x691, tooltip thời gian duyệt công tối đa
TS_CROP = (470, 70, 1060, 450)
def sc_lock(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thời điểm khóa dữ liệu công phép", 257.3)
    s_ = pop(t, 257.6)
    if s_ > 0.01: panel(img, d, IMG_LOCK, TS_CROP, 70, 230, 820, s_)
    items = [(cn("nhân viên không", 258), "Nhân viên không thể gửi / điều chỉnh\nđề nghị công, phép, làm thêm của kỳ", "people", BLUE),
             (cn("quản lý cũng", 268), "Quản lý không thể phê duyệt\ncác đề nghị thuộc phạm vi đã khóa", "check", NAVY),
             (cn("mốc khóa", 272), "Mốc chốt dữ liệu đầu vào\ntrước khi hoàn tất tính lương", "lock", ORANGE)]
    for j, (st, lab, kind, col) in enumerate(items):
        hcard(d, 1430, 330 + j * 175, 820, 140, pop(t, st), col, kind, lab, 26, True)
    role_tag(img, d, CB, "C&B")

# ================= Thời gian duyệt công tối đa =================
def sc_approve_where(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thiết lập tại Tham số lương", 284.7)
    s_ = pop(t, 285.0)
    if s_ > 0.01:
        X = panel(img, d, IMG_TIP, TS_CROP, 460, 190, 1000, s_)
        if t >= cn("thiết lập này xác", 285): hl(d, X(501, 300, 760, 354), t); hl(d, X(646, 228, 834, 295), t)   # trường + chú thích
    pill(d, W / 2, 900, 900, 76, NAVY, "Quản lý được phê duyệt công trong phạm vi bao nhiêu ngày gần nhất", 24, pop(t, cn("được phép phê", 290)))
    role_tag(img, d, CB, "C&B")

DAYS = [("29", "Th.8"), ("30", "Th.8"), ("31", "Th.8"), ("01", "Th.9"), ("02", "Th.9"), ("03", "Th.9")]
def day_strip(d, t, y, today, ok, locked=(), x0=420, k=1.0):
    for i, (dd, mm) in enumerate(DAYS):
        x = x0 + i * 180
        on = i in ok; lk = i in locked
        fill = (220, 245, 228) if on else ((255, 232, 232) if lk else (238, 242, 252))
        out = GREEN if on else (RED if lk else (205, 212, 230))
        d.rounded_rectangle([x - 78, y - 50, x + 78, y + 50], 14, fill=fill, outline=out, width=4 if (on or lk) else 2)
        text(d, (x, y - 12), dd, 40, INK); text(d, (x, y + 26), mm, 22, GREY, "Bold")
        if on: badge(d, x + 70, y - 46, True, 1.0, 18)
        if lk: icon(d, "lock", x + 70, y - 46, 1.0, RED, 26)
        if i == today:
            text(d, (x, y - 95), "Hôm nay", 26, ORANGE)
            d.polygon([(x - 14, y - 74), (x + 14, y - 74), (x, y - 58)], fill=ORANGE)

def sc_approve_ex(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ví dụ: thời gian duyệt công tối đa = 3 ngày", 292.6)
    if t < cn("sang ngày", 304):   today, ok, lk, note = 3, (1, 2, 3), (), "Ngày 01/09: quản lý duyệt công ngày 30/08, 31/08, 01/09"
    elif t < cn("trong ví dụ", 314): today, ok, lk, note = 4, (2, 3, 4), (), "Ngày 02/09 (trước 12h): duyệt công ngày 31/08, 01/09, 02/09"
    else:           today, ok, lk, note = 4, (3, 4), (2,), "Từ 12h ngày 02/09: dữ liệu kỳ tháng 8 đã khóa → không duyệt được 31/08"
    if t >= cn("ví dụ thời", 292): day_strip(d, t, 470, today, ok, lk)
    if t >= cn("trong ví dụ", 314):
        pill(d, W / 2, 300, 900, 66, RED, "12h ngày 02/09 = thời điểm khóa dữ liệu kỳ lương tháng 8", 24, pop(t, cn("trong ví dụ", 314)))
    hcard(d, W / 2, 720, 1300, 110, pop(t, cn("ví dụ thời", 292) + 1.5 if t < cn("sang ngày", 304) else (cn("sang ngày", 304) if t < cn("trong ví dụ", 314) else cn("trong ví dụ", 314) + 4)),
          GREEN if t < cn("trong ví dụ", 314) else RED, "calendar" if t < cn("trong ví dụ", 314) else "lock", note, 26, True)
    role_tag(img, d, MANAGER, "Quản lý")

def sc_two_rules(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Phân biệt hai thiết lập", 330.3)
    for j, (st, title, sub, col, kind, ok, lk) in enumerate([
            (cn("như vậy thời", 328), "Thời gian duyệt công tối đa", "Xác định phạm vi ngày\nquản lý được phép xử lý", BLUE, "check", (2, 3, 4), ()),
            (cn("còn thời điểm", 332), "Thời điểm khóa dữ liệu", "Xác định mốc cập nhật\ncủa kỳ lương", RED, "lock", (3, 4), (2,))]):
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        x = 500 + j * 920
        card(d, x, 560, 860, 640, s_, True, col)
        icon(d, kind, x - 330, 300, s_, col, 56)
        text(d, (x + 30, 300), title, 32 * s_, INK, anchor="mm")
        text(d, (x, 400), sub, 26 * s_, col, "Bold")
        if s_ > 0.95:
            for i, (dd, mm) in enumerate(DAYS[1:5]):
                xx = x - 270 + i * 180; idx = i + 1
                on = idx in ok; l_ = idx in lk
                d.rounded_rectangle([xx - 70, 530, xx + 70, 620], 12, fill=(220, 245, 228) if on else ((255, 232, 232) if l_ else (238, 242, 252)),
                                    outline=GREEN if on else (RED if l_ else (205, 212, 230)), width=3)
                text(d, (xx, 560), dd, 32, INK); text(d, (xx, 596), mm, 18, GREY, "Bold")
                if on: badge(d, xx + 62, 528, True, 1.0, 15)
                if l_: icon(d, "lock", xx + 62, 528, 1.0, RED, 22)
            text(d, (x, 690), "Ngày 02/09: duyệt 31/08, 01/09, 02/09" if j == 0 else "Sau 12h 02/09: 31/08 thuộc kỳ đã khóa",
                 24, GREEN if j == 0 else RED, "Bold")
    role_tag(img, d, CB, "C&B")

def sub(key, kicker, lines, size=96):
    return lambda img, d, t: sub_card(img, d, t, HN[key], kicker, lines, size)

def sc_part_new(img, d, t): G["sc_part"](img, d, min(t, 1.2))

SCENES = [(-OFFSET, 3.3, "part"), (3.3, HN["ckl"], "intro"), (HN["ckl"], 36.0, "h_ckl"), (36.0, M(52.38), "ckl_def"),
          (M(52.38), M(59.87), "ckl_rec"), (M(59.87), 60.9, "ckl_states"), (60.9, HN["scope"], "states"),
          (HN["scope"], 135.8, "h_scope"), (135.8, HN["delete"], "scope"), (HN["delete"], 190.3, "h_delete"),
          (190.3, HN["tsl"], "delete"), (HN["tsl"], 223.9, "h_tsl"), (223.9, HN["lock"], "tsl_problem"),
          (HN["lock"], 257.3, "h_lock"), (257.3, HN["approve"], "lock"), (HN["approve"], 284.7, "h_approve"),
          (284.7, 292.5, "approve_where"), (292.5, 330.3, "approve_ex"), (330.3, HN["after"], "two_rules"),
          (HN["after"], 342.2, "h_after"), (342.2, 377.2, "after"), (377.2, HN["link"], "principle"),
          (HN["link"], 398.3, "h_link"), (398.3, 436.4, "link"), (436.4, 445.2, "outro1"), (445.2, 999, "outro2")]

def intro_old(img, d, t):
    to = Minv(t)
    fn = G["sc_intro1"] if to < 13.94 else (G["sc_intro2"] if to < 20.13 else G["sc_intro3"])
    fn(img, d, to)

FN = dict(part=sc_part_new, intro=intro_old,
          h_ckl=sub("ckl", "PHẦN 4", ["CHU KỲ LƯƠNG"], 118), ckl_def=old(G["sc_ckl_def"]), ckl_rec=old(G["sc_ckl_rec"]),
          ckl_states=old(G["sc_ckl_states"]), states=sc_states_new,
          h_scope=sub("scope", "CHU KỲ LƯƠNG", ["PHẠM VI NHÂN VIÊN", "ĐƯỢC XEM PHIẾU LƯƠNG"], 84), scope=sc_scope_new,
          h_delete=sub("delete", "CHU KỲ LƯƠNG", ["XÓA CHU KỲ LƯƠNG"], 96), delete=sc_delete_new,
          h_tsl=sub("tsl", "PHẦN 4", ["THAM SỐ LƯƠNG"], 118), tsl_problem=old(G["sc_tsl_problem"]),
          h_lock=sub("lock", "THAM SỐ LƯƠNG", ["THỜI ĐIỂM KHÓA", "DỮ LIỆU CÔNG PHÉP"], 96), lock=sc_lock,
          h_approve=sub("approve", "THAM SỐ LƯƠNG", ["THỜI GIAN DUYỆT", "CÔNG TỐI ĐA"], 96), approve_where=sc_approve_where,
          approve_ex=sc_approve_ex, two_rules=sc_two_rules,
          h_after=sub("after", "THAM SỐ LƯƠNG", ["KIỂM SOÁT DỮ LIỆU", "SAU THỜI ĐIỂM KHÓA"], 80), after=old(G["sc_after"]),
          principle=old(G["sc_principle"]), h_link=sub("link", "PHẦN 4", ["MỐI LIÊN HỆ", "VỚI BẢNG LƯƠNG"], 96),
          link=old(G["sc_link"]), outro1=old(G["sc_outro1"]), outro2=old(G["sc_outro2"]))

def preview(times):
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.resize((960, 540)).save(f"/tmp/pv4b_{tv}.png")

N = 12
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p4b_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p4b_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
