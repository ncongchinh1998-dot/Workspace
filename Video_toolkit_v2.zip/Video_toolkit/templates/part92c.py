"""PHẦN 9.2 (voice 01/11/2026 bản cuối, b01134) — giữ cảnh part92b, ánh xạ thời gian (lệch ≤ 0,9 s, bỏ 1 từ).
Cập nhật: cảnh câu hỏi 3–4 dùng màn hình danh sách "Cách thể hiện" thật + ô "Chạy một lần cuối chu kỳ" (không hiển thị sẵn một giá trị gây hiểu nhầm)."""
import sys, math
from hw_core import *
from remap_voice import make_maps
import part92b as Q
from part81 import IMG_DD, DD_FULL, XDD, DD_LIST

M, Minv = make_maps(A + "words_p92b.json", A + "words_p92e.json")
VOICE = A + "voice_p92e.wav"
OFFSET = 1.0
VOICE_DUR = 303.78
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = Q.OUT
SFX_AT = [0.0]

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
Q.hl = lambda d, box, t=0.0, kind="rect": hl(d, box, t)
Q.P.hl = Q.hl
import part81; part81.hl = Q.hl

DD_CHAY = (1822, 1110, 2182, 1156)       # ô "Chạy một lần cuối chu kỳ" trên màn hình có danh sách cách thể hiện
def sc_setup(img, d, t):                  # t theo voice cũ (đã qua Minv)
    fs_shot(img, IMG_DD, DD_FULL, DD_FULL, 0)
    top_title(d, t, "Cách thể hiện & cách chạy nào cho kết quả 25,5 công?", 148.8)
    if 149.2 <= t < 150.0: hl(d, XDD(*DD_LIST), t)
    if t >= 150.0: hl(d, XDD(*DD_LIST), t); hl(d, XDD(*DD_CHAY), t)
    role_tag(img, d, CB, "C&B")
Q.FN["setup"] = sc_setup

def old(fn): return lambda img, d, t: fn(img, d, Minv(t))
SCENES = [(s if s < 0 else M(s), 999 if e >= 999 else M(e), n) for s, e, n in Q.SCENES]
FN = {n: old(Q.FN[n]) for _, _, n in SCENES}
FN["h_th1"] = Q.FN["h_th1"]

def preview(times, out="/tmp/pv92c"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 11
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p92c_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p92c_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
