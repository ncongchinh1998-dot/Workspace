"""PHẦN 8.1 — CÔNG THỨC LƯƠNG (đoạn 1)
Mục: Công thức lương là gì · Ba yếu tố quyết định kết quả · Trước khi viết cần xác định gì ·
     Thiết lập thông tin cơ bản · Viết quy tắc công thức · Các hàm · Cách thể hiện trên bảng lương · Mẹo nhỏ.
Toạ độ khung: đo trên ảnh gốc (OCR + vẽ kiểm, xem /tmp/cf*.png)."""
import sys, math
from hw_core import *
from PIL import ImageFont
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p81b.wav"          # voice sửa từ đọc sai 27/10/2026 (timing lệch < 0,25 s)
OFFSET = 1.0
VOICE_DUR = 330.61
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan8_1_Cong_thuc_luong.mp4"
HD = dict(p8=-0.6, lagi=11.6, yeuto=35.2, xacdinh=52.4, thietlap=78.2, viet=181.4, ham=220.5, cth=255.6, meo=291.5)
SFX_AT = [0.0] + [OFFSET + v for v in list(HD.values())[1:]]

IMG_FORM = U + "Màu_sắc_phân_biệt_trong_công_thức.png"          # 2795x1519 form công thức lương (Phụ cấp trách nhiệm)
IMG_KQ = U + "Kết_quả_tính_lương.png"                            # 2808x1530 bảng lương view ngang
IMG_TN = U + "Thực_nhận.png"                                     # 2877x1530 bảng lương (cột Tổng thu nhập, Thực nhận)
IMG_DS = U + "Tìm_kiếm_công_thức_lương_trong_công_thức_lương_khác.png"   # 2879x1697 danh sách công thức lương
IMG_HAM = U + "Hàm.png"                                          # 2861x1598 Excel các hàm

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    w_ = 6 + int(2 * abs(math.sin(t * 5)))
    d.rounded_rectangle(box, 10, outline=RED, width=w_)

def sub_card(img, d, t, t0, kicker, lines, size=96):
    paste(img, SECTION)
    pill(d, 280, 280, 340, 76, BLUE, kicker, 30, pop(t, t0 + 0.05), weight="ExtraBold")
    for j, line in enumerate(lines):
        k = p(t, t0 + 0.15 + j * 0.12, 0.45)
        if k > 0: text(d, (110, 430 + j * size * 1.12 + (1 - k) * 50), line, size, NAVY, anchor="lm", align="left")
    underline(d, 115, 430 + (len(lines) - 1) * size * 1.12 + size * 0.75, 700, p(t, t0 + 0.45, 0.5))
    person(img, d, CB, 1220, 900, 340, pop(t, t0 + 0.4, 0.5), "C&B", 30)

def hl_pad(d, box, t, pad):
    """khung lề hẹp (chữ sát dòng trên/dưới): co box trước khi hl nới HL_PAD"""
    k = HL_PAD - pad
    hl(d, (box[0] + k, box[1] + k, box[2] - k, box[3] - k), t)

def shot_xy(box):
    k = 1920 / (box[2] - box[0])
    return lambda x0, y0, x1, y1: ((x0 - box[0]) * k, (y0 - box[1]) * k, (x1 - box[0]) * k, (y1 - box[1]) * k)
def full_of(iw, ih): return box169(iw / 2, ih / 2, iw, iw, ih)
FORM_FULL = full_of(2795, 1519); XF = shot_xy(FORM_FULL)
KQ_FULL = full_of(2808, 1530); XK = shot_xy(KQ_FULL)
TN_FULL = full_of(2877, 1530); XT = shot_xy(TN_FULL)
DS_FULL = full_of(2879, 1697); XD = shot_xy(DS_FULL)
HAM_FULL = full_of(2861, 1598); XH = shot_xy(HAM_FULL)

def S(k): return lambda x0, y0, x1, y1: (x0 * k, y0 * k, x1 * k, y1 * k)       # toạ độ ảnh hiển thị → ảnh gốc
KQ = S(2808 / 2576); TN = S(2877 / 2576); DSK = S(2879 / 2518)

# ---------- form công thức lương (toạ độ ảnh gốc) ----------
F = dict(TEN=(1222, 250, 1778, 362), MA=(1222, 370, 1778, 480), NHOM=(1820, 370, 2374, 480), CT=(1222, 492, 2374, 828),
         MOTA=(1222, 838, 1778, 948), TTS=(1820, 838, 2374, 948), CTH=(1222, 952, 1778, 1067), NBD=(1820, 952, 2374, 1075),
         THUTU=(1222, 1080, 1778, 1200), DVT=(1820, 1084, 2374, 1195), CHAY=(1822, 1212, 2190, 1268),
         IF=(1313, 618, 1341, 651), PCTN=(1313, 664, 1797, 701), CCKL=(1928, 616, 2235, 653))
def form(img): fs_shot(img, IMG_FORM, FORM_FULL, FORM_FULL, 0)
def fhl(d, key, t): hl(d, XF(*F[key]), t)

# Excel hàm: sửa đè lỗi gõ ở dòng "<=" (file gốc ghi ">")
_inter = ImageFont.truetype(A + "Inter.ttf", 27); _inter.set_variation_by_name("Regular")
HAM_FIX = "/tmp/p81_ham_fix.png"
def _fix_ham():
    import os
    if os.path.exists(HAM_FIX): return
    im = Image.open(IMG_HAM).convert("RGB"); dd = ImageDraw.Draw(im)
    dd.rectangle([313, 1527, 760, 1561], fill=WHITE)
    dd.text((316, 1530), "(logical/ number <= logical/ number)", font=_inter, fill=(0, 0, 0))
    im.save(HAM_FIX)
_fix_ham()
HAM = dict(IF=(52, 663, 2666, 722), ANDOR=(52, 729, 2666, 844), MAXMIN=(52, 950, 2666, 1034), ALL=(52, 592, 2666, 1563))

def mini_chip(d, cx, cy, w, h, lab, col, s=1.0, size=22):
    if s <= 0.01: return
    w, h = w * s, h * s
    d.rounded_rectangle([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], h / 2, fill=col)
    text(d, (cx, cy), lab, fit_size(d, lab, size * s, "Bold", w - 24 * s), WHITE, "Bold")

def badge(d, x, y, ok, s, r0=24):
    if s <= 0.01: return
    r = r0 * s; w = max(int(6 * s), 1)
    d.ellipse([x - r, y - r, x + r, y + r], fill=GREEN if ok else RED)
    if ok: d.line([x - r * 0.45, y, x - r * 0.1, y + r * 0.4, x + r * 0.5, y - r * 0.35], fill=WHITE, width=w, joint="curve")
    else:
        d.line([x - r * 0.4, y - r * 0.4, x + r * 0.4, y + r * 0.4], fill=WHITE, width=w)
        d.line([x - r * 0.4, y + r * 0.4, x + r * 0.4, y - r * 0.4], fill=WHITE, width=w)

# ================= Mở đầu =================
def sc_h_p8(img, d, t): sub_card(img, d, t, HD["p8"], "PHẦN 8", ["CÔNG THỨC LƯƠNG"], 110)

def sc_intro(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Đã có nền tảng, bước tiếp theo là công thức lương", 2.4, size=52)
    hcard(d, 560, 360, 760, 150, pop(t, 3.5), GREEN, "db", "Thành phần lương\nchứa dữ liệu", 30, True)
    hcard(d, 560, 560, 760, 150, pop(t, 5.8), NAVY, "logic", "Nhóm công thức\ntổ chức cấu trúc phiếu lương", 28, True)
    arrow(d, 960, 460, 1090, 460, p(t, 9.5, 0.4), ORANGE, 8)
    s_ = pop(t, 10.0)
    if s_ > 0.01:
        card(d, 1430, 460, 560, 360, s_, True, ORANGE)
        icon(d, "fx", 1430, 390, s_, ORANGE, 70)
        text(d, (1430, 500), "CÔNG THỨC LƯƠNG", 38 * s_, NAVY)
        k = pop(t, 10.4, 0.4)
        if k > 0.01: text(d, (1430, 560), "Phần quan trọng nhất", 26 * k, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B", pop(t, 3.0, 0.4))

# ================= Công thức lương là gì =================
def sc_h_lagi(img, d, t): sub_card(img, d, t, HD["lagi"], "PHẦN 8", ["CÔNG THỨC LƯƠNG", "LÀ GÌ?"], 104)

def sc_lagi(img, d, t):
    if t < 21.3:
        paste(img, BOARD)
        board_title(d, t, "C&B chuyển cách tính lương thành quy tắc", 13.7, size=54)
        steps = [(15.8, "Cách tính lương\nthực tế", "doc", BLUE), (17.4, "Quy tắc\ntrên Haraworks", "fx", ORANGE), (19.2, "Haraworks\nthực hiện tính toán", "run", GREEN)]
        for i, (st, lab, kind, col) in enumerate(steps):
            vcard(d, 480 + i * 480, 540, 400, 360, pop(t, st), col, kind, lab, 28, True)
            if i: arrow(d, 480 + (i - 1) * 480 + 210, 540, 480 + i * 480 - 210, 540, p(t, st - 0.2, 0.4), ORANGE, 7)
        role_tag(img, d, CB, "C&B")
        return
    fs_shot(img, IMG_KQ, KQ_FULL, KQ_FULL, 0)
    top_title(d, t, "Mỗi công thức lương ↔ một thông tin / kết quả trên bảng lương", 21.4)
    if t >= 23.3: hl(d, XK(*KQ(1012, 362, 1200, 1155)), t)                 # cột Lương Thực Tế
    role_tag(img, d, CB, "C&B")

def sc_hieu(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Trước khi viết công thức trên Haraworks", 28.3, size=54)
    s_ = pop(t, 31.4)
    if s_ > 0.01:
        card(d, W / 2, 520, 1100, 300, s_, True, ORANGE)
        icon(d, "search", W / 2 - 400 * s_, 520, s_, ORANGE, 80)
        text(d, (W / 2 + 80, 480), "Hiểu rõ quy tắc nghiệp vụ", 44 * s_, NAVY)
        k = pop(t, 33.2, 0.4)
        if k > 0.01: text(d, (W / 2 + 80, 560), "mà công thức đó đang thể hiện", 30 * k, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B", pop(t, 28.6, 0.4))

# ================= Ba yếu tố =================
def sc_h_yeuto(img, d, t): sub_card(img, d, t, HD["yeuto"], "PHẦN 8", ["BA YẾU TỐ QUYẾT ĐỊNH", "KẾT QUẢ CÔNG THỨC LƯƠNG"], 78)

def sc_yeuto(img, d, t):
    form(img)
    top_title(d, t, "Kiểm tra đồng thời ba yếu tố", 38.3)
    if t >= 43.6: fhl(d, "CT", t)
    if t >= 45.9: fhl(d, "CTH", t)
    if t >= 48.5: fhl(d, "CHAY", t)
    chip_bar(d, t, [(43.6, "1. Nội dung công thức", RED), (45.9, "2. Cách thể hiện trên bảng lương", RED),
                    (48.5, "3. Chạy một lần cuối chu kỳ hay chạy hàng ngày", RED)], size=22)
    role_tag(img, d, CB, "C&B")

# ================= Trước khi viết công thức =================
def sc_h_xd(img, d, t): sub_card(img, d, t, HD["xacdinh"], "PHẦN 8", ["TRƯỚC KHI VIẾT CÔNG THỨC", "CẦN XÁC ĐỊNH GÌ?"], 80)

QS = [(59.7, "Khoản này được tính dựa trên dữ liệu nào?", "db", BLUE), (62.2, "Dữ liệu đó được lấy từ đâu?", "search", CYAN),
      (64.1, "Điều kiện áp dụng là gì?", "logic", ORANGE), (65.9, "Nhiều trường hợp: quy tắc xử lý thế nào?", "compare", NAVY),
      (69.6, "Kết quả cuối cùng công thức cần trả về là gì?", "check", GREEN)]
def sc_xd(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Với mỗi công thức lương, xác định trước", 56.8, size=54)
    for j, (st, lab, kind, col) in enumerate(QS):
        hcard(d, W / 2 + 60, 250 + j * 132, 1180, 108, pop(t, st), col, kind, lab, 30, True)
    pill(d, W / 2 + 60, 945, 1080, 76, ORANGE, "Rõ các thông tin này → mới thiết lập công thức trên Haraworks", 26, pop(t, 74.4))
    role_tag(img, d, CB, "C&B")

# ================= Thiết lập thông tin cơ bản =================
def sc_h_tl(img, d, t): sub_card(img, d, t, HD["thietlap"], "PHẦN 8", ["THIẾT LẬP THÔNG TIN CƠ BẢN", "CỦA CÔNG THỨC LƯƠNG"], 76)

def sc_them(img, d, t):
    fs_shot(img, IMG_DS, DS_FULL, DS_FULL, 0)
    top_title(d, t, "Danh sách công thức lương", 82.3)
    if t >= 84.3: hl(d, XD(*DSK(181, 291, 357, 352)), t)
    role_tag(img, d, CB, "C&B")

TOUR = [(88.1, "TEN"), (89.0, "MA"), (89.8, "NHOM"), (90.9, "CT"), (92.1, "MOTA"), (92.9, "TTS"), (93.7, "NBD"), (94.7, "THUTU"), (96.2, "DVT")]
def sc_fields(img, d, t):
    form(img)
    if t < 97.2:
        top_title(d, t, "Thông tin công thức lương", 86.1)
        cur = None
        for st, k in TOUR:
            if t >= st: cur = k
        if cur and t < 97.0: fhl(d, cur, t)
    elif t < 106.2:
        top_title(d, t, "Tên công thức", 97.3)
        fhl(d, "TEN", t)
        chip_bar(d, t, [(97.8, "Tên nên phản ánh rõ kết quả công thức tạo ra", NAVY)], size=24)
    elif t < 116.2:
        top_title(d, t, "Mã công thức", 106.3)
        fhl(d, "MA", t)
        if t < 112.9: chip_bar(d, t, [(108.0, "Mã không thể chỉnh sửa sau khi tạo: xác định cẩn thận ngay từ đầu", RED)], size=24)
        else: chip_bar(d, t, [(113.0, "Có thể tự đặt mã theo hệ thống riêng của doanh nghiệp", NAVY)], size=24)
    elif t < 126.3:
        top_title(d, t, "Nhóm công thức", 116.3)
        fhl(d, "NHOM", t)
        if t < 122.0: chip_bar(d, t, [(118.1, "Chọn nhóm để công thức hiển thị trên phiếu lương của nhân viên", GREEN)], size=24)
        else: chip_bar(d, t, [(122.0, "Không chọn nhóm → không hiển thị trên phiếu lương của nhân viên", NAVY)], size=24)
    elif t < 135.4:
        top_title(d, t, "Mô tả công thức", 126.4)
        fhl(d, "MOTA", t)
        chip_bar(d, t, [(128.5, "Giải thích ngắn mục đích hoặc cách tính, thuận tiện tra cứu & kiểm tra sau này", NAVY)], size=22)
    elif t < 145.4:
        top_title(d, t, "Ngày bắt đầu", 135.5)
        fhl(d, "NBD", t)
        chip_bar(d, t, [(139.3, "Chỉ ghi nhận thời điểm vận hành, không quyết định thời điểm công thức bắt đầu hoạt động", ORANGE)], size=21)
    elif t < 160.0:
        top_title(d, t, "Thứ tự hiển thị", 155.6)
        fhl(d, "THUTU", t)
        chip_bar(d, t, [(157.4, "Dùng để sắp xếp các công thức trên bảng lương", NAVY)], size=24)
    else:
        top_title(d, t, "Đơn vị tính", 176.3)
        fhl(d, "DVT", t)
        chip_bar(d, t, [(178.4, "Chọn đơn vị phù hợp với kết quả cần hiển thị", NAVY)], size=24)
    role_tag(img, d, CB, "C&B")

NAME_COLS = [(101.2, "kq", (812, 362, 1005, 1155)), (102.1, "kq", (1012, 362, 1200, 1155)), (103.1, "kq", (2002, 362, 2195, 1155)),
             (104.0, "tn", (1318, 362, 1505, 1185)), (105.5, "tn", (2287, 362, 2470, 1185))]
def sc_names(img, d, t):
    if t < 103.9:
        fs_shot(img, IMG_KQ, KQ_FULL, KQ_FULL, 0); XX, SS = XK, KQ; src = "kq"
    else:
        fs_shot(img, IMG_TN, TN_FULL, TN_FULL, 0); XX, SS = XT, TN; src = "tn"
    top_title(d, t, "Ví dụ tên công thức trên bảng lương", 100.6)
    cur = None
    for st, s_, b in NAME_COLS:
        if t >= st and s_ == src: cur = b
    if cur: hl(d, XX(*SS(*cur)), t)
    role_tag(img, d, CB, "C&B")

def sc_nbd(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ví dụ: ngày bắt đầu không quyết định kỳ được tính", 145.5, size=52)
    hcard(d, 520, 380, 680, 140, pop(t, 147.0), BLUE, "calendar", "Ngày bắt đầu: 01/09", 32, True)
    hcard(d, 520, 600, 680, 140, pop(t, 149.4), ORANGE, "run", "Chạy chu kỳ lương tháng 08", 30, True)
    arrow(d, 880, 490, 1040, 490, p(t, 151.2, 0.4), ORANGE, 8)
    s_ = pop(t, 151.3)
    if s_ > 0.01:
        card(d, 1390, 490, 620, 320, s_, True, GREEN)
        text(d, (1390, 440), "Công thức vẫn được tính", 34 * s_, INK)
        text(d, (1390, 520), "& trả kết quả theo dữ liệu\nkỳ lương tháng 08", 28 * s_, GREEN, "Bold")
        badge(d, 1660, 350, True, pop(t, 152.6, 0.4), 32)
    role_tag(img, d, CB, "C&B")

def colchip(d, x, y, lab, num, col, s):
    if s <= 0.01: return
    card(d, x, y, 260, 170, s, True, col)
    if s > 0.6:
        text(d, (x, y - 30), lab, 28, INK)
        text(d, (x, y + 35), num, fit_size(d, num, 24, "Bold", 230), col, "Bold")
def sc_order(img, d, t):
    if t < 160.2:
        fs_shot(img, IMG_KQ, KQ_FULL, KQ_FULL, 0)
        top_title(d, t, "Thứ tự hiển thị: sắp xếp các cột công thức trên bảng lương", 158.0)
        if t >= 158.6: hl(d, XK(*KQ(200, 358, 2380, 445)), t)
        role_tag(img, d, CB, "C&B")
        return
    paste(img, BOARD)
    board_title(d, t, "Thứ tự nhỏ nhất xếp ngoài cùng bên trái", 160.2, size=54)
    text(d, (W / 2, 205), "Bảng lương (từ trái sang phải)", 28 * max(pop(t, 160.4), 0.3), GREY, "Bold")
    if t < 169.8:
        cols = [("A", "Thứ tự 1", BLUE, 160.6), ("B", "Thứ tự 2", BLUE, 160.9), ("C", "Thứ tự 3", BLUE, 161.2)]
        if t >= 163.9: cols = [("A", "Thứ tự 1", BLUE, 0), ("B", "Thứ tự 2", ORANGE, 164.5), ("D", "Thứ tự 2", ORANGE, 164.6), ("C", "Thứ tự 3", BLUE, 0)]
        for i, (lab, num, col, st) in enumerate(cols):
            colchip(d, 360 + i * 300, 420, lab, num, col, pop(t, st) if st else 1)
        if t >= 166.7:
            pill(d, W / 2, 640, 900, 76, ORANGE, "Cùng thứ tự → Haraworks sắp xếp theo bảng chữ cái A → Z", 26, pop(t, 166.7))
    else:
        cols = [("E", "Thứ tự trống", RED, 171.0), ("A", "Thứ tự 1", BLUE, 0), ("B", "Thứ tự 2", BLUE, 0), ("C", "Thứ tự 3", BLUE, 0)]
        for i, (lab, num, col, st) in enumerate(cols):
            colchip(d, 360 + i * 300, 420, lab, num, col, pop(t, st) if st else 1)
        pill(d, W / 2, 640, 1000, 76, RED, "Không nhập thứ tự = thứ tự 0 → xếp bên trái công thức có thứ tự 1", 26, pop(t, 172.2))
    role_tag(img, d, CB, "C&B")

# ================= Viết quy tắc công thức =================
def sc_h_viet(img, d, t): sub_card(img, d, t, HD["viet"], "PHẦN 8", ["VIẾT QUY TẮC CÔNG THỨC"], 92)

def sc_viet(img, d, t):
    if t < 192.4:
        paste(img, BOARD)
        board_title(d, t, "Xây dựng quy tắc tính toán từ", 184.1, size=54)
        items = [(187.4, "Thành phần lương", "db", GREEN), (188.2, "Công thức lương khác", "fx", BLUE),
                 (189.4, "Các hàm", "logic", RED), (190.5, "Các điều kiện", "q", ORANGE)]
        for i, (st, lab, kind, col) in enumerate(items):
            vcard(d, 360 + i * 400, 540, 360, 320, pop(t, st), col, kind, lab, 28, True)
        role_tag(img, d, CB, "C&B")
        return
    form(img)
    top_title(d, t, "Màu sắc giúp nhận biết từng loại dữ liệu", 192.5)
    if 197.1 <= t < 199.4: hl_pad(d, XF(*F["PCTN"]), t, 3)
    if 199.4 <= t < 201.3: hl_pad(d, XF(*F["CCKL"]), t, 3)
    if 201.3 <= t < 203.4: hl_pad(d, XF(*F["IF"]), t, 3)
    if t >= 203.4: fhl(d, "CT", t)
    if t < 205.9:
        chip_bar(d, t, [(197.1, "Xanh lá: thành phần lương", GREEN), (199.4, "Xanh dương: công thức lương", BLUE), (201.3, "Đỏ: hàm", RED)], size=24)
    else:
        chip_bar(d, t, [(205.9, "Dữ liệu đầu vào", GREEN), (207.4, "Kết quả lấy từ công thức khác", BLUE),
                        (209.6, "Xử lý điều kiện hoặc tính toán", RED)], size=24)
    role_tag(img, d, CB, "C&B")

def sc_vidu(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ví dụ kết hợp dữ liệu trong một công thức", 212.6, size=54)
    s1 = pop(t, 214.5)
    if s1 > 0.01:
        card(d, 470, 480, 560, 260, s1, True, GREEN)
        text(d, (470, 440), "Mức lương", 40 * s1, GREEN)
        text(d, (470, 510), "lấy từ thành phần lương", 26 * s1, GREY, "Bold")
    s0 = pop(t, 216.7)
    if s0 > 0.01: text(d, (W / 2, 480), "kết hợp", 34 * s0, ORANGE)
    s2 = pop(t, 217.5)
    if s2 > 0.01:
        card(d, 1450, 480, 560, 260, s2, True, BLUE)
        text(d, (1450, 440), "Tổng công", 40 * s2, BLUE)
        text(d, (1450, 510), "kết quả từ công thức lương khác", 24 * s2, GREY, "Bold")
    arrow(d, W / 2, 640, W / 2, 740, p(t, 219.3, 0.4), ORANGE, 8)
    s3 = pop(t, 219.5)
    if s3 > 0.01:
        card(d, W / 2, 830, 640, 140, s3, True, ORANGE)
        text(d, (W / 2, 830), "Kết quả công thức", 36 * s3, NAVY)
    role_tag(img, d, CB, "C&B")

# ================= Các hàm =================
def sc_h_ham(img, d, t): sub_card(img, d, t, HD["ham"], "PHẦN 8", ["CÁC HÀM SỬ DỤNG", "TRONG CÔNG THỨC"], 92)

def sc_ham(img, d, t):
    fs_shot(img, HAM_FIX, HAM_FULL, HAM_FULL, 0)
    if t < 234.3: top_title(d, t, "Hàm & toán tử Haraworks hỗ trợ", 223.0)
    elif t < 238.5: top_title(d, t, "IF: kiểm tra điều kiện & trả về kết quả tương ứng", 234.4)
    elif t < 242.2: top_title(d, t, "AND, OR: kết hợp nhiều điều kiện", 238.6)
    elif t < 247.3: top_title(d, t, "MIN, MAX: giá trị nhỏ nhất / lớn nhất trong các giá trị đang xét", 242.3)
    else: top_title(d, t, "Tham chiếu danh sách hàm & toán tử khác theo quy tắc cần xây dựng", 247.4)
    if 230.9 <= t < 231.7 or 234.5 <= t < 238.5: hl(d, XH(*HAM["IF"]), t)          # voice liệt kê: IF → AND, OR → MIN, MAX
    if 231.7 <= t < 233.2: hl(d, XH(*HAM["ANDOR"]), t)
    if 233.2 <= t < 234.5: hl_pad(d, XH(*HAM["MAXMIN"]), t, 5)
    if 238.6 <= t < 242.2: hl(d, XH(*HAM["ANDOR"]), t)
    if 242.3 <= t < 247.3: hl_pad(d, XH(*HAM["MAXMIN"]), t, 5)
    if t >= 251.2: hl(d, XH(*HAM["ALL"]), t)

# ================= Cách thể hiện =================
def sc_h_cth(img, d, t): sub_card(img, d, t, HD["cth"], "PHẦN 8", ["CÁCH THỂ HIỆN", "TRÊN BẢNG LƯƠNG"], 84)

CTH_OPTS = [(274.7, "Tổng"), (275.2, "Giá trị trung bình"), (276.4, "Giá trị đầu tiên"), (277.6, "Giá trị cuối cùng"),
            (278.8, "Giá trị lớn nhất"), (280.1, "Giá trị nhỏ nhất"), (281.4, "Giá trị xuất hiện nhiều nhất"),
            (282.9, "Giá trị đầu tiên khác không"), (285.0, "Giá trị cuối cùng khác không")]
IMG_DD = U + "Cách_thể_hiện_trên_bảng_lương.png"      # 2793x1515 form có danh sách cách thể hiện đang mở
DD_FULL = full_of(2793, 1515); XDD = shot_xy(DD_FULL)
DD_FIELD = (1226, 846, 1772, 950); DD_LIST = (1234, 952, 1770, 1388)
DD_ROWS = [959, 1007, 1055, 1103, 1151, 1199, 1247, 1295, 1343]   # Tổng, TB, Cuối cùng, Đầu tiên, Lớn nhất, Bé nhất, XH nhiều nhất, Đầu tiên ≠0, Cuối cùng ≠0
DD_SEQ = [(274.7, 0), (275.2, 1), (276.4, 3), (277.6, 2), (278.8, 4), (280.1, 5), (281.4, 6), (282.9, 7), (285.0, 8)]   # theo thứ tự voice đọc
def sc_cth(img, d, t):
    if t < 273.2:
        form(img)
        top_title(d, t, "Yếu tố thứ hai ảnh hưởng trực tiếp đến kết quả công thức", 262.8)
        if t >= 261.3: fhl(d, "CTH", t)
        chip_bar(d, t, [(267.1, "Haraworks xử lý dãy giá trị ghi nhận trong kỳ theo cách này để trả ra kết quả", NAVY)], size=22)
        role_tag(img, d, CB, "C&B")
        return
    # màn hình hệ thống: danh sách lựa chọn "Cách thể hiện trên bảng lương" đang mở
    fs_shot(img, IMG_DD, DD_FULL, DD_FULL, 0)
    top_title(d, t, "Các lựa chọn cách thể hiện trên bảng lương", 273.3)
    cur = None
    for st, row in DD_SEQ:
        if t >= st: cur = row
    if t < 274.6: hl(d, XDD(*DD_LIST), t)
    elif cur is not None and t < 287.5: hl_pad(d, XDD(1238, DD_ROWS[cur] - 5, 1766, DD_ROWS[cur] + 43), t, 2)   # dòng sát nhau → lề khung nhỏ để không đè dòng kế bên
    else: hl(d, XDD(*DD_FIELD), t)
    chip_bar(d, t, [(287.6, "Chọn cách thể hiện theo đúng tính chất của dữ liệu cần sử dụng", NAVY)], size=24)
    role_tag(img, d, CB, "C&B")

# ================= Mẹo nhỏ =================
def sc_h_meo(img, d, t): sub_card(img, d, t, HD["meo"], "PHẦN 8", ["MỘT MẸO NHỎ KHI THIẾT LẬP", "CÔNG THỨC LƯƠNG"], 70)

DAYS = ["Ngày 1", "Ngày 2", "Ngày 3", "Ngày 4"]
def strip(d, cx, y, vals, res_lab, res, col, s, t_res, t):
    if s <= 0.01: return
    for i, v in enumerate(vals):
        x = cx - 330 + i * 150
        d.rounded_rectangle([x - 62, y - 40, x + 62, y + 40], 12, fill=(240, 244, 252), outline=LINE, width=2)
        text(d, (x, y - 18), DAYS[i], 16, GREY, "Bold"); text(d, (x, y + 14), v, 22, INK, "Bold")
    k = pop(t, t_res, 0.4)
    if k > 0.01:
        mini_chip(d, cx, y + 90, 560, 56, f"{res_lab} = {res}", col, k, 24)

def sc_meo(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Phân biệt hai nhóm dữ liệu khi chọn cách thể hiện", 294.5, size=50)
    sL = pop(t, 298.6); sR = pop(t, 300.5)
    if sL > 0.01:
        card(d, 560, 500, 820, 620, sL, True, BLUE)
        if sL > 0.9: text(d, (560, 235), "Dữ liệu thay đổi theo ngày", 34, BLUE)
    if sR > 0.01:
        card(d, 1420, 500, 820, 620, sR, True, ORANGE)
        if sR > 0.9: text(d, (1420, 235), "Dữ liệu cố định qua từng ngày", 34, ORANGE)
    for j, (st, lab) in enumerate([(305.2, "Ngày công"), (305.9, "Giờ công"), (306.6, "Giờ làm thêm")]):
        mini_chip(d, 560, 320 + j * 70, 420, 54, lab, (95, 108, 140), pop(t, st, 0.4), 24)
    for j, (st, lab) in enumerate([(318.1, "Mức lương hợp đồng"), (319.6, "Phụ cấp cố định"), (321.2, "Công chuẩn kỳ lương")]):
        mini_chip(d, 1420, 320 + j * 70, 460, 54, lab, (95, 108, 140), pop(t, st, 0.4), 24)
    strip(d, 560, 600, ["1", "1", "0.5", "1"], "Tổng", "3.5 công", BLUE, pop(t, 308.6), 310.2, t)
    strip(d, 1420, 600, ["10tr", "10tr", "10tr", "10tr"], "Giá trị cuối cùng", "10tr", ORANGE, pop(t, 322.6), 325.5, t)
    k = pop(t, 326.4, 0.4)
    if k > 0.01: text(d, (1420, 770), "hoặc Giá trị cuối cùng khác không", 24 * k, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B")

SCENES = [(-OFFSET, 2.2, "h_p8"), (2.2, HD["lagi"], "intro"), (HD["lagi"], 13.5, "h_lagi"), (13.5, 28.0, "lagi"),
          (28.0, HD["yeuto"], "hieu"), (HD["yeuto"], 38.1, "h_yeuto"), (38.1, HD["xacdinh"], "yeuto"),
          (HD["xacdinh"], 56.5, "h_xd"), (56.5, HD["thietlap"], "xd"), (HD["thietlap"], 82.2, "h_tl"), (82.2, 86.0, "them"),
          (86.0, 100.5, "fields"), (100.5, 106.2, "names"), (106.2, 145.4, "fields"), (145.4, 155.5, "nbd"),
          (155.5, 158.0, "fields"), (158.0, 176.2, "order"), (176.2, HD["viet"], "fields"),
          (HD["viet"], 184.0, "h_viet"), (184.0, 212.5, "viet"), (212.5, HD["ham"], "vidu"),
          (HD["ham"], 222.9, "h_ham"), (222.9, HD["cth"], "ham"), (HD["cth"], 258.0, "h_cth"), (258.0, HD["meo"], "cth"),
          (HD["meo"], 294.3, "h_meo"), (294.3, 999, "meo")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv81"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 12
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p81_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p81_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
