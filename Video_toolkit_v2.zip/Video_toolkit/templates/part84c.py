"""PHẦN 8.4 (voice thu lại 30/10/2026) — Hiển thị là tổng thu nhập · Tổng nhóm dữ liệu lương · Hiển thị là thu nhập thực lãnh ·
Trạng thái công thức · Cách kiểm tra kết quả công thức lương.  Thay bản 8.4 cũ và 8.5.
Phiếu lương App: bản quay mới Phiếu_lương_nhân_viên_xem_1.MP4 (PHỤ CẤP 22.321.428,57 = Trách nhiệm + Nhan sắc)."""
import sys, math
from hw_core import *
from part81 import (sub_card, full_of, shot_xy, FORM_FULL, XF, F, IMG_FORM, mini_chip, badge,
                    KQ_FULL, XK, TN_FULL, XT, DS_FULL, XD, IMG_KQ, IMG_TN, IMG_DS)
from part84 import fcard, IMG_HTV, HTV_FULL, XV, V
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p84c.wav"
OFFSET = 1.0
VOICE_DUR = 234.21
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan8_4_Thiet_lap_khac_va_kiem_tra.mp4"
HD = dict(ttn=-0.6, tn=24.1, tl=109.6, tt=169.3, kt=200.5)
SFX_AT = [0.0] + [OFFSET + v for v in list(HD.values())[1:]]

REC_APP = U + "Phiếu_lương_nhân_viên_xem_1.MP4"      # 576x1280
A_PC_ROW = (8, 440, 568, 492)       # dòng PHỤ CẤP khi thu gọn (ct 8.0)
A_PC_HEAD = (8, 660, 568, 738)      # dòng PHỤ CẤP khi mở (ct 14.0)
A_PC_ITEMS = (8, 742, 568, 1018)    # Trách nhiệm, Nhan sắc, Tổng phụ cấp
A_PC_TONG = (8, 940, 568, 1018)     # dòng Tổng Phụ Cấp
F_IFLQT = (1313, 616, 1618, 656); F_PCTN = F["PCTN"]

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
def htv(img): fs_shot(img, IMG_HTV, HTV_FULL, HTV_FULL, 0)
def form(img): fs_shot(img, IMG_FORM, FORM_FULL, FORM_FULL, 0)
_clips = {}
def app_phone(img, d, cx, top, sw, tc, s=1.0):
    sh = int(sw * 1280 / 576); k2 = f"app_{sw}"
    if k2 not in _clips: _clips[k2] = Clip(REC_APP, (sw, sh))
    phone(img, d, cx, top, sw, sh, _clips[k2].get(tc) if s > 0.98 else None, s)
    sx, sy = cx - sw / 2, top + 14; k = sw / 576
    return lambda x0, y0, x1, y1: (sx + x0 * k, sy + y0 * k, sx + x1 * k, sy + y1 * k)

# ================= Hiển thị là tổng thu nhập =================
def sc_h_ttn(img, d, t): sub_card(img, d, t, HD["ttn"], "PHẦN 8", ["HIỂN THỊ LÀ", "TỔNG THU NHẬP"], 96)

def sc_ttn(img, d, t):
    htv(img)
    top_title(d, t, "Hiển thị là tổng thu nhập", 2.5)
    if t >= 2.7: hl(d, XV(*V["TTN"]), t)
    if t < 7.3: chip_bar(d, t, [(4.0, "Thường dùng khi doanh nghiệp triển khai áp tính thưởng", NAVY)], size=24)
    elif t < 16.8: chip_bar(d, t, [(7.3, "Tính lương tự động (video này): không cần thiết lập, không ảnh hưởng kết quả & màn hình đang dùng", GREEN)], size=20)
    else: chip_bar(d, t, [(16.8, "Khi cần dùng app tính thưởng: C&B được tư vấn & hướng dẫn thiết lập theo tình huống thực tế", NAVY)], size=20)
    role_tag(img, d, CB, "C&B")

# ================= Tổng nhóm dữ liệu lương =================
def sc_h_tn(img, d, t): sub_card(img, d, t, HD["tn"], "PHẦN 8", ["TỔNG NHÓM DỮ LIỆU LƯƠNG"], 84)

def sc_app(img, d, t):
    paste(img, BOARD)
    top_title(d, t, "Hiển thị ngay tổng giá trị của một nhóm trên phiếu lương", 26.7)
    ct = 8.0 if t < 35.3 else 14.0
    P = app_phone(img, d, 760, 78, 432, ct)
    if 30.4 <= t < 35.3: hl(d, P(*A_PC_ROW), t)
    if 35.4 <= t < 40.9: hl(d, P(*A_PC_ITEMS), t)
    if t >= 41.0: hl(d, P(*A_PC_HEAD), t)
    role_badge(img, d, EMP, "Nhân viên", 1420, 760, pop(t, 27.0, 0.5), 300)

CARD1 = 580
def cach1_board(d, t, t0=46.2, full=False):
    s_ = 1 if full else pop(t, t0)
    if s_ > 0.01:
        card(d, CARD1, 560, 760, 600, s_, True, BLUE)
        if s_ > 0.9: text(d, (CARD1, 300), "Cách 1: đã có công thức Tổng phụ cấp", 28, BLUE)
    for j, lab in enumerate(["Phụ cấp xăng", "Phụ cấp trách nhiệm", "Phụ cấp khác"]):
        fcard(d, CARD1 - 40, 390 + j * 80, 480, lab, (110, 122, 150), 1 if full else pop(t, 50.3 + j * 0.2, 0.4), tick=False)
    fcard(d, CARD1 - 40, 650, 480, "Tổng phụ cấp", GREEN, 1 if full else pop(t, 51.7, 0.4), tick=full or t >= 53.9)
    if full: text(d, (CARD1, 770), "Tổng phụ cấp → giá trị của nhóm", 24, GREEN, "Bold")

def sc_cach1(img, d, t):
    if t < 53.8:
        paste(img, BOARD)
        board_title(d, t, "Hai cách tạo giá trị tổng cho nhóm công thức", 46.2, size=54)
        cach1_board(d, t)
        role_tag(img, d, CB, "C&B")
        return
    if t < 57.4:
        htv(img)
        top_title(d, t, "Cách 1: chọn Tổng nhóm dữ liệu lương tại công thức Tổng phụ cấp", 53.9)
        hl(d, XV(*V["TNDL"]), t)
        role_tag(img, d, CB, "C&B")
        return
    paste(img, BOARD)
    top_title(d, t, "Kết quả Tổng phụ cấp = giá trị tổng hiển thị cho nhóm PHỤ CẤP", 57.5)
    P = app_phone(img, d, 760, 78, 432, 14.0)
    if 58.4 <= t < 60.9: hl(d, P(*A_PC_TONG), t)
    if t >= 60.9: hl(d, P(*A_PC_HEAD), t)
    role_badge(img, d, EMP, "Nhân viên", 1420, 760, 1, 300)

def sc_cach2(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Hai cách tạo giá trị tổng cho nhóm công thức", 64.0, size=54)
    cach1_board(d, t, full=True)
    s_ = pop(t, 64.5)
    if s_ > 0.01:
        card(d, 1360, 560, 760, 600, s_, True, ORANGE)
        if s_ > 0.9: text(d, (1360, 300), "Cách 2: chọn tại từng công thức riêng lẻ", 28, ORANGE)
    for j, lab in enumerate(["Phụ cấp xăng", "Phụ cấp trách nhiệm", "Phụ cấp khác"]):
        fcard(d, 1320, 390 + j * 80, 480, lab, ORANGE, pop(t, 65.0 + j * 0.2, 0.4), tick=t >= 66.3 + j * 0.6)
    fcard(d, 1320, 650, 480, "Tổng phụ cấp", (110, 122, 150), pop(t, 70.0, 0.4), tick=False)
    k = pop(t, 73.0, 0.4)
    if k > 0.01: text(d, (1360, 770), "Hệ thống cộng các công thức đã chọn", 24 * k, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B")

def sc_uutien(img, d, t):
    paste(img, BOARD)
    if t < 92.8:
        board_title(d, t, "Đã có công thức Tổng phụ cấp: ưu tiên cách 1", 80.4, size=54)
        for i, (st, lab, kind, col) in enumerate([(85.3, "Giảm số lượng thao tác\nkhi thiết lập", "check", BLUE),
                                                   (87.8, "Thuận tiện kiểm soát khi công thức\nđược bổ sung hoặc điều chỉnh", "search", GREEN)]):
            vcard(d, 700 + i * 520, 540, 480, 380, pop(t, st), col, kind, lab, 26, True)
        role_tag(img, d, CB, "C&B")
        return
    board_title(d, t, "Lưu ý: tránh cộng trùng giá trị của nhóm", 93.0, size=54)
    s_ = pop(t, 94.1)
    if s_ > 0.01:
        card(d, W / 2, 500, 1200, 460, s_, True, RED)
        if s_ > 0.9: text(d, (W / 2, 315), "Nhiều công thức cùng nhóm đều chọn Tổng nhóm dữ liệu lương", 26, RED)
    for j, lab in enumerate(["Phụ cấp xăng", "Phụ cấp trách nhiệm", "Tổng phụ cấp"]):
        fcard(d, 860, 400 + j * 80, 520, lab, RED if j == 2 else ORANGE, pop(t, 96.1 + j * 0.2, 0.4), tick=True)
    k = pop(t, 98.7, 0.4)
    if k > 0.01: text(d, (W / 2, 660), "→ Hệ thống cộng giá trị của tất cả các công thức đó", 26 * k, INK, "Bold")
    pill(d, W / 2 + 60, 880, 1240, 72, NAVY, "Xác định rõ công thức nào tạo giá trị tổng cho nhóm, tránh cộng trùng kết quả", 24, pop(t, 102.7))
    role_tag(img, d, CB, "C&B")

# ================= Thu nhập thực lãnh =================
def sc_h_tl(img, d, t): sub_card(img, d, t, HD["tl"], "PHẦN 8", ["HIỂN THỊ LÀ", "THU NHẬP THỰC LÃNH"], 84)

def sc_tl(img, d, t):
    if t < 120.0:
        htv(img)
        top_title(d, t, "Hiển thị là thu nhập thực lãnh", 113.0)
        if t >= 113.4: hl(d, XV(*V["TL"]), t)
        chip_bar(d, t, [(115.0, "Xác định số tiền cuối cùng nhân viên được nhận khi chi lương", NAVY)], size=24)
    else:
        fs_shot(img, IMG_TN, TN_FULL, TN_FULL, 0)
        top_title(d, t, "Thông thường: chọn tại công thức Thực nhận / Thực lãnh cuối cùng", 120.1)
        if t >= 122.8: hl(d, XT(2550, 395, 2760, 1320), t)
        chip_bar(d, t, [(125.0, "Đã tổng hợp các khoản thu nhập & khấu trừ để trả ra số tiền cuối cùng cần chi", GREEN)], size=22)
    role_tag(img, d, CB, "C&B")

def sc_tlvd(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Cơ chế tương tự Tổng nhóm dữ liệu lương", 132.5, size=54)
    k0 = pop(t, 136.9, 0.4)
    if k0 > 0.01: text(d, (W / 2, 220), "Nhiều công thức cùng chọn → hệ thống cộng kết quả để xác định thu nhập thực lãnh", 26 * k0, INK, "Bold")
    for i, (st, lab, val) in enumerate([(147.0, "Công thức A", "5.000.000đ"), (149.8, "Công thức B", "10.000.000đ")]):
        s_ = pop(t, st)
        if s_ > 0.01:
            card(d, 470 + i * 560, 470, 440, 220, s_, True, BLUE)
            if s_ > 0.9:
                text(d, (470 + i * 560, 420), lab, 30, BLUE); text(d, (470 + i * 560, 490), val, 34, INK)
                fcard(d, 470 + i * 560 - 30, 550, 300, "Thu nhập thực lãnh", GREEN, pop(t, 153.3, 0.4), tick=t >= 153.8, size=18)
    if t >= 152.2: text(d, (750, 470), "+", 70, ORANGE)
    arrow(d, 1270, 470, 1380, 470, p(t, 155.6, 0.4), ORANGE, 8)
    s3 = pop(t, 155.8)
    if s3 > 0.01:
        card(d, 1600, 470, 400, 220, s3, True, ORANGE)
        if s3 > 0.9: text(d, (1600, 420), "Thực lãnh", 30, ORANGE)
        k = pop(t, 158.1, 0.4)
        if k > 0.01: text(d, (1600, 490), "15.000.000đ", 36 * k, INK)
    pill(d, W / 2 + 60, 820, 1300, 76, RED, "Đã có công thức Thực nhận / Thực lãnh cuối cùng → thường chỉ chọn tại công thức đó", 23, pop(t, 160.1))
    k2 = pop(t, 167.6, 0.4)
    if k2 > 0.01: text(d, (W / 2 + 60, 900), "để tránh cộng trùng kết quả", 26 * k2, RED, "Bold")
    role_tag(img, d, CB, "C&B")

# ================= Trạng thái công thức =================
def sc_h_tt(img, d, t): sub_card(img, d, t, HD["tt"], "PHẦN 8", ["TRẠNG THÁI CÔNG THỨC"], 88)

def sc_tt(img, d, t):
    if t < 183.8:
        form(img)
        top_title(d, t, "Trạng thái công thức", 171.7)
        if t >= 171.9: hl(d, XF(*F["TTS"]), t)
        if t < 176.4: chip_bar(d, t, [(172.3, "Công thức đang được áp dụng: để Đang sử dụng", GREEN)], size=24)
        else: chip_bar(d, t, [(176.5, "Không còn áp dụng → Ngưng sử dụng để hệ thống không tiếp tục xử lý khi chạy lương", ORANGE)], size=21)
        role_tag(img, d, CB, "C&B")
        return
    fs_shot(img, IMG_DS, DS_FULL, DS_FULL, 0)
    if t >= 186.4: hl(d, XD(1300, 160, 2004, 262), t)
    if t >= 188.3: hl(d, XD(1318, 669, 1839, 1515), t)
    if t < 190.5: chip_bar(d, t, [(183.9, "Trước khi ngưng: kiểm tra công thức có đang được công thức khác sử dụng không", NAVY)], size=22)
    else: chip_bar(d, t, [(190.6, "Vẫn còn tham chiếu → xử lý mối liên hệ trước, tránh ảnh hưởng kết quả của các công thức liên quan", RED)], size=20)
    role_tag(img, d, CB, "C&B")

# ================= Kiểm tra kết quả =================
def sc_h_kt(img, d, t): sub_card(img, d, t, HD["kt"], "PHẦN 8", ["CÁCH KIỂM TRA KẾT QUẢ", "CÔNG THỨC LƯƠNG"], 84)

CHK = [(212.9, "PCTN", "1. Dữ liệu đầu vào đang được lấy từ thành phần lương nào?"), (216.4, "CT", "2. Nội dung công thức đã đúng quy tắc tính chưa?"),
       (219.2, "CTH", "3. Cách thể hiện trên bảng lương đã lấy dữ liệu đúng cách chưa?"), (222.8, "CHAY", "4. Chạy hàng ngày hay chạy một lần cuối chu kỳ?")]
def sc_kt(img, d, t):
    if t < 210.5:
        fs_shot(img, IMG_KQ, KQ_FULL, KQ_FULL, 0)
        top_title(d, t, "Chạy thử trên một chu kỳ lương trước khi áp dụng chính thức", 203.7)
        if t >= 205.8: hl(d, XK(860, 252, 1470, 362), t)
        role_tag(img, d, CB, "C&B")
        return
    form(img)
    top_title(d, t, "Kết quả chưa đúng: lần lượt kiểm tra", 210.6)
    cur = None
    for st, key, lab in CHK:
        if t >= st: cur = (key, lab, st)
    if cur:
        key, lab, st = cur
        b = XF(*F[key])
        if key == "PCTN": b = (b[0] + 6, b[1] + 6, b[2] - 6, b[3] - 6)      # dòng chữ sát nhau → lề khung hẹp
        hl(d, b, t)
        chip_bar(d, t, [(st, lab, RED)], size=23)
    role_tag(img, d, CB, "C&B")

def sc_end(img, d, t):
    paste(img, BOARD)
    k = pop(t, 227.2)
    pill(d, W / 2, 330, 360, 76, NAVY, "Bước tiếp theo", 32, k)
    s_ = pop(t, 229.6, 0.6)
    if s_ > 0.01:
        card(d, W / 2, 590, 1200, 320, s_, True, ORANGE)
        icon(d, "doc", W / 2 - 460 * s_, 590, s_, ORANGE, 90)
        text(d, (W / 2 + 80, 550), "TÌNH HUỐNG TÍNH LƯƠNG CỤ THỂ", 48 * s_, NAVY)
        k2 = pop(t, 231.7)
        if k2 > 0.01: text(d, (W / 2 + 80, 630), "Xem cách áp dụng các nguyên tắc vào thực tế", 26 * k2, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B", k)

SCENES = [(-OFFSET, 2.4, "h_ttn"), (2.4, HD["tn"], "ttn"), (HD["tn"], 26.6, "h_tn"), (26.6, 45.4, "app"), (45.4, 64.0, "cach1"),
          (64.0, 79.6, "cach2"), (79.6, HD["tl"], "uutien"), (HD["tl"], 112.8, "h_tl"), (112.8, 132.0, "tl"), (132.0, HD["tt"], "tlvd"),
          (HD["tt"], 171.6, "h_tt"), (171.6, HD["kt"], "tt"), (HD["kt"], 203.5, "h_kt"), (203.5, 226.9, "kt"), (226.9, 999, "end")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv84c"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 9
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p84c_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p84c_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
