"""PHẦN 8.2 — bản chỉnh 01/11: cắt cụm "tương đương 208 giờ" khỏi voice (≈0:54, 1,99 s) và
màn hình so sánh 2 trạng thái ô "Chạy một lần cuối chu kỳ": không tick = chạy hàng ngày · có tick = chạy cuối kỳ.
Giữ toàn bộ cảnh của part82n, ánh xạ thời gian qua Minv."""
import sys, math
from hw_core import *
import part82n as P
from part81 import FORM_FULL, XF, F

CUT0, CUT = 53.66, 1.99
def M(t): return t if t < CUT0 else (CUT0 if t < CUT0 + CUT else t - CUT)
def Minv(t): return t if t < CUT0 else t + CUT

VOICE = A + "voice_p82d.wav"
OFFSET = 1.0
VOICE_DUR = 226.85
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = P.OUT
SFX_AT = [0.0]

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
P.hl = lambda d, box, t=0.0, kind="rect": hl(d, box, t)

# ---------- màn hình so sánh tick / không tick ----------
IMG_TICK = "/home/claude/p7/form_tick.png"; IMG_UNTICK = "/home/claude/p7/form_untick.png"   # sửa đè: bỏ dấu tick
CROP = (1105, 830, 2390, 1420); PW = 860; K = PW / (CROP[2] - CROP[0]); PH = int((CROP[3] - CROP[1]) * K)
PX = [80, 980]; PY = 330
_pc = {}
def panel(path):
    if path not in _pc: _pc[path] = Image.open(path).convert("RGB").crop(CROP).resize((PW, PH), Image.LANCZOS)
    return _pc[path]
def pxy(i, b): return (PX[i] + (b[0] - CROP[0]) * K, PY + (b[1] - CROP[1]) * K, PX[i] + (b[2] - CROP[0]) * K, PY + (b[3] - CROP[1]) * K)

def sc_form(img, d, t):
    if t < 7.2:
        fs_shot(img, P.IMG_FORM, FORM_FULL, FORM_FULL, 0)
        top_title(d, t, "Tính theo từng ngày hay một lần tại ngày cuối chu kỳ lương?", 3.4)
        if t >= 4.6: hl(d, XF(*F["CHAY"]), t)
        role_tag(img, d, CB, "C&B")
        return
    paste(img, BOARD)
    top_title(d, t, "Ô “Chạy một lần cuối chu kỳ” quyết định cách chạy công thức", 7.3)
    for i, (path, lab, col) in enumerate([(IMG_UNTICK, "Không chọn → chạy hàng ngày", GREEN), (IMG_TICK, "Có chọn → chạy một lần cuối chu kỳ", ORANGE)]):
        im = panel(path); img.paste(im, (PX[i], PY)); d.rectangle([PX[i], PY, PX[i] + PW, PY + PH], outline=LINE, width=3)
        mini_chip(d, PX[i] + PW / 2, PY - 55, 620, 66, lab, col, 1, 28)
    c = F["CHAY"]
    if 7.3 <= t < 8.4 or t >= 11.8: hl(d, pxy(0, c), t)
    if 8.5 <= t < 11.8: hl(d, pxy(1, c), t)
    if t >= 16.3: chip_bar(d, t, [(16.3, "Chạy hàng ngày: xét dữ liệu từng ngày → tính theo điều kiện → tổng hợp theo cách thể hiện", NAVY)], size=21)
    role_tag(img, d, CB, "C&B")
from part81 import mini_chip

def sc_data(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Kỳ lương 06/2026 · Nhân viên A", 48.3, size=54)
    s_ = pop(t, 50.8)
    if s_ > 0.01:
        card(d, W / 2, 290, 800, 110, s_, True, NAVY)
        text(d, (W / 2, 290), "Ngày công chuẩn: 26 ngày", 32 * s_, NAVY)
    rows = [(55.7, "23 ngày", "làm đủ 8 giờ"), (58.1, "1 ngày", "làm 4 giờ"), (59.3, "1 ngày", "làm 6,4 giờ"), (61.8, "1 ngày", "không đi làm")]
    for j, (st, a, b) in enumerate(rows):
        k = pop(t, st, 0.4)
        if k <= 0.01: continue
        y = 450 + j * 110
        d.rounded_rectangle([560, y - 42, 1360, y + 42], 16, fill=WHITE, outline=LINE, width=3)
        text(d, (620, y), a, 32 * k, BLUE, anchor="lm"); text(d, (860, y), b, 30 * k, INK, "Bold", anchor="lm")
    role_tag(img, d, CB, "C&B")

def old(fn): return lambda img, d, t: fn(img, d, Minv(t))
SCENES = []
for s, e, n in P.SCENES:
    SCENES.append((s if s < 0 else M(s), 999 if e >= 999 else M(e), n))
FN = {n: old(P.FN[n]) for _, _, n in SCENES}
FN["form"] = sc_form            # cảnh trước điểm cắt → thời gian không đổi
FN["data"] = sc_data            # thời gian mới (sau điểm cắt đã trừ 1,99 s)

def preview(times, out="/tmp/pv82p"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 8
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p82p_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p82p_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
