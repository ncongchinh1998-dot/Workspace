"""PHẦN 9.1 (voice 01/11/2026) — Thực hành bằng tình huống cụ thể: cách tiếp cận bằng 4 câu hỏi.
Mỗi câu hỏi đi kèm màn hình hệ thống tương ứng (file TPL, form công thức, danh sách cách thể hiện)."""
import sys, math
from hw_core import *
from part81 import (sub_card, full_of, shot_xy, FORM_FULL, XF, F, IMG_FORM, mini_chip, badge,
                    IMG_DD, DD_FULL, XDD, DD_ROWS, DD_FIELD, hl_pad)
from part91 import IMG_ID, ID_FULL, XI, COL_TEN, COL_GT

VOICE = A + "voice_p91b.wav"
OFFSET = 1.0
VOICE_DUR = 67.61
TOTAL = OFFSET + VOICE_DUR + 1.5
OUT = "/mnt/user-data/outputs/Phan9_1_Thuc_hanh_tinh_huong.mp4"
HD = dict(p9=-0.6)
SFX_AT = [0.0]

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
import part81; part81.hl = lambda d, box, t=0.0, kind="rect": hl(d, box, t)   # hl_pad dùng hl của file này
def form(img): fs_shot(img, IMG_FORM, FORM_FULL, FORM_FULL, 0)

Q = [("Cần dữ liệu nào để tính? Đang ghi nhận tại thành phần lương nào?", "db", GREEN),
     ("Tính theo quy tắc nào? Các dữ liệu kết hợp với nhau thế nào?", "fx", BLUE),
     ("Kết quả lấy theo cách thể hiện nào trên bảng lương?", "chart", ORANGE),
     ("Chạy hàng ngày hay chạy một lần cuối chu kỳ?", "run", NAVY)]

def sc_h_p9(img, d, t): sub_card(img, d, t, HD["p9"], "PHẦN 9", ["THỰC HÀNH BẰNG", "TÌNH HUỐNG CỤ THỂ"], 96)

def sc_recap(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Kết hợp những nội dung đã tìm hiểu", 3.5, size=56)
    for i, (st, lab, kind, col) in enumerate([(6.6, "Thành phần lương", "db", GREEN), (7.6, "Nhóm công thức", "logic", NAVY),
                                              (8.9, "Cách công thức\nlương hoạt động", "fx", BLUE)]):
        vcard(d, 300 + i * 380, 520, 340, 320, pop(t, st), col, kind, lab, 26, True)
    arrow(d, 1250, 520, 1370, 520, p(t, 14.4, 0.4), ORANGE, 8)
    vcard(d, 1600, 520, 400, 360, pop(t, 14.8), ORANGE, "doc", "Xử lý một yêu cầu\ntính lương\ntừ đầu đến cuối", 26, True)
    role_tag(img, d, CB, "C&B", pop(t, 3.8, 0.4))

def sc_goal(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Mục tiêu của phần này", 17.8, size=56)
    s_ = pop(t, 19.3)
    if s_ > 0.01:
        card(d, 470, 520, 560, 300, s_, True, (130, 140, 160))
        text(d, (470, 520), "Ghi nhớ một\ncông thức mẫu", 36 * s_, GREY)
        badge(d, 720, 400, False, pop(t, 19.6, 0.4), 30)
    s1 = pop(t, 23.2)
    if s1 > 0.01:
        card(d, 1100, 520, 440, 300, s1, True, BLUE)
        text(d, (1100, 520), "Nhu cầu tính\nlương thực tế", 32 * s1, BLUE)
    arrow(d, 1330, 520, 1420, 520, p(t, 24.9, 0.4), ORANGE, 8)
    s2 = pop(t, 25.1)
    if s2 > 0.01:
        card(d, 1640, 520, 400, 300, s2, True, GREEN)
        text(d, (1640, 520), "Cách thiết lập\ntrên Haraworks", 30 * s2, GREEN)
        badge(d, 1830, 400, True, pop(t, 26.0, 0.4), 30)
    role_tag(img, d, CB, "C&B")

def four(d, t, t0, hi=None, step=0.3):
    for i, (lab, kind, col) in enumerate(Q):
        y = 300 + i * 160
        hcard(d, W / 2 + 40, y, 1440, 130, pop(t, t0 + i * step), col, kind, f"{i + 1}.  {lab}", 28, True)
        if hi == i: hl(d, (W / 2 + 40 - 720, y - 65, W / 2 + 40 + 720, y + 65), t)

def sc_approach(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Cách tiếp cận một tình huống tính lương", 27.6, size=54)
    k = pop(t, 30.4, 0.4)
    if k > 0.01: text(d, (W / 2, 190), "Với mỗi tình huống, lần lượt trả lời bốn câu hỏi", 30 * k, NAVY, "Bold")
    four(d, t, 34.0)
    role_tag(img, d, CB, "C&B")

def sc_q1(img, d, t):
    fs_shot(img, IMG_ID, ID_FULL, ID_FULL, 0)
    top_title(d, t, "1 · Cần dữ liệu nào? Ghi nhận tại thành phần lương nào?", 35.3)
    if t >= 39.4: hl(d, XI(*COL_TEN), t)

def sc_q2(img, d, t):
    form(img)
    top_title(d, t, "2 · Quy tắc tính & cách kết hợp các dữ liệu", 41.7)
    if t >= 42.5: hl(d, XF(*F["CT"]), t)
    role_tag(img, d, CB, "C&B")

DD_Q3 = [(53.4, 0), (54.0, 2), (55.5, 8)]   # Tổng · Giá trị cuối cùng · Giá trị cuối cùng khác không
def sc_q3(img, d, t):
    fs_shot(img, IMG_DD, DD_FULL, DD_FULL, 0)
    top_title(d, t, "3 · Kết quả lấy theo cách thể hiện nào trên bảng lương?", 48.3)
    cur = None
    for st, row in DD_Q3:
        if t >= st: cur = row
    if cur is None: hl(d, XDD(*DD_FIELD), t) if t >= 49.8 else None
    else: hl_pad(d, XDD(1238, DD_ROWS[cur] - 5, 1766, DD_ROWS[cur] + 43), t, 2)
    role_tag(img, d, CB, "C&B")

def sc_q4(img, d, t):
    form(img)
    top_title(d, t, "4 · Chạy hàng ngày hay chạy một lần cuối chu kỳ?", 57.6)
    if t >= 58.5: hl(d, XF(*F["CHAY"]), t)
    role_tag(img, d, CB, "C&B")

def sc_next(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Dùng bốn câu hỏi này để phân tích từng tình huống", 62.7, size=52)
    four(d, t, 0, step=0)
    pill(d, W / 2 + 40, 960, 760, 70, ORANGE, "Phần tiếp theo: các tình huống cụ thể", 26, pop(t, 65.3))
    role_tag(img, d, CB, "C&B")

SCENES = [(-OFFSET, 3.2, "h_p9"), (3.2, 17.6, "recap"), (17.6, 27.3, "goal"), (27.3, 35.1, "approach"), (35.1, 41.5, "q1"),
          (41.5, 48.1, "q2"), (48.1, 57.4, "q3"), (57.4, 62.5, "q4"), (62.5, 999, "next")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv91b"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 3
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p91b_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p91b_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
