"""PHẦN 7 — NHÓM CÔNG THỨC
Mục: Nhóm công thức là gì · Xác định cấu trúc nhóm trước khi thiết lập · Thiết lập nhóm công thức trên Haraworks ·
     Nhóm công thức & cách hiển thị trên phiếu lương · (lưu ý chèn thêm: Ẩn trên Thu nhập cá nhân khi = 0) · Tổng kết.
Voice: voice_p7x.wav = voice gốc + 6 s lặng chèn tại 194.5 (cảnh lưu ý). Mốc sau 194.5 đã cộng 6 s (hàm X).
Khung đỏ: toạ độ đo trên khung hình gốc (OCR + lưới), xem p7/g*.png."""
import sys, math
from hw_core import *
from PIL import ImageFont
U = "/mnt/user-data/uploads/"
ST = "/home/claude/p7/st/"

VOICE = A + "voice_p7b.wav"          # voice thu lại 27/10/2026 (sửa 1 từ "C&B"), không chèn khoảng lặng
OFFSET = 1.0
INS_AT, INS = 194.5, 0.0
def X(v): return v if v < INS_AT else v + INS
VOICE_DUR = 225.90 + INS
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan7_Nhom_cong_thuc.mp4"
HD = dict(p7=-0.6, lagi=20.5, ct=64.5, tl=107.4, ht=153.9, tk=X(194.6))
SFX_AT = [0.0] + [OFFSET + v for v in list(HD.values())[1:]]

# ---------- Tư liệu ----------
REC_ADD = U + "Thêm_nhóm_công_thức.mp4"                          # 1912x1016 web
REC_PICK = U + "Công_thức_lương_có_chọn_nhóm_công_thức.mp4"      # 1824x1078 có thanh trình duyệt
REC_BL = U + "Hiển_thị_trên_bảng_lương.mp4"                      # 1824x1078
REC_APP = U + "Phiếu_lương_nhân_viên_xem.MP4"   # bản quay mới: tổng PHỤ CẤP khớp các khoản                  # 576x1280 app nhân viên
IMG_DS = U + "Khai_báo_nhóm_công_thức.png"                       # 2796x1530 danh sách nhóm
IMG_PC = U + "Nhóm_công_thức_phụ_cấp.png"                        # 2812x1524 Thu nhập nhân viên (mở rộng)
IMG_AN = U + "ẩn_trên_thu_nhập_cá_nhân.png"                      # 2879x1531 form công thức (có khung tay)
IMG_TNCN = U + "Thu_nhập_cá_nhân.png"                            # 2879x1523 Thu nhập của tôi (web)

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    w_ = 6 + int(2 * abs(math.sin(t * 5)))
    if kind == "rect": d.rounded_rectangle(box, 10, outline=RED, width=w_)
    else: d.ellipse(box, outline=RED, width=w_)

def sub_card(img, d, t, t0, kicker, lines, size=96):
    paste(img, SECTION)
    pill(d, 280, 280, 340, 76, BLUE, kicker, 30, pop(t, t0 + 0.05), weight="ExtraBold")
    for j, line in enumerate(lines):
        k = p(t, t0 + 0.15 + j * 0.12, 0.45)
        if k > 0: text(d, (110, 430 + j * size * 1.12 + (1 - k) * 50), line, size, NAVY, anchor="lm", align="left")
    underline(d, 115, 430 + (len(lines) - 1) * size * 1.12 + size * 0.75, 700, p(t, t0 + 0.45, 0.5))
    person(img, d, CB, 1220, 900, 340, pop(t, t0 + 0.4, 0.5), "C&B", 30)

def shot_xy(box):
    k = 1920 / (box[2] - box[0])
    return lambda x0, y0, x1, y1: ((x0 - box[0]) * k, (y0 - box[1]) * k, (x1 - box[0]) * k, (y1 - box[1]) * k)
def full_of(iw, ih): return box169(iw / 2, ih / 2, iw, iw, ih)
def piece(t, pts):
    if t <= pts[0][0]: return pts[0][1]
    for (a_, ca), (b_, cb) in zip(pts, pts[1:]):
        if a_ <= t <= b_: return ca + (t - a_) * (cb - ca) / (b_ - a_)
    return pts[-1][1]

FULLB = (0, 0, 1920, 1080)
_clips = {}
REC_WEB = dict(crop=(0, 0, 1912, 1016), size=(1920, 1020), y0=30, sw=1912)
# bản quay 1824x1078 có thanh tab trình duyệt: giữ trọn chiều cao, đẩy lên 55 px để bỏ dải tab (thanh địa chỉ vẫn thấy)
REC_BR = dict(crop=(0, 0, 1824, 1078), size=(1920, 1135), y0=-55, sw=1824)
def scr(img, key, path, tc, spec=REC_WEB):
    if key not in _clips: _clips[key] = Clip(path, spec["size"], spec["crop"])
    fr = _clips[key].get(tc); bg = Image.new("RGB", (1920, 1080), WHITE)
    if fr is not None: bg.paste(fr, (0, spec["y0"]))
    img.paste(bg, (0, 0))
def B(x0, y0, x1, y1, spec=REC_WEB):
    s_ = 1920 / spec["sw"]; y_ = spec["y0"]
    return (x0 * s_, y0 * s_ + y_, x1 * s_, y1 * s_ + y_)

_st = {}
def still(path):
    if path not in _st: _st[path] = Image.open(path).convert("RGB")
    return _st[path]
def still_web(img, im, spec=REC_WEB):
    bg = Image.new("RGB", (1920, 1080), WHITE)
    bg.paste(im.resize(spec["size"], Image.LANCZOS) if spec["crop"][2:] == im.size else im, (0, spec["y0"]))
    img.paste(bg, (0, 0))

DS_FULL = full_of(2796, 1530); XD = shot_xy(DS_FULL)
PC_FULL = full_of(2812, 1524); XP = shot_xy(PC_FULL)
AN_FULL = full_of(2879, 1531); XA = shot_xy(AN_FULL)

# ảnh "ẩn trên thu nhập cá nhân" có khung đỏ vẽ tay → xoá nét đỏ, dùng khung chuẩn
IMG_AN_CLEAN = "/tmp/p7_an_clean.png"
def _clean_an():
    import numpy as np, os
    if os.path.exists(IMG_AN_CLEAN): return
    a = np.array(Image.open(IMG_AN).convert("RGB")).copy()
    ai = a.astype(int); m = (ai[:, :, 0] - ai[:, :, 1] > 40) & (ai[:, :, 0] - ai[:, :, 2] > 40)
    m[:1290, :] = False; m[1420:, :] = False; m[:, :1800] = False
    a[m] = 255
    Image.fromarray(a).save(IMG_AN_CLEAN)
_clean_an()

# ---------- màn hình app (điện thoại) ----------
def app_screen(key, tc, sw, sh):
    k2 = f"app_{key}_{sw}"
    if k2 not in _clips: _clips[k2] = Clip(REC_APP, (sw, sh))
    return _clips[k2].get(tc)
def app_phone(img, d, cx, top, sw, tc, s=1.0, key="a"):
    sh = int(sw * 1280 / 576)
    phone(img, d, cx, top, sw, sh, app_screen(key, tc, sw, sh) if s > 0.98 else None, s)
    sx, sy = cx - sw / 2, top + 14; k = sw / 576
    return lambda x0, y0, x1, y1: (sx + x0 * k, sy + y0 * k, sx + x1 * k, sy + y1 * k)
APP_GROUPS = (8, 348, 568, 708)         # LƯƠNG → THUẾ (thu gọn, ct 8.0)
APP_PC = (8, 660, 568, 1018)             # khối PHỤ CẤP mở rộng (ct 14.0): Trách nhiệm + Nhan sắc = Tổng

_inter = ImageFont.truetype(A + "Inter.ttf", 18); _inter.set_variation_by_name("Regular")

def mini_chip(d, cx, cy, w, h, lab, col, s=1.0, size=22):
    if s <= 0.01: return
    w, h = w * s, h * s
    d.rounded_rectangle([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], h / 2, fill=col)
    text(d, (cx, cy), lab, fit_size(d, lab, size * s, "Bold", w - 24 * s), WHITE, "Bold")

# ================= Mở đầu =================
def sc_h_p7(img, d, t): sub_card(img, d, t, HD["p7"], "PHẦN 7", ["NHÓM CÔNG THỨC"], 110)

def sc_intro(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Từ dữ liệu đến bảng lương & phiếu lương", 3.3, size=54)
    vcard(d, 330, 430, 380, 300, pop(t, 7.5), GREEN, "db", "Thành phần lương", 30, True)
    arrow(d, 530, 430, 610, 430, p(t, 9.2, 0.4), ORANGE, 7)
    vcard(d, 810, 430, 380, 300, pop(t, 9.6), BLUE, "fx", "Công thức lương", 30, True)
    arrow(d, 1010, 430, 1090, 430, p(t, 13.0, 0.4), ORANGE, 7)
    if t < 19.4: vcard(d, 1290, 430, 380, 300, pop(t, 13.4), ORANGE, "q", "Tổ chức thế nào?", 30, True)
    else: vcard(d, 1290, 430, 380, 300, pop(t, 19.4), NAVY, "logic", "Nhóm công thức", 30, True)
    arrow(d, 1220, 590, 1080, 700, p(t, 15.0, 0.4), ORANGE, 6)
    arrow(d, 1360, 590, 1500, 700, p(t, 15.9, 0.4), ORANGE, 6)
    hcard(d, 1000, 790, 440, 120, pop(t, 15.1), BLUE, "sheet", "Bảng lương", 30, True)
    hcard(d, 1560, 790, 500, 120, pop(t, 16.1), GREEN, "doc", "Phiếu lương nhân viên", 28, True)
    role_tag(img, d, CB, "C&B", pop(t, 4.0, 0.4))

# ================= Nhóm công thức là gì =================
def sc_h_lagi(img, d, t): sub_card(img, d, t, HD["lagi"], "PHẦN 7", ["NHÓM CÔNG THỨC", "LÀ GÌ?"], 104)

GROUPS = [(35.5, "CÔNG", BLUE, ["Công thực tế", "Phép năm"]), (36.0, "LƯƠNG", NAVY, ["Lương thực tế"]),
          (36.9, "PHỤ CẤP", GREEN, ["Phụ cấp trách nhiệm", "Phụ cấp xăng"]), (37.7, "THƯỞNG", ORANGE, ["Thưởng doanh số"]),
          (38.3, "BHXH", CYAN, ["Trích đóng BHXH"]), (39.9, "THUẾ", RED, ["Thuế TNCN"]), (40.6, "THỰC NHẬN", DEEP, ["Thực lãnh"])]
SCATTER = [(220, 250), (200, 410), (450, 330), (700, 250), (720, 410), (960, 330), (1200, 250), (1460, 410), (1680, 330)]   # mỗi thẻ nằm phía trên ô nhóm của nó → bay thẳng xuống, không cắt qua ô khác
def sc_gom(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Gom các công thức lương cùng nhóm thông tin", 23.4, size=52)
    bw, gap, x0, cy, bh = 240, 22, 54, 660, 320
    k = 0
    for i, (tg, lab, col, items) in enumerate(GROUPS):
        bx = x0 + bw / 2 + i * (bw + gap)
        s_ = pop(t, tg)
        if s_ > 0.01: card(d, bx, cy, bw, bh, s_, True, col)
        for j, it in enumerate(items):
            sx, sy = SCATTER[k]; k += 1
            a = pop(t, 25.9 + k * 0.15, 0.4)
            if a <= 0.01: continue
            f = ease(clamp((t - tg - 0.1 - j * 0.25) / 0.6))
            tx, ty = bx, cy - bh / 2 + 120 + j * 66
            x = sx + (tx - sx) * f; y = sy + (ty - sy) * f
            w = 330 + (bw - 34 - 330) * f
            mini_chip(d, x, y, w, 54, it, (95, 108, 140) if f < 1 else col, a, 22)
        if s_ > 0.01: mini_chip(d, bx, cy - bh / 2 + 42, bw - 30, 52, lab, col, s_, 24)     # nhãn nhóm vẽ sau → luôn nổi trên thẻ đang bay vào
    role_tag(img, d, CB, "C&B")

def sc_app1(img, d, t):
    paste(img, BOARD)
    top_title(d, t, "Phiếu lương của nhân viên trên App", 41.5)
    ct = 8.0 if t < 48.4 else 14.0
    P = app_phone(img, d, 760, 78, 432, ct)
    if 43.6 <= t < 48.4: hl(d, P(*APP_GROUPS), t)
    if 50.2 <= t: hl(d, P(*APP_PC), t)
    role_badge(img, d, EMP, "Nhân viên", 1420, 760, pop(t, 42.0, 0.5), 300)

def sc_imagine(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Hình dung đồng thời bảng lương & phiếu lương", 56.7, size=52)
    s1 = pop(t, 60.9)
    if s1 > 0.01:
        im = still(ST + "bl.png").crop((0, 110, 1824, 1078)); w = 1100; h = int(im.height * w / im.width); x0 = 200   # bảng lương view ngang, đủ màn hình
        text(d, (x0 + w / 2, 225), "Bảng lương (C&B)", 32 * max(s1, 0.3), NAVY)
        if s1 > 0.98:
            img.paste(im.resize((w, h), Image.LANCZOS), (x0, 260)); d.rectangle([x0, 260, x0 + w, 260 + h], outline=LINE, width=3)
    s2 = pop(t, 62.2)
    if s2 > 0.01:
        text(d, (1560, 190), "Phiếu lương nhân viên đọc", 30 * max(s2, 0.3), GREEN)
        app_phone(img, d, 1560, 225, 340, 8.0, s2, "b")
    role_tag(img, d, CB, "C&B")

# ================= Xác định cấu trúc nhóm =================
def sc_h_ct(img, d, t): sub_card(img, d, t, HD["ct"], "PHẦN 7", ["XÁC ĐỊNH CẤU TRÚC NHÓM", "TRƯỚC KHI THIẾT LẬP"], 80)

EX_CONG = [(83.6, "Công thực tế"), (84.7, "Phép năm"), (85.5, "Ngày lễ"), (86.7, "Tổng công")]
EX_PC = [(89.9, "Phụ cấp trách nhiệm"), (90.2, "Phụ cấp xăng"), (90.5, "Phụ cấp dáng đẹp")]
def sc_plan(img, d, t):
    paste(img, BOARD)
    if t < 82.4:
        board_title(d, t, "Trước khi thao tác trên Haraworks", 68.4)
        hcard(d, W / 2, 260, 900, 120, pop(t, 71.2), NAVY, "sheet", "Nhìn lại bảng lương đang sử dụng", 30, True)
        qs = [(73.9, "Công thức nào cùng\nmột nhóm thông tin?", "search", BLUE), (77.3, "Các nhóm đặt tên\nnhư thế nào?", "edit", ORANGE),
              (79.9, "Thứ tự các nhóm\nxuất hiện ra sao?", "chart", GREEN)]
        for i, (st, lab, kind, col) in enumerate(qs):
            vcard(d, 500 + i * 460, 600, 420, 380, pop(t, st), col, kind, lab, 28, True, f"0{i + 1}")
        role_tag(img, d, CB, "C&B")
        return
    board_title(d, t, "Ví dụ tổ chức nhóm", 82.5)
    boxes = [(700, 88.8, "NHÓM CÔNG", BLUE, EX_CONG, 94.7, "1"), (1300, 92.1, "NHÓM PHỤ CẤP", GREEN, EX_PC, 95.2, "2")]
    for bx, tg, lab, col, items, t_no, no in boxes:
        s_ = pop(t, tg)
        if s_ > 0.01: card(d, bx, 560, 520, 440, s_, True, col)
        n = len(items)
        for j, (st, it) in enumerate(items):
            a = pop(t, st, 0.4)
            if a <= 0.01: continue
            sx = bx + (-130 if j % 2 == 0 else 130) if not (n % 2 and j == n - 1) else bx
            sy = 200 + (j // 2) * 66
            f = ease(clamp((t - tg - 0.1 - j * 0.3) / 0.5))
            ty = 460 + j * 72
            x = sx + (bx - sx) * f; y = sy + (ty - sy) * f
            w = 250 + (440 - 250) * f
            mini_chip(d, x, y, w, 56, it, (95, 108, 140) if f < 1 else col, a, 22)
        if s_ > 0.01: mini_chip(d, bx, 385, 420, 60, lab, col, s_, 28)
        b = pop(t, t_no, 0.4)
        if b > 0.01:
            r = 40 * b; cx_, cy_ = bx - 260, 340
            d.ellipse([cx_ - r, cy_ - r, cx_ + r, cy_ + r], fill=ORANGE)
            text(d, (cx_, cy_), no, 40 * b, WHITE)
    pill(d, W / 2, 890, 1000, 76, NAVY, "Thứ tự hiển thị trên phiếu lương: 1. CÔNG  →  2. PHỤ CẤP", 26, pop(t, 96.7))
    role_tag(img, d, CB, "C&B")

def sc_need2(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Cần có sẵn hai thông tin trước khi thiết lập", 100.1, size=54)
    vcard(d, 700, 540, 460, 380, pop(t, 104.5), BLUE, "edit", "Tên nhóm công thức", 32, True, "01")
    vcard(d, 1220, 540, 460, 380, pop(t, 106.3), ORANGE, "chart", "Thứ tự xuất hiện", 32, True, "02")
    role_tag(img, d, CB, "C&B", pop(t, 100.5, 0.4))

# ================= Thiết lập trên Haraworks =================
def sc_h_tl(img, d, t): sub_card(img, d, t, HD["tl"], "PHẦN 7", ["THIẾT LẬP NHÓM CÔNG THỨC", "TRÊN HARAWORKS"], 80)

F_MENU = (64, 648, 300, 690)            # menu Lương thưởng › Nhóm công thức (ct 0–1.0)
F_THEM = (137, 106, 272, 154)           # nút Thêm mới (ct 1.6–2.0)
F_TEN = (820, 168, 1186, 241)           # Tên nhóm công thức (nhãn + ô)
F_TT = (1234, 168, 1564, 245)           # Thứ tự (nhãn + ô)
F_LUU = (1577, 89, 1685, 136)           # nút Lưu
def sc_add(img, d, t):
    ct = piece(t, [(110.5, 0.0), (113.7, 0.4), (115.2, 1.0), (115.4, 1.6), (116.9, 2.0), (117.5, 2.7), (117.9, 3.4)])
    scr(img, "add", REC_ADD, ct)
    top_title(d, t, "Thêm mới nhóm công thức", 110.6)
    if 113.9 <= t < 115.25: hl(d, B(*F_MENU), t)
    if 115.6 <= t < 116.9: hl(d, B(*F_THEM), t)
    if 119.1 <= t < 120.55 or 122.0 <= t: hl(d, B(*F_TEN), t)
    if 120.6 <= t < 121.95: hl(d, B(*F_TT), t)
    if 122.3 <= t < 126.3: chip_bar(d, t, [(122.3, "Tên nhóm nên phản ánh rõ nhóm thông tin đang được tổ chức", NAVY)], size=24)
    elif t >= 126.3:
        chip_bar(d, t, [(126.3, "Ví dụ:", GREY), (127.3, "CÔNG", BLUE), (128.1, "PHỤ CẤP", GREEN), (129.0, "THƯỞNG", ORANGE),
                        (130.4, "KHẤU TRỪ", RED)], size=26)
    role_tag(img, d, CB, "C&B")

def sc_dup(img, d, t):
    fs_shot(img, IMG_DS, DS_FULL, DS_FULL, 0)
    if t >= 132.9: hl(d, XD(204, 300, 486, 826), t)
    chip_bar(d, t, [(132.0, "Lưu ý: tên nhóm công thức không được trùng nhau", RED)], size=26)
    role_tag(img, d, CB, "C&B")

AZ_ROWS = [("LƯƠNG", "1"), ("PHỤ CẤP", "2"), ("THƯỞNG", "3"), ("KHẤU TRỪ", "3"), ("BHXH", "4")]
AZ_OUT = ["LƯƠNG", "PHỤ CẤP", "KHẤU TRỪ", "THƯỞNG", "BHXH"]
def sc_order(img, d, t):
    if t < 140.6:
        fs_shot(img, IMG_DS, DS_FULL, DS_FULL, 0)
        if t >= 136.2: hl(d, XD(744, 300, 858, 826), t)
        chip_bar(d, t, [(136.6, "Thứ tự xuất hiện xác định vị trí của từng nhóm trong cấu trúc hiển thị", NAVY)], size=24)
        role_tag(img, d, CB, "C&B")
        return
    paste(img, BOARD)
    board_title(d, t, "Nhiều nhóm cùng thứ tự: sắp xếp từ A đến Z", 140.7, size=52)
    s1 = pop(t, 141.0)
    if s1 > 0.01:
        card(d, 600, 560, 640, 560, s1, True, BLUE)
        if s1 > 0.98:
            text(d, (380, 330), "Tên nhóm", 26, GREY, "Bold", anchor="lm"); text(d, (820, 330), "Thứ tự", 26, GREY, "Bold")
            for j, (n, o) in enumerate(AZ_ROWS):
                y = 410 + j * 80; hi = o == "3" and t >= 142.5
                if hi: d.rounded_rectangle([320, y - 32, 880, y + 32], 14, fill=(255, 236, 214))
                text(d, (380, y), n, 30, ORANGE if hi else INK, anchor="lm"); text(d, (820, y), o, 30, ORANGE if hi else INK)
    arrow(d, 940, 560, 1080, 560, p(t, 144.7, 0.4), ORANGE, 8)
    s2 = pop(t, 144.8)
    if s2 > 0.01:
        card(d, 1380, 560, 520, 560, s2, True, GREEN)
        if s2 > 0.98:
            text(d, (1380, 330), "Hiển thị", 26, GREY, "Bold")
            for j, n in enumerate(AZ_OUT):
                y = 410 + j * 80; hi = n in ("KHẤU TRỪ", "THƯỞNG")
                if hi: d.rounded_rectangle([1160, y - 32, 1600, y + 32], 14, fill=(255, 236, 214))
                text(d, (1380, y), n, 30, ORANGE if hi else INK)
    pill(d, 1380, 900, 380, 70, ORANGE, "K trước T (A → Z)", 26, pop(t, 147.1))
    role_tag(img, d, CB, "C&B")

_save = {}
def save_still():
    if "im" not in _save:
        im = still(ST + "add34.png").copy(); dd = ImageDraw.Draw(im)
        dd.text((840, 208), "KHẤU TRỪ", font=_inter, fill=(24, 24, 27))          # sửa đè: tên nhóm ví dụ
        dd.text((1253, 208), "6", font=_inter, fill=(24, 24, 27))                 # sửa đè: thứ tự ví dụ
        _save["im"] = im
    return _save["im"]
def sc_save(img, d, t):
    still_web(img, save_still())
    top_title(d, t, "Lưu nhóm công thức", 148.5)
    if t < 150.5: hl(d, B(*F_TEN), t); hl(d, B(*F_TT), t)
    else: hl(d, B(*F_LUU), t)
    chip_bar(d, t, [(151.6, "Nhóm công thức được dùng khi thiết lập công thức lương", GREEN)], size=24)
    role_tag(img, d, CB, "C&B")

# ================= Hiển thị trên phiếu lương =================
def sc_h_ht(img, d, t): sub_card(img, d, t, HD["ht"], "PHẦN 7", ["NHÓM CÔNG THỨC & CÁCH", "HIỂN THỊ TRÊN PHIẾU LƯƠNG"], 72)

F_NHOM = (1157, 350, 1503, 411)          # trường Nhóm công thức = PHỤ CẤP (form công thức lương)
F_BL_PC = (628, 358, 1295, 945)          # cột phụ cấp liền nhau trên bảng lương
def sc_pick(img, d, t):
    ct = piece(t, [(158.1, 0.3), (163.4, 3.0)])
    scr(img, "pick", REC_PICK, ct, REC_BR)
    top_title(d, t, "Công thức lương được chọn nhóm", 158.2)
    if t >= 159.9: hl(d, B(*F_NHOM, REC_BR), t)
    role_tag(img, d, CB, "C&B")

# view dọc (Thu nhập nhân viên mở rộng): kết quả công thức hiển thị theo nhóm. View ngang KHÔNG chịu ảnh hưởng của nhóm.
PC_CARD = (262, 496, 1000, 1305)         # thẻ Tổng thu nhập: LƯƠNG, PHỤ CẤP…
PC_BLOCK = (283, 990, 1000, 1298)        # khối PHỤ CẤP
def sc_grp(img, d, t):
    if t < 169.6:
        fs_shot(img, IMG_PC, PC_FULL, PC_FULL, 0)
        if t < 166.7:
            top_title(d, t, "Kết quả công thức hiển thị theo nhóm tương ứng", 163.5)
            if t >= 163.7: hl(d, XP(*PC_CARD), t)
        else:
            top_title(d, t, "Các khoản phụ cấp nằm trong nhóm PHỤ CẤP", 166.8)
            if t >= 167.3: hl(d, XP(*PC_BLOCK), t)
        return
    paste(img, BOARD)
    top_title(d, t, "Phiếu lương của nhân viên trên App", 169.7)
    P = app_phone(img, d, 760, 78, 432, 14.0)
    if t >= 170.2: hl(d, P(*APP_PC), t)
    role_badge(img, d, EMP, "Nhân viên", 1420, 760, pop(t, 169.8, 0.5), 300)

_pn = {}
def nogroup_panel():
    if "im" not in _pn:
        im = still(ST + "form.png").crop((760, 255, 1520, 420)).copy()
        ImageDraw.Draw(im).rectangle([1165 - 760, 377 - 255, 1497 - 760, 409 - 255], fill=WHITE)    # xoá "PHỤ CẤP" ×
        _pn["im"] = im
    return _pn["im"]
def sc_nogrp(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Công thức không cần hiển thị cho nhân viên", 174.7, size=52)
    hcard(d, 560, 300, 780, 120, pop(t, 177.3), BLUE, "search", "Công thức để kiểm tra, đối chiếu", 28, True)
    hcard(d, 560, 450, 780, 120, pop(t, 178.9), CYAN, "logic", "Dữ liệu trung gian cho công thức khác", 28, True)
    role_tag(img, d, CB, "C&B")

_nf = {}
def nogroup_form():
    """form công thức lương đầy đủ, xoá giá trị ở trường Nhóm công thức (minh hoạ để trống)"""
    if "im" not in _nf:
        im = still(ST + "form.png").copy()
        ImageDraw.Draw(im).rectangle([1165, 377, 1497, 409], fill=WHITE)
        _nf["im"] = im
    return _nf["im"]
def sc_nogrp_form(img, d, t):
    still_web(img, nogroup_form(), REC_BR)
    top_title(d, t, "Công thức không cần hiển thị cho nhân viên", 181.9)
    if t >= 182.2: hl(d, B(*F_NHOM, REC_BR), t)
    if t < 184.6: chip_bar(d, t, [(182.0, "Không cần hiển thị cho nhân viên", ORANGE)], size=24)
    else: chip_bar(d, t, [(184.7, "Có thể không chọn nhóm công thức (để trống trường này)", GREEN)], size=24)
    role_tag(img, d, CB, "C&B")

TN_CROP = (216, 285, 2300, 520); TN_W = 1180; TN_X, TN_Y = 50, 430
def tn_xy(x0, y0, x1, y1):
    k = TN_W / (TN_CROP[2] - TN_CROP[0])
    return (TN_X + (x0 - TN_CROP[0]) * k, TN_Y + (y0 - TN_CROP[1]) * k, TN_X + (x1 - TN_CROP[0]) * k, TN_Y + (y1 - TN_CROP[1]) * k)
def sc_zero(img, d, t):
    paste(img, BOARD)
    top_title(d, t, "Kết quả bằng 0: không hiển thị trên phiếu lương", 187.2)
    P = app_phone(img, d, 640, 78, 432, 8.0)
    if t >= 191.2: hl(d, P(*APP_GROUPS), t)
    s_ = pop(t, 188.4)
    if s_ > 0.01:
        card(d, 1370, 330, 760, 230, s_, True, NAVY)
        if s_ > 0.9:
            text(d, (1370, 260), "Các nhóm đã khai báo", 26, GREY, "Bold")
            for i, (lab, zero) in enumerate([("LƯƠNG", 0), ("PHỤ CẤP", 0), ("THƯỞNG", 1), ("BHXH", 0), ("THUẾ", 0)]):
                mini_chip(d, 1070 + i * 150, 340, 138, 54, lab, (150, 158, 175) if zero and t >= 191.2 else BLUE, 1, 20)
            if t >= 191.2: text(d, (1370, 410), "THƯỞNG = 0 → không xuất hiện", 24, RED, "Bold")
    pill(d, 1370, 560, 760, 72, GREEN, "Phiếu lương chỉ hiện các khoản có giá trị", 26, pop(t, 192.9))
    role_badge(img, d, EMP, "Nhân viên", 1370, 1000, pop(t, 188.0, 0.5), 260)

def sc_note0(img, d, t):
    fs_shot(img, IMG_AN_CLEAN, AN_FULL, AN_FULL, 0)
    top_title(d, t, "Lưu ý: hiển thị giá trị 0 trên Thu nhập cá nhân (web)", 194.6)
    if t >= 195.0: hl(d, XA(1828, 1320, 2372, 1394), t)
    chip_bar(d, t, [(195.3, "Thu nhập cá nhân trên web vẫn hiện giá trị 0 nếu không tick ô này", NAVY)], size=24)
    role_tag(img, d, CB, "C&B")

# ================= Tổng kết =================
def sc_h_tk(img, d, t): sub_card(img, d, t, HD["tk"], "PHẦN 7", ["TỔNG KẾT"], 110)

def sc_tk(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Ba nội dung khi thiết lập nhóm công thức", X(196.7), size=54)
    qs = [(X(200.7), "Công thức nào nằm\ncùng một nhóm", "search", BLUE), (X(203.5), "Tên nhóm là gì", "edit", ORANGE),
          (X(205.1), "Thứ tự nhóm\ntrên phiếu lương", "chart", GREEN)]
    for i, (st, lab, kind, col) in enumerate(qs):
        vcard(d, 500 + i * 460, 470, 420, 360, pop(t, st), col, kind, lab, 28, True, f"0{i + 1}")
    s_ = pop(t, X(207.6))
    if s_ > 0.01:
        card(d, W / 2 + 60, 845, 1340, 170, s_, True, NAVY)
        text(d, (W / 2 + 60, 815), "Nhóm công thức giúp tổ chức hiển thị các khoản thu nhập trên phiếu lương", 28 * s_, INK, "Bold")
        k = pop(t, X(213.4), 0.4)
        if k > 0.01: text(d, (W / 2 + 60, 875), "phù hợp chính sách và nhu cầu thực tế của doanh nghiệp", 28 * k, BLUE, "Bold")
    role_tag(img, d, CB, "C&B", pop(t, X(197.0), 0.4))

def sc_end(img, d, t):
    paste(img, BOARD)
    k = pop(t, X(218.7))
    pill(d, W / 2, 300, 360, 76, NAVY, "Bước tiếp theo", 32, k)
    s_ = pop(t, X(221.0), 0.6)
    if s_ > 0.01:
        card(d, W / 2, 560, 1100, 320, s_, True, ORANGE)
        icon(d, "fx", W / 2 - 420 * s_, 560, s_, ORANGE, 90)
        text(d, (W / 2 + 90, 520), "CÔNG THỨC LƯƠNG", 58 * s_, NAVY)
        k2 = pop(t, X(222.7))
        if k2 > 0.01: text(d, (W / 2 + 90, 600), "Hình thành bảng lương & tính toán tự động", 26 * k2, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B", k)

SCENES = [(-OFFSET, 3.0, "h_p7"), (3.0, HD["lagi"], "intro"), (HD["lagi"], 23.1, "h_lagi"), (23.1, 41.4, "gom"),
          (41.4, 56.2, "app1"), (56.2, HD["ct"], "imagine"), (HD["ct"], 67.7, "h_ct"), (67.7, 99.8, "plan"),
          (99.8, HD["tl"], "need2"), (HD["tl"], 110.5, "h_tl"), (110.5, 131.5, "add"), (131.5, 135.3, "dup"),
          (135.3, 148.4, "order"), (148.4, HD["ht"], "save"), (HD["ht"], 158.1, "h_ht"), (158.1, 163.4, "pick"),
          (163.4, 174.5, "grp"), (174.5, 181.8, "nogrp"), (181.8, 186.3, "nogrp_form"), (186.3, HD["tk"], "zero"),
          (HD["tk"], X(196.6), "h_tk"), (X(196.6), X(216.7), "tk"), (X(216.7), 999, "end")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv7"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 8
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p7_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p7_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
