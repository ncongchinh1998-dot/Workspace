"""PHẦN 8.3 — THIẾT LẬP HIỂN THỊ CỦA CÔNG THỨC LƯƠNG
Mục: Thiết lập hiển thị (báo cáo, báo cáo tổng hợp lương theo đơn vị / nhân viên) · Hiển thị trên bảng lương (Hiển thị với)
     · Ẩn trên Thu nhập cá nhân khi giá trị bằng 0.  Hình: tư liệu phần 8 (ảnh + 2 GIF)."""
import sys, math
from hw_core import *
from part81 import sub_card, full_of, shot_xy, mini_chip, badge
U = "/mnt/user-data/uploads/"

VOICE = A + "voice_p83.wav"
OFFSET = 1.0
VOICE_DUR = 212.09
TOTAL = OFFSET + VOICE_DUR + 1.0
OUT = "/mnt/user-data/outputs/Phan8_3_Thiet_lap_hien_thi.mp4"
HD = dict(ht=-0.6, bl=45.2, an=153.3)
SFX_AT = [0.0] + [OFFSET + v for v in list(HD.values())[1:]]

IMG_HTV = U + "Hiển_thị_với.png"                    # 2864x1532 form: các ô hiển thị + Hiển thị với
IMG_XUAT = U + "Nút_xuất_dữ_liệu_bảng_lương.png"     # 2813x1534
IMG_BCDV = U + "Báo_cáo_tiền_lương.png"              # 2794x1460 báo cáo tổng hợp lương theo đơn vị
IMG_BCNV = U + "Báo_cáo_tổng_hợp_lương_nhân_viên.png"  # 2779x1526
IMG_TNCN = U + "Thu_nhập_cá_nhân.png"                # 2879x1523 Thu nhập của tôi (web)
GIF_ALL = U + "hiển_thị_tại_tất_cả_chu_kỳ_lương.gif"  # 1470x736
GIF_RNG = U + "Hiển_thị_ctl_theo_khoảng_thời_gian.gif"  # 1464x806
IMG_AN = "/tmp/p7_an_clean.png"                     # ảnh "ẩn trên thu nhập cá nhân" đã xoá khung vẽ tay (phần 7)

HTV_FULL = full_of(2864, 1532); XV = shot_xy(HTV_FULL)
XUAT_BOX = (86, 0, 2813, 1534); XX = shot_xy(XUAT_BOX)                 # canh phải để thấy trọn nút Xuất dữ liệu
BCDV_BOX = (0, 0, 2596, 1460); XB = shot_xy(BCDV_BOX)                  # canh trái để thấy menu Báo cáo tiền lương
BCNV_FULL = full_of(2779, 1526); XN = shot_xy(BCNV_FULL)
TN_FULL = full_of(2879, 1523); XT = shot_xy(TN_FULL)
AN_FULL = full_of(2879, 1531); XA = shot_xy(AN_FULL)

V = dict(BC=(1228, 405, 1540, 456), THDV=(1228, 462, 1770, 535), BL=(1825, 548, 2170, 596), THNV=(1228, 695, 1770, 760),
         AN=(1825, 600, 2370, 672), ALLR=(1228, 932, 2378, 1172), SEC=(1199, 912, 2408, 1497), GROUP=(1228, 405, 2370, 760))

HL_PAD = 10
def hl(d, box, t=0.0, kind="rect"):
    box = (box[0] - HL_PAD, box[1] - HL_PAD, box[2] + HL_PAD, box[3] + HL_PAD)
    d.rounded_rectangle(box, 10, outline=RED, width=6 + int(2 * abs(math.sin(t * 5))))
def htv(img): fs_shot(img, IMG_HTV, HTV_FULL, HTV_FULL, 0)
def vhl(d, k, t): hl(d, XV(*V[k]), t)

_clips = {}
def gif(img, key, path, tc, w, h, y0):
    if key not in _clips: _clips[key] = Clip(path, (w, h))
    fr = _clips[key].get(tc); bg = Image.new("RGB", (1920, 1080), WHITE)
    if fr is not None: bg.paste(fr, (0, y0))
    img.paste(bg, (0, 0))
G1 = dict(w=1920, h=961, y0=70, k=1920 / 1470)                     # GIF tất cả chu kỳ
def g1xy(x0, y0, x1, y1): k = G1["k"]; return (x0 * k, y0 * k + G1["y0"], x1 * k, y1 * k + G1["y0"])
G2 = dict(w=1920, h=1057, y0=12, k=1920 / 1464)
def g2xy(x0, y0, x1, y1): k = G2["k"]; return (x0 * k, y0 * k + G2["y0"], x1 * k, y1 * k + G2["y0"])

def piece(t, pts):
    if t <= pts[0][0]: return pts[0][1]
    for (a_, ca), (b_, cb) in zip(pts, pts[1:]):
        if a_ <= t <= b_: return ca + (t - a_) * (cb - ca) / (b_ - a_)
    return pts[-1][1]

# ================= Thiết lập hiển thị =================
def sc_h_ht(img, d, t): sub_card(img, d, t, HD["ht"], "PHẦN 8", ["THIẾT LẬP HIỂN THỊ", "CỦA CÔNG THỨC LƯƠNG"], 88)

def sc_intro(img, d, t):
    htv(img)
    top_title(d, t, "Kết quả công thức được sử dụng & hiển thị ở đâu?", 3.4)
    if t >= 9.2: vhl(d, "GROUP", t)
    role_tag(img, d, CB, "C&B")

def sc_bc(img, d, t):
    if t < 18.3:
        htv(img)
        top_title(d, t, "Hiển thị trên báo cáo", 12.6)
        if t >= 13.6: vhl(d, "BC", t)
        role_tag(img, d, CB, "C&B")
        return
    fs_shot(img, IMG_XUAT, XUAT_BOX, XUAT_BOX, 0)
    top_title(d, t, "Kết quả hiển thị trên file Excel khi xuất bảng lương", 18.4)
    if t >= 20.8: hl(d, XX(2584, 143, 2798, 214), t)
    role_tag(img, d, CB, "C&B")

def sc_thdv(img, d, t):
    if t < 27.8:
        htv(img)
        top_title(d, t, "Hiển thị tại báo cáo tổng hợp lương theo đơn vị", 22.6)
        if t >= 23.3: vhl(d, "THDV", t)
        role_tag(img, d, CB, "C&B")
        return
    fs_shot(img, IMG_BCDV, BCDV_BOX, BCDV_BOX, 0)
    if t < 30.3: chip_bar(d, t, [(27.9, "Kết quả xuất hiện tại Báo cáo tiền lương", NAVY)], size=24)
    if t >= 28.4: hl(d, XB(1106, 96, 1779, 132), t)
    if t >= 30.4: hl(d, XB(100, 1342, 330, 1378), t)

def sc_thnv(img, d, t):
    if t < 37.2:
        htv(img)
        top_title(d, t, "Hiển thị tại báo cáo tổng hợp lương theo nhân viên", 32.0)
        if t >= 32.6: vhl(d, "THNV", t)
        role_tag(img, d, CB, "C&B")
        return
    fs_shot(img, IMG_BCNV, BCNV_FULL, BCNV_FULL, 0)
    top_title(d, t, "Chọn kết quả tính cần đưa vào báo cáo", 37.3)
    if t >= 37.8: hl(d, XN(1146, 176, 1886, 212), t)
    chip_bar(d, t, [(41.0, "Phục vụ tổng hợp dữ liệu cho kê khai và quyết toán thuế", GREEN)], size=24)
    role_tag(img, d, CB, "C&B")

# ================= Hiển thị trên bảng lương =================
def sc_h_bl(img, d, t): sub_card(img, d, t, HD["bl"], "PHẦN 8", ["HIỂN THỊ TRÊN BẢNG LƯƠNG"], 88)

FORMS = [("Tổng công tính lương", True), ("Công thức trung gian 1", False), ("Lương thực tế", True), ("Công thức trung gian 2", False), ("Tổng thu nhập", True)]
def sc_bl(img, d, t):
    if t >= 71.0:
        htv(img)
        top_title(d, t, "Hiển thị trên bảng lương", 71.1)
        vhl(d, "BL", t)
        chip_bar(d, t, [(72.3, "Chỉ bật với công thức có kết quả cần hiển thị để theo dõi hoặc kiểm tra", NAVY)], size=23)
        role_tag(img, d, CB, "C&B")
        return
    paste(img, BOARD)
    board_title(d, t, "Không phải công thức nào cũng cần bật hiển thị", 48.0, size=52)
    for j, (lab, show) in enumerate(FORMS):
        s_ = pop(t, 50.8 + j * 0.3)
        col = BLUE if show else (130, 140, 160)
        mini_chip(d, 480, 260 + j * 110, 600, 70, lab, col, s_, 26)
        if not show and s_ > 0.9 and t >= 51.9:
            text(d, (480, 260 + j * 110 + 50), "phục vụ tính toán", 18, GREY, "Bold")
    s2 = pop(t, 55.2)
    if s2 > 0.01:
        card(d, 1360, 500, 840, 560, s2, True, NAVY)
        if s2 > 0.9:
            text(d, (1360, 265), "Bảng lương", 32, NAVY)
            shown = [l for l, sh in FORMS if sh]
            for i, l in enumerate(shown):
                x = 1120 + i * 240
                d.rounded_rectangle([x - 110, 320, x + 110, 400], 12, fill=(232, 240, 255))
                text(d, (x, 360), l, fit_size(d, l, 20, "Bold", 200), NAVY, "Bold")
                for r in range(3): d.rounded_rectangle([x - 110, 420 + r * 70, x + 110, 470 + r * 70], 10, fill=(245, 247, 251))
    for j, (lab, show) in enumerate(FORMS):
        if show: arrow(d, 790, 260 + j * 110, 930, 260 + j * 110, p(t, 55.4, 0.4), BLUE, 5)
    k = pop(t, 62.0)
    if k > 0.01:
        card(d, W / 2 + 60, 900, 1300, 150, k, True, ORANGE)
        text(d, (W / 2 + 60, 875), "Không bật: công thức vẫn được tính & dùng trong công thức khác", 24 * k, INK, "Bold")
        k2 = pop(t, 67.6, 0.4)
        if k2 > 0.01: text(d, (W / 2 + 60, 925), "nhưng kết quả không hiển thị trên bảng lương", 24 * k2, ORANGE, "Bold")
    role_tag(img, d, CB, "C&B")

def sc_htv(img, d, t):
    htv(img)
    if t < 86.6:
        top_title(d, t, "Khi bật Hiển thị trên bảng lương", 77.9)
        vhl(d, "BL", t)
    else:
        top_title(d, t, "Hiển thị với: chu kỳ lương & khoảng thời gian hiển thị", 86.7)
        if t < 89.0: vhl(d, "SEC", t)
        else: vhl(d, "ALLR", t)
    role_tag(img, d, CB, "C&B")

def sc_gall(img, d, t):
    if t < 115.6:
        gif(img, "g1", GIF_ALL, 13.5, G1["w"], G1["h"], G1["y0"])
        top_title(d, t, "Tất cả chu kỳ lương, từ ngày 1 đến ngày 31", 106.5)
        if t >= 107.2: hl(d, g1xy(628, 580, 1205, 705), t)
        return
    ct = piece(t, [(115.6, 19.2), (117.2, 19.2), (117.3, 20.6), (119.8, 23.4)])
    gif(img, "g1", GIF_ALL, ct, G1["w"], G1["h"], G1["y0"])
    top_title(d, t, "Chu kỳ lương khác vẫn hiển thị công thức", 115.7)
    if 115.9 <= t < 117.2 or t >= 119.9: hl(d, g1xy(440, 155, 750, 222), t); hl(d, g1xy(1205, 228, 1400, 655), t)

def sc_ctrl(img, d, t):
    """bố cục cân: mỗi thẻ chia 2 cột — trái: các khoản (chip), phải: ý nghĩa; nội dung canh giữa theo chiều dọc thẻ"""
    paste(img, BOARD)
    board_title(d, t, "Chủ động kiểm soát thời điểm hiển thị trên bảng lương", 123.6, size=50)
    CX0, CW = 980, 1300                        # thẻ 330–1630
    for (t0, y, col, items, msg, ok) in [
            (133.2, 400, GREEN, [(134.5, "Công"), (135.1, "Làm thêm giờ")], (133.6, "Cho nhân viên\nkiểm tra trước"), True),
            (136.4, 680, ORANGE, [(137.5, "Lương"), (138.0, "Phụ cấp"), (139.0, "Tổng thu nhập")], (139.7, "Chưa phải số liệu\ncuối cùng để chi trả"), False)]:
        s_ = pop(t, t0)
        if s_ <= 0.01: continue
        card(d, CX0, y, CW, 210, s_, True, col)
        if s_ < 0.9: continue
        d.line([1170, y - 70, 1170, y + 70], fill=LINE, width=3)
        n = len(items); xs = [750 + (i - (n - 1) / 2) * 250 for i in range(n)]
        for x, (st, lab) in zip(xs, items):
            mini_chip(d, x, y, 230, 62, lab, col, pop(t, st, 0.4), 24)
        k = pop(t, msg[0], 0.4)
        if k > 0.01: text(d, (1380, y), msg[1], 26 * k, col)
        if ok: badge(d, 1575, y, True, pop(t, 133.8, 0.4), 24)
    role_tag(img, d, CB, "C&B")

def sc_default(img, d, t):
    if t < 149.8:
        htv(img)
        top_title(d, t, "Mặc định: tất cả chu kỳ lương, từ ngày 1 đến ngày 31", 143.2)
        if t >= 144.4: vhl(d, "ALLR", t)
    else:
        gif(img, "g2", GIF_RNG, 5.0, G2["w"], G2["h"], G2["y0"])
        top_title(d, t, "Có thể điều chỉnh theo nhu cầu vận hành", 149.9)
        if t >= 150.3: hl(d, g2xy(612, 666, 1250, 792), t)
    role_tag(img, d, CB, "C&B")

# ================= Ẩn trên thu nhập cá nhân =================
def sc_h_an(img, d, t): sub_card(img, d, t, HD["an"], "PHẦN 8", ["ẨN TRÊN THU NHẬP CÁ NHÂN", "KHI GIÁ TRỊ BẰNG 0"], 80)

def sc_tncn(img, d, t):
    fs_shot(img, IMG_TNCN, TN_FULL, TN_FULL, 0)
    top_title(d, t, "Màn hình Thu nhập cá nhân trên máy tính", 157.6)
    if t >= 158.6: hl(d, XT(150, 40, 412, 84), t)
    chip_bar(d, t, [(161.0, "Thường được nhân viên khối văn phòng sử dụng để xem thu nhập của mình", NAVY)], size=23)
    role_tag(img, d, EMP, "Nhân viên")

def sc_policy(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Chính sách khác nhau cho từng khối nhân viên", 166.2, size=52)
    s0 = pop(t, 172.6)
    if s0 > 0.01:
        card(d, W / 2, 290, 760, 110, s0, True, ORANGE)
        text(d, (W / 2, 290), "Thưởng chỉ áp dụng cho khối cửa hàng", 30 * s0, ORANGE)
    s1 = pop(t, 174.6)
    if s1 > 0.01:
        card(d, 560, 640, 700, 380, s1, True, GREEN)
        if s1 > 0.9:
            text(d, (560, 490), "Khối cửa hàng", 34, GREEN)
            text(d, (560, 600), "Thưởng khối cửa hàng", 26, INK, "Bold")
            text(d, (560, 670), "Có giá trị", 40, GREEN)
            badge(d, 860, 490, True, 1, 24)
    s2 = pop(t, 175.6)
    if s2 > 0.01:
        card(d, 1360, 640, 700, 380, s2, True, (130, 140, 160))
        if s2 > 0.9:
            text(d, (1360, 490), "Khối văn phòng", 34, NAVY)
            text(d, (1360, 600), "Thưởng khối cửa hàng", 26, INK, "Bold")
            k = pop(t, 180.4, 0.4)
            if k > 0.01: text(d, (1360, 670), "= 0", 48 * k, RED)
            k2 = pop(t, 178.4, 0.4)
            if k2 > 0.01: text(d, (1360, 760), "Không thuộc chính sách áp dụng", 22 * k2, GREY, "Bold")
    role_tag(img, d, CB, "C&B")

def sc_tick(img, d, t):
    fs_shot(img, IMG_AN, AN_FULL, AN_FULL, 0)
    top_title(d, t, "Công thức thưởng dành riêng cho khối cửa hàng", 182.6)
    if t >= 187.2: hl(d, XA(1828, 1320, 2372, 1394), t)
    role_tag(img, d, CB, "C&B")

ROWS_TN = [("Lương thực tế", "x.xxx.xxx", False), ("Phụ cấp trách nhiệm", "x.xxx.xxx", False), ("Thưởng khối cửa hàng", "0", True), ("Tổng thu nhập", "x.xxx.xxx", False)]
def sc_result(img, d, t):
    paste(img, BOARD)
    board_title(d, t, "Thu nhập cá nhân của nhân viên khối văn phòng", 191.0, size=52)
    for col, cx, label, hide, st in [(GREY, 560, "Không chọn ẩn", False, 191.4), (GREEN, 1360, "Chọn ẩn khi giá trị bằng 0", True, 196.6)]:
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        card(d, cx, 560, 700, 520, s_, True, col)
        if s_ < 0.9: continue
        text(d, (cx, 345), label, 30, col)
        y = 420
        for lab, val, zero in ROWS_TN:
            if zero and hide:
                continue
            d.rounded_rectangle([cx - 300, y - 32, cx + 300, y + 32], 12, fill=(255, 236, 236) if zero else (243, 246, 252))
            text(d, (cx - 280, y), lab, 24, INK, "Bold", anchor="lm"); text(d, (cx + 280, y), val, 24, RED if zero else GREEN, "Bold", anchor="rm")
            y += 80
        if hide: badge(d, cx + 320, 345, True, 1, 26)
    pill(d, W / 2 + 60, 920, 1180, 70, NAVY, "Chỉ hiển thị những khoản thực sự liên quan đến nhân viên", 26, pop(t, 201.2))
    role_tag(img, d, EMP, "Nhân viên")

SCENES = [(-OFFSET, 3.1, "h_ht"), (3.1, 12.4, "intro"), (12.4, 22.4, "bc"), (22.4, 31.9, "thdv"), (31.9, HD["bl"], "thnv"),
          (HD["bl"], 47.9, "h_bl"), (47.9, 77.8, "bl"), (77.8, 106.3, "htv"), (106.3, 123.2, "gall"), (123.2, 143.1, "ctrl"),
          (143.1, HD["an"], "default"), (HD["an"], 157.5, "h_an"), (157.5, 166.1, "tncn"), (166.1, 182.4, "policy"),
          (182.4, 190.9, "tick"), (190.9, 999, "result")]
FN = {n: globals()["sc_" + n] for _, _, n in SCENES}

def preview(times, out="/tmp/pv83"):
    import os; os.makedirs(out, exist_ok=True)
    for tv in times:
        img = BG.copy()
        for s, e, name in SCENES:
            if s <= tv < e: FN[name](img, ImageDraw.Draw(img), tv)
        img.save(f"{out}/{tv:07.2f}.png")

N = 8
if __name__ == "__main__":
    n = int(TOTAL * FPS); size = math.ceil(n / N)
    if sys.argv[1] == "preview": preview([float(x) for x in sys.argv[2:]])
    elif sys.argv[1] == "seg":
        k = int(sys.argv[2]); render_segment(SCENES, FN, OFFSET, TOTAL, k * size, min(n, (k + 1) * size), f"/tmp/p83_seg{k}.mp4")
    elif sys.argv[1] == "mux":
        mux([f"/tmp/p83_seg{k}.mp4" for k in range(N)], VOICE, OFFSET, TOTAL, OUT, SFX_AT)
