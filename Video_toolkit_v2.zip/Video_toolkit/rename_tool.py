"""Sửa đè tên chu kỳ lương trên ảnh/khung hình: lấp nền (màu lấy ngay bên trái chữ) rồi viết tên mới bằng Inter, màu lấy từ chữ gốc."""
from PIL import Image, ImageDraw, ImageFont
import numpy as np
FONT = "/home/claude/assets/Inter.ttf"
def _font(sz):
    f = ImageFont.truetype(FONT, sz); f.set_variation_by_name("Regular"); return f
def rename(img, box, new, size, pad=4, align="left", mode="auto"):
    """box = (x0, y0, x1, y1) vùng chữ cũ (toạ độ của img)"""
    x0, y0, x1, y1 = [int(round(v)) for v in box]
    a = np.asarray(img.convert("RGB"))
    bg = tuple(int(c) for c in a[(y0 + y1) // 2, max(x0 - 8, 0)])
    reg = a[y0:y1, x0:x1].reshape(-1, 3).astype(int)
    sat = reg[:, 2] - (reg[:, 0] + reg[:, 1]) / 2                             # chữ link màu xanh: lấy pixel xanh đậm nhất
    if mode == "auto" and sat.max() > 40: col = tuple(int(c) for c in reg[sat.argmax()])
    else: col = tuple(int(c) for c in reg[reg.sum(1).argmin()])            # chữ thường: pixel đậm nhất
    d = ImageDraw.Draw(img)
    d.rectangle([x0 - pad, y0 - pad, x1 + pad, y1 + pad], fill=bg)
    f = _font(size)
    if align == "right": d.text((x1, (y0 + y1) / 2), new, font=f, fill=col, anchor="rm")
    else: d.text((x0, (y0 + y1) / 2), new, font=f, fill=col, anchor="lm")
