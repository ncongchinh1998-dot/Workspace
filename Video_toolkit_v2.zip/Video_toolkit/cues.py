"""Neo hiệu ứng vào mốc thời gian từng từ (ASR word timestamps).
ASR trả mốc sớm ~0.25s so với thực tế; hình nên vào trước lời ~0.1s => +0.15s."""
import json
CAL = 0.15
class Cues:
    def __init__(self, path):
        self.w = [(a, t) for a, t in json.load(open(path))]
    def __call__(self, phrase, after=0.0, shift=0.0):
        ws = phrase.lower().split()
        for i in range(len(self.w) - len(ws) + 1):
            if self.w[i][1] >= after and all(self.w[i + j][0] == ws[j] for j in range(len(ws))):
                return round(self.w[i][1] + CAL + shift, 2)
        raise ValueError(f"cue not found: {phrase!r} after {after}")
