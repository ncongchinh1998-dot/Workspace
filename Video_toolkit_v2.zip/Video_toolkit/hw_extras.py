"""hw_extras — các kỹ thuật bổ sung đã chuẩn hoá trong quá trình làm (dùng chung với hw_core).

    from hw_core import *
    from hw_extras import *

Gồm:
  hl(d, box, t)                         khung đỏ có nới lề, viền nhấp nháy nhẹ
  piece(t, pts)                         khớp nhịp bản quay với voice: [(giây_voice, giây_clip), …]
  panel(img, d, path, crop, x, y, w)    đặt ảnh/màn hình hệ thống vào khung, trả về hàm đổi toạ độ ảnh gốc -> khung hình
  callout(d, X, field, label, col)      hộp chú thích + đường dẫn tới ô (đặt ở vùng trống bên trái; ô cột phải -> đặt dưới)
  overlay_text(fr, box, txt, …)         sửa đè chữ trên ảnh/khung hình (đúng font, cỡ, màu chữ gốc)
  FixClip(path, size, crop, fixes)      Clip tự sửa đè chữ theo khoảng thời gian (vd đồng nhất tên kỳ lương trên bản quay)
  grid_steps(img, d, t, steps, …)       lưới nhiều màn hình (2×2 / 3 cột) hiện lần lượt, mỗi ô có tiêu đề bước + khung đỏ
  erase_rect(path, out, box, color)     xoá logo/chi tiết thừa trên ảnh slide bằng màu nền
  board_bg()                            nền BOARD hoàn chỉnh (để che vùng cũ khi chỉnh một phần cảnh)
  warp(fn, Minv)                        chạy cảnh cũ theo nhịp mốc thời gian mới
"""
import math
from PIL import Image, ImageDraw, ImageFont
from hw_core import *          # noqa: F401,F403  (A, W, RED, WHITE, LINE, text, fit_size, Clip, BG, BOARD, paste, …)

HL_PAD = 10

def hl(d, box, t=0.0, pad=HL_PAD, col=None):
    b = (box[0] - pad, box[1] - pad, box[2] + pad, box[3] + pad)
    d.rounded_rectangle(b, 10, outline=col or RED, width=6 + int(2 * abs(math.sin(t * 5))))

def piece(t, pts):
    if t <= pts[0][0]: return pts[0][1]
    for (a_, ca), (b_, cb) in zip(pts, pts[1:]):
        if a_ <= t <= b_: return ca + (t - a_) * (cb - ca) / (b_ - a_)
    return pts[-1][1]

_shots = {}
def panel(img, d, path, crop, x, y, w, s=1.0, frame=True):
    """Ảnh hệ thống (vùng crop của ảnh gốc) đặt tại (x, y) rộng w. Trả về X(x0,y0,x1,y1) đổi toạ độ ảnh gốc -> khung hình."""
    if path not in _shots: _shots[path] = Image.open(path).convert("RGB")
    im = _shots[path].crop(crop); k = w / im.width; h = int(im.height * k)
    if s > 0.01:
        if frame: d.rounded_rectangle([x - 8, y - 8, x + w + 8, y + h + 8], 16, fill=WHITE, outline=LINE, width=3)
        img.paste(im.resize((int(w), h), Image.LANCZOS), (int(x), int(y)))
    return lambda x0, y0, x1, y1: (x + (x0 - crop[0]) * k, y + (y0 - crop[1]) * k, x + (x1 - crop[0]) * k, y + (y1 - crop[1]) * k)

def callout_below(d, X, field, label, col=RED, y_top=None, w=300):
    fb = X(*field); xc = (fb[0] + fb[2]) / 2
    y0 = (y_top if y_top is not None else fb[3] + 60)
    f = fit_size(d, label, 22, "ExtraBold", w - 24)
    d.rounded_rectangle([xc - w / 2, y0, xc + w / 2, y0 + 48], 12, fill=col)
    text(d, (xc, y0 + 24), label, f, WHITE, "ExtraBold")
    d.line([xc, y0, xc, fb[3] + HL_PAD + 2], fill=col, width=4)
    d.ellipse([xc - 6, fb[3] + HL_PAD - 4, xc + 6, fb[3] + HL_PAD + 8], fill=col)

def callout(d, X, field, label, col=RED, left_zone=(70, 445), right_col_x=None, y_top=None):
    """Hộp chữ ở vùng trống bên trái (toạ độ ảnh gốc left_zone) + đường dẫn ngang tới ô.
    Nếu ô nằm ở cột phải (field[0] >= right_col_x) → hộp đặt dưới, đường dẫn thẳng lên (không cắt qua chữ)."""
    if right_col_x is not None and field[0] >= right_col_x:
        return callout_below(d, X, field, label, col, y_top)
    fb = X(*field); yc = (fb[1] + fb[3]) / 2
    bx0, _, bx1, _ = X(left_zone[0], 0, left_zone[1], 0)
    f = fit_size(d, label, 22, "ExtraBold", bx1 - bx0 - 24)
    d.rounded_rectangle([bx0, yc - 24, bx1, yc + 24], 12, fill=col)
    text(d, ((bx0 + bx1) / 2, yc), label, f, WHITE, "ExtraBold")
    x2 = fb[0] - HL_PAD - 2
    d.line([bx1, yc, x2, yc], fill=col, width=4)
    d.ellipse([x2 - 6, yc - 6, x2 + 6, yc + 6], fill=col)

_ff = {}
def _font(px, weight="Regular"):
    k = (px, weight)
    if k not in _ff:
        f = ImageFont.truetype(A + "Inter.ttf", px); f.set_variation_by_name(weight); _ff[k] = f
    return _ff[k]

def overlay_text(fr, box, txt, font_px, ink=None, ref_box=None, bg=None, weight="Regular", link_color=False):
    """Sửa đè chữ trong box (toạ độ của fr). Màu chữ: ink, hoặc lấy từ ref_box (link_color=True: lấy màu xanh link)."""
    dd = ImageDraw.Draw(fr)
    x0, y0, x1, y1 = box
    if ink is None:
        rb = ref_box or box
        px = list(fr.crop(tuple(int(v) for v in rb)).convert("RGB").getdata())
        ink = max(px, key=lambda p: (p[2] - p[0]) * 2 - sum(p) / 3) if link_color else min(px, key=lambda p: sum(p))
    if bg is None: bg = fr.getpixel((min(fr.width - 1, int(x1) + 6), int((y0 + y1) / 2)))
    dd.rectangle([x0 - 1, y0 - 1, x1 + 1, y1 + 1], fill=bg)
    dd.text((x0, (y0 + y1) / 2), txt, font=_font(max(6, int(round(font_px))), weight), fill=ink, anchor="lm")
    return fr

class FixClip(Clip):
    """Clip có sửa đè chữ. fixes = [((x0,y0,x1,y1) toạ độ khung gốc, "chữ mới", (t_clip_từ, t_clip_đến), cỡ_px_gốc, vùng_màu_mẫu|None)]."""
    def __init__(self, path, size, crop, fixes, src_size=None):
        super().__init__(path, size, crop); self.fixes = fixes
        if src_size is None and not crop:
            import subprocess
            w_, h_ = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height",
                                     "-of", "csv=p=0", path], capture_output=True, text=True).stdout.strip().split(",")[:2]
            src_size = (int(w_), int(h_))
        self.src_size = src_size
    def get(self, t):
        fr = super().get(t)
        if fr is None: return fr
        todo = [f for f in self.fixes if f[2][0] <= t <= f[2][1]]
        if not todo: return fr
        fr = fr.copy()
        cx, cy, cw, ch = self.crop if self.crop else (0, 0) + tuple(self.src_size)
        kx, ky = self.size[0] / cw, self.size[1] / ch
        M_ = lambda b: ((b[0] - cx) * kx, (b[1] - cy) * ky, (b[2] - cx) * kx, (b[3] - cy) * ky)
        for box, txt, _, fpx, ref in todo:
            overlay_text(fr, M_(box), txt, fpx * ky, ref_box=M_(ref) if ref else None, link_color=bool(ref))
        return fr

def grid_steps(img, d, t, steps, cols=2, cell=(880, 400), origin=(60, 150), gap=(40, 60)):
    """steps = [(ảnh PIL đã cắt, "1. Tiêu đề bước", (x0,y0,x1,y1) khung đỏ theo toạ độ ảnh đó | None, t_hiện)]."""
    cw, ch = cell
    for i, (im, lab, box, st) in enumerate(steps):
        s_ = pop(t, st)
        if s_ <= 0.01: continue
        cx = origin[0] + (i % cols) * (cw + gap[0]); cy = origin[1] + (i // cols) * (ch + gap[1])
        sc = min(cw / im.width, (ch - 50) / im.height); iw, ih = int(im.width * sc), int(im.height * sc)
        ox, oy = cx + (cw - iw) // 2, cy + 50
        img.paste(im.resize((iw, ih)), (ox, oy)); d.rectangle([ox, oy, ox + iw, oy + ih], outline=LINE, width=3)
        text(d, (cx + cw / 2, cy + 20), lab, 26, NAVY, "ExtraBold")
        if box and t >= st + 0.4:
            hl(d, (ox + box[0] * sc, oy + box[1] * sc, ox + box[2] * sc, oy + box[3] * sc), t)

def erase_rect(path, out, box, color):
    im = Image.open(path).convert("RGB"); ImageDraw.Draw(im).rectangle(box, fill=color); im.save(out); return out

_bb = None
def board_bg():
    global _bb
    if _bb is None: _bb = BG.copy(); paste(_bb, BOARD)
    return _bb

def warp(fn, Minv):
    return lambda img, d, t: fn(img, d, Minv(t))
