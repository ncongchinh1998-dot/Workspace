# Hướng dẫn chuẩn bị dữ liệu cho mỗi phần video

> Không bắt buộc làm đủ, Claude vẫn tự xử lý được. Mỗi mục bạn làm được sẽ giúp **ít vòng sửa hơn và video sát ý hơn**. Mục ★ là hiệu quả nhất.

## 1. Voice
- ★ **Gửi voice đã chốt.** Mỗi lần đổi voice, toàn bộ nhịp hình phải canh lại.
- Nếu chỉ sửa vài câu, ghi chú ngắn: "sửa câu về …".
- Xuất file .wav (hoặc .mp3) và **nghe lại đoạn cuối trước khi gửi**. Đã có lần file bị im lặng từ giây thứ 14.
- Đọc chậm và rõ ở **tên mục**, ngắt khoảng 0,5 giây trước và sau tiêu đề. Claude dựa vào khoảng ngắt này để chèn âm thanh chuyển mục.
- Số liệu ví dụ trong voice nên **khớp với dữ liệu trên màn hình** (ví dụ voice nói phụ cấp xăng 10 triệu thì màn hình cũng là 10 triệu).

## 2. Quay màn hình
- ★ **Dừng khoảng 2 giây ở mỗi chỗ voice sẽ nói tới**: trường cần nhập, nút bấm, kết quả sau khi lưu.
- Thao tác chậm, hạn chế cuộn liên tục; tránh **Alt-Tab** hoặc chuyển cửa sổ khi đang quay.
- Trình duyệt để **zoom 100%**, cửa sổ toàn màn hình, độ phân giải 1920×1080 nếu được.
- Mỗi thao tác một file ngắn (10–30 giây) tốt hơn một file dài nhiều thao tác.
- Đóng hoặc ẩn thông báo, popup không liên quan; dữ liệu demo **đúng với ví dụ trong voice**.
- Muốn thể hiện nhiều sheet hoặc nhiều tab (ví dụ Xuất chi tiết) thì để **thanh tab hiện rõ** trong khung quay.

## 3. Ảnh chụp màn hình
- Chụp **toàn màn hình**, không cắt sát, để học viên biết đang ở màn hình nào.
- Nội dung cần nói nên nằm ở **nửa trên hoặc giữa màn hình**. Góc trái dưới có icon nhân vật C&B nên dễ bị che.
- Ảnh có dropdown hoặc hộp thoại thì chụp lúc **đang mở** sẵn.

## 4. Đặt tên & sắp xếp file (nếu tiện)
- Đặt tên theo thứ tự xuất hiện trong voice: `7_01_danh_sach_nhom.mp4`, `7_02_tao_nhom.png`…
- Gửi một lần đủ tư liệu của cả phần (voice và màn hình) để Claude ghép một lượt.

## 5. Ghi chú kèm (không bắt buộc)
- Một vài dòng kiểu: *"câu về X → dùng màn hình Y, khoanh trường Z"*. Claude coi đây là **gợi ý**, vẫn tự kiểm lại trên màn hình thật.
- Có thể khoanh sẵn trên ảnh nếu thấy nhanh. Khoanh chưa chuẩn cũng không sao.

## 6. Khi duyệt & góp ý
- **Bước storyboard:** chỉ cần xem nội dung nghiệp vụ đúng chưa và chọn ý tưởng trình bày. Đây là lúc góp ý rẻ nhất.
- **Bước video:** góp ý theo bất kỳ dạng nào: mốc phút:giây, số khung `#12` trên sheet bằng chứng, hoặc mô tả bằng lời. **Hạn chế gửi ảnh chụp** để tiết kiệm giới hạn hình của đoạn chat.
- Lỗi định dạng (khung lệch, che chữ, lệch thời điểm) là việc Claude phải tự soát. Nếu vẫn gặp, chỉ cần báo một chỗ, Claude sẽ tự rà các chỗ tương tự.
