"""QA cho khung đỏ & bố cục — chạy TRƯỚC khi giao video, không cần người duyệt định dạng.

1) Định vị bằng chữ (OCR tiếng Việt) thay vì ước lượng toạ độ bằng mắt:
     from qa_kit import locate, snap_box
     box = locate(frame_img, "Mã thành phần lương")          # bbox của cụm chữ trên khung hình thật
     box = locate(frame_img, "Ngày lương", grow=(0, 0, 0, 60)) # nới thêm xuống dưới để ôm cả ô dữ liệu
2) Tự nới khung để không cắt ngang chữ:  box = snap_box(img, box)
3) Kiểm tra cả video (chưa render):  python3 qa_kit.py part62.py [bước_giây=0.4]
     -> /tmp/qa/<part>_report.txt + /tmp/qa/<part>_sheet_*.png (mỗi khung đỏ: lúc bắt đầu / giữa / cuối, có số thứ tự)
   Cảnh báo tự động:
     CẮT_CHỮ     viền khung đi qua chữ / nét đậm
     CHUYỂN_ĐỘNG nội dung trong khung thay đổi khi khung đang hiện (màn hình đang tải / cuộn / đóng hộp thoại)
     TRỐNG       vùng trong khung gần như không có nội dung (màn hình trắng lúc đang tải, khung đặt sai chỗ)
     CHE         khung đỏ trùng vùng nhãn vai trò (góc trái dưới), tiêu đề trên cùng hoặc dải chip dưới cùng
     CHỒNG_KHUNG hai khung đỏ cùng lúc đè lên nhau
Cài OCR tiếng Việt (1 lần):
  mkdir -p /home/claude/tessdata && cp /usr/share/tesseract-ocr/5/tessdata/eng.traineddata /home/claude/tessdata/
  curl -sL -o /home/claude/tessdata/vie.traineddata https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/vie.traineddata
"""
import sys, os, math, unicodedata, importlib.util
import numpy as np
from PIL import Image, ImageDraw, ImageFont

TESS = "--tessdata-dir /home/claude/tessdata --psm 11"

def _norm(s):
    s = unicodedata.normalize("NFD", s.lower())
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn").replace("đ", "d")

_ocr_cache = {}
def ocr_words(img, dense=False):
    import pytesseract
    key = (img.size, dense, hash(img.resize((64, 36)).tobytes()))
    if key in _ocr_cache: return _ocr_cache[key]
    from PIL import ImageOps
    ws = []
    g = img.convert("L"); big = g.resize((g.width * 2, g.height * 2), Image.LANCZOS)
    # lượt 1: chữ tối trên nền sáng · lượt 2: chữ sáng trên nền màu (nút bấm) → nhị phân hoá ngưỡng cao rồi đảo
    passes = [big, big.point(lambda v: 0 if v > 200 else 255)]
    cfgs = (TESS.replace("--psm 11", "--psm 6"),) * 2 if dense else (TESS, TESS.replace("--psm 11", "--psm 6"))
    for src, cfg in zip(passes, cfgs):
        d = pytesseract.image_to_data(src, lang="vie", config=cfg, output_type=pytesseract.Output.DICT)
        ws += [(d["text"][i].strip(), d["left"][i] // 2, d["top"][i] // 2, (d["left"][i] + d["width"][i]) // 2, (d["top"][i] + d["height"][i]) // 2)
               for i in range(len(d["text"])) if d["text"][i].strip() and float(d["conf"][i]) > 30]
    _ocr_cache[key] = ws
    return ws

def locate_all(img, phrase, region=None, pad=6):
    """Mọi vị trí khớp cụm chữ (điểm cao trước). Ưu tiên khớp trọn cụm, đúng chữ hoa/thường."""
    sub = img.crop(region) if region else img
    ox, oy = (region[0], region[1]) if region else (0, 0)
    ws = ocr_words(sub, dense=region is not None); target = _norm(phrase).split(); raw = phrase.split()
    out = []
    for i in range(len(ws)):
        for j in range(i + 1, min(len(ws), i + len(target) + 2) + 1):
            seg = ws[i:j]; cand = [_norm(w[0]) for w in seg]
            if max(w[2] for w in seg) - min(w[2] for w in seg) > 40: continue          # cùng một dòng
            hit = sum(1 for t in target if any(t == c or (len(t) > 2 and (t in c or c in t)) for c in cand))
            score = hit / len(target) - 0.08 * abs(len(cand) - len(target))
            if " ".join(cand) == " ".join(target): score += 0.5
            if [w[0] for w in seg] == raw: score += 0.3                                  # đúng chữ hoa/thường
            if score >= 0.6:
                b = (min(w[1] for w in seg) + ox - pad, min(w[2] for w in seg) + oy - pad,
                     max(w[3] for w in seg) + ox + pad, max(w[4] for w in seg) + oy + pad)
                out.append((score, b))
    out.sort(key=lambda x: -x[0])
    return out

def locate(img, phrase, region=None, grow=(0, 0, 0, 0), pad=6, nth=0):
    """bbox (x0,y0,x1,y1) của cụm chữ trên khung hình thật. grow=(trái,trên,phải,dưới) để ôm thêm ô dữ liệu.
    region: giới hạn vùng tìm (ví dụ trong hộp thoại). nth: chọn kết quả thứ n."""
    r = locate_all(img, phrase, region, pad)
    if not r and region is None:                     # chưa thấy: quét lại theo từng dải ngang (bắt được chữ trên nút màu)
        for y in range(0, img.height, 180):
            r = locate_all(img, phrase, (0, max(0, y - 40), img.width, min(img.height, y + 220)), pad)
            if r: break
    if len(r) <= nth: return None
    b = r[nth][1]
    return (b[0] - grow[0], b[1] - grow[1], b[2] + grow[2], b[3] + grow[3])

def _ink(arr, bg):
    return (np.abs(arr.astype(int) - bg).sum(-1) > 90)

def _cross(line):
    """Số lần 'cắt qua nét chữ' trên một đường viền: chữ tạo nhiều chuyển sáng/tối liên tiếp,
    còn nền màu (nút, ô xám, lớp phủ) chỉ tạo rất ít chuyển."""
    g = line.astype(int).mean(-1) if line.ndim == 2 else line.astype(int)
    if g.size < 8: return 0.0
    dg = np.abs(np.diff(g)) > 45
    return dg.sum() / (g.size / 100.0)

def edge_ink(img, box):
    """Mức độ viền khung đi qua chữ (số chuyển sáng/tối trên mỗi 100px viền, lấy cạnh tệ nhất)."""
    a = np.asarray(img.convert("RGB")); H_, W_ = a.shape[:2]
    x0, y0, x1, y1 = [int(round(v)) for v in box]
    x0, x1 = max(0, x0), min(W_ - 1, x1); y0, y1 = max(0, y0), min(H_ - 1, y1)
    if x1 - x0 < 8 or y1 - y0 < 8: return 0.0
    return max(_cross(a[y0, x0:x1]), _cross(a[y1, x0:x1]), _cross(a[y0:y1, x0]), _cross(a[y0:y1, x1]))

def snap_box(img, box, step=4, maxgrow=48, thr=3.0):
    """Nới từng cạnh ra ngoài (tối đa maxgrow px) cho tới khi cạnh không còn đi qua chữ."""
    a = np.asarray(img.convert("RGB")); H_, W_ = a.shape[:2]
    x0, y0, x1, y1 = [float(v) for v in box]
    for _ in range(maxgrow // step):
        changed = False
        xa, xb, ya, yb = int(max(0, x0)), int(min(W_ - 1, x1)), int(max(0, y0)), int(min(H_ - 1, y1))
        if ya > 0 and _cross(a[ya, xa:xb]) > thr: y0 -= step; changed = True
        if yb < H_ - 1 and _cross(a[yb, xa:xb]) > thr: y1 += step; changed = True
        if xa > 0 and _cross(a[ya:yb, xa]) > thr: x0 -= step; changed = True
        if xb < W_ - 1 and _cross(a[ya:yb, xb]) > thr: x1 += step; changed = True
        if not changed: break
    return (x0, y0, x1, y1)

# ---------------- Kiểm tra toàn bộ một file partX.py ----------------
ZONES = {"nhãn vai trò": (0, 790, 270, 1080), "tiêu đề trên": (560, 0, 1360, 95), "dải chip": (200, 1010, 1720, 1080)}
def _inter(a, b):
    w = min(a[2], b[2]) - max(a[0], b[0]); h = min(a[3], b[3]) - max(a[1], b[1])
    return max(0, w) * max(0, h)

def run(part_path, step=0.4, out="/tmp/qa"):
    os.makedirs(out, exist_ok=True)
    for f in os.listdir(out):
        if f.startswith(os.path.splitext(os.path.basename(part_path))[0] + "_"): os.remove(os.path.join(out, f))
    name = os.path.splitext(os.path.basename(part_path))[0]
    sys.argv = [part_path, "qa"]
    spec = importlib.util.spec_from_file_location(name, part_path); mod = importlib.util.module_from_spec(spec)
    sys.path.insert(0, os.path.dirname(os.path.abspath(part_path)))
    spec.loader.exec_module(mod)
    log = []
    orig = mod.hl
    def hl_rec(d, box, t=0.0, kind="rect"):
        pad = getattr(mod, "HL_PAD", 0)
        b = (box[0] - pad, box[1] - pad, box[2] + pad, box[3] + pad)
        img = d._image
        log.append((CUR[0], tuple(round(v) for v in b), img.copy()))
        return orig(d, box, t, kind)
    mod.hl = hl_rec
    CUR = [0.0]
    t, T_END = -mod.OFFSET + 0.05, mod.VOICE_DUR
    while t < T_END:
        img = mod.BG.copy(); CUR[0] = t
        for s, e, nm in mod.SCENES:
            if s <= t < e: mod.FN[nm](img, ImageDraw.Draw(img), t)
        t += step
    # gom các lần vẽ cùng một khung liên tiếp thành 1 nhóm
    groups, active = [], {}
    for tt, b, im in log:
        key = (round(b[0] / 6), round(b[1] / 6), round(b[2] / 6), round(b[3] / 6))
        g = active.get(key)
        if g and tt - g["t1"] <= step * 1.6:
            if tt != g["t1"]: g["frames"].append((tt, b, im))
            g["t1"] = tt
        else:
            g = dict(t0=tt, t1=tt, frames=[(tt, b, im)]); groups.append(g); active[key] = g
    lines, crops = [], []
    for n, g in enumerate(groups, 1):
        fr = g["frames"]; picks = [fr[0], fr[len(fr) // 2], fr[-1]]
        warns = []
        ei = max(edge_ink(im, b) for _, b, im in picks)
        if ei > 4.0: warns.append(f"CẮT_CHỮ({ei:.1f})")
        def region(im, b): return np.asarray(im.convert("L").crop(tuple(int(v) for v in b)).resize((64, 32))).astype(int)
        mv = max(np.abs(region(fr[i][2], fr[i][1]) - region(fr[i - 1][2], fr[i - 1][1])).mean() for i in range(1, len(fr))) if len(fr) > 1 else 0
        if mv > 6: warns.append(f"CHUYỂN_ĐỘNG({mv:.0f})")
        std = region(picks[1][2], picks[1][1]).std()
        if std < 6: warns.append("TRỐNG")
        b = picks[1][1]; area = max(1, (b[2] - b[0]) * (b[3] - b[1]))
        for zn, z in ZONES.items():
            if _inter(b, z) / area > 0.25: warns.append(f"CHE:{zn}")
        for m_, g2 in enumerate(groups, 1):
            if g2 is g or g2["t1"] < g["t0"] or g2["t0"] > g["t1"]: continue
            b2 = g2["frames"][len(g2["frames"]) // 2][1]
            if _inter(b, b2) > 0.05 * area and not (b2[0] <= b[0] and b2[1] <= b[1] and b2[2] >= b[2] and b2[3] >= b[3]):
                warns.append(f"CHỒNG_KHUNG(#{m_:02d})")
        lines.append(f"#{n:02d}  {g['t0']:7.2f}s → {g['t1']:7.2f}s  box={b}  " + (" ".join(warns) if warns else "OK"))
        for tt, bb, im in picks:
            x0, y0, x1, y1 = bb; m = 50
            c = im.crop((max(0, x0 - m), max(0, y0 - m), min(1920, x1 + m), min(1080, y1 + m))).copy()
            dd = ImageDraw.Draw(c); ox, oy = max(0, x0 - m), max(0, y0 - m)
            dd.rectangle([x0 - ox, y0 - oy, x1 - ox, y1 - oy], outline=(255, 0, 0), width=4)
            c.thumbnail((420, 240))
            crops.append((n, tt, c, bool(warns)))
    # ghép sheet: mỗi dòng = 1 khung (bắt đầu | giữa | cuối)
    font = ImageFont.load_default()
    per_sheet = 8
    for si in range(0, len(groups), per_sheet):
        rows = [crops[i * 3:(i + 1) * 3] for i in range(si, min(si + per_sheet, len(groups)))]
        sheet = Image.new("RGB", (60 + 3 * 430, len(rows) * 255 + 10), "white"); d = ImageDraw.Draw(sheet)
        for r, row in enumerate(rows):
            n = row[0][0]; y = 5 + r * 255
            d.text((8, y + 110), f"#{n:02d}", fill=(200, 0, 0) if row[0][3] else (0, 120, 0), font=font)
            for k, (_, tt, c, _) in enumerate(row):
                sheet.paste(c, (60 + k * 430, y)); d.text((60 + k * 430, y + 242), f"{tt:.1f}s", fill=(0, 0, 0), font=font)
        sheet.save(f"{out}/{name}_sheet_{si // per_sheet + 1}.png")
    rep = f"{out}/{name}_report.txt"
    open(rep, "w").write("\n".join(lines))
    bad = [l for l in lines if not l.endswith("OK")]
    print(f"{len(groups)} khung đỏ · {len(bad)} cảnh báo → {rep}")
    for l in bad: print(l)

if __name__ == "__main__":
    run(sys.argv[1], float(sys.argv[2]) if len(sys.argv) > 2 else 0.4)
