# BỘ CÔNG CỤ DỰNG VIDEO ĐÀO TẠO PHẦN MỀM (phong cách Haraworks)

Dành cho AI dựng video ở đoạn chat mới. Đọc file này trước, sau đó đọc `PROMPT_EDIT_VIDEO.md` và `STYLE_GUIDE.pdf`.

## 1. Cài đặt (mỗi phiên làm việc)

```bash
mkdir -p /home/claude && cd /home/claude
unzip -o <đường_dẫn>/Video_toolkit.zip && cp -r Video_toolkit/* /home/claude/
# Nhận dạng giọng nói tiếng Việt (mốc thời gian từng từ)
pip install sherpa-onnx --break-system-packages -q
cd /tmp && curl -sL -O https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-zipformer-vi-int8-2025-04-20.tar.bz2 && tar xjf sherpa-onnx-zipformer-vi-int8-2025-04-20.tar.bz2
# OCR tiếng Việt (tìm vị trí chữ trên màn hình hệ thống)
mkdir -p /home/claude/tessdata && cp /usr/share/tesseract-ocr/5/tessdata/eng.traineddata /home/claude/tessdata/
curl -sL -o /home/claude/tessdata/vie.traineddata https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/vie.traineddata
```

Tư liệu nằm ở `/home/claude/assets/`. Tư liệu người dùng gửi nằm ở `/mnt/user-data/uploads/`.

## 2. Thành phần

| File | Vai trò |
|---|---|
| `hw_core.py` | Thư viện dựng hình chính. Nền `BG / SECTION / BOARD` (từ `bg-1.png`), font Montserrat, các thành phần `pill`, `card`, `hcard`, `vcard`, `board_title`, `top_title`, `chip_bar`, `role_tag`, `role_badge`, `person`, `icon`, `arrow`, `sparks`, `phone`; màn hình `fullscreen`, `fs_shot`, `box169`; `Clip` (đọc video theo giây); `render_segment`, `mux` (ghép, chèn voice và âm thanh chuyển mục) |
| `hw_extras.py` | **Các kỹ thuật chuẩn hoá về sau:** `hl` (khung đỏ có lề), `piece` (khớp nhịp bản quay với voice), `panel` (đặt màn hình hệ thống và đổi toạ độ), `callout` (hộp chú thích có đường dẫn ở vùng trống), `overlay_text` / `FixClip` (sửa đè chữ trên ảnh/bản quay đúng font, cỡ, màu), `grid_steps` (lưới nhiều màn hình), `erase_rect` (xoá logo), `board_bg`, `warp` |
| `cues.py` | `Cues(words.json)`: `c("cụm từ", sau_giây)` trả về thời điểm từ bắt đầu được đọc |
| `asr_words.py` | `python3 asr_words.py voice.wav words.json`: mốc thời gian từng từ |
| `qa_kit.py` | `locate(khung_hình, "tên trường")` tìm toạ độ chữ bằng OCR. `python3 qa_kit.py partX.py` soát toàn bộ khung đỏ (cắt chữ / đang chuyển động / trống / bị che / chồng khung) và xuất sheet ảnh bằng chứng |
| `remap_voice.py` | So khớp hai bản voice theo từng từ, dùng khi người dùng gửi lại voice |
| `templates/` | **Kịch bản dựng thật của các phần đã duyệt**, dùng làm mẫu (xem mục 3) |
| `assets/` | `bg-1.png` (nền + logo), `Logo.png`, `Montserrat.ttf` (chữ dựng), `Inter.ttf` (chữ giao diện hệ thống, dùng khi sửa đè), `sfx.wav` (âm thanh chuyển mục), nhân vật `p1–p6.png`, `std_*.png` |

**Nhân vật** (`hw_core`): `CB` (p2, nữ cầm laptop) · `CEO` (p1, nam vest) · `HR_LEAD` (p3, nữ áo cam) · `EMP` (p4, nữ cầm điện thoại) · `STAFF` (p5, nam áo vàng) · `MANAGER` (p6, nữ cầm tablet). Nhãn vai trò đổi theo ứng dụng (ví dụ "Kế toán" thay cho "C&B").

## 3. Mẫu nên tham khảo khi dựng phần mới

- `templates/part62.py`: cấu trúc chuẩn của một phần: `SCENES`, `FN`, `sub_card` (thẻ tiêu đề mục), bản quay kèm khung đỏ, **lưới nhiều màn hình** (`sc_copy`, `sc_upload`), preview / seg / mux.
- `templates/part4d.py` (chạy cùng `part4c.py`, `part4b.py`, `part4.py`): **toàn màn hình hệ thống + hộp chú thích có đường dẫn**, **ví dụ đặt song song màn hình** (dải ngày), cảnh "hiểu đơn giản ba thiết lập", sửa đè giá trị trên màn hình.
- `templates/part23.py`: **`FixClip`**, đồng nhất tên gọi trên bản quay (ví dụ "Tháng mm/yyyy"); điện thoại hiển thị phiếu lương.
- `templates/part52.py`: bản quay toàn màn hình **không zoom**, khung đỏ theo lời đọc, nhãn vai trò đổi theo người thực hiện, chip.
- `templates/part1.py`: các cảnh minh hoạ trên nền BOARD (thẻ, sơ đồ, quy trình bước).

Các file mẫu tham chiếu tư liệu của dự án tính lương ở `/mnt/user-data/uploads/`. Chỉ dùng chúng làm **mẫu cấu trúc và cách làm**, không chạy lại nguyên trạng.

## 4. Quy trình kỹ thuật một phần

1. Kiểm tra voice: biên độ từng 30 giây, phát hiện file lỗi hoặc im lặng.
2. Chạy `asr_words.py` để lấy mốc từng từ; dùng `silencedetect` để tìm tiêu đề mục.
3. Lập contact sheet cho bản quay, ghi diễn biến theo giây.
4. Dùng `locate()` hoặc lưới toạ độ để lấy toạ độ khung trên khung hình thật.
5. Viết `partX.py` theo mẫu, rồi `python3 partX.py preview <các giây>` và xem sheet.
6. Chạy `python3 qa_kit.py partX.py`, sửa hết cảnh báo.
7. `python3 partX.py seg k`: mỗi lệnh bash render 2–3 đoạn, `timeout 280`.
8. `python3 partX.py mux`, rồi copy file ra `/mnt/user-data/outputs/`.

**Lưu ý:**
- `Clip(path, size, crop=(x, y, rộng, cao))`: crop là rộng/cao, không phải toạ độ góc.
- Thư mục `/home/claude` và `/tmp` có thể bị xoá giữa các phiên. Luôn lưu file `.py` ra outputs sau mỗi lần sửa.
- Khi chỉ sửa vài cảnh, render lại riêng các đoạn chứa cảnh đó rồi `mux` (cần còn các file đoạn trong /tmp; nếu mất thì render lại toàn bộ).

## 5. Bổ sung từ Phần 7–13 (mẫu & kỹ thuật)

| Mẫu | Kỹ thuật nên tham khảo |
|---|---|
| `templates/part81.py` | Form công thức toàn màn hình + khung trường; danh sách dropdown thật, khung chạy theo thứ tự voice liệt kê; bảng Excel hàm |
| `templates/part82n.py` + `part82p.py` | Bảng theo ngày hiện theo nhịp đọc; hai màn hình cạnh nhau (Có chọn / Không chọn); cắt cụm từ khỏi voice và dời cảnh |
| `templates/part83d.py` | Thanh thời gian theo ngày song song màn hình; sửa đè giá trị ô (Từ ngày 4/5); so sánh có ẩn / không ẩn |
| `templates/part84c.py` | Điện thoại App (phiếu lương) + khung dòng nhóm; thẻ cách 1/cách 2 |
| `templates/part91b.py` | Mỗi câu hỏi đi kèm màn hình hệ thống tương ứng |
| `templates/part92b.py` (+ `part92.py`, `part92c.py`, `part92e.py`) | Thẻ tra cứu TPL căn giữa khi bên phải trống; ví dụ hiện nhãn trước, kết quả sau (8/8 = 1 công); dấu + giữa kết quả, khoanh nhấp nháy, Tổng ÷ 30; cắt chữ đọc lặp & ánh xạ voice nhiều lớp |
| `templates/part93b.py` | Ánh xạ voice đọc lại bằng `remap_voice.make_maps`, chèn/bỏ cảnh |
| `templates/part10.py` | Sửa đè tên chu kỳ "Tháng mm/yyyy" trên ảnh và từng khung hình bản quay |
| `templates/part11b.py` | Thao tác App từng bước (khung hình chính + khung chỗ bấm + chip bước); sửa số rác trên báo cáo; thêm tiêu đề mục theo voice mới |
| `rename_tool.py` | `rename(img, box, chữ_mới, cỡ, align, mode)`: sửa đè chữ, tự lấy màu nền & màu chữ gốc (mode="dark" cho chữ thường, auto cho chữ link xanh) |

**Xử lý voice gửi lại:** so MD5 → nếu khác thì so ASR + tương quan sóng âm để đo lệch → lệch ≈ 0 chỉ thay audio (mux lại, giữ sfx); lệch cục bộ thì ánh xạ thời gian; kịch bản đổi nhiều thì dựng mới. Không bao giờ chèn khoảng lặng vào voice.
