"""Haraworks video core: palette, fonts, layers, helpers, icons, render.
Dùng chung cho mọi phần (Phần 1, Phần 2, ...) để giữ đúng quy chuẩn template."""
import math, subprocess
from PIL import Image, ImageDraw, ImageFont

A = "/home/claude/assets/"
LOGO = A + "Logo.png"
W, H, FPS = 1920, 1080, 30

# ---------- Brand palette ----------
NAVY = (27, 42, 135); BLUE = (43, 98, 232); CYAN = (0, 166, 240); DEEP = (22, 50, 165)
ORANGE = (242, 140, 40); YEL = (250, 182, 45); RED = (240, 82, 80); INK = (22, 22, 30)
GREEN = (33, 150, 83); WHITE = (255, 255, 255); LINE = (215, 222, 240); SHADOW = (165, 180, 222)
GREY = (120, 128, 150)

# ---------- Fonts ----------
_fc = {}
def font(size, weight="ExtraBold"):
    k = (max(int(size), 1), weight)
    if k not in _fc:
        f = ImageFont.truetype(A + "Montserrat.ttf", k[0]); f.set_variation_by_name(weight); _fc[k] = f
    return _fc[k]

# ---------- Easing ----------
def clamp(t): return max(0.0, min(1.0, t))
def ease(t): t = clamp(t); return 1 - (1 - t) ** 3
def back(t, s=1.7): t = clamp(t) - 1; return t * t * ((s + 1) * t + s) + 1
def p(t, a, d=0.45): return ease((t - a) / d)
def pop(t, a, d=0.5): return back((t - a) / d) if t > a else 0.0

# ---------- Static layers ----------
BG = Image.open(A + "bg-1.png").convert("RGB").resize((W, H))          # nền + logo (Slide.pdf)
CHARS = [Image.open(A + f"p{i}.png").convert("RGBA") for i in range(1, 7)]
# Quy ước nhân vật
CB, CEO, HR_LEAD, EMP, STAFF, MANAGER = 1, 0, 2, 3, 4, 5   # Nhân viên = cô gái cầm điện thoại; Quản lý = cô gái cầm máy tính bảng
MOCK = [Image.open(A + f"std_{i:03d}.png").convert("RGB") for i in range(1, 67)]
SCREEN = (98, 95, 1408, 915)

LOGO_IMG = Image.open(LOGO).convert("RGBA")
_px = LOGO_IMG.load()
for _y in range(LOGO_IMG.height):
    for _x in range(LOGO_IMG.width):
        r, g, b, _ = _px[_x, _y]
        if min(r, g, b) > 235: _px[_x, _y] = (r, g, b, 0)

def _section_layer():
    L = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
    for off, col in [(0, (190, 205, 245, 200)), (40, (120, 150, 240, 230)), (85, (70, 110, 238, 255)), (120, BLUE + (255,))]:
        pts = [(W, 0)] + [(1460 + off + 70 * math.sin(y / 260 + 0.6) - 40 * math.cos(y / 140), y) for y in range(0, H + 1, 20)] + [(W, H)]
        d.polygon(pts, fill=col)
    d.ellipse([-130, 830, 290, 1250], fill=DEEP + (255,))
    d.ellipse([340, 850, 450, 960], fill=ORANGE + (255,))
    d.ellipse([1520, 760, 1770, 1010], fill=YEL + (255,))
    return L
SECTION = _section_layer()

def _board_layer():
    L = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
    d.polygon([(1510, 0), (W, 0), (W, 240), (1700, 160)], fill=CYAN + (255,))
    d.polygon([(W, 280), (W, 560), (1870, 540), (1860, 320)], fill=DEEP + (255,))
    d.polygon([(0, 560), (60, 600), (60, 860), (0, 900)], fill=DEEP + (255,))
    d.polygon([(0, 960), (200, H), (0, H)], fill=CYAN + (255,))
    for gx in range(12):
        for gy in range(5):
            x, y = 1700 + gx * 16, 960 + gy * 16
            d.ellipse([x - 2, y - 2, x + 2, y + 2], fill=(60, 70, 90, 200))
    return L
BOARD = _board_layer()

# ---------- Helpers ----------
def paste(img, layer, alpha=1.0):
    if alpha >= 1: img.paste(layer, (0, 0), layer)
    elif alpha > 0: img.paste(layer, (0, 0), layer.getchannel("A").point(lambda v: int(v * alpha)))

_cc = {}
def char(img, idx, cx, bottom, h, s=1.0, dx=0):
    if s <= 0.01: return
    hh = max(int(h * s), 2)
    key = (idx, hh)
    if key not in _cc:
        c = CHARS[idx]; _cc[key] = c.resize((max(int(c.width * hh / c.height), 2), hh), Image.LANCZOS)
    c = _cc[key]
    img.paste(c, (int(cx - c.width / 2 + dx), int(bottom - hh)), c)

def fit_size(d, s, size, weight, max_w):
    """Giảm cỡ chữ cho tới khi vừa khung (tránh chữ tràn ra ngoài thẻ)."""
    while size > 12:
        b = d.multiline_textbbox((0, 0), s, font=font(size, weight), spacing=int(size * 0.2))
        if b[2] - b[0] <= max_w: break
        size -= 1
    return size

def text(d, xy, s, size, fill, weight="ExtraBold", anchor="mm", align="center"):
    if size < 2: return
    d.multiline_text(xy, s, font=font(size, weight), fill=fill, anchor=anchor, align=align, spacing=int(size * 0.2))

def sparks(d, cx, cy, side, s, t, size=1.0):
    if s <= 0.01: return
    wob = 1 + 0.06 * math.sin(t * 8)
    for k, ang in enumerate([-35, 0, 35]):
        a = math.radians(ang + (180 if side < 0 else 0))
        L = (70 if k == 1 else 58) * s * size * wob
        x0, y0 = cx + 22 * math.cos(a) * size, cy + 22 * math.sin(a) * size
        x1, y1 = x0 + L * math.cos(a), y0 + L * math.sin(a)
        nx, ny = -math.sin(a) * 9 * s * size, math.cos(a) * 9 * s * size
        d.polygon([(x0, y0), (x1 + nx, y1 + ny), (x1 - nx, y1 - ny)], fill=RED)

def underline(d, x, y, w, k):
    if k <= 0: return
    d.line([x, y, x + w * k, y], fill=ORANGE, width=5)
    if k > 0.95: d.ellipse([x + w - 11, y - 11, x + w + 11, y + 11], outline=ORANGE, width=5)

def pill(d, cx, cy, w, h, col, label, size, s, tcol=WHITE, weight="Bold"):
    if s <= 0.01: return
    w, h = w * s, h * s
    d.rounded_rectangle([cx - w / 2 + 4, cy - h / 2 + 7, cx + w / 2 + 4, cy + h / 2 + 7], h / 2, fill=SHADOW)
    d.rounded_rectangle([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], h / 2, fill=col)
    text(d, (cx, cy), label, fit_size(d, label, size * s, weight, w - h * 0.6), tcol, weight)

def card(d, cx, cy, w, h, s, active=False, col=BLUE, fill=WHITE):
    if s <= 0.01: return
    w, h = w * s, h * s
    d.rounded_rectangle([cx - w / 2 + 6, cy - h / 2 + 10, cx + w / 2 + 6, cy + h / 2 + 10], 28 * s, fill=SHADOW)
    d.rounded_rectangle([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], 28 * s, fill=fill,
                        outline=col if active else LINE, width=max(int(6 * s), 1))

def board_title(d, t, s, start, y=95, size=60):
    a = pop(t, start, 0.5)
    if a > 0.01: text(d, (W / 2, y), s, size * max(a, 0.3), INK)

def section_title(d, t, start, kicker, lines, size=120, y0=250, line_w=760):
    a = p(t, start, 0.5)
    if a > 0 and kicker: text(d, (110, y0 + (1 - a) * 40), kicker, 56, BLUE, anchor="lm", align="left")
    for j, line in enumerate(lines):
        k = p(t, start + 0.2 + j * 0.18, 0.55)
        if k > 0: text(d, (110, y0 + 125 + j * (size * 1.18) + (1 - k) * 60), line, size, NAVY, anchor="lm", align="left")
    yl = y0 + 125 + (len(lines) - 1) * size * 1.18 + size * 0.85
    underline(d, 115, yl, line_w, p(t, start + 0.6, 0.6))
    return yl

def arrow(d, x0, y0, x1, y1, k, col=ORANGE, w=6, head=True):
    if k <= 0: return
    xe, ye = x0 + (x1 - x0) * k, y0 + (y1 - y0) * k
    d.line([x0, y0, xe, ye], fill=col, width=w)
    if head and k > 0.9:
        a = math.atan2(y1 - y0, x1 - x0); L = 20
        d.polygon([(xe + 4 * math.cos(a), ye + 4 * math.sin(a)),
                   (xe - L * math.cos(a - 0.5), ye - L * math.sin(a - 0.5)),
                   (xe - L * math.cos(a + 0.5), ye - L * math.sin(a + 0.5))], fill=col)

def name_tag(d, cx, y, label, s, col=INK):
    if s > 0.01: text(d, (cx, y), label, 34 * max(s, 0.3), col)

def person(img, d, idx, cx, bottom, h, s, label, size=None, dx=0):
    """Nhân vật + tên vai trò bên dưới (theo slide mẫu 'Vai trò')."""
    if s <= 0.01: return
    char(img, idx, cx, bottom, h, s, dx)
    if label:
        fs = (size or max(24, min(36, h * 0.085))) * max(s, 0.3)
        d.multiline_text((cx, bottom + 12), label, font=font(fs, "ExtraBold"), fill=INK, anchor="ma", align="center", spacing=int(fs * 0.15))

# ---------- Icons (white glyph in brand-colored circle) ----------
def icon(d, kind, cx, cy, s, col, r0=70):
    if s <= 0.01: return
    r = r0 * s; k = s * r0 / 70; Wt = WHITE
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=col)
    lw = max(int(6 * k), 1)
    def R(x0, y0, x1, y1, **kw): d.rounded_rectangle([cx + x0 * k, cy + y0 * k, cx + x1 * k, cy + y1 * k], **kw)
    if kind == "db":
        for i in range(3): R(-32, -30 + i * 22, 32, -12 + i * 22, radius=9 * k, fill=Wt)
    elif kind == "logic":
        pts = [(cx - 30 * k, cy + 22 * k), (cx, cy - 26 * k), (cx + 30 * k, cy + 22 * k)]
        d.line(pts + [pts[0]], fill=Wt, width=lw)
        for x, y in pts: d.ellipse([x - 11 * k, y - 11 * k, x + 11 * k, y + 11 * k], fill=Wt)
    elif kind == "run":
        d.polygon([(cx - 20 * k, cy - 30 * k), (cx + 32 * k, cy), (cx - 20 * k, cy + 30 * k)], fill=Wt)
    elif kind == "check":
        d.line([cx - 30 * k, cy + 2 * k, cx - 8 * k, cy + 24 * k, cx + 32 * k, cy - 22 * k], fill=Wt, width=max(int(12 * k), 1), joint="curve")
    elif kind == "sheet":
        R(-32, -32, 32, 32, radius=6 * k, fill=Wt)
        for i in (1, 2): d.line([cx - 32 * k, cy - 32 * k + i * 21 * k, cx + 32 * k, cy - 32 * k + i * 21 * k], fill=col, width=max(int(4 * k), 1))
        d.line([cx - 8 * k, cy - 32 * k, cx - 8 * k, cy + 32 * k], fill=col, width=max(int(4 * k), 1))
    elif kind == "tabs":
        for i in range(3): R(-34 + i * 10, -28 + i * 10, 18 + i * 10, 22 + i * 10, radius=6 * k, fill=Wt, outline=col, width=max(int(3 * k), 1))
    elif kind == "funnel":
        d.polygon([(cx - 36 * k, cy - 28 * k), (cx + 36 * k, cy - 28 * k), (cx + 8 * k, cy + 4 * k), (cx + 8 * k, cy + 30 * k),
                   (cx - 8 * k, cy + 22 * k), (cx - 8 * k, cy + 4 * k)], fill=Wt)
    elif kind == "fx":
        text(d, (cx, cy), "fx", 46 * k, Wt)
    elif kind == "compare":
        R(-36, -26, -6, 26, radius=5 * k, fill=Wt); R(6, -26, 36, 26, radius=5 * k, fill=Wt)
        for y in (-10, 4): d.line([cx - 30 * k, cy + y * k, cx - 12 * k, cy + y * k], fill=col, width=max(int(4 * k), 1))
        for y in (-10, 4): d.line([cx + 12 * k, cy + y * k, cx + 30 * k, cy + y * k], fill=col, width=max(int(4 * k), 1))
    elif kind == "lock":
        d.arc([cx - 20 * k, cy - 40 * k, cx + 20 * k, cy + 4 * k], 180, 360, fill=Wt, width=max(int(8 * k), 1))
        d.line([cx - 16 * k, cy - 18 * k, cx - 16 * k, cy - 4 * k], fill=Wt, width=max(int(8 * k), 1))
        d.line([cx + 16 * k, cy - 18 * k, cx + 16 * k, cy - 4 * k], fill=Wt, width=max(int(8 * k), 1))
        R(-30, -6, 30, 32, radius=6 * k, fill=Wt)
        d.ellipse([cx - 6 * k, cy + 6 * k, cx + 6 * k, cy + 18 * k], fill=col)
    elif kind == "calendar":
        R(-34, -26, 34, 32, radius=6 * k, fill=Wt)
        d.rectangle([cx - 34 * k, cy - 20 * k, cx + 34 * k, cy - 8 * k], fill=col)
        for x in (-18, 18): d.line([cx + x * k, cy - 36 * k, cx + x * k, cy - 20 * k], fill=Wt, width=lw)
        for i in range(3):
            for j in range(2): d.rectangle([cx + (-24 + i * 18) * k, cy + (0 + j * 14) * k, cx + (-14 + i * 18) * k, cy + (8 + j * 14) * k], fill=col)
    elif kind == "clock":
        d.ellipse([cx - 34 * k, cy - 34 * k, cx + 34 * k, cy + 34 * k], outline=Wt, width=lw)
        d.line([cx, cy, cx, cy - 22 * k], fill=Wt, width=lw); d.line([cx, cy, cx + 16 * k, cy + 8 * k], fill=Wt, width=lw)
    elif kind == "doc":
        d.polygon([(cx - 26 * k, cy - 34 * k), (cx + 12 * k, cy - 34 * k), (cx + 28 * k, cy - 18 * k), (cx + 28 * k, cy + 34 * k), (cx - 26 * k, cy + 34 * k)], fill=Wt)
        for i in range(3): d.line([cx - 16 * k, cy - 8 * k + i * 14 * k, cx + 18 * k, cy - 8 * k + i * 14 * k], fill=col, width=max(int(4 * k), 1))
    elif kind == "warn":
        d.polygon([(cx, cy - 34 * k), (cx + 36 * k, cy + 28 * k), (cx - 36 * k, cy + 28 * k)], fill=Wt)
        text(d, (cx, cy + 6 * k), "!", 40 * k, col)
    elif kind == "chart":
        for i, hh in enumerate([24, 44, 62]): d.rectangle([cx + (-32 + i * 24) * k, cy + (30 - hh) * k, cx + (-14 + i * 24) * k, cy + 30 * k], fill=Wt)
    elif kind == "people":
        for x in (-16, 16):
            d.ellipse([cx + (x - 11) * k, cy - 30 * k, cx + (x + 11) * k, cy - 8 * k], fill=Wt)
            d.rounded_rectangle([cx + (x - 18) * k, cy - 2 * k, cx + (x + 18) * k, cy + 30 * k], 12 * k, fill=Wt)
    elif kind == "chat":
        R(-36, -28, 36, 18, radius=14 * k, fill=Wt)
        d.polygon([(cx - 14 * k, cy + 16 * k), (cx - 24 * k, cy + 34 * k), (cx + 2 * k, cy + 16 * k)], fill=Wt)
    elif kind == "hourglass":
        d.polygon([(cx - 26 * k, cy - 32 * k), (cx + 26 * k, cy - 32 * k), (cx, cy)], fill=Wt)
        d.polygon([(cx - 26 * k, cy + 32 * k), (cx + 26 * k, cy + 32 * k), (cx, cy)], fill=Wt)
    elif kind == "search":
        d.ellipse([cx - 30 * k, cy - 30 * k, cx + 12 * k, cy + 12 * k], outline=Wt, width=max(int(8 * k), 1))
        d.line([cx + 8 * k, cy + 8 * k, cx + 30 * k, cy + 30 * k], fill=Wt, width=max(int(10 * k), 1))
    elif kind == "edit":
        d.polygon([(cx + 18 * k, cy - 34 * k), (cx + 34 * k, cy - 18 * k), (cx - 14 * k, cy + 30 * k), (cx - 32 * k, cy + 32 * k), (cx - 30 * k, cy + 14 * k)], fill=Wt)
    elif kind == "shield":
        d.polygon([(cx, cy - 36 * k), (cx + 30 * k, cy - 24 * k), (cx + 26 * k, cy + 10 * k), (cx, cy + 36 * k), (cx - 26 * k, cy + 10 * k), (cx - 30 * k, cy - 24 * k)], fill=Wt)
        d.line([cx - 12 * k, cy, cx - 2 * k, cy + 10 * k, cx + 14 * k, cy - 10 * k], fill=col, width=max(int(6 * k), 1))
    elif kind == "grow":
        d.line([cx - 32 * k, cy + 24 * k, cx - 8 * k, cy, cx + 6 * k, cy + 12 * k, cx + 30 * k, cy - 18 * k], fill=Wt, width=max(int(8 * k), 1), joint="curve")
        d.polygon([(cx + 34 * k, cy - 30 * k), (cx + 36 * k, cy - 8 * k), (cx + 16 * k, cy - 22 * k)], fill=Wt)
    elif kind == "fast":
        for x in (-30, 0): d.polygon([(cx + x * k, cy - 24 * k), (cx + (x + 30) * k, cy), (cx + x * k, cy + 24 * k)], fill=Wt)
    elif kind == "q":
        text(d, (cx, cy + 2 * k), "?", 64 * k, Wt)
    elif kind == "up":
        d.polygon([(cx, cy - 34 * k), (cx + 28 * k, cy - 4 * k), (cx + 10 * k, cy - 4 * k), (cx + 10 * k, cy + 32 * k), (cx - 10 * k, cy + 32 * k), (cx - 10 * k, cy - 4 * k), (cx - 28 * k, cy - 4 * k)], fill=Wt)
    elif kind == "eq":
        for y in (-10, 10): d.rounded_rectangle([cx - 28 * k, cy + (y - 5) * k, cx + 28 * k, cy + (y + 5) * k], 4 * k, fill=Wt)

def hcard(d, cx, cy, w, h, s, col, kind, label, size=34, active=False, tcol=INK, fill=WHITE):
    """Thẻ ngang: icon tròn bên trái + chữ."""
    if s <= 0.01: return
    card(d, cx, cy, w, h, s, active, col, fill)
    ic = h * 0.33
    icon(d, kind, cx - w * s / 2 + (ic + 24) * s, cy, s, col, r0=ic)
    x_txt = cx - w * s / 2 + (2 * ic + 48) * s
    max_w = cx + w * s / 2 - 28 * s - x_txt
    text(d, (x_txt, cy), label, fit_size(d, label, size * s, "Bold", max_w), tcol, "Bold", anchor="lm", align="left")

def vcard(d, cx, cy, w, h, s, col, kind, label, size=32, active=False, num=None):
    """Thẻ dọc: icon trên + chữ dưới."""
    if s <= 0.01: return
    card(d, cx, cy, w, h, s, active, col)
    icon(d, kind, cx, cy - h * 0.18 * s, s, col, r0=min(62, h * 0.18))
    text(d, (cx, cy + h * 0.24 * s), label, fit_size(d, label, size * s, "Bold", (w - 40) * s), INK, "Bold")
    if num: text(d, (cx - w * s / 2 + 34 * s, cy - h * s / 2 + 34 * s), num, 28 * s, col)

# ---------- Render ----------
def render(scenes, fn_map, voice, out, offset, total, sfx_at=()):
    """scenes: list (start, end, name) in voice-time; offset = seconds of video before voice starts."""
    end_v = total - offset
    def frame(tv):
        img = BG.copy()
        for s, e, name in scenes:
            if s <= tv < e:
                fn_map[name](img, ImageDraw.Draw(img), tv)
                fin = 1.0 if s <= scenes[0][0] else p(tv, s, 0.3)
                fout = 1 - (p(tv, end_v - 0.6, 0.6) if e >= end_v else p(tv, e - 0.3, 0.3))
                f = min(fin, fout)
                if f < 1: img = Image.blend(BG, img, max(f, 0))
        return img
    ins = ["-i", voice] + sum([["-i", A + "sfx.wav"] for _ in sfx_at], [])
    ms = int(offset * 1000)
    flt = f"[1:a]adelay={ms}:all=1,apad[v];"
    flt += "".join(f"[{i + 2}:a]adelay={int(x * 1000)}:all=1,volume=0.6[s{i}];" for i, x in enumerate(sfx_at))
    flt += "[v]" + "".join(f"[s{i}]" for i in range(len(sfx_at))) + f"amix=inputs={len(sfx_at) + 1}:duration=first:normalize=0,atrim=0:{total}[a]"
    cmd = ["ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-"] + ins + \
          ["-filter_complex", flt, "-map", "0:v", "-map", "[a]", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "19",
           "-preset", "medium", "-c:a", "aac", "-b:a", "192k", "-t", str(total), out]
    pr = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)
    n = int(total * FPS)
    for i in range(n):
        pr.stdin.write(frame(i / FPS - offset).tobytes())
        if i % 300 == 0: print(f"{i}/{n}", flush=True)
    pr.stdin.close(); pr.wait()
    return frame

def render_segment(scenes, fn_map, offset, total, f0, f1, out):
    """Render frames [f0, f1) video-only (để chia nhỏ khi dựng video dài)."""
    end_v = total - offset
    cmd = ["ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "19", "-preset", "veryfast", out]
    pr = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)
    for i in range(f0, f1):
        tv = i / FPS - offset
        img = BG.copy()
        for s, e, name in scenes:
            if s <= tv < e:
                fn_map[name](img, ImageDraw.Draw(img), tv)
                fin = 1.0 if s <= scenes[0][0] else p(tv, s, 0.3)
                fout = 1 - (p(tv, end_v - 0.6, 0.6) if e >= end_v else p(tv, e - 0.3, 0.3))
                f = min(fin, fout)
                if f < 1: img = Image.blend(BG, img, max(f, 0))
        pr.stdin.write(img.tobytes())
    pr.stdin.close(); pr.wait()

def mux(segments, voice, offset, total, out, sfx_at=()):
    lst = "/tmp/seglist.txt"
    open(lst, "w").write("".join(f"file '{s}'\n" for s in segments))
    ins = ["-f", "concat", "-safe", "0", "-i", lst, "-i", voice] + sum([["-i", A + "sfx.wav"] for _ in sfx_at], [])
    flt = f"[1:a]adelay={int(offset * 1000)}:all=1,apad[v];"
    flt += "".join(f"[{i + 2}:a]adelay={int(x * 1000)}:all=1,volume=0.6[s{i}];" for i, x in enumerate(sfx_at))
    flt += "[v]" + "".join(f"[s{i}]" for i in range(len(sfx_at))) + f"amix=inputs={len(sfx_at) + 1}:duration=first:normalize=0[a]"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error"] + ins + ["-filter_complex", flt, "-map", "0:v", "-map", "[a]",
                    "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-t", str(total), out], check=True)

# ---------- Screen recordings & device frames ----------
class Clip:
    """Đọc video quay màn hình tuần tự qua ffmpeg (đã crop + scale sẵn), tránh tốn RAM."""
    def __init__(self, path, size, crop=None):
        self.path, self.size, self.crop = path, size, crop
        self.dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path],
                                        capture_output=True, text=True).stdout.strip())
        self.pr = None; self.idx = -1; self.t0 = 0; self.last = None
    def _open(self, t):
        if self.pr: self.pr.kill()
        vf = (f"crop={self.crop[2]}:{self.crop[3]}:{self.crop[0]}:{self.crop[1]}," if self.crop else "") + \
             f"scale={self.size[0]}:{self.size[1]}:flags=lanczos,fps={FPS}"
        self.pr = subprocess.Popen(["ffmpeg", "-loglevel", "error", "-ss", f"{t:.3f}", "-i", self.path, "-an", "-vf", vf,
                                    "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE)
        self.t0 = t; self.idx = -1
    def get(self, t):
        t = max(0.0, min(t, self.dur - 0.1))
        want = int(round((t - self.t0) * FPS)) if self.pr else -1
        if self.pr is None or want < self.idx or want - self.idx > 3 * FPS:
            self._open(t); want = 0
        n = self.size[0] * self.size[1] * 3
        while self.idx < want:
            buf = self.pr.stdout.read(n)
            if len(buf) < n: break
            self.last = Image.frombytes("RGB", self.size, buf); self.idx += 1
        return self.last

def laptop(img, d, cx, top, sw, sh, screen=None, s=1.0):
    """Laptop theo 'Màn hình chuẩn': viền đen bo góc + đế xám; screen là ảnh đã đúng kích thước."""
    if s <= 0.01: return
    sw2, sh2 = sw * s, sh * s; b = 16 * s; tb = 22 * s
    x0, y0 = cx - sw2 / 2 - b, top
    d.rounded_rectangle([x0 + 8, y0 + 12, x0 + sw2 + 2 * b + 8, y0 + sh2 + b + tb + 12], 26 * s, fill=SHADOW)
    d.rounded_rectangle([x0, y0, x0 + sw2 + 2 * b, y0 + sh2 + b + tb], 26 * s, fill=(18, 18, 22))
    sx, sy = int(x0 + b), int(y0 + tb)
    if screen is not None and s > 0.98: img.paste(screen, (sx, sy))
    else: d.rectangle([sx, sy, sx + sw2, sy + sh2], fill=WHITE)
    by = y0 + sh2 + b + tb
    d.rounded_rectangle([x0 - 50 * s, by - 2, x0 + sw2 + 2 * b + 50 * s, by + 22 * s], 10 * s, fill=(150, 154, 162))
    d.rounded_rectangle([cx - 70 * s, by - 2, cx + 70 * s, by + 8 * s], 5 * s, fill=(110, 114, 122))

def phone(img, d, cx, top, sw, sh, screen=None, s=1.0):
    if s <= 0.01: return
    sw2, sh2 = sw * s, sh * s; b = 14 * s
    x0, y0 = cx - sw2 / 2 - b, top
    d.rounded_rectangle([x0 + 8, y0 + 12, x0 + sw2 + 2 * b + 8, y0 + sh2 + 2 * b + 12], 54 * s, fill=SHADOW)
    d.rounded_rectangle([x0, y0, x0 + sw2 + 2 * b, y0 + sh2 + 2 * b], 54 * s, fill=(18, 18, 22))
    sx, sy = int(x0 + b), int(y0 + b)
    if screen is not None and s > 0.98:
        m = Image.new("L", screen.size, 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, screen.size[0] - 1, screen.size[1] - 1], 42, fill=255)
        img.paste(screen, (sx, sy), m)
    else: d.rounded_rectangle([sx, sy, sx + sw2, sy + sh2], 42 * s, fill=WHITE)
    d.rounded_rectangle([cx - 55 * s, sy + 12 * s, cx + 55 * s, sy + 40 * s], 14 * s, fill=(18, 18, 22))

# ---------- Màn hình hệ thống cỡ lớn + nhãn vai trò góc trái ----------
TAG_BG = (98, 110, 132)
def screen(img, d, box, scr, s=1.0):
    """Khung màn hình hệ thống gần full màn: box=(x0, y0, w, h) là vùng hiển thị ảnh quay."""
    if s <= 0.01: return
    x0, y0, w, h = box; cx, cy = x0 + w / 2, y0 + h / 2
    ww, hh = w * s, h * s; b = 10
    d.rounded_rectangle([cx - ww / 2 - b + 8, cy - hh / 2 - b + 12, cx + ww / 2 + b + 8, cy + hh / 2 + b + 12], 22, fill=SHADOW)
    d.rounded_rectangle([cx - ww / 2 - b, cy - hh / 2 - b, cx + ww / 2 + b, cy + hh / 2 + b], 22, fill=(18, 18, 22))
    if scr is not None and s > 0.98: img.paste(scr, (int(x0), int(y0)))
    else: d.rectangle([cx - ww / 2, cy - hh / 2, cx + ww / 2, cy + hh / 2], fill=WHITE)

def role_tag(img, d, idx, label, s=1.0, x=0, bottom=H, h=190):
    """Nhân vật nhỏ + dải nhãn vai trò ở góc trái dưới (theo mẫu 'NGƯỜI DUYỆT CHƯƠNG TRÌNH')."""
    if s <= 0.01: return
    lab = label.upper(); f = font(28, "ExtraBold")
    tw = d.textlength(lab, font=f); w = (tw + 60) * s; th = 48
    char(img, idx, x + 95, bottom - th, h, s)
    yt = bottom - th
    d.polygon([(x, yt), (x + w, yt), (x + w + 18 * s, yt + th / 2), (x + w, bottom), (x, bottom)], fill=TAG_BG)
    if s > 0.6: d.text((x + 20, yt + th / 2), lab, font=font(28 * s, "ExtraBold"), fill=WHITE, anchor="lm")

def chip_bar(d, t, items, x0=260, y=1040, h=56, gap=12, size=24):
    """Dải nhãn nằm dưới đáy màn hình: items = [(thời điểm, nhãn, màu)]; nhãn bật ra theo lời đọc."""
    x = x0
    for st, lab, col in items:
        s_ = pop(t, st, 0.4)
        if s_ <= 0.01: continue
        w = d.textlength(lab, font=font(size, "Bold")) + 44
        pill(d, x + w / 2, y, w, h, col, lab, size, s_)
        x += w + gap

def fullscreen(img, scr, box):
    """Màn hình hệ thống full khung hình (không viền), phần dư tô trắng liền với nền ứng dụng."""
    ImageDraw.Draw(img).rectangle([0, 0, W, H], fill=WHITE)
    if scr is not None: img.paste(scr, (int(box[0]), int(box[1])))

def top_title(d, t, label, start, size=28):
    s_ = pop(t, start, 0.45)
    if s_ <= 0.01: return
    w = d.textlength(label, font=font(size, "ExtraBold")) + 60
    pill(d, W / 2, 40, w, 56, NAVY, label, size, s_, weight="ExtraBold")

def role_badge(img, d, idx, label, cx, bottom, s=1.0, h=200):
    """Nhân vật + dải nhãn vai trò đặt tự do (vd. phía trên cột nội dung nói về vai trò đó)."""
    if s <= 0.01: return
    lab = label.upper(); f = font(28, "ExtraBold"); th = 48
    w = (d.textlength(lab, font=f) + 60) * s
    char(img, idx, cx, bottom - th + 2, h, s)
    x0, yt = cx - w / 2, bottom - th
    d.polygon([(x0, yt), (x0 + w, yt), (x0 + w + 18 * s, yt + th / 2), (x0 + w, bottom), (x0, bottom)], fill=TAG_BG)
    if s > 0.6: d.text((cx + 9 * s, yt + th / 2), lab, font=font(28 * s, "ExtraBold"), fill=WHITE, anchor="mm")

_fsimg = {}
def fs_shot(img, path, box0, box1, k):
    """Ảnh chụp màn hình hệ thống full khung hình, zoom chậm từ box0 tới box1 (box tỉ lệ 16:9)."""
    if path not in _fsimg: _fsimg[path] = Image.open(path).convert("RGB")
    k = ease(clamp(k)); box = tuple(box0[i] + (box1[i] - box0[i]) * k for i in range(4))
    img.paste(_fsimg[path].resize((W, H), Image.LANCZOS, box=box), (0, 0))

def box169(cx, cy, w, iw, ih):
    """Khung 16:9 rộng w quanh (cx, cy), tự đẩy vào trong ảnh iw x ih."""
    h = w * 9 / 16
    if h > ih: h = ih; w = h * 16 / 9
    x0 = min(max(0, cx - w / 2), iw - w); y0 = min(max(0, cy - h / 2), ih - h)
    return (x0, y0, x0 + w, y0 + h)
