"""Khi khách gửi voice SỬA LẠI: so khớp từ của voice cũ và voice mới để ánh xạ thời gian.
from remap_voice import make_maps;  M, Minv = make_maps("words_old.json", "words_new.json")
M(t_cũ) -> t_mới ; Minv(t_mới) -> t_cũ.  Cách an toàn nhất: giữ nguyên các hàm cảnh cũ, bọc
lambda img,d,t: fn(img,d,Minv(t)) và chỉ viết cảnh mới cho đoạn voice thay đổi (xem part62.py, hàm old())."""
import json, bisect, difflib
def make_maps(old_path, new_path):
    wo = json.load(open(old_path)); wn = json.load(open(new_path))
    sm = difflib.SequenceMatcher(a=[w for w, _ in wo], b=[w for w, _ in wn], autojunk=False)
    pairs = sorted((wo[a + k][1], wn[b + k][1]) for a, b, n in sm.get_matching_blocks() for k in range(n))
    xo = [p[0] for p in pairs]; xn = [p[1] for p in pairs]
    def interp(t, xs, ys):
        i = bisect.bisect_left(xs, t)
        if i <= 0: return ys[0] + (t - xs[0])
        if i >= len(xs): return ys[-1] + (t - xs[-1])
        x0, x1, y0, y1 = xs[i - 1], xs[i], ys[i - 1], ys[i]
        return y0 if x1 == x0 else y0 + (t - x0) * (y1 - y0) / (x1 - x0)
    return (lambda t: interp(t, xo, xn)), (lambda t: interp(t, xn, xo))
def diff(old_path, new_path):
    wo = json.load(open(old_path)); wn = json.load(open(new_path))
    sm = difflib.SequenceMatcher(a=[w for w, _ in wo], b=[w for w, _ in wn], autojunk=False)
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op != "equal" and (i2 - i1 > 1 or j2 - j1 > 1):
            print(op, round(wo[min(i1, len(wo) - 1)][1], 1), "->", round(wn[min(j1, len(wn) - 1)][1], 1), "|",
                  " ".join(w for w, _ in wo[i1:i2])[:200], "=>", " ".join(w for w, _ in wn[j1:j2])[:300])
