# HRWs — Quản lý hợp đồng lao động: Mở đầu và tình huống

Bản dựng dựa trên voice và kịch bản do người dùng gửi. Minh họa, thẻ nội dung và nhân vật Haraworks; không mô phỏng giao diện hệ thống.

## Sản phẩm

- outputs/HRWs_Quan_ly_hop_dong_Mo_dau_1080p.mp4: H.264 1920×1080, 30fps, AAC; phụ đề được chèn vào hình và kèm track tiếng Việt.
- outputs/HRWs_intro.vi.srt: phụ đề rời để chỉnh sửa.
- outputs/timeline.json và timeline.csv: 14 phân đoạn, các mốc xuất hiện và voice tương ứng.
- outputs/storyboard.jpg: bố cục tổng thể.
- outputs/qa/: bằng chứng đầu/giữa/cuối từng cảnh, kết quả kiểm tra kỹ thuật và âm thanh.
- inputs/voice.mp3: voice gốc, không sửa nội dung; inputs/script.txt: kịch bản người dùng.
- src/build_video.py: mã dựng và căn phụ đề từ outputs/asr_words.json; src/assets: tư liệu/font từ toolkit.

## Dựng lại

Yêu cầu Python 3.12+, Pillow và NumPy; FFmpeg/FFprobe có libx264 và libass. Không cần ASR để dựng lại với dữ liệu đã lưu.

```bash
cd /đường/dẫn/hrws-video
python src/build_video.py --preview
python src/build_video.py
python src/validate_video.py
```

Nếu cần môi trường Python riêng: `python -m venv --system-site-packages .venv`, rồi dùng `.venv/bin/python` với các lệnh trên. Dependencies được ghi trong requirements.txt.

## Các quyết định và chỉnh sửa đã thực hiện

- Voice giải mã dài 126,29 giây; metadata MP3 báo 121,07 giây. Lấy thời lượng PCM làm chuẩn để không mất câu cuối.
- ASR tiếng Việt dùng sherpa-onnx Zipformer (model vi-int8-2025-04-20). Mốc ASR được hiệu chỉnh +0,18 giây, có đối chiếu điểm bắt đầu âm thanh. Đây là căn theo ASR, không phải nhãn do người nghe gán thủ công từng từ.
- Tên HRWs, Haraworks, C&B và nội dung phụ đề giữ theo kịch bản; không sửa lời trong audio. Các từ không được ASR nhận đúng được nội suy giữa các từ đã khớp.
- Cảnh bắt đầu ở mốc đoạn voice kế tiếp, làm tròn lên khung hình 30fps; chuyển mờ ngắn diễn ra sau ranh giới này.
- Nội dung minh họa xuất hiện theo cụm từ. Không dùng ảnh nghiệp vụ tính lương trong toolkit làm giao diện quản lý hợp đồng.
- Không sửa đè dữ liệu nghiệp vụ. Toàn bộ hình/sơ đồ/thẻ là minh họa mới từ kịch bản; dùng nền, font và nhân vật có sẵn trong toolkit.
- Không thêm SFX vào phần voice liên tục này để tránh che lời hoặc phải chèn khoảng lặng. Voice được mã hóa AAC cho tính tương thích MP4; bản MP3 gốc được giữ riêng.
- Kiểm tra qa_kit theo tọa độ khung đỏ không áp dụng vì không có trường giao diện/khung đỏ trong phần này. Dùng sheet 42 frame và kiểm tra kỹ thuật/đồng bộ âm thanh thay thế, không coi zero-test là kiểm định.

Các file chỉ được tạo cục bộ, chưa tự commit/push lên GitHub. Có thể sửa TITLES/DATA/layout trong src/build_video.py và dựng lại. Khi thay voice hoặc kịch bản phải căn lại ASR/timeline, không dùng mốc cũ.
