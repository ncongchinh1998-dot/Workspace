from pathlib import Path
import subprocess,json,wave,math
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];O=R/'outputs';V=O/'HRWs_Quan_ly_hop_dong_Mo_dau_1080p.mp4';T=json.loads((O/'timeline.json').read_text());Q=O/'qa';Q.mkdir(exist_ok=True)
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(V)]))
v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'])==(1920,1080,'30/1')
assert abs(float(a['duration'])-T['duration'])<.05
assert all(s['start']<s['end'] for s in T['subtitles'])
assert all(x['end']<=y['start']+.001 for x,y in zip(T['subtitles'],T['subtitles'][1:]))
source=' '.join((R/'inputs/script.txt').read_text().split());captions=' '.join(s['text'] for s in T['subtitles']);assert source==captions
subprocess.run(['ffmpeg','-v','error','-i',str(V),'-f','null','-'],check=True,stdout=subprocess.DEVNULL)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(V),'-vn','-ac','1','-ar','16000',str(R/'work/output_audio.wav')],check=True)
def load(p):
 with wave.open(str(p)) as f:return np.frombuffer(f.readframes(f.getnframes()),np.int16).astype(float),f.getframerate()
x,sr=load(R/'work/voice.wav');y,_=load(R/'work/output_audio.wav')
audio=[]
for t in [2,60,120]:
 z=x[int(t*sr):int((t+2)*sr):4];best=(-1,None)
 for lag in range(-40,41):
  st=int(t*sr)+lag*4;b=y[st:st+len(z)*4:4]
  corr=float(np.dot(z,b)/np.sqrt(np.dot(z,z)*np.dot(b,b)))
  if corr>best[0]:best=(corr,lag/4000)
 assert best[0]>.97 and abs(best[1])<.03
 audio.append({'source_time':t,'correlation':best[0],'offset_seconds':best[1]})
for page in range(2):
 sheet=Image.new('RGB',(1440,7*305),'white');d=ImageDraw.Draw(sheet)
 for row,scene in enumerate(T['scenes'][page*7:(page+1)*7]):
  start,end=scene['start'],scene['end'];sample=[start+.45,(start+end)/2,end-.12]
  for col,t in enumerate(sample):
   p=Q/f'scene{scene["scene"]:02}_{col}.jpg'
   subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(V),'-frames:v','1','-vf','scale=480:270',str(p)],check=True)
   with Image.open(p) as im:sheet.paste(im,(col*480,row*305))
   d.text((col*480+8,row*305+278),f'Scene {scene["scene"]:02} | {t:.2f}s',fill='black')
 sheet.save(Q/f'evidence_{page+1}.jpg',quality=92)
report={'result':'passed automated checks; visual evidence requires review','video':{'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'duration':probe['format']['duration'],'frames':v.get('nb_frames')},'source_decoded_duration':T['duration'],'subtitles':len(T['subtitles']),'subtitle_script_exact_match':True,'full_decode':'passed','audio_waveform_checks':audio,'visual_samples':42,'notes':['Audio content and timing retained; encoded AAC for MP4 compatibility. Original MP3 included.','MP3 metadata duration is incorrect; used decoded PCM duration.','No screen recording or system UI fabricated.','No red field highlights in this illustration-only section: toolkit qa_kit field-coordinate checks are not applicable.','No transition sound mixed over continuous narration.','Manual review covers evidence frames, not a complete human listening pass.']}
(Q/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
