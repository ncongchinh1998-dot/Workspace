"""Nhận dạng giọng nói tiếng Việt, xuất mốc thời gian từng từ.
Cách dùng:  python3 asr_words.py <file_voice.wav> <words_out.json>
Cài đặt (1 lần):
  pip install sherpa-onnx --break-system-packages
  cd /tmp && curl -L -O https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-zipformer-vi-int8-2025-04-20.tar.bz2 && tar xjf sherpa-onnx-zipformer-vi-int8-2025-04-20.tar.bz2
Voice gốc nên chuyển sang wav mono 24k/16k trước:  ffmpeg -i voice.wav -ac 1 -ar 24000 assets/voice_pX.wav"""
import sherpa_onnx, wave, numpy as np, json, subprocess, re, sys, os
M = os.environ.get("HRWS_ASR_MODEL_DIR", "/workspace/hrws-reference/sherpa-onnx-zipformer-vi-int8-2025-04-20").rstrip("/") + "/"
rec = sherpa_onnx.OfflineRecognizer.from_transducer(encoder=M + "encoder-epoch-12-avg-8.int8.onnx", decoder=M + "decoder-epoch-12-avg-8.onnx",
    joiner=M + "joiner-epoch-12-avg-8.int8.onnx", tokens=M + "tokens.txt", num_threads=4, decoding_method="greedy_search")
P, OUT = sys.argv[1], sys.argv[2]
w = wave.open(P); sr = w.getframerate(); x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
if sr != 16000:   # mô hình nhận 16k; sherpa tự resample nhưng chia đoạn theo khoảng lặng cho chính xác
    pass
dur = len(x) / sr
o = subprocess.run(["ffmpeg", "-hide_banner", "-i", P, "-af", "silencedetect=noise=-32dB:d=0.45", "-f", "null", "-"], capture_output=True, text=True).stderr
ss = [float(v) for v in re.findall(r"silence_start: ([0-9.]+)", o)]; se = [float(v) for v in re.findall(r"silence_end: ([0-9.]+)", o)]
cuts = [0] + [(a + b) / 2 for a, b in zip(ss, se) if a > 0.5 and b < dur - 0.3] + [dur]
words = []
for a, b in zip(cuts[:-1], cuts[1:]):
    s = rec.create_stream(); s.accept_waveform(sr, x[int(a * sr):int(b * sr)]); rec.decode_stream(s); r = s.result
    for tok, t in zip(r.tokens, r.timestamps):
        if tok.startswith(" ") or not words: words.append([tok.strip().lower(), a + t])
        else: words[-1][0] += tok.lower()
json.dump(words, open(OUT, "w"), ensure_ascii=False)
print(len(words), "từ · thời lượng", round(dur, 2), "s")
