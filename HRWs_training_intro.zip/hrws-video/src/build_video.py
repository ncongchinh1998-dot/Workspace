#!/usr/bin/env python3
"""Rebuild: python src/build_video.py [--preview]. Needs Pillow, FFmpeg and FFprobe.
Uses saved ASR alignment; does not download models or change the original voice.
"""
from pathlib import Path
import json, re, difflib, unicodedata, wave, math, subprocess, sys, csv, hashlib, os
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs'; WORK=ROOT/'work'; A=Path(__file__).parent/'assets'
OUT.mkdir(exist_ok=True); WORK.mkdir(exist_ok=True)
FONTDIR=Path(__file__).parent/'fonts'
FONTDIR.mkdir(exist_ok=True)
import shutil
for fn in ['Montserrat.ttf','Inter.ttf']:shutil.copyfile(A/fn,FONTDIR/fn)
os.environ['XDG_CACHE_HOME']=str(WORK/'cache')
(WORK/'cache').mkdir(exist_ok=True)
W,H,FPS=1920,1080,30
NAVY='#1B2A87'; BLUE='#2B62E8'; CYAN='#00A6F0'; ORANGE='#F28C28'; RED='#F05250'; GREEN='#219653'; INK='#16161E'
words=json.loads((OUT/'asr_words.json').read_text()); words=[[w,min(t+0.18,9999)] for w,t in words]; paragraphs=(ROOT/'inputs/script.txt').read_text().strip().split('\n\n')
voice=ROOT/'inputs/voice.mp3'; wav=WORK/'voice.wav'
subprocess.run(['ffmpeg','-v','error','-y','-i',str(voice),'-ac','1','-ar','16000',str(wav)],check=True)
with wave.open(str(wav)) as f: DUR=f.getnframes()/f.getframerate()
# Audio decode duration is authoritative; the supplied MP3 container reports an incorrect shorter duration.
def norm(s):return ''.join(c for c in unicodedata.normalize('NFD',s.lower()) if c.isalnum())
tokens=[]; ranges=[]
for p in paragraphs:
 st=len(tokens); tokens.extend(p.split()); ranges.append((st,len(tokens)))
x=[norm(t) for t in tokens]; y=[norm(w) for w,t in words]
anchors={}
for block in difflib.SequenceMatcher(None,x,y,autojunk=False).get_matching_blocks():
 for j in range(block.size):anchors[block.a+j]=words[block.b+j][1]
ks=sorted(anchors)
times=[]
for i in range(len(tokens)):
 if i in anchors: times.append(anchors[i]); continue
 lo=max((k for k in ks if k<i),default=None); hi=min((k for k in ks if k>i),default=None)
 if lo is None: t=anchors[hi]*i/max(1,hi)
 elif hi is None:t=anchors[lo]+(DUR-anchors[lo])*(i-lo)/(len(tokens)-lo)
 else:t=anchors[lo]+(anchors[hi]-anchors[lo])*(i-lo)/(hi-lo)
 times.append(t)
# Each scene changes at the next paragraph's spoken onset, never during the previous paragraph.
starts=[0]+[times[a] for a,b in ranges[1:]]; ends=starts[1:]+[DUR]
TITLES=['QUẢN LÝ HỢP ĐỒNG\nLAO ĐỘNG','Từ thiết lập đến báo cáo','Ba vai trò cùng phối hợp','Hiểu tính năng, kết nối dữ liệu','Một tình huống quen thuộc','Nhiều nhân viên • Nhiều lần ký','Khi dữ liệu nằm ở nhiều nơi','Chủ động trước kỳ hết hạn','Nguy cơ bỏ sót thời hạn','Hợp đồng kết nối nghiệp vụ','Từ thử việc sang chính thức','Thay đổi lương và phụ cấp','Thông tin đúng người, đúng quyền','Quản lý hợp đồng toàn diện']
# Every reveal is anchored to an actual recognized phrase, within its own paragraph.
def cue(phrase,scene):
 ws=phrase.split(); a,b=starts[scene],ends[scene]
 for i in range(len(words)-len(ws)+1):
  if a-.1<=words[i][1]<b and [norm(z[0]) for z in words[i:i+len(ws)]]==[norm(z) for z in ws]:return words[i][1]
 raise ValueError(f'Missing cue: {scene} {phrase}')
DATA=[
 [('Chào mừng bạn',0),('Hướng dẫn trên HRWs',cue('trên',0))],
 [('Thiết lập danh mục',cue('thiết lập danh mục',1)),('Tạo mới • Quản lý thay đổi',cue('tạo mới',1)),('Theo dõi thời hạn',cue('theo dõi thời hạn',1)),('Tái ký • Ký kết • Báo cáo',cue('xử lý tái',1))],
 [('C&B',cue('cách',2)+.2),('Quản lý trực tiếp',cue('quản lý trực tiếp',2)),('Nhân viên',cue('nhân viên',2))],
 [('Mục đích tính năng',cue('mục đích',3)),('Ý nghĩa thông tin khai báo',cue('ý nghĩa',3)),('Tính phép • Tính lương • Bảo hiểm',cue('tính phép',3))],
 [('Một tình huống trong công tác',starts[4]),('quản lý hợp đồng lao động',cue('quản lý hợp đồng',4))],
 [('Hàng trăm → hàng nghìn nhân viên',cue('hàng trăm',5)),('Thử việc',cue('thử việc',5)),('Chính thức',cue('chính thức',5)),('Tái ký',cue('tái ký',5)),('Phụ lục điều chỉnh',cue('điều chỉnh',5)-.4)],
 [('Nhiều nguồn dữ liệu',cue('nhiều nguồn',6)),('Tra cứu → Tổng hợp → Đối chiếu',cue('tra cứu',6)),('Loại hợp đồng • Thời hạn',cue('loại hợp đồng',6)),('Mức lương • Phụ cấp',cue('mức lương',6))],
 [('Nhiều hợp đồng sắp hết hạn',cue('nhiều hợp đồng',7)),('C&B kiểm tra danh sách',cue('kiểm tra danh sách',7)),('Phối hợp Quản lý trực tiếp',cue('quản lý trực tiếp',7)),('Đánh giá → Chuẩn bị tái ký',cue('đánh giá',7))],
 [('Theo dõi không kịp thời',cue('theo dõi',8)),('Bỏ sót hợp đồng',cue('bỏ sót',8)),('Xử lý chậm so với thời hạn',cue('xử lý chậm',8))],
 [('DỮ LIỆU HỢP ĐỒNG',cue('thông tin hợp đồng',9)),('Liên quan nhiều nghiệp vụ nhân sự',cue('nhiều nghiệp vụ',9))],
 [('Thử việc → Chính thức',cue('thử việc',10)),('Loại hợp đồng + Ngày hiệu lực',cue('loại hợp đồng',10)),('Kiểm tra thời điểm cộng phép',cue('thời điểm cộng phép',10))],
 [('Điều chỉnh lương / phụ cấp',cue('điều chỉnh',11)),('C&B cập nhật và đối chiếu',cue('cập nhật',11)),('Dữ liệu chính xác để tính lương',cue('dữ liệu',11))],
 [('Mức lương • Phụ cấp • Điều khoản',cue('mức lương',12)),('Kiểm soát quyền truy cập',cue('kiểm soát',12)),('Phù hợp trách nhiệm từng vai trò',cue('trách nhiệm',12))],
 [('Lưu trữ hồ sơ',cue('lưu trữ hồ sơ',13)),('Theo dõi thời hạn',cue('theo dõi thời hạn',13)),('Kiểm soát thay đổi',cue('kiểm soát thay đổi',13)),('Liên kết dữ liệu nghiệp vụ',cue('liên kết',13)),('Phối hợp đúng thời điểm',cue('phối hợp',13))]
]
# Subtitle text follows the supplied script; ASR only supplies timing. Align missing proper names by neighboring words.
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
subs=[]
for a,b in ranges:
 i=a
 while i<b:
  j=min(i+11,b)
  # Prefer a punctuation boundary after at least five words.
  for k in range(i+5,j+1):
   if tokens[k-1].endswith((',', '.', '!', '?', ';')): j=k;break
  start=times[i];end=min(times[j] if j<len(times) else DUR,ends[next(n for n,(aa,bb) in enumerate(ranges) if aa==a)])
  text=' '.join(tokens[i:j]); subs.append({'start':start,'end':end,'text':text});i=j
(OUT/'HRWs_intro.vi.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(s["start"])} --> {stamp(s["end"])}\n{s["text"]}' for i,s in enumerate(subs))+'\n',encoding='utf-8')
timeline=[]
for i,(a,b) in enumerate(zip(starts,ends)):
 timeline.append({'scene':i+1,'start':a,'end':b,'title':TITLES[i].replace('\n',' '),'voice':paragraphs[i],'visual':'Minh họa; không phải giao diện hệ thống','reveals':[{'text':txt,'time':t} for txt,t in DATA[i]]})
(OUT/'timeline.json').write_text(json.dumps({'fps':FPS,'duration':DUR,'original_voice_sha256':hashlib.sha256(voice.read_bytes()).hexdigest(),'scenes':timeline,'subtitles':subs},ensure_ascii=False,indent=2))
with (OUT/'timeline.csv').open('w',newline='',encoding='utf-8-sig') as f:
 wr=csv.writer(f);wr.writerow(['scene','start','end','title','voice']);wr.writerows([[s[k] for k in ['scene','start','end','title','voice']] for s in timeline])
fonts={}
def font(n,bold=True):
 key=n,bold
 if key not in fonts:
  f=ImageFont.truetype(str(A/'Montserrat.ttf'),n);f.set_variation_by_name('ExtraBold' if bold else 'Medium');fonts[key]=f
 return fonts[key]
def text(d,pos,s,n=36,fill=INK,anchor='mm',bold=True):d.multiline_text(pos,s,font=font(n,bold),fill=fill,anchor=anchor,align='center',spacing=12)
def fit(d,s,n,width):
 while d.textbbox((0,0),s,font=font(n))[2]>width:n-=1
 return n
def card(d,box,label,color=BLUE,active=False):
 x0,y0,x1,y1=box
 d.rounded_rectangle((x0+5,y0+8,x1+5,y1+8),24,fill='#CCD7ED')
 d.rounded_rectangle(box,24,fill='white',outline=color,width=5 if active else 3)
 text(d,((x0+x1)/2,(y0+y1)/2),label,fit(d,label,34,x1-x0-52),color)
def character(im,idx,x,y,h):
 c=Image.open(A/f'p{idx}.png').convert('RGBA');c=c.resize((round(c.width*h/c.height),h),Image.Resampling.LANCZOS);im.paste(c,(int(x-c.width/2),int(y-h)),c)
def draw_scene(i,count):
 im=Image.open(A/'bg-1.png').convert('RGB').resize((W,H));d=ImageDraw.Draw(im)
 # Branded board decoration, outside the teaching and subtitle zones.
 d.polygon([(1720,0),(1920,0),(1920,300)],fill=BLUE);d.polygon([(1840,0),(1920,0),(1920,550),(1870,510)],fill=CYAN)
 d.rounded_rectangle((95,148,470,201),26,fill=BLUE)
 text(d,(282,174),'QUẢN LÝ HỢP ĐỒNG',23,'white')
 d.line((95,335,1825,335),fill='#C0CCE4',width=2)
 text(d,(960,270),TITLES[i],64 if i==0 else 49,NAVY)
 visible=DATA[i][:count]
 if i==0:
  character(im,2,1470,875,430)
  text(d,(705,510),'HRWs',110,BLUE)
  text(d,(705,640),'Quy trình • Vai trò • Dữ liệu',37,NAVY)
  for k,(s,t) in enumerate(visible):text(d,(705,735+k*65),s,31,INK,bold=False)
 elif i==2:
  for k,(s,t) in enumerate(visible):
   cx=420+k*540; character(im,[2,6,4][k],cx,745,330);card(d,(cx-225,770,cx+225,860),s,[BLUE,ORANGE,GREEN][k],True)
 else:
  if i in [4,9]:
   for k,(s,t) in enumerate(visible):card(d,(310,460+k*170,1610,585+k*170),s,BLUE,k==count-1)
  else:
   n=len(DATA[i]);cols=2 if n!=3 else 3
   cw=780 if cols==2 else 510;gap=45;left=(W-(cols*cw+(cols-1)*gap))/2
   rows=math.ceil(n/cols);ch=125 if rows==3 else 155;top=405
   for k,(s,t) in enumerate(visible):
    row,col=divmod(k,cols);xx=left+col*(cw+gap)
    if row==rows-1 and n%cols==1:xx=(W-cw)/2
    yy=top+row*(ch+38)
    card(d,(xx,yy,xx+cw,yy+ch),s,[BLUE,GREEN,ORANGE,BLUE,CYAN][k%5],k==count-1)
  if i in [3,8,10,11,12] and count:
   # Linked nodes reinforce the spoken relationships without inventing UI.
   colors=[BLUE,GREEN,ORANGE];centers=[420,960,1500]
   for k in range(min(count,3)):
    cx=centers[k];cy=740;col=colors[k]
    if k:
     d.line((centers[k-1]+75,cy,cx-75,cy),fill='#A4B6D8',width=5)
     d.polygon([(cx-78,cy-10),(cx-62,cy),(cx-78,cy+10)],fill=col)
    d.ellipse((cx-62,cy-62,cx+62,cy+62),fill='white',outline=col,width=5)
    if i==12 and k==1:
     d.arc((cx-20,cy-34,cx+20,cy+10),180,360,fill=col,width=6)
     d.rounded_rectangle((cx-28,cy-5,cx+28,cy+35),7,fill=col)
     d.ellipse((cx-4,cy+7,cx+4,cy+15),fill='white')
    elif (i==10 and k==2) or i==8:
     d.rounded_rectangle((cx-31,cy-29,cx+31,cy+30),6,outline=col,width=5)
     d.line((cx-30,cy-12,cx+30,cy-12),fill=col,width=4)
     if i==8:text(d,(cx,cy+9),'!',28,col)
     else:d.line((cx-13,cy+7,cx-3,cy+17,cx+17,cy-3),fill=col,width=5)
    else:
     d.rounded_rectangle((cx-25,cy-35,cx+25,cy+35),6,outline=col,width=4)
     for dy in [-13,0,13]: d.line((cx-14,cy+dy,cx+14,cy+dy),fill=col,width=3)
  if i not in [4,9] and len(DATA[i])<=4:
   character(im,2,145,883,135)
   text(d,(145,909),'C&B',22,NAVY)
 # Reserve bottom 130px for captions; avoids collision with chips/characters.
 d.rectangle((0,950,W,H),fill='#101B45')
 text(d,(1790,913),f'{i+1:02} / 14',22,NAVY,bold=False)
 return im
# Timeline on the 30fps grid: use ceil so a scene cannot enter before the spoken onset.
events=[]
for i in range(len(starts)):
 events.append((math.ceil(starts[i]*FPS),i,0))
 for k,(txt,t) in enumerate(DATA[i]):events.append((math.ceil(max(starts[i],t)*FPS),i,k+1))
# Last event at a timestamp wins (e.g. introductory reveal at scene start).
events=sorted({f:(f,i,c) for f,i,c in events}.values())
if '--preview' in sys.argv:
 sheet=Image.new('RGB',(1280,math.ceil(len(starts)/2)*400),'#eeeeee');sd=ImageDraw.Draw(sheet)
 for i in range(len(starts)):
  pic=draw_scene(i,len(DATA[i]));pic.thumbnail((640,360)); xx=(i%2)*640;yy=(i//2)*400;sheet.paste(pic,(xx,yy));sd.text((xx+12,yy+365),f'{i+1:02}  {starts[i]:.2f} - {ends[i]:.2f}s',fill='black')
 sheet.save(OUT/'storyboard.jpg',quality=92)
 print('Preview, timeline and subtitles saved',flush=True);sys.exit()
cmd=['ffmpeg','-hide_banner','-loglevel','warning','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1920x1080','-r','30','-i','-','-i',str(wav),'-i',str(OUT/'HRWs_intro.vi.srt'),'-vf',f"subtitles='{OUT/'HRWs_intro.vi.srt'}':fontsdir='{FONTDIR}':force_style='FontName=Montserrat,FontSize=12,PrimaryColour=&H00FFFFFF,Outline=0,Shadow=0,MarginV=10,Alignment=2'",'-map','0:v:0','-map','1:a:0','-map','2:s:0','-c:v','libx264','-preset','veryfast','-crf','19','-threads','3','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-c:s','mov_text','-metadata:s:s:0','language=vie','-t',str(DUR),'-movflags','+faststart',str(OUT/'HRWs_Quan_ly_hop_dong_Mo_dau_1080p.mp4')]
pr=subprocess.Popen(cmd,stdin=subprocess.PIPE);idx=0;current=None;prev=None;buf=None;event_frame=0
try:
 for f in range(math.ceil(DUR*FPS)):
  if idx<len(events) and f>=events[idx][0]:
   _,i,c=events[idx];prev=current;current=draw_scene(i,c);buf=current.tobytes();event_frame=f;idx+=1
  if prev is not None and f-event_frame<6:
   frame=Image.blend(prev,current,(f-event_frame+1)/6).tobytes()
  else:frame=buf
  pr.stdin.write(frame)
  if f%900==0: print(f'Render {f/FPS:.0f}/{DUR:.2f}s',flush=True)
 pr.stdin.close();rc=pr.wait()
 if rc:raise RuntimeError(f'FFmpeg exit {rc}')
except BaseException:
 pr.kill();raise
print('Video complete',flush=True)
